import { RootSetTestSupport, RootPayload, RootHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/rootset/RootSetTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class ThreadLocalRootTest extends RootSetTestSupport {
    rsE01_mainThreadThreadLocalKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE02_mainThreadThreadLocalClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE03_mainThreadThreadLocalReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE04_threadLocalHolderRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE05_threadLocalChildGraphRootKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE06_threadLocalListRootKeepsElementAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE07_workerThreadLocalKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE08_threadLocalValuesAreIsolatedBetweenMainAndWorker() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE09_workerThreadLocalClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE10_clearingMainThreadLocalDoesNotAffectWorkerThreadLocal() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE11_multipleWorkersEachHaveThreadLocalRoots() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE12_workerThreadExitRemovesThreadLocalRoot() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE13_threadLocalNullableNonNullKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsE14_threadLocalAnyAndInterfaceRootsKeepRuntimeObjectsAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
