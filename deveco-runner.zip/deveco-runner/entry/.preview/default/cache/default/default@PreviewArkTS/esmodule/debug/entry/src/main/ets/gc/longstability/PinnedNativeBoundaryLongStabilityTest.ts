import { LongStabilityTestSupport, PinnedLike, SHORT_ITERATIONS, MEDIUM_BYTES, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
import { assertEquals, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class PinnedNativeBoundaryLongStabilityTest extends LongStabilityTestSupport {
    ls_k01_repeatUsepinnedNormal() {
        assertEquals(SHORT_ITERATIONS, this.pinnedLikeLoop());
    }
    ls_k02_repeatUsepinnedException() {
        assertEquals(SHORT_ITERATIONS, this.pinnedLikeLoop(SHORT_ITERATIONS, true));
    }
    ls_k03_pinnedWithGcLoop() {
        assertTrue(this.pinnedLikeLoop(16) > 0);
    }
    ls_k04_pinnedWithAllocationPressure() {
        let count = 0;
        for (let i = 0; i < 16; i++) {
            const bytes = new Array(MEDIUM_BYTES).fill(0);
            PinnedLike.use(bytes, array => { array[0] = i; this.allocateMediumBatch(4); count++; });
        }
        assertEquals(16, count);
    }
    ls_k05_nestedUsepinnedLoop() {
        for (let i = 0; i < 16; i++)
            PinnedLike.use(new Array(128).fill(0), first => PinnedLike.use(new Array(128).fill(0), second => { first[0] = i; second[0] = i + 1; }));
        assertTrue(true);
    }
    ls_k06_multiplePinnedArrays() {
        for (let i = 0; i < 16; i++)
            Array.from({ length: 4 }, () => new Array(128).fill(0)).forEach(bytes => PinnedLike.use(bytes, array => { array[0] = i; }));
        assertTrue(true);
    }
    ls_k07_manualPinUnpinLikeLoop() {
        for (let index = 0; index < 16; index++) {
            const bytes = new Array(128).fill(0);
            bytes[0] = index;
            assertEquals(index, bytes[0]);
        }
    }
    ls_k08_nativeLikePointerReadWrite() {
        const helper = (bytes: number[], value: number) => { PinnedLike.use(bytes, array => { array[0] = value; }); };
        for (let i = 0; i < 16; i++) {
            const bytes = new Array(8).fill(0);
            helper(bytes, i);
            assertEquals(i, bytes[0]);
        }
    }
    ls_k09_nativeLikeCallbackChurn() {
        for (let i = 0; i < 16; i++) {
            const callback = (bytes: number[]) => { bytes[0] = i; return bytes[0]; };
            assertEquals(i, callback(new Array(8).fill(0)));
        }
    }
    ls_k10_pinnedBoundaryMixedStress() {
        const weak = new WeakReference(new Array(128).fill(0));
        this.pinnedLikeLoop(8);
        assertTrue(weak.value === null || weak.value.length > 0);
    }
}
