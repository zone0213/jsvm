import { assertEquals, assertNotNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
import { buildSharedGraph, forceGc, runGcAroundMutation, publishChain, publishCycle, publishField, publishTree, Holder, Node, WeakReference, LambdaHolder, Box, setGlobalNode, getGlobalNode, setThreadLocalNode, getThreadLocalNode, globalHolder, stressFieldReplacement, } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class ConcurrentStrongPublishTest {
    cgB01_publishNormalFieldDuringGc() {
        forceGc();
        const [holder, weak] = publishField(201);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }
    cgB02_publishNullableFieldDuringGc() {
        const holder = new Holder<Node>(null);
        const node = new Node(202);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { holder.ref = node; });
        assertEquals(202, holder.ref!.id);
        assertNotNull(weak.value);
    }
    cgB03_publishLeftRightFieldsDuringGc() {
        const root = new Node(203);
        const left = new Node(204);
        const right = new Node(205);
        const weakLeft = new WeakReference(left);
        const weakRight = new WeakReference(right);
        runGcAroundMutation(() => { root.left = left; root.right = right; });
        assertEquals(204, root.left!.id);
        assertEquals(205, root.right!.id);
        assertNotNull(weakLeft.value);
        assertNotNull(weakRight.value);
    }
    cgB04_publishNewChainDuringGc() {
        forceGc();
        const [holder, weaks] = publishChain(206);
        forceGc();
        weaks.forEach((weak, i) => assertNotNull(weak.value, `Expected weak[${i}] to remain alive.`));
        assertNotNull(holder.ref);
    }
    cgB05_publishNewTreeDuringGc() {
        forceGc();
        const [holder, weaks] = publishTree(220);
        forceGc();
        weaks.forEach((weak, i) => assertNotNull(weak.value, `Expected weak[${i}] to remain alive.`));
        assertNotNull(holder.ref);
    }
    cgB06_publishNewCycleDuringGc() {
        forceGc();
        const [holder, weaks] = publishCycle(230);
        forceGc();
        weaks.forEach((weak, i) => assertNotNull(weak.value, `Expected weak[${i}] to remain alive.`));
        assertNotNull(holder.ref);
    }
    cgB07_publishPreviouslyWeakOnlyObjectDuringGc() {
        const holder = new Holder<Node>(null);
        const node = new Node(240);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { holder.ref = node; });
        assertEquals(240, holder.ref!.id);
        assertNotNull(weak.value);
    }
    cgB08_publishSharedSubgraphDuringGc() {
        const graph = buildSharedGraph(250);
        const weak = new WeakReference(graph.shared);
        runGcAroundMutation(() => {
            globalHolder.ref = graph.parent1;
            graph.parent1.right = graph.parent2;
        });
        assertEquals(252, graph.parent1.left!.id);
        assertEquals(252, graph.parent2.left!.id);
        assertNotNull(weak.value);
    }
    cgB09_publishLambdaCaptureDuringGc() {
        const node = new Node(260);
        const weak = new WeakReference(node);
        const holder = new LambdaHolder(null);
        runGcAroundMutation(() => { holder.block = () => node.id; });
        assertEquals(260, holder.block!());
        assertNotNull(weak.value);
    }
    cgB10_publishGenericBoxValueDuringGc() {
        const box = new Box<Node>(null);
        const node = new Node(270);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { box.value = node; });
        assertEquals(270, box.value!.id);
        assertNotNull(weak.value);
    }
    cgB11_publishGlobalObjectDuringGc() {
        const node = new Node(280);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { setGlobalNode(node); });
        assertEquals(280, getGlobalNode()!.id);
        assertNotNull(weak.value);
    }
    cgB12_publishThreadLocalObjectDuringGc() {
        const node = new Node(290);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { setThreadLocalNode(node); });
        assertEquals(290, getThreadLocalNode()!.id);
        assertNotNull(weak.value);
    }
    cgB13_producerConsumerPublishDuringGc() {
        const shared = new Holder<Node>(null);
        const produced = new Node(300);
        const weak = new WeakReference(produced);
        runGcAroundMutation(() => { shared.ref = produced; });
        const consumed = shared.ref;
        assertEquals(300, consumed!.id);
        assertNotNull(weak.value);
    }
    cgB14_repeatedStrongPublishAcrossGc() {
        forceGc();
        const [holder, weak] = stressFieldReplacement(32);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }
}
