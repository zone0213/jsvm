import { GC, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class SweepAllocatorTestSupport {
    protected forceGc() {
        for (let i = 0; i < 3; i++) {
            GC.collect();
        }
    }
    protected weakCheck(obj: any): WeakReference<any> | null {
        return obj != null ? new WeakReference(obj) : null;
    }
}
