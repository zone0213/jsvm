import { LongStabilityTestSupport, LsNode, LargePayload, Holder, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
import { assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class WeakProcessingLongStabilityTest extends LongStabilityTestSupport {
    ls_i01_manyWeakSameTargetAlive() {
        const target = new LsNode(1);
        const weaks = Array.from({ length: 256 }, () => new WeakReference(target));
        this.forceGc();
        assertTrue(weaks.every(it => it.value === target));
    }
    ls_i02_manyWeakSameTargetReleased() {
        const weaks = (() => { const target = new LsNode(2); return Array.from({ length: 256 }, () => new WeakReference(target)); })();
        this.assertAllWeakCollectedEventually(weaks);
    }
    ls_i03_oneWeakPerShortLivedObject() {
        const weaks = Array.from({ length: 256 }, (_, it) => new WeakReference(new LsNode(it)));
        this.assertAllWeakCollectedEventually(weaks);
    }
    ls_i04_partialStrongWeakBatch() {
        const roots: LsNode[] = [];
        const alive: WeakReference<LsNode>[] = [];
        const dead: WeakReference<LsNode>[] = [];
        for (let i = 0; i < 64; i++) {
            const node = new LsNode(i);
            const weak = new WeakReference(node);
            if (i % 2 === 0) {
                roots.push(node);
                alive.push(weak);
            }
            else {
                dead.push(weak);
            }
        }
        this.forceGc();
        assertTrue(alive.every(it => it.value !== null));
        this.assertAllWeakCollectedEventually(dead);
    }
    ls_i05_weakListChurn() {
        const list: WeakReference<LsNode>[] = [];
        this.containerSamples(i => { const node = new LsNode(i); list.push(new WeakReference(node)); if (list.length > 64)
            list.shift(); });
        assertTrue(list.length <= 64);
    }
    ls_i06_weakMapChurn() {
        const map = new Map<number, WeakReference<LsNode>>();
        this.containerSamples(i => { const node = new LsNode(i); map.set(i, new WeakReference(node)); map.delete(i - 64); });
        assertTrue(map.size <= 64);
    }
    ls_i07_toggleStrongRoot() {
        const holder = new Holder<LsNode | null>(null);
        let weak: WeakReference<LsNode> | null = null;
        this.containerSamples(i => { holder.ref = i % 2 === 0 ? new LsNode(i) : null; if (holder.ref !== null)
            weak = new WeakReference(holder.ref); });
        assertTrue(weak === null || weak.value === null || weak.value.id >= 0);
    }
    ls_i08_weakWithMemoryPressure() {
        const weaks: WeakReference<LsNode>[] = [];
        for (let i = 0; i < 32; i++) {
            const node = new LsNode(i);
            weaks.push(new WeakReference(node));
            new LargePayload(i, new Array(1024).fill(0));
        }
        this.forceGc();
        assertTrue(weaks.every(it => it.value === null || it.value.id >= 0));
    }
    ls_i09_weakCoroutineLikeCompletion() {
        const weaks = this.coroutineLikeBatch(16);
        this.assertAllWeakCollectedEventually(weaks);
    }
    ls_i10_weakProcessingRegressionLoop() {
        const roots: LsNode[] = [];
        const weaks: WeakReference<LsNode>[] = [];
        for (let i = 0; i < 32; i++) {
            const node = new LsNode(i);
            roots.push(node);
            weaks.push(new WeakReference(node));
        }
        roots.length = 0;
        this.forceGc();
        assertTrue(weaks.every(it => it.value === null || it.value.id >= 0));
    }
}
