// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, WeakHolder, Box, Root, WeakOnlyResult, globalWeak, setGlobalWeak, ObjectStrongWeakHolder } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/strongweak/WeakReferenceTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertNotNull, assertNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * WR-B group: WeakReference-only cases.
 */
export class WeakOnlyReachabilityTest extends WeakReferenceTestSupport {
    createLocalWeakOnly() {
        const obj = new Payload(201);
        return new WeakReference(obj);
    }
    /**
     * WR-B01
     * Scenario: only a local WeakReference escapes from helper.
     * Expectation: the target object can be collected.
     */
    wrB01_localWeakOnlyDoesNotKeepTargetAlive() {
        const weak = this.createLocalWeakOnly();
        this.assertWeakCollected(weak);
    }
    createWeakHolderOnly() {
        const obj = new Payload(202);
        const holder = new WeakHolder(new WeakReference(obj));
        return new WeakOnlyResult(new Root(holder), holder.weak);
    }
    /**
     * WR-B02
     * Scenario: root strongly holds WeakHolder, and WeakHolder only weakly points to target.
     * Expectation: holder remains reachable, but target can be collected.
     */
    wrB02_holderWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createWeakHolderOnly();
        this.forceGc();
        assertNotNull(scenario.root.ref);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createGlobalWeakOnly() {
        const obj = new Payload(203);
        setGlobalWeak(new WeakReference(obj));
        return globalWeak;
    }
    /**
     * WR-B03
     * Scenario: a global variable holds only WeakReference to target.
     * Expectation: the global WeakReference object survives, but its target can be collected.
     */
    wrB03_globalWeakOnlyDoesNotKeepTargetAlive() {
        const weak = this.createGlobalWeakOnly();
        this.forceGc();
        assertNotNull(globalWeak);
        weak.clear();
        assertNull(weak.value);
    }
    createObjectWeakOnly() {
        const obj = new Payload(204);
        ObjectStrongWeakHolder.weak = new WeakReference(obj);
        return ObjectStrongWeakHolder.weak;
    }
    /**
     * WR-B04
     * Scenario: an object singleton holds only WeakReference to target.
     * Expectation: the target can be collected.
     */
    wrB04_objectWeakOnlyDoesNotKeepTargetAlive() {
        const weak = this.createObjectWeakOnly();
        this.forceGc();
        assertNotNull(ObjectStrongWeakHolder.weak);
        weak.clear();
        assertNull(weak.value);
    }
    createWeakListOnly() {
        const obj = new Payload(205);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root([weak]), weak);
    }
    /**
     * WR-B05
     * Scenario: a list strongly holds WeakReference, but no strong reference holds target.
     * Expectation: target can be collected.
     */
    wrB05_listWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createWeakListOnly();
        this.forceGc();
        assertNotNull(scenario.root.ref.single());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createWeakArrayOnly() {
        const obj = new Payload(206);
        const weak = new WeakReference(obj);
        const array = new Array(1).fill(null);
        array[0] = weak;
        return new WeakOnlyResult(new Root(array), weak);
    }
    /**
     * WR-B06
     * Scenario: an array strongly holds WeakReference, but no strong reference holds target.
     * Expectation: target can be collected.
     */
    wrB06_arrayWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createWeakArrayOnly();
        this.forceGc();
        assertNotNull(scenario.root.ref[0]);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createWeakMapValueOnly() {
        const obj = new Payload(207);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Map([["target", weak]])), weak);
    }
    /**
     * WR-B07
     * Scenario: a map value strongly holds WeakReference.
     * Expectation: target can be collected.
     */
    wrB07_mapValueWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createWeakMapValueOnly();
        this.forceGc();
        assertNotNull(scenario.root.ref.get("target"));
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createWeakMapKeyOnly() {
        const obj = new Payload(208);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Map([[weak, "metadata"]])), weak);
    }
    /**
     * WR-B08
     * Scenario: a map key is a WeakReference object.
     * Expectation: the key object remains in the map, but its target can be collected.
     */
    wrB08_mapKeyWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createWeakMapKeyOnly();
        this.forceGc();
        assertNotNull(Array.from(scenario.root.ref.keys()).single());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createGenericBoxWeakOnly() {
        const obj = new Payload(209);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Box(weak)), weak);
    }
    /**
     * WR-B09
     * Scenario: a generic Box holds only WeakReference to target.
     * Expectation: target can be collected.
     */
    wrB09_genericBoxWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createGenericBoxWeakOnly();
        this.forceGc();
        assertNotNull(scenario.root.ref.value);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createLambdaCapturingWeakOnly() {
        const obj = new Payload(210);
        const weak = new WeakReference(obj);
        const block = () => weak.value?.id;
        return new WeakOnlyResult(new Root(block), weak);
    }
    /**
     * WR-B10
     * Scenario: a lambda captures WeakReference, but not the target itself.
     * Expectation: target can be collected.
     */
    wrB10_lambdaCapturingWeakOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createLambdaCapturingWeakOnly();
        this.forceGc();
        scenario.weak.clear();
        assertNull(scenario.root.ref());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createAnyWeakOnly() {
        const obj = new Payload(211);
        return new WeakReference(obj);
    }
    /**
     * WR-B11
     * Scenario: only WeakReference<Any> points to a Payload runtime object.
     * Expectation: target can be collected.
     */
    wrB11_weakOnlyAnyTypedTargetCanBeCollected() {
        const weak = this.createAnyWeakOnly();
        this.assertWeakCollected(weak);
    }
    createInterfaceWeakOnly() {
        const obj = new MarkerPayload(212);
        return new WeakReference(obj);
    }
    /**
     * WR-B12
     * Scenario: only WeakReference<Marker> points to an interface-typed target.
     * Expectation: target can be collected.
     */
    wrB12_weakOnlyInterfaceTypedTargetCanBeCollected() {
        const weak = this.createInterfaceWeakOnly();
        this.assertWeakCollected(weak);
    }
}
//# sourceMappingURL=WeakOnlyReachabilityTest.js.map