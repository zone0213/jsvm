import { LongStabilityTestSupport, LsNode, LargePayload, MixedPayload, WORKER_COUNT, SAMPLE_EVERY, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
import { assertEquals, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class MultiThreadGcLongStabilityTest extends LongStabilityTestSupport {
    ls_g01_multiThreadSmallChurn() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => new LsNode(i)));
    }
    ls_g02_multiThreadLargeChurn() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => new LargePayload(i, new Array(1024).fill(0))));
    }
    ls_g03_multiThreadMixedChurn() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((worker, i) => new MixedPayload(worker * 1000 + i)));
    }
    ls_g04_multiThreadLongLivedRoots() {
        const roots: LsNode[] = [];
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((worker, i) => { if (i === 0)
            roots.push(new LsNode(worker)); new LsNode(i); }));
        assertEquals(WORKER_COUNT, roots.length);
    }
    ls_g05_workerExitReleasesObjects() {
        const weak = (() => { const node = new LsNode(5); return new WeakReference(node); })();
        this.assertWeakCollectedEventually(weak);
    }
    ls_g06_gcThreadWithMutatorProgress() {
        let progress = 0;
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => { progress += i >= 0 ? 1 : 0; }));
        assertTrue(progress > 0);
    }
    ls_g07_eachWorkerRunsGc() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((worker, i) => { if (i % SAMPLE_EVERY === 0)
            this.forceGc(1); new LsNode(worker * 100 + i); }));
    }
    ls_g08_mainSamplesGcinfoWhileWorkersRun() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => { if (i % 2 === 0)
            this.assertGcInfoReadable(); }));
    }
    ls_g09_multiThreadSpike() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => new LargePayload(i, new Array(2048).fill(0))));
    }
    ls_g10_multiThreadReleaseReallocate() {
        assertEquals(WORKER_COUNT, this.runPseudoWorkers((_worker, i) => { const list: LsNode[] = []; list.push(new LsNode(i)); list.length = 0; }));
    }
}
