if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    status?: string;
    detail?: string;
    running?: boolean;
}
import { runAllGcTests } from "@bundle:com.example.gcreachabilityrunner/entry/ets/GcTestRunner";
import type { GcTestSummary } from "@bundle:com.example.gcreachabilityrunner/entry/ets/GcTestRunner";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__status = new ObservedPropertySimplePU('Ready', this, "status");
        this.__detail = new ObservedPropertySimplePU('Tap Run All Tests to execute the converted ArkTS GC tests.', this, "detail");
        this.__running = new ObservedPropertySimplePU(false, this, "running");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.status !== undefined) {
            this.status = params.status;
        }
        if (params.detail !== undefined) {
            this.detail = params.detail;
        }
        if (params.running !== undefined) {
            this.running = params.running;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__status.purgeDependencyOnElmtId(rmElmtId);
        this.__detail.purgeDependencyOnElmtId(rmElmtId);
        this.__running.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__status.aboutToBeDeleted();
        this.__detail.aboutToBeDeleted();
        this.__running.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __status: ObservedPropertySimplePU<string>;
    get status() {
        return this.__status.get();
    }
    set status(newValue: string) {
        this.__status.set(newValue);
    }
    private __detail: ObservedPropertySimplePU<string>;
    get detail() {
        return this.__detail.get();
    }
    set detail(newValue: string) {
        this.__detail.set(newValue);
    }
    private __running: ObservedPropertySimplePU<boolean>;
    get running() {
        return this.__running.get();
    }
    set running(newValue: boolean) {
        this.__running.set(newValue);
    }
    private formatSummary(summary: GcTestSummary, elapsedMs: number): string {
        if (summary.failed === 0) {
            return 'Passed ' + summary.passed + ' tests in ' + summary.classes + ' classes. Elapsed: ' + elapsedMs + ' ms.';
        }
        let lines: string[] = [];
        lines.push('Passed ' + summary.passed + ', failed ' + summary.failed + ', classes ' + summary.classes + '.');
        const shown = summary.failures.slice(0, 20);
        for (const failure of shown) {
            lines.push(failure.suite + ' ' + failure.test + ': ' + failure.message);
        }
        if (summary.failures.length > shown.length) {
            lines.push('More failures omitted: ' + (summary.failures.length - shown.length));
        }
        return lines.join('\n');
    }
    private async runTests(): Promise<void> {
        if (this.running)
            return;
        this.running = true;
        this.status = 'Running';
        this.detail = 'Executing tests on device...';
        const started = Date.now();
        try {
            const summary = await runAllGcTests();
            const elapsedMs = Date.now() - started;
            this.status = summary.failed === 0 ? 'Passed' : 'Failed';
            this.detail = this.formatSummary(summary, elapsedMs);
        }
        catch (error) {
            this.status = 'Runner Error';
            this.detail = String(error);
        }
        finally {
            this.running = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(48:5)", "entry");
            Row.width('100%');
            Row.height('100%');
            Row.backgroundColor('#F7F8FA');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(49:7)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(50:9)", "entry");
            Column.width('100%');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('GC Reachability ArkTS Tests');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(51:11)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.status);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(56:11)", "entry");
            Text.fontSize(18);
            Text.fontColor(this.status === 'Passed' ? '#0A7F42' : this.status === 'Failed' || this.status === 'Runner Error' ? '#B42318' : '#344054');
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.running ? 'Running...' : 'Run All Tests');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(61:11)", "entry");
            Button.enabled(!this.running);
            Button.width('100%');
            Button.height(44);
            Button.onClick(() => {
                this.runTests();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.detail);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(69:11)", "entry");
            Text.fontSize(13);
            Text.fontColor('#101828');
            Text.width('100%');
            Text.padding(12);
            Text.backgroundColor('#FFFFFF');
            Text.borderRadius(8);
        }, Text);
        Text.pop();
        Column.pop();
        Scroll.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.gcreachabilityrunner", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
