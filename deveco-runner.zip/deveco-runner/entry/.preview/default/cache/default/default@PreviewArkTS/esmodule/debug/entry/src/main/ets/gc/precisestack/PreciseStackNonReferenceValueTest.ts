import { PreciseStackTestSupport, StackPayload, StackHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/precisestack/PreciseStackTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class PreciseStackNonReferenceValueTest extends PreciseStackTestSupport {
    psE01_longValuesDoNotRetainDeadReference() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psE02_ulongValuesDoNotRetainDeadReference() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psE03_mixedPrimitiveLocalsDoNotRetainDeadReference() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psE04_liveReferenceSurvivesAmongPrimitiveLocals() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psE05_clearedAnySlotIsNotRetainedByPrimitiveLocals() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
