import { GraphTopologyTestSupport, GraphRoot, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/graphtopology/GraphTopologyTestSupport";
import { assertEquals, assertNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
/** GT-H group: container-backed graph tests. */
export class ContainerGraphTest extends GraphTopologyTestSupport {
    /** GT-H01: Array refs can carry a chain-shaped graph. */
    gtH01_arrayBackedChainKeepsTailAlive() {
        const head = new ArrayNode(16000, 1);
        const mid = new ArrayNode(16001, 1);
        const tail = new ArrayNode(16002, 0);
        head.refs[0] = mid;
        mid.refs[0] = tail;
        const scenario = new RootedWeaks(new GraphRoot(head), this.weakRefs([head, mid, tail]));
        this.forceGc();
        assertEquals(16002, scenario.root.ref!.refs[0]!.refs[0]!.id);
        this.assertAllAlive(scenario.weaks);
    }
    /** GT-H02: Array refs can carry a tree-shaped graph. */
    gtH02_arrayBackedTreeKeepsLeavesAlive() {
        const rootNode = new ArrayNode(16010, 2);
        const left = new ArrayNode(16011, 1);
        const right = new ArrayNode(16012, 1);
        const leftLeaf = new ArrayNode(16013, 0);
        const rightLeaf = new ArrayNode(16014, 0);
        rootNode.refs[0] = left;
        rootNode.refs[1] = right;
        left.refs[0] = leftLeaf;
        right.refs[0] = rightLeaf;
        const scenario = new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, left, right, leftLeaf, rightLeaf]));
        this.forceGc();
        assertEquals(16013, scenario.root.ref!.refs[0]!.refs[0]!.id);
        assertEquals(16014, scenario.root.ref!.refs[1]!.refs[0]!.id);
        this.assertAllAlive(scenario.weaks);
    }
    /** GT-H03: Array null holes are skipped while non-null refs are still scanned. */
    gtH03_arrayNullHoleKeepsNonNullChildrenAlive() {
        const rootNode = new ArrayNode(16020, 3);
        const child1 = new ArrayNode(16021, 0);
        const child2 = new ArrayNode(16022, 0);
        rootNode.refs[0] = child1;
        rootNode.refs[1] = null;
        rootNode.refs[2] = child2;
        const scenario = new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, child1, child2]));
        this.forceGc();
        assertNull(scenario.root.ref!.refs[1]);
        assertEquals(16021, scenario.root.ref!.refs[0]!.id);
        assertEquals(16022, scenario.root.ref!.refs[2]!.id);
        this.assertAllAlive(scenario.weaks);
    }
    private arrayAfterSetNull(): MixedWeaks<GraphRoot<ArrayNode>, ArrayNode> {
        const rootNode = new ArrayNode(16030, 2);
        const removed = new ArrayNode(16031, 0);
        const remaining = new ArrayNode(16032, 0);
        rootNode.refs[0] = removed;
        rootNode.refs[1] = remaining;
        rootNode.refs[0] = null;
        return new MixedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, remaining]), this.weakRefs([removed]));
    }
    /** GT-H04: setting an Array edge to null collects only the removed child. */
    gtH04_arraySetNullCollectsRemovedChildOnly() {
        const scenario = this.arrayAfterSetNull();
        this.forceGc();
        assertNull(scenario.root.ref!.refs[0]);
        assertEquals(16032, scenario.root.ref!.refs[1]!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    private arrayAfterReplace(): ReplacementWeaks<GraphRoot<ArrayNode>, ArrayNode> {
        const rootNode = new ArrayNode(16040, 1);
        const oldChild = new ArrayNode(16041, 0);
        const newChild = new ArrayNode(16042, 0);
        rootNode.refs[0] = oldChild;
        const oldWeak = new WeakReference(oldChild);
        rootNode.refs[0] = newChild;
        const newWeak = new WeakReference(newChild);
        return new ReplacementWeaks(new GraphRoot(rootNode), [oldWeak], [newWeak]);
    }
    /** GT-H05: replacing an Array edge collects old child and keeps new child alive. */
    gtH05_arrayReplaceCollectsOldChildAndKeepsNewChildAlive() {
        const scenario = this.arrayAfterReplace();
        this.forceGc();
        assertEquals(16042, scenario.root.ref!.refs[0]!.id);
        this.assertAllCollected(scenario.oldWeaks);
        this.assertAllAlive(scenario.newWeaks);
    }
    /** GT-H06: List adjacency can carry a chain-shaped graph. */
    gtH06_listAdjacencyChainKeepsTailAlive() {
        const head = new MultiNode(16100);
        const mid = new MultiNode(16101);
        const tail = new MultiNode(16102);
        head.children.add(mid);
        mid.children.add(tail);
        const scenario = new RootedWeaks(new GraphRoot(head), this.weakRefs([head, mid, tail]));
        this.forceGc();
        assertEquals(16102, scenario.root.ref!.children[0].children[0].id);
        this.assertAllAlive(scenario.weaks);
    }
    /** GT-H07: List adjacency can carry a multi-way tree. */
    gtH07_listAdjacencyMultiWayTreeKeepsChildrenAlive() {
        const nodes = this.buildMultiTree(2, 3, 16110);
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(16110, scenario.root.ref!.id);
        assertEquals(3, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }
    private listAfterRemoveChild(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const rootNode = new MultiNode(16120);
        const removed = new MultiNode(16121);
        const removedLeaf = new MultiNode(16122);
        const remaining = new MultiNode(16123);
        removed.children.add(removedLeaf);
        rootNode.children.add(removed);
        rootNode.children.add(remaining);
        rootNode.children.remove(removed);
        return new MixedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, remaining]), this.weakRefs([removed, removedLeaf]));
    }
    /** GT-H08: removing a List child collects the removed subtree only. */
    gtH08_listRemoveChildCollectsRemovedSubtreeOnly() {
        const scenario = this.listAfterRemoveChild();
        this.forceGc();
        assertEquals(1, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    private listAfterClearChildren(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildMultiTree(2, 3, 16130);
        const root = new GraphRoot(nodes.first());
        root.ref!.children.clear();
        return new MixedWeaks(root, this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }
    /** GT-H09: clearing List children collects all child nodes and keeps root alive. */
    gtH09_listClearCollectsAllChildren() {
        const scenario = this.listAfterClearChildren();
        assertEquals(0, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    /** GT-H10: Map value can carry a graph edge. */
    gtH10_mapValueEdgeKeepsChildAlive() {
        const rootNode = new MapNode(16200);
        const child = new MapNode(16201);
        rootNode.refs.set("next", child);
        const scenario = new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, child]));
        this.forceGc();
        assertEquals(16201, scenario.root.ref!.refs.get("next")!.id);
        this.assertAllAlive(scenario.weaks);
    }
    private mapValueAfterRemove(): MixedWeaks<GraphRoot<MapNode>, MapNode> {
        const rootNode = new MapNode(16210);
        const child = new MapNode(16211);
        rootNode.refs.set("next", child);
        rootNode.refs.remove("next");
        return new MixedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode]), this.weakRefs([child]));
    }
    /** GT-H11: removing a Map value edge allows the child to be collected. */
    gtH11_mapValueRemoveCollectsChild() {
        const scenario = this.mapValueAfterRemove();
        assertEquals(0, scenario.root.ref!.refs.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    /** GT-H12: two Map value edges sharing one child keep the shared child alive. */
    gtH12_mapValueDagSharedChildRemainsAlive() {
        const parent1 = new MapNode(16220);
        const parent2 = new MapNode(16221);
        const shared = new MapNode(16222);
        const root = new MapNode(16223);
        root.refs.set("p1", parent1);
        root.refs.set("p2", parent2);
        parent1.refs.set("shared", shared);
        parent2.refs.set("shared", shared);
        const scenario = new RootedWeaks(new GraphRoot(root), this.weakRefs([root, parent1, parent2, shared]));
        this.forceGc();
        assertEquals(16222, scenario.root.ref!.refs.get("p1")!.refs.get("shared")!.id);
        this.assertAllAlive(scenario.weaks);
    }
    /** GT-H13: removing one Map edge to shared child still keeps it alive through another edge. */
    gtH13_mapValueDagSharedChildSurvivesOneEdgeRemoval() {
        const parent1 = new MapNode(16230);
        const parent2 = new MapNode(16231);
        const shared = new MapNode(16232);
        const root = new MapNode(16233);
        root.refs.set("p1", parent1);
        root.refs.set("p2", parent2);
        parent1.refs.set("shared", shared);
        parent2.refs.set("shared", shared);
        parent1.refs.remove("shared");
        const scenario = new RootedWeaks(new GraphRoot(root), this.weakRefs([root, parent1, parent2, shared]));
        this.forceGc();
        assertEquals(16232, scenario.root.ref!.refs.get("p2")!.refs.get("shared")!.id);
        this.assertAllAlive(scenario.weaks);
    }
    private mapDagAfterAllSharedEdgesRemoved(): MixedWeaks<GraphRoot<MapNode>, MapNode> {
        const parent1 = new MapNode(16240);
        const parent2 = new MapNode(16241);
        const shared = new MapNode(16242);
        const root = new MapNode(16243);
        root.refs.set("p1", parent1);
        root.refs.set("p2", parent2);
        parent1.refs.set("shared", shared);
        parent2.refs.set("shared", shared);
        parent1.refs.remove("shared");
        parent2.refs.remove("shared");
        return new MixedWeaks(new GraphRoot(root), this.weakRefs([root, parent1, parent2]), this.weakRefs([shared]));
    }
    /** GT-H14: removing all Map edges to a shared child allows it to be collected. */
    gtH14_mapValueDagSharedChildCollectedAfterAllEdgesRemoved() {
        const scenario = this.mapDagAfterAllSharedEdgesRemoved();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    /** GT-H15: Set elements used as children are scanned and kept alive. */
    gtH15_setChildrenKeepChildAlive() {
        const rootNode = new SetNode(16300);
        const child = new SetNode(16301);
        rootNode.children.add(child);
        const scenario = new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, child]));
        this.forceGc();
        assertEquals(1, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }
    private setAfterRemoveChild(): MixedWeaks<GraphRoot<SetNode>, SetNode> {
        const rootNode = new SetNode(16310);
        const child = new SetNode(16311);
        rootNode.children.add(child);
        rootNode.children.remove(child);
        return new MixedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode]), this.weakRefs([child]));
    }
    /** GT-H16: removing a Set child allows that child to be collected. */
    gtH16_setRemoveChildCollectsChild() {
        const scenario = this.setAfterRemoveChild();
        assertEquals(0, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
    /** GT-H17: a Map key can keep a node alive. */
    gtH17_mapKeyKeepsNodeAlive() {
        const key = new MapNode(16400);
        const map = new Map([[key, "metadata"]]);
        const scenario = new RootedWeaks(new GraphRoot(map), [new WeakReference(key)]);
        this.forceGc();
        assertEquals(16400, Array.from(scenario.root.ref!.keys()).single().id);
        this.assertAllAlive(scenario.weaks);
    }
    private mapKeyAfterRemove(): MixedWeaks<GraphRoot<Map<MapNode, string>>, MapNode> {
        const key = new MapNode(16410);
        const map = new Map([[key, "metadata"]]);
        const weak = new WeakReference(key);
        map.remove(key);
        return new MixedWeaks(new GraphRoot(map), [], [weak]);
    }
    /** GT-H18: removing a Map key allows that key node to be collected. */
    gtH18_mapKeyRemoveCollectsKeyNode() {
        const scenario = this.mapKeyAfterRemove();
        assertEquals(0, scenario.root.ref!.size);
        this.assertAllCollected(scenario.collectedWeaks);
    }
}
