import { SweepAllocatorTestSupport } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/sweepallocator/SweepAllocatorTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals, assertNotNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class MixedSizeAllocatorSweepTest extends SweepAllocatorTestSupport {
    sa_e01() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e02() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e03() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e04() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e05() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e06() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e07() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e08() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e09() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
    sa_e10() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);
    }
}
