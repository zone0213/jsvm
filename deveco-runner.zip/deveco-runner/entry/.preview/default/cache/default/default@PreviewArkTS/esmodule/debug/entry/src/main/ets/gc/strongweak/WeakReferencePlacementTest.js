// @ts-nocheck
import { WeakReferenceTestSupport, Payload, StrongHolder, WeakHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/strongweak/WeakReferenceTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * WR-E group: WeakReference object placement tests.
 */
export class WeakReferencePlacementTest extends WeakReferenceTestSupport {
    createRootedWeakHolder() {
        const obj = new Payload(501);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new WeakHolder(weak)), weak);
    }
    /**
     * WR-E01
     * Scenario: root holds WeakHolder, which holds WeakReference to target.
     * Expectation: holder survives, target can be collected.
     */
    wrE01_rootedWeakHolderDoesNotKeepTargetAlive() {
        const scenario = this.createRootedWeakHolder();
        this.forceGc();
        assertNotNull(scenario.root.ref);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedWeakList() {
        const obj = new Payload(502);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root([weak]), weak);
    }
    /**
     * WR-E02
     * Scenario: root holds a list containing WeakReference.
     * Expectation: list and WeakReference object survive, target can be collected.
     */
    wrE02_rootedWeakListDoesNotKeepTargetAlive() {
        const scenario = this.createRootedWeakList();
        this.forceGc();
        assertEquals(1, scenario.root.ref.size);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedWeakArray() {
        const obj = new Payload(503);
        const weak = new WeakReference(obj);
        const array = new Array(1).fill(null);
        array[0] = weak;
        return new WeakOnlyResult(new Root(array), weak);
    }
    /**
     * WR-E03
     * Scenario: root holds an array containing WeakReference.
     * Expectation: array and WeakReference object survive, target can be collected.
     */
    wrE03_rootedWeakArrayDoesNotKeepTargetAlive() {
        const scenario = this.createRootedWeakArray();
        this.forceGc();
        assertNotNull(scenario.root.ref[0]);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedWeakMapValue() {
        const obj = new Payload(504);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Map([["target", weak]])), weak);
    }
    /**
     * WR-E04
     * Scenario: root holds a map whose value is WeakReference.
     * Expectation: map and WeakReference object survive, target can be collected.
     */
    wrE04_rootedWeakMapValueDoesNotKeepTargetAlive() {
        const scenario = this.createRootedWeakMapValue();
        this.forceGc();
        assertNotNull(scenario.root.ref.get("target"));
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedWeakMapKey() {
        const obj = new Payload(505);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Map([[weak, "value"]])), weak);
    }
    /**
     * WR-E05
     * Scenario: root holds a map whose key is WeakReference.
     * Expectation: map and key object survive, target can be collected.
     */
    wrE05_rootedWeakMapKeyDoesNotKeepTargetAlive() {
        const scenario = this.createRootedWeakMapKey();
        this.forceGc();
        assertEquals(1, scenario.root.ref.size);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedBoxOfWeak() {
        const obj = new Payload(506);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new Box(weak)), weak);
    }
    /**
     * WR-E06
     * Scenario: root holds Box containing WeakReference.
     * Expectation: box and WeakReference object survive, target can be collected.
     */
    wrE06_rootedBoxOfWeakDoesNotKeepTargetAlive() {
        const scenario = this.createRootedBoxOfWeak();
        this.forceGc();
        assertNotNull(scenario.root.ref.value);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createRootedDataWeakHolder() {
        const obj = new Payload(507);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new DataWeakHolder(weak)), weak);
    }
    /**
     * WR-E07
     * Scenario: root holds data-style holder containing WeakReference.
     * Expectation: holder survives, target can be collected.
     */
    wrE07_rootedDataWeakHolderDoesNotKeepTargetAlive() {
        const scenario = this.createRootedDataWeakHolder();
        this.forceGc();
        assertNotNull(scenario.root.ref.weak);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createNullableWeakFieldHolder() {
        const obj = new Payload(508);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new Root(new WeakHolder(weak)), weak);
    }
    /**
     * WR-E08
     * Scenario: WeakReference is stored in a nullable field.
     * Expectation: field can stay non-null while weak.value becomes null.
     */
    wrE08_nullableWeakFieldSurvivesButTargetCanBeCollected() {
        const scenario = this.createNullableWeakFieldHolder();
        this.forceGc();
        assertNotNull(scenario.root.ref.weak);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createWeakObjectAfterClearingWeakField() {
        const obj = new Payload(509);
        const weak = new WeakReference(obj);
        const weakObjectObserver = new WeakReference(weak);
        const holder = new WeakHolder(weak);
        holder.weak = null;
        return weakObjectObserver;
    }
    /**
     * WR-E09
     * Scenario: a holder weak field is cleared.
     * Expectation: the WeakReference object itself can be collected when no strong reference keeps it.
     */
    wrE09_clearingWeakFieldAllowsWeakReferenceObjectCollection() {
        const weakObjectObserver = this.createWeakObjectAfterClearingWeakField();
        this.assertWeakCollected(weakObjectObserver);
    }
    createWeakObjectAfterClearingWeakList() {
        const obj = new Payload(510);
        const weak = new WeakReference(obj);
        const weakObjectObserver = new WeakReference(weak);
        const list = [weak];
        list.clear();
        return weakObjectObserver;
    }
    /**
     * WR-E10
     * Scenario: a list containing WeakReference is cleared.
     * Expectation: the WeakReference object itself can be collected.
     */
    wrE10_clearingWeakListAllowsWeakReferenceObjectCollection() {
        const weakObjectObserver = this.createWeakObjectAfterClearingWeakList();
        this.assertWeakCollected(weakObjectObserver);
    }
    createWeakObjectAfterArraySlotNull() {
        const obj = new Payload(511);
        const weak = new WeakReference(obj);
        const weakObjectObserver = new WeakReference(weak);
        const array = new Array(1).fill(null);
        array[0] = weak;
        array[0] = null;
        return weakObjectObserver;
    }
    /**
     * WR-E11
     * Scenario: an array slot containing WeakReference is set to null.
     * Expectation: the WeakReference object itself can be collected.
     */
    wrE11_nullingWeakArraySlotAllowsWeakReferenceObjectCollection() {
        const weakObjectObserver = this.createWeakObjectAfterArraySlotNull();
        this.assertWeakCollected(weakObjectObserver);
    }
    createWeakObjectAfterMapRemove() {
        const obj = new Payload(512);
        const weak = new WeakReference(obj);
        const weakObjectObserver = new WeakReference(weak);
        const map = new Map([["target", weak]]);
        map.remove("target");
        return weakObjectObserver;
    }
    /**
     * WR-E12
     * Scenario: a map entry containing WeakReference is removed.
     * Expectation: the WeakReference object itself can be collected.
     */
    wrE12_removingWeakMapEntryAllowsWeakReferenceObjectCollection() {
        const weakObjectObserver = this.createWeakObjectAfterMapRemove();
        this.assertWeakCollected(weakObjectObserver);
    }
    createWeakHolderWithUnrelatedStrongObject() {
        const weakTarget = new Payload(513);
        const unrelated = new Payload(514);
        const weak = new WeakReference(weakTarget);
        const weakHolder = new WeakHolder(weak);
        const strongHolder = new StrongHolder(unrelated);
        weakHolder.weak = weak;
        return new MixedWeakResult(new Root(strongHolder), [new WeakReference(unrelated)], [weak]);
    }
    /**
     * WR-E13
     * Scenario: root holds an unrelated strong object while another holder contains WeakReference to target.
     * Expectation: unrelated strong object survives; weak target can be collected.
     */
    wrE13_unrelatedStrongObjectSurvivesWhileWeakTargetIsCollected() {
        const scenario = this.createWeakHolderWithUnrelatedStrongObject();
        this.forceGc();
        assertEquals(514, scenario.root.ref.ref.id);
        this.assertAllWeakAlive(scenario.aliveWeaks);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
    createMultiLevelHolderWithWeak() {
        const obj = new Payload(515);
        const weak = new WeakReference(obj);
        const inner = new WeakHolder(weak);
        const outer = new StrongHolder(inner);
        return new WeakOnlyResult(new Root(outer), weak);
    }
    /**
     * WR-E14
     * Scenario: root -> holder1 -> holder2 -> WeakReference -> target.
     * Expectation: holder chain survives, but target can be collected.
     */
    wrE14_multiLevelHolderWeakDoesNotKeepTargetAlive() {
        const scenario = this.createMultiLevelHolderWithWeak();
        this.forceGc();
        assertNotNull(scenario.root.ref.ref);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
}
//# sourceMappingURL=WeakReferencePlacementTest.js.map