import { RootSetTestSupport, RootPayload, RootHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/rootset/RootSetTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class InitializationRootTest extends RootSetTestSupport {
    rsD01_lazyNotAccessedDoesNotInitialize() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD02_lazyAccessInitializesAndKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD03_lazyPayloadWithChildKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD04_lazyHolderKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD05_objectLazyRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD06_companionLazyRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD07_lateinitInitializedRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD08_lateinitReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD09_lateinitHolderRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD10_lateinitChildGraphRootKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD11_clearableLateinitLikeNullableRootAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    rsD12_failedInitializationDoesNotKeepPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
