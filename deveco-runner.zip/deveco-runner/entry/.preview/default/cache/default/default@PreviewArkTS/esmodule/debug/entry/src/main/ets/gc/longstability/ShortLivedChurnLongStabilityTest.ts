import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, MEDIUM_BYTES } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
export class ShortLivedChurnLongStabilityTest extends LongStabilityTestSupport {
    ls_b01_smallObjectChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => new LsNode(it)));
    }
    ls_b02_mediumObjectChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => new MediumPayload(it)));
    }
    ls_b03_largeObjectChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(12, it => new LargePayload(it, new Array(MEDIUM_BYTES).fill(0))));
    }
    ls_b04_mixedObjectChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => new MixedPayload(it)));
    }
    ls_b05_stringChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => `value-${it}`.split("").reverse().join("")));
    }
    ls_b06_bytearrayChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(12, it => Array.from({ length: 4096 }, (_, b) => b + it)));
    }
    ls_b07_nestedDtoChurn() {
        this.assertNoSustainedMonotonicGrowth(this.businessDtoSamples());
    }
    ls_b08_lambdaChurn() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => { const node = new LsNode(it); return () => node.id; }));
    }
    ls_b09_exceptionChurn() {
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(index => { try {
            throw new Error(`boom-${index}`);
        }
        catch (_e) { } }));
    }
    ls_b10_burstChurn() {
        const spike = this.spikeLoop(() => this.allocateMixedBatch().slice());
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
        this.assertNoSustainedMonotonicGrowth(spike);
    }
}
