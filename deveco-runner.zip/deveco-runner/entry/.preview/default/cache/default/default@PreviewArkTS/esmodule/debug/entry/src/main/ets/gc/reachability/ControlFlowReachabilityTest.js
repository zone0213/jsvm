// @ts-nocheck
import { ReachabilityTestSupport, Payload, RootedWeak, LoopReplacementResult } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/reachability/ReachabilityTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * G group: control-flow-related basic reachability.
 */
export class ControlFlowReachabilityTest extends ReachabilityTestSupport {
    /**
     * RC-G01
     * Scenario: a nullable local variable is assigned inside an if branch.
     * Expectation: the assigned object remains reachable through the local variable.
     */
    rcG01_ifBranchAssignmentKeepsObjectAlive() {
        let obj = null;
        if (true) {
            obj = new Payload(601);
        }
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(601, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-G02
     * Scenario: an if branch does not assign an object and the variable remains null.
     * Expectation: GC should not crash or treat null as a reference.
     */
    rcG02_ifBranchWithoutAssignmentKeepsNullSafe() {
        let obj = null;
        if (false) {
            obj = new Payload(602);
        }
        this.forceGc();
        assertNull(obj);
    }
    /**
     * RC-G03
     * Scenario: a nullable local variable is assigned inside a when branch.
     * Expectation: the assigned object remains reachable through the local variable.
     */
    rcG03_whenBranchAssignmentKeepsObjectAlive() {
        const selector = 3;
        let obj = null;
        switch (selector) {
            case 3:
                obj = new Payload(603);
                break;
            default:
                fail("Unexpected branch");
                break;
        }
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(603, obj.id);
        assertNotNull(weak.value);
    }
    createLoopReplacementResult() {
        let current = null;
        const oldWeaks = [];
        for (let i = 0; i < 5; i++) {
            if (current !== null) {
                oldWeaks.add(new WeakReference(current));
            }
            current = new Payload(6040 + i);
        }
        const liveObject = current;
        const liveWeak = new WeakReference(liveObject);
        return new LoopReplacementResult(liveObject, oldWeaks, liveWeak);
    }
    /**
     * RC-G04
     * Scenario: a loop repeatedly assigns a local variable to new Payload objects.
     * Expectation: only the last assigned object remains strongly reachable through the returned result;
     * earlier objects can be collected.
     */
    rcG04_loopVariableKeepsLastObjectAndReleasesOldObjects() {
        const result = this.createLoopReplacementResult();
        this.forceGc();
        result.oldWeaks.forEach((oldWeak) => {
            oldWeak.clear();
            assertNull(oldWeak.value);
        });
        assertNotNull(result.liveWeak.value);
        assertEquals(6044, result.liveObject.id);
    }
    createWeakReferencesFromLoopTemporaries() {
        const weaks = [];
        for (let i = 0; i < 5; i++) {
            const tmp = new Payload(6050 + i);
            weaks.add(new WeakReference(tmp));
            assertEquals(6050 + i, tmp.id);
        }
        return weaks;
    }
    /**
     * RC-G05
     * Scenario: a loop creates temporary objects that are not kept by strong references.
     * Expectation: after the helper stack frame returns, loop temporary objects can be collected.
     */
    rcG05_loopTemporaryObjectsCanBeCollected() {
        const weaks = this.createWeakReferencesFromLoopTemporaries();
        this.forceGc();
        weaks.forEach((weak) => {
            weak.clear();
            assertNull(weak.value);
        });
    }
    /**
     * RC-G06
     * Scenario: an object is created and used inside a try block.
     * Expectation: the object remains reachable while used after GC inside the try block.
     */
    rcG06_tryBlockLocalObjectKeepsAliveInsideTry() {
        try {
            const obj = new Payload(606);
            const weak = new WeakReference(obj);
            this.forceGc();
            assertEquals(606, obj.id);
            assertNotNull(weak.value);
        }
        catch (t) {
            throw new Error("Unexpected exception: ${t.message}");
        }
    }
    /**
     * RC-G07
     * Scenario: an object is created and used inside a catch block.
     * Expectation: the object remains reachable while used after GC inside the catch block.
     */
    rcG07_catchBlockLocalObjectKeepsAliveInsideCatch() {
        try {
            throw new Error("Force catch branch");
        }
        catch (t) {
            const obj = new Payload(607);
            const weak = new WeakReference(obj);
            this.forceGc();
            assertEquals(607, obj.id);
            assertNotNull(weak.value);
            assertTrue(t.message.includes("Force"));
        }
    }
    createWeakAfterFinallyCleanup() {
        let obj = new Payload(608);
        const weak = new WeakReference(obj);
        try {
            assertEquals(608, obj.id);
        }
        finally {
            obj = null;
        }
        assertNull(obj);
        return weak;
    }
    /**
     * RC-G08
     * Scenario: a finally block clears the last strong local reference.
     * Expectation: after the helper stack frame returns, the object can be collected.
     */
    rcG08_finallyCleanupAllowsCollection() {
        const weak = this.createWeakAfterFinallyCleanup();
        this.assertWeakCollected(weak);
    }
    createWeakWithEarlyReturn() {
        const obj = new Payload(609);
        const weak = new WeakReference(obj);
        if (obj.id == 609) {
            return weak;
        }
        return weak;
    }
    /**
     * RC-G09
     * Scenario: a function returns early after creating an object, and only WeakReference escapes.
     * Expectation: after early return, the object can be collected.
     */
    rcG09_earlyReturnAllowsLocalObjectCollection() {
        const weak = this.createWeakWithEarlyReturn();
        this.assertWeakCollected(weak);
    }
    createNestedFunctionCaptureRoot() {
        const obj = new Payload(610);
        const readId = () => obj.id;
        const block = () => readId();
        return new RootedWeak(block, new WeakReference(obj));
    }
    /**
     * RC-G10
     * Scenario: a nested local function captures a Payload and is invoked through a returned lambda.
     * Expectation: the captured object remains reachable through lambda -> local function capture.
     */
    rcG10_nestedFunctionCaptureKeepsObjectAlive() {
        const scenario = this.createNestedFunctionCaptureRoot();
        this.forceGc();
        assertEquals(610, scenario.root());
        assertNotNull(scenario.weak.value);
    }
}
//# sourceMappingURL=ControlFlowReachabilityTest.js.map