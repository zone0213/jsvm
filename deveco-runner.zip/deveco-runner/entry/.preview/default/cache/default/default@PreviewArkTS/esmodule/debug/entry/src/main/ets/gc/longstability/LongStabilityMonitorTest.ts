import { LongStabilityTestSupport, LsNode } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
import { assertEquals, assertNotNull, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class LongStabilityMonitorTest extends LongStabilityTestSupport {
    ls_a01_gcinfoCollectionBaseline() {
        this.assertGcInfoReadable();
    }
    ls_a02_heapafterSamplingBaseline() {
        const samples = Array.from({ length: 5 }, () => this.heapAfterBytes());
        assertTrue(samples.every(it => it >= 0));
    }
    ls_a03_sweepstatisticsSamplingBaseline() {
        for (let i = 0; i < 5; i++)
            this.assertGcInfoReadable();
    }
    ls_a04_workloadProgressCounter() {
        let iteration = 0;
        for (let i = 0; i < 64; i++)
            iteration++;
        assertTrue(iteration === 64);
    }
    ls_a05_latencySampling() {
        const samples: number[] = [];
        for (let i = 0; i < 8; i++) {
            const before = this.heapAfterBytes();
            this.forceGc();
            const after = this.heapAfterBytes();
            samples.push(Math.abs(after - before));
        }
        assertTrue(samples.every(it => it >= 0));
    }
    ls_a06_warmupExcludedTrend() {
        this.shortLivedSamples(4, it => new LsNode(it));
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(12, it => new LsNode(it)));
    }
    ls_a07_monotonicGrowthDetector() {
        this.assertNoSustainedMonotonicGrowth([10, 11, 9, 12, 8, 8, 9]);
    }
    ls_a08_spikeRecoveryDetector() {
        this.assertSpikeRecovered(100, 500, 160);
    }
    ls_a09_sweptcountActivityDetector() {
        this.shortLivedSamples(8, it => new LsNode(it));
        assertTrue(this.sweptCount() >= 0);
    }
    ls_a10_reportDataCompleteness() {
        const report = new Map<string, string>([["case", "LS-A10"], ["heap", String(this.heapAfterBytes())]]);
        assertEquals("LS-A10", report.get("case"));
        assertNotNull(report.get("heap"));
    }
}
