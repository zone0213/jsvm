import { assertEquals, assertNotNull, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
import { Holder, Node, WeakReference, forceGc, runGcAroundMutation, replaceField, assertWeakAlive, assertWeakCollectedEventually, assertAllWeakCollectedEventually, buildSharedGraph, buildCycle, repeatMutationWithGc, } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class ConcurrentWeakMutationTest {
    cgI01_addStrongDuringGcWeakNotCleared() {
        const holder = new Holder<Node>(null);
        const node = new Node(1101);
        const weak = new WeakReference(node);
        runGcAroundMutation(() => { holder.ref = node; });
        assertEquals(1101, holder.ref!.id);
        assertNotNull(weak.value);
    }
    cgI02_deleteStrongDuringGcWeakEventuallyCleared() {
        const holder = new Holder(new Node(1102));
        const weak = new WeakReference(holder.ref!);
        runGcAroundMutation(() => { holder.ref = null; });
        assertWeakCollectedEventually(weak);
    }
    cgI03_replaceStrongDuringGcOldWeakClearedNewAlive() {
        const r = replaceField(1103, 1104);
        assertWeakCollectedEventually(r.oldWeak);
        assertWeakAlive(r.newWeak);
        assertNotNull(r.root.ref);
    }
    cgI04_weakValuePromotionDuringGc() {
        const node = new Node(1105);
        const weak = new WeakReference(node);
        const holder = new Holder<Node>(null);
        forceGc();
        holder.ref = node;
        forceGc();
        assertEquals(1105, holder.ref!.id);
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }
    cgI05_clearPromotedStrongDuringGc() {
        const node = new Node(1106);
        const weak = new WeakReference(node);
        const holder = new Holder<Node>(weak.value);
        runGcAroundMutation(() => { holder.ref = null; });
        assertWeakCollectedEventually(weak);
    }
    cgI06_manyWeaksAddStrongDuringGc() {
        const node = new Node(1107);
        const weaks = Array.from({ length: 16 }, () => new WeakReference(node));
        const holder = new Holder<Node>(null);
        forceGc();
        holder.ref = node;
        forceGc();
        weaks.forEach((w, i) => assertNotNull(w.value, `Expected weak[${i}] to remain alive.`));
        assertNotNull(holder.ref);
    }
    cgI07_manyWeaksDeleteStrongDuringGc() {
        const holder = new Holder(new Node(1108));
        const weaks = Array.from({ length: 16 }, () => new WeakReference(holder.ref!));
        runGcAroundMutation(() => { holder.ref = null; });
        assertAllWeakCollectedEventually(weaks);
    }
    cgI08_weakObserversWithStrongListAdd() {
        const node = new Node(1109);
        const weak = new WeakReference(node);
        const list: Node[] = [];
        runGcAroundMutation(() => { list.push(node); });
        assertEquals(1109, list[0].id);
        assertNotNull(weak.value);
    }
    cgI09_weakObserversWithStrongListRemove() {
        const node = new Node(1110);
        const weak = new WeakReference(node);
        const list: Node[] = [node];
        runGcAroundMutation(() => { list.splice(list.indexOf(node), 1); });
        assertWeakCollectedEventually(weak);
    }
    cgI10_weakSharedSubgraphDisconnectOneStrongEdge() {
        const g = buildSharedGraph(1111);
        const weak = new WeakReference(g.shared);
        runGcAroundMutation(() => { g.parent1.left = null; });
        assertEquals(1113, g.parent2.left!.id);
        assertNotNull(weak.value);
    }
    cgI11_weakSharedSubgraphDisconnectAllStrongEdges() {
        const g = buildSharedGraph(1114);
        const weak = new WeakReference(g.shared);
        runGcAroundMutation(() => { g.parent1.left = null; g.parent2.left = null; });
        assertWeakCollectedEventually(weak);
    }
    cgI12_weakCycleAttachRootDuringGc() {
        const cycle = buildCycle(1120);
        const weak = new WeakReference(cycle[0]);
        const holder = new Holder<Node>(null);
        runGcAroundMutation(() => { holder.ref = cycle[0]; });
        assertEquals(1120, holder.ref!.id);
        assertNotNull(weak.value);
    }
    cgI13_weakCycleDetachRootDuringGc() {
        const cycle = buildCycle(1130);
        const holder = new Holder(cycle[0]);
        const weak = new WeakReference(cycle[0]);
        runGcAroundMutation(() => { holder.ref = null; });
        assertWeakCollectedEventually(weak);
    }
    cgI14_weakProcessingPressureWithWriter() {
        const holder = new Holder(new Node(1140));
        const weaks = Array.from({ length: 32 }, () => new WeakReference(holder.ref!));
        repeatMutationWithGc(32, (it: number) => { if (it % 2 === 0)
            holder.ref = new Node(1140 + it); });
        assertNotNull(holder.ref);
        forceGc();
        assertTrue(weaks.every(w => w.value === null || w.value!.id >= 1140));
    }
}
