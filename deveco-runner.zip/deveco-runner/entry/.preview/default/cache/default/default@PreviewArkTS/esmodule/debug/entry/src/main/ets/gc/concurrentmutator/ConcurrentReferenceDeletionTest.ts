import { assertEquals, assertNotNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
import { buildChain, buildTree, buildCycle, buildSharedGraph, clearFieldEventually, Holder, Node, WeakReference, assertAllWeakCollectedEventually, runGcAroundMutation, assertWeakCollectedEventually, setGlobalNode, setThreadLocalNode, LambdaHolder, repeatMutationWithGc, SMALL_ITERATIONS, } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class ConcurrentReferenceDeletionTest {
    cgC01_clearNormalFieldDuringGc() {
        assertWeakCollectedEventually(clearFieldEventually(301));
    }
    cgC02_clearNullableFieldDuringGc() {
        assertWeakCollectedEventually(clearFieldEventually(302));
    }
    cgC03_disconnectChainHeadDuringGc() {
        const nodes = buildChain(4, 303);
        const root = new Holder(nodes[0]);
        const suffixWeaks = nodes.slice(1).map(node => new WeakReference(node));
        runGcAroundMutation(() => { nodes[0].next = null; });
        assertEquals(303, root.ref!.id);
        assertAllWeakCollectedEventually(suffixWeaks);
    }
    cgC04_disconnectChainMiddleDuringGc() {
        const nodes = buildChain(6, 310);
        const root = new Holder(nodes[0]);
        const suffixWeaks = nodes.slice(3).map(node => new WeakReference(node));
        runGcAroundMutation(() => { nodes[2].next = null; });
        assertEquals(310, root.ref!.id);
        assertAllWeakCollectedEventually(suffixWeaks);
    }
    cgC05_disconnectTreeLeftSubtreeDuringGc() {
        const tree = buildTree(320);
        const root = new Holder(tree[0]);
        const leftWeaks = [tree[1], tree[3]].map(node => new WeakReference(node));
        const rightWeak = new WeakReference(tree[2]);
        runGcAroundMutation(() => { tree[0].left = null; });
        assertEquals(322, root.ref!.right!.id);
        assertNotNull(rightWeak.value);
        assertAllWeakCollectedEventually(leftWeaks);
    }
    cgC06_disconnectTreeRightSubtreeDuringGc() {
        const tree = buildTree(330);
        const root = new Holder(tree[0]);
        const rightWeaks = [tree[2], tree[4]].map(node => new WeakReference(node));
        runGcAroundMutation(() => { tree[0].right = null; });
        assertEquals(330, root.ref!.id);
        assertAllWeakCollectedEventually(rightWeaks);
    }
    cgC07_disconnectOneSharedParentDuringGc() {
        const g = buildSharedGraph(340);
        const weak = new WeakReference(g.shared);
        runGcAroundMutation(() => { g.parent1.left = null; });
        assertEquals(342, g.parent2.left!.id);
        assertNotNull(weak.value);
    }
    cgC08_disconnectAllSharedParentsDuringGc() {
        const g = buildSharedGraph(350);
        const weak = new WeakReference(g.shared);
        runGcAroundMutation(() => {
            g.parent1.left = null;
            g.parent2.left = null;
        });
        assertWeakCollectedEventually(weak);
    }
    cgC09_disconnectCycleEntryDuringGc() {
        const cycle = buildCycle(360);
        const holder = new Holder(cycle[0]);
        const weaks = cycle.map(node => new WeakReference(node));
        runGcAroundMutation(() => { holder.ref = null; });
        assertAllWeakCollectedEventually(weaks);
    }
    cgC10_disconnectGlobalRootDuringGc() {
        const node = new Node(370);
        const weak = new WeakReference(node);
        setGlobalNode(node);
        runGcAroundMutation(() => { setGlobalNode(null); });
        assertWeakCollectedEventually(weak);
    }
    cgC11_disconnectThreadLocalRootDuringGc() {
        const node = new Node(380);
        const weak = new WeakReference(node);
        setThreadLocalNode(node);
        runGcAroundMutation(() => { setThreadLocalNode(null); });
        assertWeakCollectedEventually(weak);
    }
    cgC12_disconnectLambdaHolderDuringGc() {
        const node = new Node(390);
        const weak = new WeakReference(node);
        const holder = new LambdaHolder(() => node.id);
        runGcAroundMutation(() => { holder.block = null; });
        assertWeakCollectedEventually(weak);
    }
    cgC13_bulkClearFieldsDuringGc() {
        const holders = Array.from({ length: 16 }, (_, i) => new Holder(new Node(400 + i)));
        const weaks = holders.map(holder => new WeakReference(holder.ref!));
        runGcAroundMutation(() => { holders.forEach(holder => { holder.ref = null; }); });
        assertAllWeakCollectedEventually(weaks);
    }
    cgC14_repeatedDisconnectReconnectAcrossGc() {
        const holder = new Holder<Node>(null);
        const count = repeatMutationWithGc((it: number) => { holder.ref = it % 2 === 0 ? new Node(420 + it) : null; });
        assertEquals(SMALL_ITERATIONS, count);
    }
}
