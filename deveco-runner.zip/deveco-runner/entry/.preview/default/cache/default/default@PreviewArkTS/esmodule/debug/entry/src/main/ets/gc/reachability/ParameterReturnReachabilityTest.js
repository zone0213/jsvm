// @ts-nocheck
import { ReachabilityTestSupport, Payload } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/reachability/ReachabilityTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * B group: function parameter roots and returned-value roots.
 */
export class ParameterReturnReachabilityTest extends ReachabilityTestSupport {
    checkPayloadParameter(obj) {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(obj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B01
     * Scenario: function parameter has static type Payload.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    rcB01_functionParameterKeepsPayloadAlive() {
        const obj = new Payload(101);
        const weak = this.checkPayloadParameter(obj);
        assertEquals(101, obj.id);
        assertNotNull(weak.value);
    }
    checkAnyParameter(obj) {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertNotNull(weak.value);
        return weak;
    }
    /**
     * RC-B02
     * Scenario: function parameter has static type Any and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    rcB02_anyTypedFunctionParameterKeepsRuntimeObjectAlive() {
        const obj = new Payload(102);
        const weak = this.checkAnyParameter(obj);
        assertEquals(102, obj.id);
        assertNotNull(weak.value);
    }
    checkInterfaceParameter(obj) {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(obj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B03
     * Scenario: function parameter has static type Marker and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    rcB03_interfaceTypedFunctionParameterKeepsRuntimeObjectAlive() {
        const obj = new Payload(103);
        const weak = this.checkInterfaceParameter(obj);
        assertEquals(103, obj.id);
        assertNotNull(weak.value);
    }
    checkNullableParameter(obj) {
        const nonNullObj = obj;
        const weak = new WeakReference(nonNullObj);
        this.forceGc();
        assertEquals(nonNullObj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B04
     * Scenario: function parameter has nullable static type Payload? and holds a non-null object.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    rcB04_nullableFunctionParameterKeepsObjectAlive() {
        const obj = new Payload(104);
        const weak = this.checkNullableParameter(obj);
        assertEquals(104, obj.id);
        assertNotNull(weak.value);
    }
    createPayload(id) { return new Payload(id); }
    /**
     * RC-B05
     * Scenario: a function returns a Payload and the caller stores the returned value.
     * Expectation: the returned object remains alive through the caller's local root.
     */
    rcB05_returnedValueStoredByCallerKeepsObjectAlive() {
        const obj = this.createPayload(105);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(105, obj.id);
        assertNotNull(weak.value);
    }
    createReturnedValueButOnlyWeakEscapes() {
        const obj = this.createPayload(106);
        return new WeakReference(obj);
    }
    /**
     * RC-B06
     * Scenario: a created returned-like object is not kept by a strong reference;
     * only WeakReference escapes the helper frame.
     * Expectation: the object can be collected.
     */
    rcB06_returnedValueWithoutStrongCallerReferenceCanBeCollected() {
        const weak = this.createReturnedValueButOnlyWeakEscapes();
        this.assertWeakCollected(weak);
    }
    /**
     * RC-B07
     * Scenario: a returned Payload is stored in a caller local variable with static type Any.
     * Expectation: the object remains reachable.
     */
    rcB07_returnedValueStoredAsAnyKeepsObjectAlive() {
        const obj = this.createPayload(107);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(107, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-B08
     * Scenario: a returned Payload is stored in a caller local variable with static type Marker.
     * Expectation: the object remains reachable.
     */
    rcB08_returnedValueStoredAsInterfaceKeepsObjectAlive() {
        const obj = this.createPayload(108);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(108, obj.id);
        assertNotNull(weak.value);
    }
}
//# sourceMappingURL=ParameterReturnReachabilityTest.js.map