import { LongStabilityTestSupport, LsNode, LargePayload, MixedPayload, Holder, FakeDto, FakeState, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/longstability/LongStabilityTestSupport";
import { assertEquals, assertNotNull, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class LongLivedGarbageMixedLongStabilityTest extends LongStabilityTestSupport {
    ls_c01_smallLongLivedWithSmallGarbage() {
        const weak = this.longLivedWithGarbage(() => new LsNode(1), it => new LsNode(it));
        assertNotNull(weak.value);
    }
    ls_c02_largeLongLivedWithSmallGarbage() {
        const weak = this.longLivedWithGarbage(() => new LargePayload(2, new Array(MEDIUM_BYTES).fill(0)), it => new LsNode(it));
        assertNotNull(weak.value);
    }
    ls_c03_mixedLongLivedWithMixedGarbage() {
        const weak = this.longLivedWithGarbage(() => new MixedPayload(3), it => new MixedPayload(it));
        assertNotNull(weak.value);
    }
    ls_c04_longLivedListWithChurn() {
        const roots = this.allocateSmallBatch(32);
        const weak = new WeakReference(roots.first());
        this.shortLivedSamples(8, it => new LsNode(it));
        assertEquals(0, roots.first().id);
        assertNotNull(weak.value);
    }
    ls_c05_longLivedMapCacheWithChurn() {
        const cache = new Map<number, LargePayload>();
        cache.set(0, new LargePayload(0, new Array(1024).fill(0)));
        const weak = new WeakReference(cache.get(0)!);
        this.repositoryCacheStateSamples(8);
        assertEquals(0, cache.get(0)!.id);
        assertNotNull(weak.value);
    }
    ls_c06_longLivedStateTreeWithChurn() {
        const state = new FakeState([new FakeDto(1, "state", [])]);
        this.shortLivedSamples(8, it => new FakeDto(it, "garbage", []));
        assertTrue(state.items.length > 0);
    }
    ls_c07_periodicLongLivedRootReplacement() {
        const holder = new Holder(new LsNode(0));
        const samples = this.containerSamples(i => { holder.ref = new LsNode(i); });
        assertNotNull(holder.ref);
        this.assertNoSustainedMonotonicGrowth(samples);
    }
    ls_c08_boundedLruGrowth() {
        const cache = new Map<number, LargePayload>();
        const samples = this.containerSamples(i => { cache.set(i, new LargePayload(i, new Array(1024).fill(0))); if (cache.size > CACHE_LIMIT)
            cache.delete(Array.from(cache.keys())[0]); });
        assertTrue(cache.size <= CACHE_LIMIT);
        this.assertNoSustainedMonotonicGrowth(samples);
    }
    ls_c09_clearLongLivedRootsAtEnd() {
        const roots = this.allocateSmallBatch(16);
        const weak = new WeakReference(roots.first());
        roots.length = 0;
        this.assertWeakCollectedEventually(weak);
    }
    ls_c10_longLivedRootWithExceptionChurn() {
        const root = new LsNode(10);
        const weak = new WeakReference(root);
        this.containerSamples(i => { try {
            if (i % 3 === 0)
                throw new Error("churn");
        }
        catch (_e) { } });
        assertNotNull(weak.value);
    }
}
