// @ts-nocheck
import { ReachabilityTestSupport, Payload, globalPayload, globalAny, globalMarker, setGlobalPayload, setGlobalAny, setGlobalMarker, GlobalHolder, CompanionRootHolder } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/reachability/ReachabilityTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * C group: top-level global, object singleton, and companion-object roots.
 */
export class GlobalRootReachabilityTest extends ReachabilityTestSupport {
    setGlobalPayloadAndReturnWeak() {
        const obj = new Payload(201);
        setGlobalPayload(obj);
        return new WeakReference(obj);
    }
    /**
     * RC-C01
     * Scenario: a top-level global variable strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    rcC01_topLevelGlobalKeepsObjectAlive() {
        const weak = this.setGlobalPayloadAndReturnWeak();
        this.forceGc();
        assertEquals(201, globalPayload.id);
        assertNotNull(weak.value);
    }
    clearGlobalPayloadAndReturnWeak() {
        const obj = new Payload(202);
        setGlobalPayload(obj);
        const weak = new WeakReference(obj);
        setGlobalPayload(null);
        return weak;
    }
    /**
     * RC-C02
     * Scenario: a top-level global variable is cleared.
     * Expectation: after the helper stack frame returns, the previously referenced object can be collected.
     */
    rcC02_clearingTopLevelGlobalAllowsCollection() {
        const weak = this.clearGlobalPayloadAndReturnWeak();
        this.assertWeakCollected(weak);
    }
    setGlobalAnyAndReturnWeak() {
        const obj = new Payload(203);
        setGlobalAny(obj);
        return new WeakReference(obj);
    }
    /**
     * RC-C03
     * Scenario: a top-level global variable has static type Any? and runtime type Payload.
     * Expectation: the runtime object remains alive.
     */
    rcC03_topLevelGlobalAnyKeepsRuntimeObjectAlive() {
        const weak = this.setGlobalAnyAndReturnWeak();
        this.forceGc();
        assertEquals(203, globalAny.id);
        assertNotNull(weak.value);
    }
    setGlobalMarkerAndReturnWeak() {
        const obj = new Payload(204);
        setGlobalMarker(obj);
        return new WeakReference(obj);
    }
    /**
     * RC-C04
     * Scenario: a top-level global variable has static type Marker? and runtime type Payload.
     * Expectation: the runtime object remains alive.
     */
    rcC04_topLevelGlobalInterfaceKeepsRuntimeObjectAlive() {
        const weak = this.setGlobalMarkerAndReturnWeak();
        this.forceGc();
        assertEquals(204, globalMarker.id);
        assertNotNull(weak.value);
    }
    setObjectHolderAndReturnWeak() {
        const obj = new Payload(205);
        GlobalHolder.ref = obj;
        return new WeakReference(obj);
    }
    /**
     * RC-C05
     * Scenario: an object singleton field strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    rcC05_objectSingletonFieldKeepsObjectAlive() {
        const weak = this.setObjectHolderAndReturnWeak();
        this.forceGc();
        assertEquals(205, GlobalHolder.ref.id);
        assertNotNull(weak.value);
    }
    clearObjectHolderAndReturnWeak() {
        const obj = new Payload(206);
        GlobalHolder.ref = obj;
        const weak = new WeakReference(obj);
        GlobalHolder.ref = null;
        return weak;
    }
    /**
     * RC-C06
     * Scenario: an object singleton field is cleared.
     * Expectation: the previously referenced object can be collected.
     */
    rcC06_clearingObjectSingletonFieldAllowsCollection() {
        const weak = this.clearObjectHolderAndReturnWeak();
        this.assertWeakCollected(weak);
    }
    setCompanionHolderAndReturnWeak() {
        const obj = new Payload(207);
        CompanionRootHolder.ref = obj;
        return new WeakReference(obj);
    }
    /**
     * RC-C07
     * Scenario: a companion object field strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    rcC07_companionObjectFieldKeepsObjectAlive() {
        const weak = this.setCompanionHolderAndReturnWeak();
        this.forceGc();
        assertEquals(207, CompanionRootHolder.ref.id);
        assertNotNull(weak.value);
    }
    clearCompanionHolderAndReturnWeak() {
        const obj = new Payload(208);
        CompanionRootHolder.ref = obj;
        const weak = new WeakReference(obj);
        CompanionRootHolder.ref = null;
        return weak;
    }
    /**
     * RC-C08
     * Scenario: a companion object field is cleared.
     * Expectation: the previously referenced object can be collected.
     */
    rcC08_clearingCompanionObjectFieldAllowsCollection() {
        const weak = this.clearCompanionHolderAndReturnWeak();
        this.assertWeakCollected(weak);
    }
}
//# sourceMappingURL=GlobalRootReachabilityTest.js.map