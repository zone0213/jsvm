import "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/KotlinCompat";
export function assertTrue(cond: boolean, msg?: string): void {
    if (!cond)
        throw new Error(msg ?? 'Assertion failed: expected true');
}
export function assertEquals(expected: any, actual: any): void {
    if (expected !== actual)
        throw new Error(`Assertion failed: expected ${expected}, got ${actual}`);
}
export function assertNotNull(x: any, msg?: string): void {
    if (x === null || x === undefined)
        throw new Error(msg ?? 'Assertion failed: value is null or undefined');
}
export function assertNull(x: any, msg?: string): void {
    if (x !== null && x !== undefined)
        throw new Error(msg ?? 'Assertion failed: value is not null');
}
