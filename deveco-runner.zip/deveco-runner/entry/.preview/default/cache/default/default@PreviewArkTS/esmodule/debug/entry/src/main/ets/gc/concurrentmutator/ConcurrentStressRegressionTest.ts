import { assertEquals, assertNotNull, assertTrue } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
import { Node, Holder, WeakReference, forceGc, repeatMutationWithGc, runBoundedConcurrentWriters, stressFieldReplacement, buildChain, buildTree, buildCycle, buildSharedGraph, allocateGarbage, globalHolder, GC, } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class ConcurrentStressRegressionTest {
    cgJ01_stressHighFrequencyFieldReplacement() {
        forceGc();
        const [holder, weak] = stressFieldReplacement(128);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }
    cgJ02_stressHighFrequencyArrayReplacement() {
        const array: Array<Node | null> = [null];
        repeatMutationWithGc(128, (it: number) => { array[0] = new Node(1200 + it); });
        assertNotNull(array[0]);
    }
    cgJ03_stressHighFrequencyListAddRemove() {
        const list: Node[] = [];
        repeatMutationWithGc(128, (it: number) => {
            list.push(new Node(1300 + it));
            if (list.length > 4)
                list.splice(0, 1);
        });
        list.forEach(item => assertTrue(item.id >= 1300));
    }
    cgJ04_stressHighFrequencyMapPutRemove() {
        const map = new Map<number, Node>();
        repeatMutationWithGc(128, (it: number) => {
            map.set(it, new Node(1400 + it));
            map.delete(it - 4);
        });
        map.forEach(value => assertTrue(value.id >= 1400));
    }
    cgJ05_stressHighFrequencySubgraphMove() {
        const child = new Node(1500);
        const weak = new WeakReference(child);
        const p1 = new Node(1501);
        const p2 = new Node(1502);
        repeatMutationWithGc(64, (it: number) => {
            if (it % 2 === 0) {
                p1.left = child;
                p2.left = null;
            }
            else {
                p2.left = child;
                p1.left = null;
            }
        });
        assertNotNull(weak.value);
        assertTrue(p1.left === child || p2.left === child);
    }
    cgJ06_stressProducerConsumerHandoff() {
        const shared = new Holder<Node>(null);
        repeatMutationWithGc(128, (it: number) => { shared.ref = new Node(1600 + it); shared.ref?.id; });
        assertNotNull(shared.ref);
    }
    cgJ07_stressManyWritersReadersGc() {
        const completed = runBoundedConcurrentWriters(4, 32, (w, i) => {
            globalHolder.ref = new Node(1700 + w * 100 + i);
            globalHolder.ref?.id;
            GC.collect();
        });
        assertEquals(4, completed);
    }
    cgJ08_stressAllocationPressureMutation() {
        const holder = new Holder(new Node(1800));
        repeatMutationWithGc(128, (it: number) => { holder.ref = new Node(1800 + it); allocateGarbage(8); });
        assertNotNull(holder.ref);
    }
    cgJ09_stressWeakObserversMutation() {
        const holder = new Holder(new Node(1900));
        const weak = new WeakReference(holder.ref!);
        repeatMutationWithGc(64, (it: number) => { if (it % 2 === 0)
            holder.ref = new Node(1900 + it); });
        assertNotNull(holder.ref);
        forceGc();
        assertTrue(weak.value === null || weak.value!.id >= 1900);
    }
    cgJ10_stressLargeChainAttachDetach() {
        const holder = new Holder<Node>(null);
        repeatMutationWithGc(64, (it: number) => { holder.ref = it % 2 === 0 ? buildChain(8, 2000 + it)[0] : null; });
        forceGc();
        if (holder.ref)
            assertTrue(holder.ref.id >= 2000);
    }
    cgJ11_stressLargeTreeAttachDetach() {
        const holder = new Holder<Node>(null);
        repeatMutationWithGc(64, (it: number) => { holder.ref = it % 2 === 0 ? buildTree(2100 + it)[0] : null; });
        if (holder.ref)
            assertTrue(holder.ref.id >= 2100);
    }
    cgJ12_stressDagSharedParentEdges() {
        const g = buildSharedGraph(2200);
        const weak = new WeakReference(g.shared);
        repeatMutationWithGc(64, (it: number) => {
            if (it % 2 === 0)
                g.parent1.left = g.shared;
            else
                g.parent1.left = null;
            g.parent2.left = g.shared;
        });
        assertNotNull(weak.value);
    }
    cgJ13_stressCycleAttachDetach() {
        const cycle = buildCycle(2300);
        const holder = new Holder<Node>(null);
        repeatMutationWithGc(64, (it: number) => { holder.ref = it % 2 === 0 ? cycle[0] : null; });
        forceGc();
        if (holder.ref)
            assertTrue(holder.ref.id === 2300);
    }
    cgJ14_stressBusyMutatorAllocationGc() {
        const count = repeatMutationWithGc(128, () => allocateGarbage(16));
        assertEquals(128, count);
    }
    cgJ15_stressMixedFieldArrayListMap() {
        const holder = new Holder<Node>(null);
        const array: Array<Node | null> = [null];
        const list: Node[] = [];
        const map = new Map<number, Node>();
        repeatMutationWithGc(128, (it: number) => {
            const n = new Node(2400 + it);
            holder.ref = n;
            array[0] = n;
            list.push(n);
            map.set(it, n);
            if (list.length > 8)
                list.length = 0;
            if (map.size > 8)
                map.clear();
        });
        assertNotNull(holder.ref);
        assertNotNull(array[0]);
    }
    cgJ16_stressRegressionEntryForFuzzCrashReproducer() {
        forceGc();
        const [holder, weak] = stressFieldReplacement(32);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }
}
