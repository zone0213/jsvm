import { GC, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertTrue, assertNotNull, assertNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
const GC_REPEAT_COUNT = 3;
export class GraphTopologyTestSupport {
    beforeTest() {
        this.forceGc();
    }
    afterTest() {
        this.forceGc();
    }
    protected forceGc() {
        for (let i = 0; i < GC_REPEAT_COUNT; i++) {
            GC.collect();
        }
    }
    protected assertWeakAlive<T extends any>(weak: WeakReference<T>, message: string = "Expected object to remain reachable, but WeakReference was cleared."): T {
        this.forceGc();
        const value = weak.value;
        assertNotNull(value, message);
        return value;
    }
    protected assertWeakCollected<T extends any>(weak: WeakReference<T>, message: string = "Expected object to become unreachable and be collected.") {
        this.forceGc();
        weak.clear();
        assertNull(weak.value, message);
    }
    protected assertAllAlive<T extends any>(weaks: Iterable<WeakReference<T>>) {
        let index = 0;
        for (const weak of weaks) {
            assertNotNull(weak.value, `Expected weak[${index}] to remain alive.`);
            index++;
        }
    }
    protected assertAllCollected<T extends any>(weaks: Iterable<WeakReference<T>>) {
        this.forceGc();
        let index = 0;
        for (const weak of weaks) {
            weak.clear();
            assertNull(weak.value, `Expected weak[${index}] to be collected.`);
            index++;
        }
    }
    protected assertDiagnosticCollectedOrAlive(weak: WeakReference<GraphNode>, expectedId: number) {
        this.forceGc();
        const value = weak.value;
        assertTrue(value == null || value.id === expectedId);
    }
    protected buildGraphNodeChain(length: number, startId: number): GraphNode[] {
        if (length <= 0)
            throw new Error("length must be positive");
        const nodes: GraphNode[] = [];
        for (let i = 0; i < length; i++) {
            nodes.push(new GraphNode(startId + i));
        }
        for (let i = 0; i < nodes.length - 1; i++) {
            nodes[i].next = nodes[i + 1];
        }
        return nodes;
    }
    protected buildFullBinaryTree(levels: number, startId: number): GraphNode[] {
        if (levels <= 0)
            throw new Error("levels must be positive");
        const count = (1 << levels) - 1;
        const nodes: GraphNode[] = [];
        for (let i = 0; i < count; i++) {
            nodes.push(new GraphNode(startId + i));
        }
        for (let i = 0; i < nodes.length; i++) {
            const leftIndex = i * 2 + 1;
            const rightIndex = i * 2 + 2;
            if (leftIndex < nodes.length)
                nodes[i].left = nodes[leftIndex];
            if (rightIndex < nodes.length)
                nodes[i].right = nodes[rightIndex];
        }
        return nodes;
    }
    protected buildMultiTree(levels: number, branchingFactor: number, startId: number): MultiNode[] {
        if (levels <= 0)
            throw new Error("levels must be positive");
        if (branchingFactor <= 0)
            throw new Error("branchingFactor must be positive");
        const nodes: MultiNode[] = [];
        const root = new MultiNode(startId);
        nodes.push(root);
        let currentLevel: MultiNode[] = [root];
        let nextId = startId + 1;
        for (let level = 1; level < levels; level++) {
            const nextLevel: MultiNode[] = [];
            for (const parent of currentLevel) {
                for (let i = 0; i < branchingFactor; i++) {
                    const child = new MultiNode(nextId++);
                    parent.children.push(child);
                    nodes.push(child);
                    nextLevel.push(child);
                }
            }
            currentLevel = nextLevel;
        }
        return nodes;
    }
    protected buildCompleteMultiGraph(size: number, startId: number): MultiNode[] {
        if (size <= 0)
            throw new Error("size must be positive");
        const nodes: MultiNode[] = [];
        for (let i = 0; i < size; i++) {
            nodes.push(new MultiNode(startId + i));
        }
        for (const node of nodes) {
            for (const candidate of nodes) {
                if (candidate !== node) {
                    node.children.push(candidate);
                }
            }
        }
        return nodes;
    }
    protected buildHighOutDegreeGraph(childCount: number, startId: number): MultiNode[] {
        if (childCount <= 0)
            throw new Error("childCount must be positive");
        const center = new MultiNode(startId);
        const children: MultiNode[] = [];
        for (let i = 0; i < childCount; i++) {
            children.push(new MultiNode(startId + i + 1));
        }
        center.children.push(...children);
        return [center, ...children];
    }
    protected weakRefs<T extends any>(nodes: T[]): WeakReference<T>[] {
        return nodes.map(node => new WeakReference(node));
    }
}
export class GraphNode {
    next: GraphNode | null = null;
    left: GraphNode | null = null;
    right: GraphNode | null = null;
    constructor(readonly id: number) { }
    toString(): string {
        return `GraphNode(id=${this.id})`;
    }
}
export class MultiNode {
    children: MultiNode[] = [];
    constructor(readonly id: number) { }
    toString(): string {
        return `MultiNode(id=${this.id})`;
    }
}
export class ArrayNode {
    refs: (ArrayNode | null)[];
    constructor(readonly id: number, refCount: number) {
        this.refs = new Array(refCount).fill(null);
    }
    toString(): string {
        return `ArrayNode(id=${this.id})`;
    }
}
export class MapNode {
    refs: Map<string, MapNode> = new Map();
    constructor(readonly id: number) { }
    toString(): string {
        return `MapNode(id=${this.id})`;
    }
}
export class SetNode {
    children: Set<SetNode> = new Set();
    constructor(readonly id: number) { }
    toString(): string {
        return `SetNode(id=${this.id})`;
    }
}
export class RootedWeaks<R, T> {
    constructor(public root: R, public weaks: WeakReference<T>[]) { }
}
export class MixedWeaks<R, T> {
    constructor(public root: R, public aliveWeaks: WeakReference<T>[], public collectedWeaks: WeakReference<T>[]) { }
}
export class ReplacementWeaks<R, T> {
    constructor(public root: R, public oldWeaks: WeakReference<T>[], public newWeaks: WeakReference<T>[]) { }
}
export class GraphRoot<T> {
    ref: T | null;
    constructor(ref: T | null = null) {
        this.ref = ref;
    }
}
export { WeakReference };
