import { assertEquals, assertNotNull, assertNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
import { buildCycle, buildSharedGraph, Holder, Node, WeakReference, forceGc, forceGcLoop, replaceField, runGcAroundMutation, runBoundedConcurrentWriters, repeatMutationWithGc, globalHolder, assertWeakCollectedEventually, assertWeakAlive, } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
export class SharedGraphConcurrentMutationTest {
    cgF01_twoThreadsReadWriteSameHolder() {
        const holder = new Holder(new Node(801));
        const completed = runBoundedConcurrentWriters(2, 16, (_w, i) => {
            holder.ref = new Node(8010 + i);
            assertNotNull(holder.ref);
        });
        assertEquals(2, completed);
        assertNotNull(holder.ref);
    }
    cgF02_twoThreadsAlternatePublishObjects() {
        const completed = runBoundedConcurrentWriters(2, 16, (w, i) => {
            globalHolder.ref = new Node(8020 + w * 100 + i);
        });
        assertEquals(2, completed);
        assertNotNull(globalHolder.ref);
    }
    cgF03_readerKeepsOldObjectLocalWhileWriterReplaces() {
        const oldNode = new Node(803);
        const holder = new Holder(oldNode);
        const weak = new WeakReference(oldNode);
        const local = holder.ref!;
        holder.ref = new Node(804);
        forceGc();
        assertEquals(803, local.id);
        assertNotNull(weak.value);
    }
    cgF04_writerReplacesReaderWeakObservesOld() {
        const result = replaceField(805, 806);
        const holder = result.root;
        assertWeakCollectedEventually(result.oldWeak);
        assertWeakAlive(result.newWeak);
        assertNotNull(holder.ref);
    }
    cgF05_multiThreadUpdateDifferentFields() {
        const root = new Node(807);
        const completed = runBoundedConcurrentWriters(2, 8, (w, i) => {
            if (w === 0)
                root.left = new Node(8070 + i);
            else
                root.right = new Node(8080 + i);
        });
        assertEquals(2, completed);
        assertNotNull(root.left);
        assertNotNull(root.right);
    }
    cgF06_multiThreadUpdateSameField() {
        const root = new Node(809);
        const completed = runBoundedConcurrentWriters(2, 8, (w, i) => {
            root.next = new Node(8090 + w * 100 + i);
        });
        assertEquals(2, completed);
        assertNotNull(root.next);
    }
    cgF07_multiThreadMoveSubgraph() {
        const child = new Node(810);
        const weak = new WeakReference(child);
        const p1 = new Node(811);
        const p2 = new Node(812);
        p1.left = child;
        runGcAroundMutation(() => {
            p1.left = null;
            p2.left = child;
        });
        assertEquals(810, p2.left!.id);
        assertNotNull(weak.value);
    }
    cgF08_producerConsumerHandoff() {
        const shared = new Holder<Node>(null);
        const node = new Node(813);
        runGcAroundMutation(() => { shared.ref = node; });
        const local = shared.ref!;
        forceGc();
        assertEquals(813, local.id);
    }
    cgF09_producerClearsAfterConsumerTakesLocal() {
        const shared = new Holder(new Node(814));
        const local = shared.ref!;
        const weak = new WeakReference(local);
        runGcAroundMutation(() => { shared.ref = null; });
        assertEquals(814, local.id);
        assertNotNull(weak.value);
    }
    cgF10_producerClearsBeforeConsumerReads() {
        const shared = new Holder(new Node(815));
        runGcAroundMutation(() => { shared.ref = null; });
        const local = shared.ref;
        assertNull(local);
    }
    cgF11_sharedCycleGraphMutation() {
        const cycle = buildCycle(816);
        const holder = new Holder(cycle[0]);
        runGcAroundMutation(() => { holder.ref = cycle[1]; });
        assertEquals(817, holder.ref!.id);
    }
    cgF12_sharedDagParentMutation() {
        const g = buildSharedGraph(820);
        const weak = new WeakReference(g.shared);
        runGcAroundMutation(() => {
            g.parent1.left = null;
            g.parent2.right = g.shared;
        });
        assertNotNull(weak.value);
    }
    cgF13_manyWritersOneGcThread() {
        const holders = Array.from({ length: 4 }, () => new Holder<Node>(null));
        const completed = runBoundedConcurrentWriters(4, 16, (w, i) => {
            holders[w].ref = new Node(8300 + w * 100 + i);
        });
        forceGcLoop();
        assertEquals(4, completed);
        holders.forEach(holder => assertNotNull(holder.ref));
    }
    cgF14_manyWritersReadersAndGc() {
        const holders = Array.from({ length: 4 }, (_, i) => new Holder(new Node(8400 + i)));
        const count = repeatMutationWithGc(64, (i: number) => {
            holders[i % 4].ref = new Node(8400 + i);
            holders.forEach(holder => holder.ref?.id);
        });
        assertEquals(64, count);
    }
}
