import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import UIAbility from "@ohos:app.ability.UIAbility";
import type Want from "@ohos:app.ability.Want";
import hilog from "@ohos:hilog";
import type window from "@ohos:window";
const DOMAIN = 0x0000;
const TAG = 'GcRunner';
export default class EntryAbility extends UIAbility {
    onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
        hilog.info(DOMAIN, TAG, 'EntryAbility onCreate');
    }
    onDestroy(): void {
        hilog.info(DOMAIN, TAG, 'EntryAbility onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage): void {
        windowStage.loadContent('pages/Index', (error) => {
            if (error.code) {
                hilog.error(DOMAIN, TAG, 'Failed to load page. code: %{public}d', error.code);
            }
        });
    }
    onWindowStageDestroy(): void {
        hilog.info(DOMAIN, TAG, 'EntryAbility onWindowStageDestroy');
    }
    onForeground(): void {
        hilog.info(DOMAIN, TAG, 'EntryAbility onForeground');
    }
    onBackground(): void {
        hilog.info(DOMAIN, TAG, 'EntryAbility onBackground');
    }
}
