// @ts-nocheck
import { WeakReferenceTestSupport, Payload, WeakHolder, Root, WeakOnlyResult, MixedWeakResult } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/strongweak/WeakReferenceTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * WR-C group: weak edge does not participate in object graph reachability.
 */
export class WeakEdgeGraphTest extends WeakReferenceTestSupport {
    createParentWeakChild() {
        const parent = new Payload(301);
        const child = new Payload(302);
        parent.weak = new WeakReference(child);
        return new WeakOnlyResult(new Root(parent), parent.weak);
    }
    /**
     * WR-C01
     * Scenario: root -> parent and parent weakly points to child.
     * Expectation: parent survives, but child can be collected.
     */
    wrC01_parentWeakChildDoesNotKeepChildAlive() {
        const scenario = this.createParentWeakChild();
        this.forceGc();
        assertEquals(301, scenario.root.ref.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createParentStrongChild() {
        const parent = new Payload(303);
        const child = new Payload(304);
        parent.strong = child;
        return new WeakOnlyResult(new Root(parent), new WeakReference(child));
    }
    /**
     * WR-C02
     * Scenario: root -> parent and parent strongly points to child.
     * Expectation: both parent and child survive.
     */
    wrC02_parentStrongChildKeepsChildAlive() {
        const scenario = this.createParentStrongChild();
        this.forceGc();
        assertEquals(303, scenario.root.ref.id);
        assertEquals(304, scenario.root.ref.strong.id);
        assertNotNull(scenario.weak.value);
    }
    createParentStrongAndWeakChild() {
        const parent = new Payload(305);
        const child = new Payload(306);
        parent.strong = child;
        parent.weak = new WeakReference(child);
        return new WeakOnlyResult(new Root(parent), parent.weak);
    }
    /**
     * WR-C03
     * Scenario: parent has both strong and weak edges to child.
     * Expectation: child survives because of the strong edge.
     */
    wrC03_parentStrongAndWeakChildKeepsChildAlive() {
        const scenario = this.createParentStrongAndWeakChild();
        this.forceGc();
        assertEquals(306, scenario.root.ref.strong.id);
        assertNotNull(scenario.weak.value);
    }
    createParentAfterClearingStrongChild() {
        const parent = new Payload(307);
        const child = new Payload(308);
        parent.strong = child;
        parent.weak = new WeakReference(child);
        parent.strong = null;
        return new WeakOnlyResult(new Root(parent), parent.weak);
    }
    /**
     * WR-C04
     * Scenario: parent initially has strong and weak edges to child, then strong edge is cleared.
     * Expectation: child can be collected and weak.value becomes null.
     */
    wrC04_clearingStrongChildLeavesOnlyWeakAndCollectsChild() {
        const scenario = this.createParentAfterClearingStrongChild();
        this.forceGc();
        assertEquals(307, scenario.root.ref.id);
        assertNull(scenario.root.ref.strong);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createChildWeakParentWithOnlyChildRoot() {
        const parent = new Payload(309);
        const child = new Payload(310);
        child.weak = new WeakReference(parent);
        return new WeakOnlyResult(new Root(child), child.weak);
    }
    /**
     * WR-C05
     * Scenario: root points to child, and child weakly points to parent.
     * Expectation: parent is not kept alive by child's weak edge.
     */
    wrC05_childWeakParentDoesNotKeepParentAlive() {
        const scenario = this.createChildWeakParentWithOnlyChildRoot();
        this.forceGc();
        assertEquals(310, scenario.root.ref.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    /**
     * WR-C06
     * Scenario: root points to parent and child weakly points to parent.
     * Expectation: parent survives because of root, and child weak reference sees a non-null value.
     */
    wrC06_childWeakParentSeesParentAliveWhenParentHasRoot() {
        const parent = new Payload(311);
        const child = new Payload(312);
        child.weak = new WeakReference(parent);
        const root = new Root(parent);
        this.forceGc();
        assertEquals(311, root.ref.id);
        assertNotNull(child.weak.value);
        assertEquals(312, child.id);
    }
    createSiblingWeakEdge() {
        const left = new Payload(313);
        const right = new Payload(314);
        left.weak = new WeakReference(right);
        return new WeakOnlyResult(new Root(left), left.weak);
    }
    /**
     * WR-C07
     * Scenario: root -> left and left weakly points to right sibling.
     * Expectation: right sibling can be collected.
     */
    wrC07_siblingWeakEdgeDoesNotKeepRightSiblingAlive() {
        const scenario = this.createSiblingWeakEdge();
        this.forceGc();
        assertEquals(313, scenario.root.ref.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createSiblingStrongEdge() {
        const left = new Payload(315);
        const right = new Payload(316);
        left.strong = right;
        return new WeakOnlyResult(new Root(left), new WeakReference(right));
    }
    /**
     * WR-C08
     * Scenario: root -> left and left strongly points to right sibling.
     * Expectation: right sibling survives.
     */
    wrC08_siblingStrongEdgeKeepsRightSiblingAlive() {
        const scenario = this.createSiblingStrongEdge();
        this.forceGc();
        assertEquals(316, scenario.root.ref.strong.id);
        assertNotNull(scenario.weak.value);
    }
    createWeakGrandchild() {
        const parent = new Payload(317);
        const grandChild = new Payload(318);
        parent.weak = new WeakReference(grandChild);
        return new WeakOnlyResult(new Root(parent), parent.weak);
    }
    /**
     * WR-C09
     * Scenario: root -> parent and parent weakly points to grandchild.
     * Expectation: grandchild can be collected.
     */
    wrC09_weakEdgeToGrandChildDoesNotKeepGrandChildAlive() {
        const scenario = this.createWeakGrandchild();
        this.forceGc();
        assertEquals(317, scenario.root.ref.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    createStrongChildWeakGrandchild() {
        const parent = new Payload(319);
        const child = new Payload(320);
        const grandChild = new Payload(321);
        parent.strong = child;
        child.weak = new WeakReference(grandChild);
        return new WeakOnlyResult(new Root(parent), child.weak);
    }
    /**
     * WR-C10
     * Scenario: root -> parent -> child, and child weakly points to grandchild.
     * Expectation: parent and child survive, but grandchild can be collected.
     */
    wrC10_strongChildWeakGrandChildDoesNotKeepGrandChildAlive() {
        const scenario = this.createStrongChildWeakGrandchild();
        this.forceGc();
        assertEquals(320, scenario.root.ref.strong.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    /**
     * WR-C11
     * Scenario: target is strongly reachable from root and also weakly referenced by another holder.
     * Expectation: target survives and weak.value is non-null.
     */
    wrC11_weakEdgeToAlreadyStrongReachableTargetRemainsNonNull() {
        const target = new Payload(322);
        const holder = new WeakHolder(new WeakReference(target));
        const root = new Root(target);
        this.forceGc();
        assertEquals(322, root.ref.id);
        assertNotNull(holder.weak.value);
    }
    createWeakEdgeToSubgraphRoot() {
        const subRoot = new Payload(323);
        const leaf = new Payload(324);
        subRoot.strong = leaf;
        const weakSubRoot = new WeakReference(subRoot);
        const weakLeaf = new WeakReference(leaf);
        const holder = new WeakHolder(weakSubRoot);
        return new MixedWeakResult(new Root(holder), [], [weakSubRoot, weakLeaf]);
        ;
    }
    /**
     * WR-C12
     * Scenario: holder weakly points to the root of a child subgraph.
     * Expectation: weak edge does not keep either subgraph root or leaf alive.
     */
    wrC12_weakEdgeToSubgraphRootDoesNotKeepSubgraphAlive() {
        const scenario = this.createWeakEdgeToSubgraphRoot();
        this.forceGc();
        assertNotNull(scenario.root.ref);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
}
//# sourceMappingURL=WeakEdgeGraphTest.js.map