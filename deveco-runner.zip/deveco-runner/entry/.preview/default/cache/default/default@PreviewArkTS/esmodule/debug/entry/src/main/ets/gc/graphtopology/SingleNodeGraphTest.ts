import { GraphTopologyTestSupport, GraphRoot, GraphNode, RootedWeaks, ReplacementWeaks, WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/graphtopology/GraphTopologyTestSupport";
import { assertEquals, assertNull } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
/** GT-A group: single-node graph tests. */
export class SingleNodeGraphTest extends GraphTopologyTestSupport {
    private singleNodeRoot(id: number): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const node = new GraphNode(id);
        return new RootedWeaks(new GraphRoot(node), [new WeakReference(node)]);
    }
    /** GT-A01: root directly keeps a single-node graph alive. */
    gtA01_singleNodeGraphRootKeepsNodeAlive() {
        const scenario = this.singleNodeRoot(101);
        this.forceGc();
        assertEquals(101, scenario.root.ref!.id);
        this.assertAllAlive(scenario.weaks);
    }
    private singleNodeAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const node = new GraphNode(102);
        const root = new GraphRoot(node);
        const weak = new WeakReference(node);
        root.ref = null;
        return new RootedWeaks(root, [weak]);
    }
    /** GT-A02: clearing root allows the single node to be collected. */
    gtA02_clearingRootAllowsSingleNodeCollection() {
        const scenario = this.singleNodeAfterRootClear();
        assertNull(scenario.root.ref);
        this.assertAllCollected(scenario.weaks);
    }
    private singleNodeReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        const oldNode = new GraphNode(103);
        const root = new GraphRoot(oldNode);
        const oldWeak = new WeakReference(oldNode);
        const newNode = new GraphNode(130);
        root.ref = newNode;
        const newWeak = new WeakReference(newNode);
        return new ReplacementWeaks(root, [oldWeak], [newWeak]);
    }
    /** GT-A03: replacing root releases the old node and keeps the new node alive. */
    gtA03_replacingSingleNodeRootReleasesOldNodeAndKeepsNewNodeAlive() {
        const scenario = this.singleNodeReplacement();
        this.forceGc();
        this.assertAllCollected(scenario.oldWeaks);
        this.assertAllAlive(scenario.newWeaks);
        assertEquals(130, scenario.root.ref!.id);
    }
    /** GT-A04: a single node with an empty next field remains alive through root. */
    gtA04_singleNodeWithEmptyReferenceFieldRemainsAlive() {
        const scenario = this.singleNodeRoot(104);
        scenario.root.ref!.next = null;
        this.forceGc();
        assertEquals(104, scenario.root.ref!.id);
        assertNull(scenario.root.ref!.next);
        this.assertAllAlive(scenario.weaks);
    }
    /** GT-A05: a single node with multiple empty reference fields remains alive through root. */
    gtA05_singleNodeWithMultipleEmptyReferenceFieldsRemainsAlive() {
        const scenario = this.singleNodeRoot(105);
        scenario.root.ref!.next = null;
        scenario.root.ref!.left = null;
        scenario.root.ref!.right = null;
        this.forceGc();
        assertEquals(105, scenario.root.ref!.id);
        assertNull(scenario.root.ref!.left);
        assertNull(scenario.root.ref!.right);
        this.assertAllAlive(scenario.weaks);
    }
    private weakOnlySingleNode(): WeakReference<GraphNode> {
        const node = new GraphNode(106);
        return new WeakReference(node);
    }
    /** GT-A06: a helper creates a single node and only WeakReference escapes. */
    gtA06_weakOnlySingleNodeCanBeCollected() {
        this.assertWeakCollected(this.weakOnlySingleNode());
    }
}
