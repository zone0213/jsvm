// @ts-nocheck
import { ReachabilityTestSupport, Payload, RootedWeak, HolderReplacementResult } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/reachability/ReachabilityTestSupport';
import { WeakReference } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull } from '@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions';
/**
 * E group: reachability through arrays and Kotlin collections.
 */
export class ArrayCollectionReachabilityTest extends ReachabilityTestSupport {
    createArrayRoot() {
        const obj = new Payload(401);
        const array = new Array(1).fill(null);
        array[0] = obj;
        return new RootedWeak(array, new WeakReference(obj));
    }
    /**
     * RC-E01
     * Scenario: an array element strongly references a Payload.
     * Expectation: the element target remains reachable through the root array.
     */
    rcE01_arrayElementKeepsObjectAlive() {
        const scenario = this.createArrayRoot();
        this.forceGc();
        assertEquals(401, scenario.root[0].id);
        assertNotNull(scenario.weak.value);
    }
    createArrayClearedElementRoot() {
        const obj = new Payload(402);
        const array = new Array(1).fill(null);
        array[0] = obj;
        const weak = new WeakReference(obj);
        array[0] = null;
        return new RootedWeak(array, weak);
    }
    /**
     * RC-E02
     * Scenario: an array element is set to null.
     * Expectation: after the helper stack frame returns, the former element object can be collected.
     */
    rcE02_clearingArrayElementAllowsCollection() {
        const scenario = this.createArrayClearedElementRoot();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root[0]);
    }
    createArrayReplacementRoot() {
        const oldObj = new Payload(403);
        const array = new Array(1).fill(null);
        array[0] = oldObj;
        const oldWeak = new WeakReference(oldObj);
        const newObj = new Payload(430);
        array[0] = newObj;
        const newWeak = new WeakReference(newObj);
        return new HolderReplacementResult(array, oldWeak, newWeak);
    }
    /**
     * RC-E03
     * Scenario: an array element is replaced.
     * Expectation: the old element can be collected, while the new element remains reachable.
     */
    rcE03_arrayElementReplacementReleasesOldObjectAndKeepsNewObjectAlive() {
        const result = this.createArrayReplacementRoot();
        this.forceGc();
        result.oldWeak.clear();
        assertNull(result.oldWeak.value);
        assertNotNull(result.newWeak.value);
        assertEquals(430, result.holder[0].id);
    }
    createListRoot() {
        const obj = new Payload(404);
        const list = [obj];
        return new RootedWeak(list, new WeakReference(obj));
    }
    /**
     * RC-E04
     * Scenario: a MutableList element strongly references a Payload.
     * Expectation: the list element remains reachable through the root list.
     */
    rcE04_mutableListElementKeepsObjectAlive() {
        const scenario = this.createListRoot();
        this.forceGc();
        assertEquals(404, scenario.root[0].id);
        assertNotNull(scenario.weak.value);
    }
    createListAfterRemove() {
        const obj = new Payload(405);
        const list = [obj];
        const weak = new WeakReference(obj);
        list.remove(obj);
        return new RootedWeak(list, weak);
    }
    /**
     * RC-E05
     * Scenario: a MutableList element is removed.
     * Expectation: the removed object can be collected.
     */
    rcE05_mutableListRemoveAllowsCollection() {
        const scenario = this.createListAfterRemove();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    createListAfterClear() {
        const obj = new Payload(406);
        const list = [obj];
        const weak = new WeakReference(obj);
        list.clear();
        return new RootedWeak(list, weak);
    }
    /**
     * RC-E06
     * Scenario: a MutableList is cleared.
     * Expectation: the previously contained object can be collected.
     */
    rcE06_mutableListClearAllowsCollection() {
        const scenario = this.createListAfterClear();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    createMapKeyRoot() {
        const key = new Payload(407);
        const map = new Map([[key, "value"]]);
        return new RootedWeak(map, new WeakReference(key));
    }
    /**
     * RC-E07
     * Scenario: a MutableMap key strongly references a Payload.
     * Expectation: the key remains reachable through the root map.
     */
    rcE07_mutableMapKeyKeepsObjectAlive() {
        const scenario = this.createMapKeyRoot();
        this.forceGc();
        const key = Array.from(scenario.root.keys()).single();
        assertEquals(407, key.id);
        assertNotNull(scenario.weak.value);
    }
    createMapValueRoot() {
        const value = new Payload(408);
        const map = new Map([["key", value]]);
        return new RootedWeak(map, new WeakReference(value));
    }
    /**
     * RC-E08
     * Scenario: a MutableMap value strongly references a Payload.
     * Expectation: the value remains reachable through the root map.
     */
    rcE08_mutableMapValueKeepsObjectAlive() {
        const scenario = this.createMapValueRoot();
        this.forceGc();
        assertEquals(408, scenario.root.get("key").id);
        assertNotNull(scenario.weak.value);
    }
    createMapAfterRemovingPayloadKey() {
        const key = new Payload(409);
        const map = new Map([[key, "value"]]);
        const weak = new WeakReference(key);
        map.remove(key);
        return new RootedWeak(map, weak);
    }
    /**
     * RC-E09
     * Scenario: a MutableMap entry is removed by its Payload key.
     * Expectation: the removed key object can be collected.
     */
    rcE09_mutableMapRemoveKeyAllowsKeyCollection() {
        const scenario = this.createMapAfterRemovingPayloadKey();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    createMapAfterRemovingPayloadValue() {
        const value = new Payload(410);
        const map = new Map([["key", value]]);
        const weak = new WeakReference(value);
        map.remove("key");
        return new RootedWeak(map, weak);
    }
    /**
     * RC-E10
     * Scenario: a MutableMap entry containing a Payload value is removed.
     * Expectation: the removed value object can be collected.
     */
    rcE10_mutableMapRemoveEntryAllowsValueCollection() {
        const scenario = this.createMapAfterRemovingPayloadValue();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    createNestedListRoot() {
        const obj = new Payload(411);
        const inner = [obj];
        const outer = [inner];
        return new RootedWeak(outer, new WeakReference(obj));
    }
    /**
     * RC-E11
     * Scenario: a nested collection path reaches Payload through outer[0][0].
     * Expectation: the object remains reachable through the nested collection path.
     */
    rcE11_nestedCollectionKeepsObjectAlive() {
        const scenario = this.createNestedListRoot();
        this.forceGc();
        assertEquals(411, scenario.root[0][0].id);
        assertNotNull(scenario.weak.value);
    }
    createNestedListAfterClear() {
        const obj = new Payload(412);
        const inner = [obj];
        const outer = [inner];
        const weak = new WeakReference(obj);
        inner.clear();
        return new RootedWeak(outer, weak);
    }
    /**
     * RC-E12
     * Scenario: the inner collection in a nested collection path is cleared.
     * Expectation: the previously contained object can be collected.
     */
    rcE12_nestedCollectionClearAllowsCollection() {
        const scenario = this.createNestedListAfterClear();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root[0].size);
    }
}
//# sourceMappingURL=ArrayCollectionReachabilityTest.js.map