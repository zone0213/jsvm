import { PreciseStackTestSupport, StackPayload, StackHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/precisestack/PreciseStackTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class PreciseStackSafepointReturnTest extends PreciseStackTestSupport {
    psI01_storedReturnValueSurvivesGcBeforeUse() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psI02_returnValuePassedAsCallArgumentSurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psI03_anyTypedReturnValueSurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psI04_interfaceTypedReturnValueSurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psI05_genericReturnValueSurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
