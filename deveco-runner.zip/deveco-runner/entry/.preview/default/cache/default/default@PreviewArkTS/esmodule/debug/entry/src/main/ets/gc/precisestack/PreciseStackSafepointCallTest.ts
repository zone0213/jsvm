import { PreciseStackTestSupport, StackPayload, StackHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/precisestack/PreciseStackTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class PreciseStackSafepointCallTest extends PreciseStackTestSupport {
    psG01_singleReferenceParameterSurvivesCalleeGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psG02_multipleReferenceParametersSurviveCalleeGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psG03_referenceParameterMixedWithPrimitiveParametersSurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psG04_anyTypedParameterSurvivesCalleeGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psG05_genericParameterSurvivesCalleeGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
