import { PreciseStackTestSupport, StackPayload, StackHolder } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/precisestack/PreciseStackTestSupport";
import { WeakReference } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/concurrentmutator/ConcurrentGcTestSupport";
import { assertEquals } from "@bundle:com.example.gcreachabilityrunner/entry/ets/gc/TestAssertions";
export class PreciseStackSafepointExpressionTest extends PreciseStackTestSupport {
    psH01_constructorCallArgumentTemporarySurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psH02_safeCallExpressionTemporarySurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psH03_castExpressionTemporarySurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psH04_collectionExpressionTemporarySurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
    psH05_holderExpressionTemporarySurvivesGc() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);
    }
}
