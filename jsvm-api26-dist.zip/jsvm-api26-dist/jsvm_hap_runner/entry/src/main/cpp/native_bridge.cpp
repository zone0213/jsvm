#include <cstddef>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <chrono>
#include <unistd.h>
#include <sys/types.h>
#include <vector>

// external-arraybuffer 实验性接口需在 include 前定义（见 use-jsvm-about-external-arraybuffer.md）
#define JSVM_EXPERIMENTAL
#include "ark_runtime/jsvm.h"
#include "hilog/log.h"
#include "napi/native_api.h"

namespace {

constexpr unsigned int JSVM_LOG_DOMAIN = 0x3200;
constexpr const char* JSVM_LOG_TAG = "JSVMDataTypesRunner";
constexpr const char* FILE_DIR = "/data/storage/el2/base/files";
constexpr const char* HEAP_BEGIN_PATH = "/data/storage/el2/base/files/heap-snapshot-begin.heapsnapshot";
constexpr const char* CPU_PROFILE_PATH = "/data/storage/el2/base/files/cpu-profile.cpuprofile";
constexpr const char* HEAP_END_PATH = "/data/storage/el2/base/files/heap-snapshot-end.heapsnapshot";

std::once_flag g_initFlag;
JSVM_Status g_initStatus = JSVM_OK;

struct StreamTarget {
    std::ofstream stream;
    std::string path;
    size_t bytes = 0;
    bool writeError = false;
};

void InitJsvmOnce()
{
    JSVM_InitOptions initOptions;
    std::memset(&initOptions, 0, sizeof(initOptions));
    g_initStatus = OH_JSVM_Init(&initOptions);
}

bool CheckStatus(JSVM_Status status, const char* call, std::ostringstream& output)
{
    if (status == JSVM_OK) {
        return true;
    }

    output << call << " failed: " << static_cast<int>(status) << "\n";
    return false;
}

long long GetFileSize(const char* path)
{
    struct stat fileStat;
    if (stat(path, &fileStat) != 0) {
        return -1;
    }
    return static_cast<long long>(fileStat.st_size);
}

bool JSVM_CDECL OutputStream(const char* data, int size, void* streamData)
{
    StreamTarget* target = static_cast<StreamTarget*>(streamData);
    if (target == nullptr) {
        return false;
    }
    if (data == nullptr) {
        target->stream.close();
        return true;
    }
    if (size > 0) {
        target->stream.write(data, size);
        if (!target->stream.good()) {
            target->writeError = true;
            return false;
        }
        target->bytes += static_cast<size_t>(size);
    }
    return true;
}

StreamTarget OpenStream(const char* path)
{
    StreamTarget target;
    target.path = path;
    target.stream.open(path, std::ios::out | std::ios::binary | std::ios::trunc);
    return target;
}

bool TakeHeapSnapshot(JSVM_VM vm, const char* path, std::ostringstream& output)
{
    StreamTarget target = OpenStream(path);
    if (!target.stream.is_open()) {
        output << "open " << path << " failed\n";
        return false;
    }
    if (!CheckStatus(OH_JSVM_TakeHeapSnapshot(vm, OutputStream, &target), "OH_JSVM_TakeHeapSnapshot", output)) {
        target.stream.close();
        return false;
    }
    target.stream.close();
    if (target.writeError) {
        output << "write " << path << " failed\n";
        return false;
    }
    return true;
}

bool StopCpuProfiler(JSVM_VM vm, JSVM_CpuProfiler profiler, const char* path, std::ostringstream& output)
{
    StreamTarget target = OpenStream(path);
    if (!target.stream.is_open()) {
        output << "open " << path << " failed\n";
        return false;
    }
    if (!CheckStatus(OH_JSVM_StopCpuProfiler(vm, profiler, OutputStream, &target), "OH_JSVM_StopCpuProfiler", output)) {
        target.stream.close();
        return false;
    }
    target.stream.close();
    if (target.writeError) {
        output << "write " << path << " failed\n";
        return false;
    }
    return true;
}

JSVM_Value ConsoleInfo(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value args[1] = {nullptr};
    void* data = nullptr;
    char log[256] = {};
    size_t logLength = 0;

    JSVM_Status status = OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, &data);
    std::ostringstream* output = static_cast<std::ostringstream*>(data);
    if (status != JSVM_OK || argc < 1 || args[0] == nullptr) {
        if (output != nullptr) {
            *output << "consoleinfo: missing argument\n";
        }
        JSVM_Value undefinedValue = nullptr;
        OH_JSVM_GetUndefined(env, &undefinedValue);
        return undefinedValue;
    }

    status = OH_JSVM_GetValueStringUtf8(env, args[0], log, sizeof(log) - 1, &logLength);
    if (status != JSVM_OK) {
        if (output != nullptr) {
            *output << "consoleinfo: GetValueStringUtf8 failed: " << static_cast<int>(status) << "\n";
        }
        JSVM_Value undefinedValue = nullptr;
        OH_JSVM_GetUndefined(env, &undefinedValue);
        return undefinedValue;
    }

    log[sizeof(log) - 1] = '\0';
    if (output != nullptr) {
        *output << "JSVM API TEST: " << log << "\n";
    }
    OH_LOG_Print(LOG_APP, LOG_INFO, JSVM_LOG_DOMAIN, JSVM_LOG_TAG, "JSVM API TEST: %{public}s", log);

    JSVM_Value undefinedValue = nullptr;
    OH_JSVM_GetUndefined(env, &undefinedValue);
    return undefinedValue;
}

JSVM_Value Add(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 2;
    JSVM_Value args[2] = {nullptr, nullptr};
    double num1 = 0;
    double num2 = 0;
    JSVM_Value sum = nullptr;

    JSVM_Status status = OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    if (status != JSVM_OK || argc < 2 || args[0] == nullptr || args[1] == nullptr) {
        JSVM_Value undefinedValue = nullptr;
        OH_JSVM_GetUndefined(env, &undefinedValue);
        return undefinedValue;
    }

    if (OH_JSVM_GetValueDouble(env, args[0], &num1) != JSVM_OK ||
        OH_JSVM_GetValueDouble(env, args[1], &num2) != JSVM_OK ||
        OH_JSVM_CreateDouble(env, num1 + num2, &sum) != JSVM_OK) {
        JSVM_Value undefinedValue = nullptr;
        OH_JSVM_GetUndefined(env, &undefinedValue);
        return undefinedValue;
    }

    return sum;
}

std::string RunJsvmSmokeInternal()
{
    std::ostringstream output;

    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));

    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    JSVM_HandleScope handleScope = nullptr;

    auto finish = [&]() {
        if (handleScope != nullptr && env != nullptr) {
            OH_JSVM_CloseHandleScope(env, handleScope);
        }
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct callbacks[] = {
        {.callback = ConsoleInfo, .data = &output},
        {.callback = Add, .data = nullptr},
    };
    JSVM_PropertyDescriptor descriptors[] = {
        {"consoleinfo", nullptr, &callbacks[0], nullptr, nullptr, nullptr, JSVM_DEFAULT},
        {"add", nullptr, &callbacks[1], nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(descriptors) / sizeof(descriptors[0]), descriptors, &env),
        "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }

    const std::string source =
        "const value = add(4.96, 5.28);\n"
        "consoleinfo('Result is:' + value);\n"
        "value;";

    JSVM_Value sourceValue = nullptr;
    if (!CheckStatus(OH_JSVM_CreateStringUtf8(env, source.c_str(), source.size(), &sourceValue),
        "OH_JSVM_CreateStringUtf8", output)) {
        finish();
        return output.str();
    }

    JSVM_Script script = nullptr;
    if (!CheckStatus(OH_JSVM_CompileScript(env, sourceValue, nullptr, 0, true, nullptr, &script),
        "OH_JSVM_CompileScript", output)) {
        finish();
        return output.str();
    }

    JSVM_Value result = nullptr;
    if (!CheckStatus(OH_JSVM_RunScript(env, script, &result), "OH_JSVM_RunScript", output)) {
        finish();
        return output.str();
    }

    double resultNumber = 0;
    if (!CheckStatus(OH_JSVM_GetValueDouble(env, result, &resultNumber), "OH_JSVM_GetValueDouble", output)) {
        finish();
        return output.str();
    }

    char buffer[64] = {};
    std::snprintf(buffer, sizeof(buffer), "%.2f", resultNumber);
    output << "JSVM API TEST result: " << buffer << "\n";

    std::string finalOutput = output.str();
    OH_LOG_Print(LOG_APP, LOG_INFO, JSVM_LOG_DOMAIN, JSVM_LOG_TAG, "%{public}s", finalOutput.c_str());
    finish();
    return finalOutput;
}

const std::string PROFILER_SOURCE = R"JS(
function sleep(delay) {
    var start = (new Date()).getTime();
    while ((new Date()).getTime() - start < delay) {
        continue;
    }
}

function work3() {
    sleep(300);
}

function work2() {
    work3();
    sleep(200);
}

function work1() {
    work2();
    sleep(100);
}

work1();
)JS";

JSVM_Value RunScriptWithStatistics(JSVM_Env env, JSVM_CallbackInfo info)
{
    std::ostringstream* output = nullptr;
    JSVM_Status status = OH_JSVM_GetCbInfo(env, info, nullptr, nullptr, nullptr, reinterpret_cast<void**>(&output));

    auto append = [&](const std::string& message) {
        if (output != nullptr) {
            *output << message << "\n";
        }
    };

    JSVM_Value undefinedValue = nullptr;
    OH_JSVM_GetUndefined(env, &undefinedValue);

    if (status != JSVM_OK) {
        append("OH_JSVM_GetCbInfo failed: " + std::to_string(static_cast<int>(status)));
        return undefinedValue;
    }

    JSVM_VM vm = nullptr;
    if (status = OH_JSVM_GetVM(env, &vm); status != JSVM_OK) {
        append("OH_JSVM_GetVM failed: " + std::to_string(static_cast<int>(status)));
        return undefinedValue;
    }

    if (output != nullptr) {
        *output << "Writing profiler files under " << FILE_DIR << "\n";
    }
    if (!TakeHeapSnapshot(vm, HEAP_BEGIN_PATH, *output)) {
        return undefinedValue;
    }

    JSVM_CpuProfiler cpuProfiler = nullptr;
    if (!CheckStatus(OH_JSVM_StartCpuProfiler(vm, &cpuProfiler), "OH_JSVM_StartCpuProfiler", *output)) {
        return undefinedValue;
    }

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", *output)) {
        StopCpuProfiler(vm, cpuProfiler, CPU_PROFILE_PATH, *output);
        return undefinedValue;
    }

    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = CheckStatus(OH_JSVM_CreateStringUtf8(env, PROFILER_SOURCE.c_str(), PROFILER_SOURCE.size(), &jsSrc),
        "OH_JSVM_CreateStringUtf8", *output) &&
        CheckStatus(OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script),
            "OH_JSVM_CompileScript", *output) &&
        CheckStatus(OH_JSVM_RunScript(env, script, &result), "OH_JSVM_RunScript", *output);

    OH_JSVM_CloseHandleScope(env, handleScope);

    if (!StopCpuProfiler(vm, cpuProfiler, CPU_PROFILE_PATH, *output)) {
        return undefinedValue;
    }
    if (!TakeHeapSnapshot(vm, HEAP_END_PATH, *output)) {
        return undefinedValue;
    }
    if (!ok) {
        return undefinedValue;
    }

    append("RunScriptWithStatistics completed");
    return undefinedValue;
}

std::string RunProfilerSnapshotInternal()
{
    std::ostringstream output;

    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));

    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    JSVM_HandleScope handleScope = nullptr;

    auto finish = [&]() {
        if (handleScope != nullptr && env != nullptr) {
            OH_JSVM_CloseHandleScope(env, handleScope);
        }
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct callback = {.callback = RunScriptWithStatistics, .data = &output};
    JSVM_PropertyDescriptor descriptor = {
        "runScriptWithStatistics", nullptr, &callback, nullptr, nullptr, nullptr, JSVM_DEFAULT};

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, 1, &descriptor, &env), "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }

    const char* source = "runScriptWithStatistics();";
    JSVM_Value sourceValue = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;

    if (CheckStatus(OH_JSVM_CreateStringUtf8(env, source, JSVM_AUTO_LENGTH, &sourceValue),
            "OH_JSVM_CreateStringUtf8", output) &&
        CheckStatus(OH_JSVM_CompileScript(env, sourceValue, nullptr, 0, true, nullptr, &script),
            "OH_JSVM_CompileScript", output) &&
        CheckStatus(OH_JSVM_RunScript(env, script, &result), "OH_JSVM_RunScript", output)) {
        output << "Native call script completed\n";
    }

    const long long heapBeginSize = GetFileSize(HEAP_BEGIN_PATH);
    const long long cpuProfileSize = GetFileSize(CPU_PROFILE_PATH);
    const long long heapEndSize = GetFileSize(HEAP_END_PATH);
    output << "heap-snapshot-begin.heapsnapshot: " << heapBeginSize << " bytes\n";
    output << "cpu-profile.cpuprofile: " << cpuProfileSize << " bytes\n";
    output << "heap-snapshot-end.heapsnapshot: " << heapEndSize << " bytes\n";

    if (heapBeginSize > 0 && cpuProfileSize > 0 && heapEndSize > 0) {
        output << "Profiler/Snapshot test: PASSED\n";
    } else {
        output << "Profiler/Snapshot test: CHECK OUTPUT\n";
    }

    std::string finalOutput = output.str();
    OH_LOG_Print(LOG_APP, LOG_INFO, JSVM_LOG_DOMAIN, JSVM_LOG_TAG, "%{public}s", finalOutput.c_str());
    finish();
    return finalOutput;
}

napi_value RunJsvmSmoke(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunJsvmSmokeInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

napi_value RunProfilerSnapshot(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunProfilerSnapshotInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

// ---- use-jsvm-about-debug-option.md 验证 ----
// 复刻 use-jsvm-process.md hello.cpp 的 IsStrictEquals 回调、descriptor、srcCallNative，
// 文档“执行结果”里的 NewString/GetCbInfo/StrictEquals/GetBoolean/IsBoolean 日志来自这套回调。

static JSVM_Value DebugOption_IsStrictEquals(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 2;
    JSVM_Value args[2] = {nullptr, nullptr};
    JSVM_Status st = OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    if (st != JSVM_OK) {
        OH_LOG_ERROR(LOG_APP, "JSVM OH_JSVM_GetCbInfo: failed");
        JSVM_Value u = nullptr;
        OH_JSVM_GetUndefined(env, &u);
        return u;
    }
    bool result = false;
    st = OH_JSVM_StrictEquals(env, args[0], args[1], &result);
    if (st != JSVM_OK) {
        OH_LOG_ERROR(LOG_APP, "JSVM OH_JSVM_StrictEquals: failed");
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM OH_JSVM_StrictEquals: success: %{public}d", result);
    }
    JSVM_Value isStrictEqual = nullptr;
    OH_JSVM_GetBoolean(env, result, &isStrictEqual);
    return isStrictEqual;
}

// 文档第一段：在正确的 HandleScope 内调用 JSVM_Value
static int32_t DebugOptionTestCorrect(JSVM_VM vm)
{
    JSVM_CallbackStruct cb = {.data = nullptr, .callback = DebugOption_IsStrictEquals};
    JSVM_PropertyDescriptor descriptor[] = {
        {"isStrictEquals", nullptr, &cb, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    JSVM_Env env = nullptr;
    if (OH_JSVM_CreateEnv(vm, sizeof(descriptor) / sizeof(descriptor[0]), descriptor, &env) != JSVM_OK) {
        return -1;
    }
    if (OH_JSVM_SetDebugOption(env, JSVM_SCOPE_CHECK, true) != JSVM_OK) {
        return -1;
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_EnvScope envScope = nullptr;
    JSVM_HandleScope handleScope = nullptr;
    if (OH_JSVM_OpenVMScope(vm, &vmScope) != JSVM_OK) {
        OH_JSVM_DestroyEnv(env);
        return -1;
    }
    if (OH_JSVM_OpenEnvScope(env, &envScope) != JSVM_OK) {
        OH_JSVM_CloseVMScope(vm, vmScope);
        OH_JSVM_DestroyEnv(env);
        return -1;
    }
    if (OH_JSVM_OpenHandleScope(env, &handleScope) != JSVM_OK) {
        OH_JSVM_CloseEnvScope(env, envScope);
        OH_JSVM_CloseVMScope(vm, vmScope);
        OH_JSVM_DestroyEnv(env);
        return -1;
    }

    const char *srcCallNative = "let data = '123'; let value = 123; isStrictEquals(data, value);"
                                "let b = true; isStrictEquals(b, b);";

    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;

    bool boolResult = true;
    JSVM_Status status = OH_JSVM_IsBoolean(env, result, &boolResult);
    if (status != JSVM_OK) {
        OH_LOG_ERROR(LOG_APP, "JSVM OH_JSVM_IsBoolean: failed");
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM OH_JSVM_IsBoolean: success: %{public}d", boolResult);
    }

    OH_JSVM_CloseHandleScope(env, handleScope);
    OH_JSVM_CloseEnvScope(env, envScope);
    OH_JSVM_CloseVMScope(vm, vmScope);
    OH_JSVM_SetDebugOption(env, JSVM_SCOPE_CHECK, false);
    OH_JSVM_DestroyEnv(env);
    (void)ok;
    return 0;
}

// 文档第二段：在错误的 HandleScope 内调用 JSVM_Value（触发 fatal）
static int32_t DebugOptionTestWrong(JSVM_VM vm)
{
    JSVM_CallbackStruct cb = {.data = nullptr, .callback = DebugOption_IsStrictEquals};
    JSVM_PropertyDescriptor descriptor[] = {
        {"isStrictEquals", nullptr, &cb, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    JSVM_Env env = nullptr;
    if (OH_JSVM_CreateEnv(vm, sizeof(descriptor) / sizeof(descriptor[0]), descriptor, &env) != JSVM_OK) {
        return -1;
    }
    if (OH_JSVM_SetDebugOption(env, JSVM_SCOPE_CHECK, true) != JSVM_OK) {
        return -1;
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_EnvScope envScope = nullptr;
    JSVM_HandleScope handleScope = nullptr;
    if (OH_JSVM_OpenVMScope(vm, &vmScope) != JSVM_OK) {
        OH_JSVM_DestroyEnv(env);
        return -1;
    }
    if (OH_JSVM_OpenEnvScope(env, &envScope) != JSVM_OK) {
        OH_JSVM_CloseVMScope(vm, vmScope);
        OH_JSVM_DestroyEnv(env);
        return -1;
    }
    if (OH_JSVM_OpenHandleScope(env, &handleScope) != JSVM_OK) {
        OH_JSVM_CloseEnvScope(env, envScope);
        OH_JSVM_CloseVMScope(vm, vmScope);
        OH_JSVM_DestroyEnv(env);
        return -1;
    }

    const char *srcCallNative = "let data = '123'; let value = 123; isStrictEquals(data, value);";

    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    (void)(OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
          OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
          OH_JSVM_RunScript(env, script, &result) == JSVM_OK);

    bool boolResult = true;
    // 关闭 HandleScope 后在错误 HandleScope 内调用 result —— 预期 "Run in wrong HandleScope" fatal
    OH_JSVM_CloseHandleScope(env, handleScope);
    OH_LOG_INFO(LOG_APP, "JSVM about to call IsBoolean in wrong HandleScope");
    JSVM_Status status = OH_JSVM_IsBoolean(env, result, &boolResult);
    // 上面调用预期触发 fatal，正常不会执行到此处。
    if (status != JSVM_OK) {
        OH_LOG_ERROR(LOG_APP, "JSVM OH_JSVM_IsBoolean: failed");
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM OH_JSVM_IsBoolean: success: %{public}d", boolResult);
    }

    OH_JSVM_CloseEnvScope(env, envScope);
    OH_JSVM_CloseVMScope(vm, vmScope);
    OH_JSVM_SetDebugOption(env, JSVM_SCOPE_CHECK, false);
    OH_JSVM_DestroyEnv(env);
    return 0;
}

std::string RunDebugOptionInternal(int mode)
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM debug-option verify start, mode=%{public}d", mode);
    output << "mode=" << (mode == 1 ? "wrong" : "correct") << "\n";

    int32_t ret = (mode == 1) ? DebugOptionTestWrong(vm) : DebugOptionTestCorrect(vm);

    OH_JSVM_DestroyVM(vm);
    OH_LOG_INFO(LOG_APP, "JSVM debug-option verify end, ret=%{public}d", ret);
    output << "ret=" << ret << "\n";
    return output.str();
}

napi_value RunDebugOption(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    int32_t mode = 0;
    if (argc >= 1 && args[0] != nullptr) {
        napi_get_value_int32(env, args[0], &mode);
    }
    const std::string result = RunDebugOptionInternal(mode);
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

// ---- use-jsvm-about-arraybuffer.md 验证 ----
// 文档代码直接使用 JSVM_CALL，定义最小版（语义同 use-jsvm-process.md：检查 JSVM_OK，失败打日志后返回）。
#define ARRAYBUFFER_JVM_CALL_BASE(env, theCall, retVal)                                                               \
    do {                                                                                                               \
        JSVM_Status cond = theCall;                                                                                    \
        if (cond != JSVM_OK) {                                                                                         \
            const JSVM_ExtendedErrorInfo *errInfo;                                                                     \
            OH_JSVM_GetLastErrorInfo(env, &errInfo);                                                                   \
            OH_LOG_ERROR(LOG_APP, "jsvm fail file: %{public}s line: %{public}d ret = %{public}d message = %{public}s", \
                         __FILE__, __LINE__, cond, errInfo != nullptr ? errInfo->errorMessage : "");                   \
            return retVal;                                                                                             \
        }                                                                                                              \
    } while (0)
#define ARRAYBUFFER_JVM_CALL(theCall) ARRAYBUFFER_JVM_CALL_BASE(env, theCall, nullptr)

// 注：文档原文仅用 OH_LOG_INFO 打印断言文本。本设备对应用私有日志(LOG_APP/0x3200)默认过滤，
// 故在保持文档 API 调用顺序与断言值不变的前提下，把同一文本也写入回调经 descriptor.data 取回的 sink，
// 以便经 napi 返回值在 UI 上可见。这一行 *output<<... 不改变文档逻辑结论。
#define AB_SINK_PUSH(line)                                                                                             \
    do {                                                                                                               \
        OH_LOG_INFO(LOG_APP, line);                                                                                    \
        if (g_abSink != nullptr) { *g_abSink << line << "\n"; }                                                       \
    } while (0)
static thread_local std::ostringstream *g_abSink = nullptr;

// 1) OH_JSVM_GetArraybufferInfo 示例（文档原文）
static JSVM_Value AB_GetArraybufferInfo(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value args[1] = {nullptr};
    OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    bool isArrayBuffer = false;
    OH_JSVM_IsArraybuffer(env, args[0], &isArrayBuffer);
    if (!isArrayBuffer) {
        AB_SINK_PUSH("JSVM GetArraybufferInfo isArrayBuffer:false");
        return nullptr;
    }
    void *data;
    size_t byteLength = 0;
    JSVM_Status status = OH_JSVM_GetArraybufferInfo(env, args[0], &data, &byteLength);
    if (status != JSVM_OK) {
        AB_SINK_PUSH("JSVM GetArraybufferInfo: failed");
    } else {
        AB_SINK_PUSH("JSVM GetArraybufferInfo: success");
    }
    return args[0];
}

// 2) OH_JSVM_IsArraybuffer 示例（文档原文；断言文本含动态值，单独拼）
static JSVM_Value AB_IsArrayBuffer(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value args[1] = {nullptr};
    OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    bool isArrayBuffer = false;
    JSVM_Status status = OH_JSVM_IsArraybuffer(env, args[0], &isArrayBuffer);
    if (status != JSVM_OK) {
        OH_LOG_INFO(LOG_APP, "JSVM IsArrayBuffer: failed");
        if (g_abSink != nullptr) { *g_abSink << "JSVM IsArrayBuffer: failed\n"; }
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM IsArrayBuffer: success");
        OH_LOG_INFO(LOG_APP, "JSVM IsArrayBuffer: %{public}d", isArrayBuffer);
        if (g_abSink != nullptr) {
            *g_abSink << "JSVM IsArrayBuffer: success\n";
            *g_abSink << "JSVM IsArrayBuffer: " << (isArrayBuffer ? 1 : 0) << "\n";
        }
    }
    JSVM_Value boolean = nullptr;
    OH_JSVM_GetBoolean(env, isArrayBuffer, &boolean);
    return boolean;
}

// 3a) OH_JSVM_DetachArraybuffer 示例（文档原文）
static JSVM_Value AB_DetachArraybuffer(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value args[1] = {nullptr};
    OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    JSVM_Value arraybuffer = args[0];
    JSVM_Status status = OH_JSVM_DetachArraybuffer(env, arraybuffer);
    if (status != JSVM_OK) {
        AB_SINK_PUSH("JSVM DetachArraybuffer: failed");
    } else {
        AB_SINK_PUSH("JSVM DetachArraybuffer: success");
    }
    return arraybuffer;
}

// 3b) OH_JSVM_IsDetachedArraybuffer 示例（文档原文；断言文本含动态值，单独拼）
static JSVM_Value AB_IsDetachedArraybuffer(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value args[1] = {nullptr};
    OH_JSVM_GetCbInfo(env, info, &argc, args, nullptr, nullptr);
    JSVM_Value arraybuffer = args[0];
    OH_JSVM_DetachArraybuffer(env, arraybuffer);
    bool result = false;
    JSVM_Status status = OH_JSVM_IsDetachedArraybuffer(env, arraybuffer, &result);
    if (status != JSVM_OK) {
        OH_LOG_INFO(LOG_APP, "JSVM IsDetachedArraybuffer: failed");
        if (g_abSink != nullptr) { *g_abSink << "JSVM IsDetachedArraybuffer: failed\n"; }
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM IsDetachedArraybuffer: success");
        OH_LOG_INFO(LOG_APP, "JSVM IsArrayBuffer: %{public}d", result);
        if (g_abSink != nullptr) {
            *g_abSink << "JSVM IsDetachedArraybuffer: success\n";
            *g_abSink << "JSVM IsArrayBuffer: " << (result ? 1 : 0) << "\n";
        }
    }
    JSVM_Value isDetached = nullptr;
    OH_JSVM_GetBoolean(env, result, &isDetached);
    return isDetached;
}

// 4) OH_JSVM_CreateArraybuffer 示例（文档原文；JSVM_CALL 映射为 ARRAYBUFFER_JVM_CALL；断言文本含动态值）
static JSVM_Value AB_CreateArraybuffer(JSVM_Env env, JSVM_CallbackInfo info)
{
    size_t argc = 1;
    JSVM_Value argv[1] = {nullptr};
    JSVM_Value result = nullptr;
    OH_JSVM_GetCbInfo(env, info, &argc, argv, nullptr, nullptr);
    int32_t value = 0;
    size_t length = 0;
    ARRAYBUFFER_JVM_CALL(OH_JSVM_GetValueInt32(env, argv[0], &value));
    length = size_t(value);
    void *data;
    JSVM_Status status = OH_JSVM_CreateArraybuffer(env, length, &data, &result);
    if (status != JSVM_OK) {
        OH_LOG_INFO(LOG_APP, "JSVM CreateArraybuffer: failed");
        if (g_abSink != nullptr) { *g_abSink << "JSVM CreateArraybuffer: failed\n"; }
        return nullptr;
    } else {
        OH_LOG_INFO(LOG_APP, "JSVM CreateArraybuffer: success");
        OH_LOG_INFO(LOG_APP, "JSVM ArrayBuffer length: %{public}d", length);
        if (g_abSink != nullptr) {
            *g_abSink << "JSVM CreateArraybuffer: success\n";
            *g_abSink << "JSVM ArrayBuffer length: " << static_cast<int>(length) << "\n";
        }
    }
    return result;
}

// 逐段运行四段示例的脚本（对应文档各自的 srcCallNative），收集断言文本。
static bool RunAbSample(JSVM_Env env, const char *name, const char *src, std::ostringstream &output)
{
    output << "---- " << name << " ----\n";
    JSVM_HandleScope handleScope = nullptr;
    if (OH_JSVM_OpenHandleScope(env, &handleScope) != JSVM_OK) {
        output << name << ": OpenHandleScope failed\n";
        return false;
    }
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, src, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << name << ": script run failed\n";
    }
    return ok;
}

// ---- use-jsvm-about-code-cache.md 验证 ----
// 文档原文 UseCodeCache；仅把 OH_LOG_INFO 断言文本同时经 descriptor.data 写回 sink（本设备过滤 LOG_APP）。
static JSVM_Value CC_UseCodeCache(JSVM_Env env, JSVM_CallbackInfo info)
{
    void *data = nullptr;
    OH_JSVM_GetCbInfo(env, info, nullptr, nullptr, nullptr, &data);
    std::ostringstream *out = static_cast<std::ostringstream *>(data);

    // 编译参数准备
    JSVM_Value jsSrc;
    JSVM_Script script;
    JSVM_Value result;
    size_t length = 0;
    const uint8_t *dataPtr = nullptr;
    bool cacheRejected = true;
    static std::string src = R"JS(
        a = 65536;
        b = 32768;
        c = a + b;
    )JS";

    // 生成code cache
    {
        JSVM_HandleScope handleScope;
        OH_JSVM_OpenHandleScope(env, &handleScope);

        // 源码字符串转换为js字符串
        OH_JSVM_CreateStringUtf8(env, src.c_str(), src.size(), &jsSrc);

        // 编译js代码
        OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script);

        // 执行js代码
        OH_JSVM_RunScript(env, script, &result);
        int value = 0;
        OH_JSVM_GetValueInt32(env, result, &value);
        OH_LOG_INFO(LOG_APP, "first run result: %{public}d\n", value);
        if (out != nullptr) { *out << "first run result: " << value << "\n"; }

        if (dataPtr == nullptr) {
            // 将js源码编译出的脚本保存到cache, 可以避免重复编译, 带来性能提升
            OH_JSVM_CreateCodeCache(env, script, &dataPtr, &length);
        }

        OH_JSVM_CloseHandleScope(env, handleScope);
    }

    // 使用code cache
    {
        JSVM_HandleScope handleScope;
        OH_JSVM_OpenHandleScope(env, &handleScope);

        // 源码字符串转换为js字符串
        OH_JSVM_CreateStringUtf8(env, src.c_str(), src.size(), &jsSrc);

        // 使用code cache编译js代码
        OH_JSVM_CompileScript(env, jsSrc, dataPtr, length, true, &cacheRejected, &script);

        // 执行js代码
        OH_JSVM_RunScript(env, script, &result);
        int value = 0;
        OH_JSVM_GetValueInt32(env, result, &value);
        OH_LOG_INFO(LOG_APP, "second run result: %{public}d\n", value);
        if (out != nullptr) { *out << "second run result: " << value << "\n"; }

        OH_JSVM_CloseHandleScope(env, handleScope);
    }
    OH_LOG_INFO(LOG_APP, "cache rejected: %{public}d\n", cacheRejected);
    if (out != nullptr) { *out << "cache rejected: " << (cacheRejected ? 1 : 0) << "\n"; }
    return result;
}

// ---- use-jsvm-trigger-gc.md 验证 ----
// 文档代码直接使用 JSVM_CALL，定义最小版（语义同 use-jsvm-process.md：检查 JSVM_OK，失败打日志后返回）。
#define TRIGGER_GC_JVM_CALL_BASE(env, theCall, retVal)                                                                \
    do {                                                                                                               \
        JSVM_Status cond = theCall;                                                                                    \
        if (cond != JSVM_OK) {                                                                                         \
            const JSVM_ExtendedErrorInfo *errInfo;                                                                     \
            OH_JSVM_GetLastErrorInfo(env, &errInfo);                                                                   \
            OH_LOG_ERROR(LOG_APP, "jsvm fail file: %{public}s line: %{public}d ret = %{public}d message = %{public}s", \
                         __FILE__, __LINE__, cond, errInfo != nullptr ? errInfo->errorMessage : "");                   \
            return retVal;                                                                                             \
        }                                                                                                              \
    } while (0)
#define JSVM_CALL(theCall) TRIGGER_GC_JVM_CALL_BASE(env, theCall, nullptr)
// 文档原文 OnBeforeGC/OnBeforeGC2/OnAfterGC*/TriggerGC；仅把 OH_LOG_INFO 断言文本同时写回 sink（本设备过滤 LOG_APP）。
// 文档代码用了 std::cout（include <iostream>），这里改写经 sink/napi 返回值回显，断言逻辑与文档一致。
static bool gc_before_flag1 = false;
static bool gc_before_flag2 = false;
static bool gc_after_flag1 = false;
static bool gc_after_flag2 = false;

void GC_OnBeforeGC(JSVM_VM vm, JSVM_GCType gcType, JSVM_GCCallbackFlags flags, void *data)
{
    OH_LOG_INFO(LOG_APP, "== before GC ==");
    OH_LOG_INFO(LOG_APP, "gc type: %{public}d", gcType);
    OH_LOG_INFO(LOG_APP, "gc flag: %{public}d", flags);
    if (g_abSink != nullptr) {
        *g_abSink << "== before GC ==\n";
        *g_abSink << "gc type: " << static_cast<int>(gcType) << "\n";
        *g_abSink << "gc flag: " << static_cast<int>(flags) << "\n";
    }
    gc_before_flag1 = true;
    (void)vm;
}

void GC_OnBeforeGC2(JSVM_VM vm, JSVM_GCType gcType, JSVM_GCCallbackFlags flags, void *data)
{
    OH_LOG_INFO(LOG_APP, "== before GC2 ==");
    OH_LOG_INFO(LOG_APP, "gc type: %{public}d", gcType);
    OH_LOG_INFO(LOG_APP, "gc flag: %{public}d", flags);
    OH_LOG_INFO(LOG_APP, "data: %{public}d", *(int *)data);
    if (g_abSink != nullptr) {
        *g_abSink << "== before GC2 ==\n";
        *g_abSink << "gc type: " << static_cast<int>(gcType) << "\n";
        *g_abSink << "gc flag: " << static_cast<int>(flags) << "\n";
        *g_abSink << "data: " << *(int *)data << "\n";
    }
    if (*(int *)data == 2024) {
        gc_before_flag2 = true;
    }
    (void)vm;
}

void GC_OnAfterGC(JSVM_VM vm, JSVM_GCType gcType, JSVM_GCCallbackFlags flags, void *data)
{
    gc_after_flag1 = true;
    (void)vm; (void)gcType; (void)flags; (void)data;
}

void GC_OnAfterGC2(JSVM_VM vm, JSVM_GCType gcType, JSVM_GCCallbackFlags flags, void *data)
{
    gc_after_flag2 = true;
    (void)vm; (void)gcType; (void)flags; (void)data;
}

void GC_OnAfterGC3(JSVM_VM vm, JSVM_GCType gcType, JSVM_GCCallbackFlags flags, void *data)
{
    gc_after_flag2 = true;
    (void)vm; (void)gcType; (void)flags; (void)data;
}

static JSVM_Value GC_TriggerGC(JSVM_Env env, JSVM_CallbackInfo info)
{
    void *cbdata = nullptr;
    OH_JSVM_GetCbInfo(env, info, nullptr, nullptr, nullptr, &cbdata);
    std::ostringstream *out = static_cast<std::ostringstream *>(cbdata);

    bool remove_repeated = false;
    bool remove_notAdded = false;
    bool add_repeated = false;
    gc_before_flag1 = false;
    gc_before_flag2 = false;
    gc_after_flag1 = false;
    gc_after_flag2 = false;
    JSVM_VM vm;
    OH_JSVM_GetVM(env, &vm);
    int data = 2024;
    JSVM_CALL(OH_JSVM_AddHandlerForGC(vm, JSVM_CB_TRIGGER_BEFORE_GC, GC_OnBeforeGC, JSVM_GC_TYPE_ALL, nullptr));
    JSVM_CALL(OH_JSVM_AddHandlerForGC(vm, JSVM_CB_TRIGGER_BEFORE_GC, GC_OnBeforeGC2, JSVM_GC_TYPE_ALL, (void *)(&data)));
    JSVM_CALL(OH_JSVM_AddHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC, JSVM_GC_TYPE_ALL, nullptr));
    JSVM_CALL(OH_JSVM_AddHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC2, JSVM_GC_TYPE_ALL, nullptr));
    if (OH_JSVM_AddHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC2, JSVM_GC_TYPE_ALL, nullptr) == JSVM_INVALID_ARG) {
        add_repeated = true;
    }
    JSVM_CALL(OH_JSVM_RemoveHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC2, nullptr));
    if (OH_JSVM_RemoveHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC2, nullptr) == JSVM_INVALID_ARG) {
        remove_repeated = true;
    }
    if (OH_JSVM_RemoveHandlerForGC(vm, JSVM_CB_TRIGGER_AFTER_GC, GC_OnAfterGC3, nullptr) == JSVM_INVALID_ARG) {
        remove_notAdded = true;
    }
    JSVM_CALL(OH_JSVM_MemoryPressureNotification(env, JSVM_MEMORY_PRESSURE_LEVEL_CRITICAL));
    if ((gc_before_flag1) && (gc_before_flag2) && (gc_after_flag1) && (!gc_after_flag2) && (remove_repeated) &&
        (remove_notAdded) && (add_repeated)) {
        OH_LOG_INFO(LOG_APP, "JSVM Trigger GC: success");
        if (out != nullptr) { *out << "JSVM Trigger GC: success\n"; }
    } else {
        OH_LOG_ERROR(LOG_APP, "JSVM Trigger GC: failed");
        if (out != nullptr) {
            *out << "JSVM Trigger GC: failed\n";
            *out << "  flags: before1=" << gc_before_flag1 << " before2=" << gc_before_flag2
                 << " after1=" << gc_after_flag1 << " after2=" << gc_after_flag2
                 << " remove_repeated=" << remove_repeated << " remove_notAdded=" << remove_notAdded
                 << " add_repeated=" << add_repeated << "\n";
        }
    }
    JSVM_Value checked;
    OH_JSVM_GetBoolean(env, true, &checked);
    return checked;
}

// ---- use-jsvm-threshold-callback.md 验证（API26，需 API26 SDK 才能编译）----
// 文档原文 HeapMgmtTest + OnHeapThresholdReached + SnapshotStreamCallback；
// 每步把 status/断言文本经 sink 回显（文档 OH_LOG_INFO 在某些设备被过滤）。
static bool g_heapThresholdCalled = false;
static uint64_t g_triggeredThreshold = 0;
static void *g_callbackUserData = nullptr;
static bool g_snapshotGenerated = false;

static constexpr int SLEEP_TIME_MS = 100;
static constexpr uint64_t THRESHOLD_SIZE = 1024 * 1024;
static constexpr int TEST_DATA_VALUE = 0x12345678;

static bool HtSnapshotStreamCallback(const char *data, int size, void *streamData)
{
    std::FILE *file = reinterpret_cast<std::FILE *>(streamData);
    if (file) {
        size_t written = std::fwrite(data, 1, size, file);
        return written == static_cast<size_t>(size);
    }
    return true;
}

static void OnHeapThresholdReached(JSVM_VM vm, uint64_t threshold, void *data)
{
    int *td = static_cast<int *>(data);
    OH_LOG_INFO(LOG_APP, "== Heap threshold reached ==");
    OH_LOG_INFO(LOG_APP, "Threshold: %{public}lu bytes", static_cast<unsigned long>(threshold));
    OH_LOG_INFO(LOG_APP, "User data: %{public}d", td != nullptr ? *td : 0);
    if (g_abSink != nullptr) {
        *g_abSink << "== Heap threshold reached ==\n";
        *g_abSink << "Threshold: " << threshold << " bytes\n";
        *g_abSink << "User data: " << (td != nullptr ? *td : 0) << "\n";
    }

    g_heapThresholdCalled = true;
    g_triggeredThreshold = threshold;
    g_callbackUserData = data;

    if (!g_snapshotGenerated) {
        g_snapshotGenerated = true;
        pid_t pid = fork();
        if (pid < 0) {
            OH_LOG_ERROR(LOG_APP, "fork failed");
            if (g_abSink != nullptr) { *g_abSink << "fork failed\n"; }
        } else if (pid == 0) {
            std::FILE *file = std::fopen("/data/storage/el2/base/temp/threshold.rawheap", "wb");
            if (file) {
                OH_JSVM_TakeRawHeapSnapshot(vm, HtSnapshotStreamCallback, file);
                std::fflush(file);
                fclose(file);
            }
            _exit(0);
        }
    }
}

static void ResetHeapTestState()
{
    g_heapThresholdCalled = false;
    g_triggeredThreshold = 0;
    g_callbackUserData = nullptr;
    g_snapshotGenerated = false;
}

static void TestSetHeapThresholdCallback(JSVM_VM vm, uint64_t threshold, int *testData)
{
    JSVM_Status addStatus = OH_JSVM_SetHeapThresholdCallback(vm, threshold, OnHeapThresholdReached, testData);
    if (addStatus == JSVM_OK) {
        OH_LOG_INFO(LOG_APP, "Set heap threshold callback success");
        if (g_abSink != nullptr) { *g_abSink << "Set heap threshold callback success\n"; }
    } else if (g_abSink != nullptr) {
        *g_abSink << "Set heap threshold callback FAILED status=" << static_cast<int>(addStatus) << "\n";
    }

    JSVM_Status addRepeatStatus = OH_JSVM_SetHeapThresholdCallback(vm, threshold, OnHeapThresholdReached, testData);
    if (addRepeatStatus == JSVM_INVALID_ARG) {
        OH_LOG_INFO(LOG_APP, "Set repeated callback failed (expected)");
        if (g_abSink != nullptr) { *g_abSink << "Set repeated callback failed (expected)\n"; }
    }

    JSVM_Status addInvalidStatus = OH_JSVM_SetHeapThresholdCallback(vm, 0, OnHeapThresholdReached, testData);
    if (addInvalidStatus == JSVM_INVALID_ARG) {
        OH_LOG_INFO(LOG_APP, "Set callback with 0 threshold failed (expected)");
        if (g_abSink != nullptr) { *g_abSink << "Set callback with 0 threshold failed (expected)\n"; }
    }
}

static void TestClearHeapThresholdCallback(JSVM_VM vm, uint64_t threshold, int *testData)
{
    JSVM_Status removeStatus = OH_JSVM_ClearHeapThresholdCallback(vm, threshold, OnHeapThresholdReached, testData);
    if (removeStatus == JSVM_OK) {
        OH_LOG_INFO(LOG_APP, "Clear heap threshold callback success");
        if (g_abSink != nullptr) { *g_abSink << "Clear heap threshold callback success\n"; }
    }

    JSVM_Status removeRepeatStatus = OH_JSVM_ClearHeapThresholdCallback(vm, threshold, OnHeapThresholdReached, testData);
    if (removeRepeatStatus == JSVM_INVALID_ARG) {
        OH_LOG_INFO(LOG_APP, "Clear repeated callback failed (expected)");
        if (g_abSink != nullptr) { *g_abSink << "Clear repeated callback failed (expected)\n"; }
    }

    JSVM_Status removeMismatchStatus = OH_JSVM_ClearHeapThresholdCallback(vm, 999999, OnHeapThresholdReached, testData);
    if (removeMismatchStatus == JSVM_INVALID_ARG) {
        OH_LOG_INFO(LOG_APP, "Clear mismatch threshold callback failed (expected)");
        if (g_abSink != nullptr) { *g_abSink << "Clear mismatch threshold callback failed (expected)\n"; }
    }
}

static void RunAllocScript(JSVM_Env env)
{
    const char *allocJs = R"JS(
        var holder = [];
        for (let i = 0; i < 10000; i++) {
            holder.push(new Uint8Array(1024));
        }
    )JS";

    JSVM_Value jsSrc;
    JSVM_Value result1;
    JSVM_Script script;
    OH_JSVM_CreateStringUtf8(env, allocJs, JSVM_AUTO_LENGTH, &jsSrc);
    OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script);
    OH_JSVM_RunScript(env, script, &result1);
}

static bool CheckHeapTestResult(uint64_t threshold, int *testData)
{
    bool testSuccess = (g_heapThresholdCalled && g_triggeredThreshold == threshold &&
                        g_callbackUserData == testData && g_snapshotGenerated);
    if (testSuccess) {
        OH_LOG_INFO(LOG_APP, "Heap management test: SUCCESS");
        if (g_abSink != nullptr) { *g_abSink << "Heap management test: SUCCESS\n"; }
    } else {
        OH_LOG_ERROR(LOG_APP, "Heap management test: FAILED");
        if (g_abSink != nullptr) {
            *g_abSink << "Heap management test: FAILED\n";
            *g_abSink << "  called=" << g_heapThresholdCalled << " trig=" << g_triggeredThreshold
                      << " threshold=" << threshold << " udMatch=" << (g_callbackUserData == testData)
                      << " snapshot=" << g_snapshotGenerated << "\n";
        }
    }
    return testSuccess;
}

static JSVM_Value HeapMgmtTest(JSVM_Env env, JSVM_CallbackInfo info)
{
    ResetHeapTestState();

    JSVM_VM vm;
    OH_JSVM_GetVM(env, &vm);
    int testData = TEST_DATA_VALUE;
    uint64_t threshold = THRESHOLD_SIZE;

    std::FILE *file = std::fopen("/data/storage/el2/base/temp/take.rawheap", "wb");
    JSVM_Status snapshotStatus = OH_JSVM_TakeRawHeapSnapshot(vm, HtSnapshotStreamCallback, file);
    if (snapshotStatus == JSVM_INVALID_ARG) {
        OH_LOG_ERROR(LOG_APP, "Take raw heap snapshot failed (invalid arg)");
        if (g_abSink != nullptr) { *g_abSink << "Take raw heap snapshot failed (invalid arg)\n"; }
    } else if (g_abSink != nullptr) {
        *g_abSink << "Take raw heap snapshot status=" << static_cast<int>(snapshotStatus) << "\n";
    }
    if (file) { std::fflush(file); fclose(file); }

    TestSetHeapThresholdCallback(vm, threshold, &testData);
    RunAllocScript(env);

    OH_JSVM_MemoryPressureNotification(env, JSVM_MEMORY_PRESSURE_LEVEL_CRITICAL);
    std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP_TIME_MS));

    TestClearHeapThresholdCallback(vm, threshold, &testData);

    bool testSuccess = CheckHeapTestResult(threshold, &testData);

    JSVM_Value result;
    OH_JSVM_GetBoolean(env, testSuccess, &result);
    return result;
}

std::string RunThresholdCallbackTestInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct htCallback = {.data = &output, .callback = HeapMgmtTest};
    JSVM_PropertyDescriptor htDescriptor[] = {
        {"heapMgmtTest", nullptr, &htCallback, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(htDescriptor) / sizeof(htDescriptor[0]), htDescriptor, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM threshold-callback test start");
    output << "JSVM threshold-callback test start\n";

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }
    g_abSink = &output;
    const char *srcCallNative = "heapMgmtTest();";
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    g_abSink = nullptr;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << "threshold-callback: script run failed\n";
    }

    OH_LOG_INFO(LOG_APP, "JSVM threshold-callback test end");
    output << "JSVM threshold-callback test end\n";
    finish();
    return output.str();
}

napi_value RunThresholdCallbackTest(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunThresholdCallbackTestInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

// ---- use-jsvm-about-external-arraybuffer.md 验证（API26，需 API26 SDK + JSVM_EXPERIMENTAL）----
// 文档原文 LoadPixelData/PixelDataFinalize/CreateArrayBufferFromExternal；断言文本经 sink 回显。
static void *LoadPixelData(size_t *outSize)
{
    *outSize = 16;  // 4pixels×4bytes(RGBA)
    uint8_t *data = static_cast<uint8_t *>(malloc(*outSize));
    if (data == nullptr) {
        return nullptr;
    }
    uint8_t pixels[] = {255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255};
    memcpy(data, pixels, *outSize);
    return data;
}

static void PixelDataFinalize(JSVM_Env env, void *data, void *hint, bool copied)
{
    if (!copied) {
        free(data);
    }
    (void)env; (void)hint;
}

static JSVM_Value CreateArrayBufferFromExternal(JSVM_Env env, JSVM_CallbackInfo info)
{
    JSVM_Value undef = nullptr;
    OH_JSVM_GetUndefined(env, &undef);

    size_t dataSize = 0;
    void *pixelData = LoadPixelData(&dataSize);
    if (pixelData == nullptr) {
        OH_LOG_ERROR(LOG_APP, "JSVM: failed to load pixel data");
        if (g_abSink != nullptr) { *g_abSink << "JSVM: failed to load pixel data\n"; }
        return undef;
    }

    JSVM_HandleScope scope = nullptr;
    OH_JSVM_OpenHandleScope(env, &scope);

    JSVM_Value arrayBuffer = nullptr;
    bool copied = false;
    JSVM_Status status = OH_JSVM_CreateArrayBufferFromExternalMemory(
        env, pixelData, dataSize, PixelDataFinalize, nullptr, &copied, &arrayBuffer);
    if (status != JSVM_OK) {
        OH_LOG_ERROR(LOG_APP, "JSVM CreateArrayBufferFromExternalMemory: failed");
        if (g_abSink != nullptr) {
            *g_abSink << "JSVM CreateArrayBufferFromExternalMemory: failed status="
                      << static_cast<int>(status) << "\n";
        }
        free(pixelData);
        OH_JSVM_CloseHandleScope(env, scope);
        return undef;
    }

    if (copied) {
        free(pixelData);
    }

    void *abData = nullptr;
    size_t abLen = 0;
    OH_JSVM_GetArraybufferInfo(env, arrayBuffer, &abData, &abLen);
    OH_LOG_INFO(LOG_APP, "JSVM CreateArrayBufferFromExternalMemory: success, byteLength=%{public}zu", abLen);
    if (g_abSink != nullptr) {
        *g_abSink << "JSVM CreateArrayBufferFromExternalMemory: success, byteLength=" << abLen << "\n";
        *g_abSink << "  copied=" << (copied ? "true" : "false") << "\n";
    }

    OH_JSVM_CloseHandleScope(env, scope);

    OH_JSVM_MemoryPressureNotification(env, JSVM_MEMORY_PRESSURE_LEVEL_CRITICAL);
    return undef;
}

std::string RunExternalArrayBufferTestInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct eabCallback = {.data = &output, .callback = CreateArrayBufferFromExternal};
    JSVM_PropertyDescriptor eabDescriptor[] = {
        {"createArrayBufferFromExternal", nullptr, &eabCallback, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(eabDescriptor) / sizeof(eabDescriptor[0]), eabDescriptor, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM external-arraybuffer test start");
    output << "JSVM external-arraybuffer test start\n";

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }
    g_abSink = &output;
    const char *srcCallNative = "createArrayBufferFromExternal();";
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    g_abSink = nullptr;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << "external-arraybuffer: script run failed\n";
    }

    OH_LOG_INFO(LOG_APP, "JSVM external-arraybuffer test end");
    output << "JSVM external-arraybuffer test end\n";
    finish();
    return output.str();
}

napi_value RunExternalArrayBufferTest(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunExternalArrayBufferTestInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

// ---- use-jsvm-about-wasm.md 验证 ----
// 文档原文 helper + WasmDemo；每步把 status/结果经 sink 回显（文档 CHECK_STATUS 仅打日志，本设备 LOG_APP 被过滤）。
static bool Wasm_IsWasmModuleObject(JSVM_Env env, JSVM_Value value)
{
    bool result = false;
    JSVM_Status status = OH_JSVM_IsWasmModuleObject(env, value, &result);
    return (status == JSVM_OK) && result;
}

static JSVM_Value Wasm_CreateString(JSVM_Env env, const char *str)
{
    JSVM_Value jsvmStr;
    OH_JSVM_CreateStringUtf8(env, str, JSVM_AUTO_LENGTH, &jsvmStr);
    return jsvmStr;
}

static JSVM_Value Wasm_CreateInt32(JSVM_Env env, int32_t val)
{
    JSVM_Value jsvmInt32;
    OH_JSVM_CreateInt32(env, val, &jsvmInt32);
    return jsvmInt32;
}

static JSVM_Value Wasm_InstantiateWasmModule(JSVM_Env env, JSVM_Value wasmModule, std::ostringstream &out)
{
    JSVM_Value globalThis;
    OH_JSVM_GetGlobal(env, &globalThis);
    JSVM_Value webAssembly;
    OH_JSVM_GetProperty(env, globalThis, Wasm_CreateString(env, "WebAssembly"), &webAssembly);
    JSVM_Value webAssemblyInstance;
    OH_JSVM_GetProperty(env, webAssembly, Wasm_CreateString(env, "Instance"), &webAssemblyInstance);
    JSVM_Value instance;
    JSVM_Value argv[] = {wasmModule};
    JSVM_Status status = OH_JSVM_NewInstance(env, webAssemblyInstance, 1, argv, &instance);
    out << "  NewInstance status=" << static_cast<int>(status) << "\n";
    return instance;
}

static std::vector<uint8_t> Wasm_GetAddWasmBuffer()
{
    /* add 模块 wasm 字节码（文档原文） */
    return {0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x07, 0x01,
            0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f, 0x03, 0x02, 0x01, 0x00, 0x07,
            0x07, 0x01, 0x03, 0x61, 0x64, 0x64, 0x00, 0x00, 0x0a, 0x09, 0x01,
            0x07, 0x00, 0x20, 0x00, 0x20, 0x01, 0x6a, 0x0b};
}

static int32_t Wasm_VerifyAddWasmInstance(JSVM_Env env, JSVM_Value wasmInstance, std::ostringstream &out)
{
    JSVM_Value exports;
    OH_JSVM_GetProperty(env, wasmInstance, Wasm_CreateString(env, "exports"), &exports);
    JSVM_Value add;
    OH_JSVM_GetProperty(env, exports, Wasm_CreateString(env, "add"), &add);
    JSVM_Value undefined;
    OH_JSVM_GetUndefined(env, &undefined);
    JSVM_Value one = Wasm_CreateInt32(env, 1);
    JSVM_Value two = Wasm_CreateInt32(env, 2);
    JSVM_Value argv[] = {one, two};
    JSVM_Value result;
    JSVM_Status status = OH_JSVM_CallFunction(env, undefined, add, 2, argv, &result);
    int32_t resultInt32 = -1;
    OH_JSVM_GetValueInt32(env, result, &resultInt32);
    out << "  CallFunction(add)(1,2) status=" << static_cast<int>(status) << " result=" << resultInt32 << "\n";
    return resultInt32;
}

static JSVM_Value Wasm_Demo(JSVM_Env env, JSVM_CallbackInfo info)
{
    void *data = nullptr;
    OH_JSVM_GetCbInfo(env, info, nullptr, nullptr, nullptr, &data);
    std::ostringstream *out = static_cast<std::ostringstream *>(data);

    std::vector<uint8_t> wasmBuffer = Wasm_GetAddWasmBuffer();
    uint8_t *wasmBytecode = wasmBuffer.data();
    size_t wasmBytecodeLength = wasmBuffer.size();
    JSVM_Value wasmModule;
    JSVM_Status status = OH_JSVM_CompileWasmModule(env, wasmBytecode, wasmBytecodeLength, nullptr, 0, nullptr, &wasmModule);
    if (out != nullptr) { *out << "CompileWasmModule(bytecode) status=" << static_cast<int>(status) << "\n"; }
    if (status != JSVM_OK) {
        if (out != nullptr) { *out << "=> CompileWasmModule FAILED (likely no JIT permission)\n"; }
        JSVM_Value r;
        OH_JSVM_GetBoolean(env, false, &r);
        return r;
    }
    bool isWasm = Wasm_IsWasmModuleObject(env, wasmModule);
    if (out != nullptr) { *out << "IsWasmModuleObject=" << (isWasm ? "true" : "false") << "\n"; }

    int32_t functionIndex = 0;
    status = OH_JSVM_CompileWasmFunction(env, wasmModule, functionIndex, JSVM_WASM_OPT_HIGH);
    if (out != nullptr) { *out << "CompileWasmFunction status=" << static_cast<int>(status) << "\n"; }

    JSVM_Value wasmInstance = Wasm_InstantiateWasmModule(env, wasmModule, *out);
    int32_t addResult = Wasm_VerifyAddWasmInstance(env, wasmInstance, *out);
    if (out != nullptr) { *out << "VerifyAddWasmInstance add(1,2)=" << addResult << (addResult == 3 ? " (OK)" : " (MISMATCH)") << "\n"; }

    const uint8_t *wasmCacheData = nullptr;
    size_t wasmCacheLength = 0;
    status = OH_JSVM_CreateWasmCache(env, wasmModule, &wasmCacheData, &wasmCacheLength);
    if (out != nullptr) { *out << "CreateWasmCache status=" << static_cast<int>(status) << " len=" << wasmCacheLength << "\n"; }

    JSVM_Value result;
    OH_JSVM_GetBoolean(env, true, &result);
    return result;
}

std::string RunWasmTestInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct wasmCallback = {.data = &output, .callback = Wasm_Demo};
    JSVM_PropertyDescriptor wasmDescriptor[] = {
        {"wasmDemo", nullptr, &wasmCallback, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(wasmDescriptor) / sizeof(wasmDescriptor[0]), wasmDescriptor, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM wasm test start");
    output << "JSVM wasm test start\n";

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }
    g_abSink = &output;
    const char *srcCallNative = "wasmDemo()";
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    g_abSink = nullptr;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << "wasm: script run failed (script-level)\n";
    }

    OH_LOG_INFO(LOG_APP, "JSVM wasm test end");
    output << "JSVM wasm test end\n";
    finish();
    return output.str();
}

napi_value RunWasmTest(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunWasmTestInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

std::string RunTriggerGcTestInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct gcCallback = {.data = &output, .callback = GC_TriggerGC};
    JSVM_PropertyDescriptor gcDescriptor[] = {
        {"triggerGC", nullptr, &gcCallback, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(gcDescriptor) / sizeof(gcDescriptor[0]), gcDescriptor, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM trigger-gc test start");
    output << "JSVM trigger-gc test start\n";

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }
    g_abSink = &output;
    const char *srcCallNative = "triggerGC();";
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    g_abSink = nullptr;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << "trigger-gc: script run failed\n";
    }

    OH_LOG_INFO(LOG_APP, "JSVM trigger-gc test end");
    output << "JSVM trigger-gc test end\n";
    finish();
    return output.str();
}

napi_value RunTriggerGcTest(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunTriggerGcTestInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

std::string RunCodeCacheTestInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    // 文档 descriptor：UseCodeCache，data 传 sink
    JSVM_CallbackStruct ccCallback = {.data = &output, .callback = CC_UseCodeCache};
    JSVM_PropertyDescriptor ccDescriptor[] = {
        {"UseCodeCache", nullptr, &ccCallback, nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(ccDescriptor) / sizeof(ccDescriptor[0]), ccDescriptor, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM code-cache test start");
    output << "JSVM code-cache test start\n";

    JSVM_HandleScope handleScope = nullptr;
    if (!CheckStatus(OH_JSVM_OpenHandleScope(env, &handleScope), "OH_JSVM_OpenHandleScope", output)) {
        finish();
        return output.str();
    }
    // 文档 srcCallNative = globalThis.UseCodeCache()
    const char *srcCallNative = "globalThis.UseCodeCache()";
    JSVM_Value jsSrc = nullptr;
    JSVM_Script script = nullptr;
    JSVM_Value result = nullptr;
    bool ok = OH_JSVM_CreateStringUtf8(env, srcCallNative, JSVM_AUTO_LENGTH, &jsSrc) == JSVM_OK &&
              OH_JSVM_CompileScript(env, jsSrc, nullptr, 0, true, nullptr, &script) == JSVM_OK &&
              OH_JSVM_RunScript(env, script, &result) == JSVM_OK;
    OH_JSVM_CloseHandleScope(env, handleScope);
    if (!ok) {
        output << "code-cache: script run failed\n";
    }

    OH_LOG_INFO(LOG_APP, "JSVM code-cache test end");
    output << "JSVM code-cache test end\n";
    finish();
    return output.str();
}

napi_value RunCodeCacheTest(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunCodeCacheTestInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

std::string RunArrayBufferTestsInternal()
{
    std::ostringstream output;
    std::call_once(g_initFlag, InitJsvmOnce);
    if (!CheckStatus(g_initStatus, "OH_JSVM_Init", output)) {
        return output.str();
    }

    JSVM_CreateVMOptions options;
    std::memset(&options, 0, sizeof(options));
    JSVM_VM vm = nullptr;
    if (!CheckStatus(OH_JSVM_CreateVM(&options, &vm), "OH_JSVM_CreateVM", output)) {
        return output.str();
    }

    JSVM_VMScope vmScope = nullptr;
    JSVM_Env env = nullptr;
    JSVM_EnvScope envScope = nullptr;
    auto finish = [&]() {
        if (envScope != nullptr && env != nullptr) {
            OH_JSVM_CloseEnvScope(env, envScope);
        }
        if (env != nullptr) {
            OH_JSVM_DestroyEnv(env);
        }
        if (vmScope != nullptr) {
            OH_JSVM_CloseVMScope(vm, vmScope);
        }
        if (vm != nullptr) {
            OH_JSVM_DestroyVM(vm);
        }
    };

    if (!CheckStatus(OH_JSVM_OpenVMScope(vm, &vmScope), "OH_JSVM_OpenVMScope", output)) {
        finish();
        return output.str();
    }

    JSVM_CallbackStruct abCallbacks[] = {
        {.data = nullptr, .callback = AB_GetArraybufferInfo},
        {.data = nullptr, .callback = AB_IsArrayBuffer},
        {.data = nullptr, .callback = AB_DetachArraybuffer},
        {.data = nullptr, .callback = AB_IsDetachedArraybuffer},
        {.data = nullptr, .callback = AB_CreateArraybuffer},
    };
    JSVM_PropertyDescriptor abDescriptors[] = {
        {"getArraybufferInfo", nullptr, &abCallbacks[0], nullptr, nullptr, nullptr, JSVM_DEFAULT},
        {"isArrayBuffer", nullptr, &abCallbacks[1], nullptr, nullptr, nullptr, JSVM_DEFAULT},
        {"detachArraybuffer", nullptr, &abCallbacks[2], nullptr, nullptr, nullptr, JSVM_DEFAULT},
        {"isDetachedArraybuffer", nullptr, &abCallbacks[3], nullptr, nullptr, nullptr, JSVM_DEFAULT},
        {"createArraybuffer", nullptr, &abCallbacks[4], nullptr, nullptr, nullptr, JSVM_DEFAULT},
    };

    if (!CheckStatus(OH_JSVM_CreateEnv(vm, sizeof(abDescriptors) / sizeof(abDescriptors[0]), abDescriptors, &env),
            "OH_JSVM_CreateEnv", output)) {
        finish();
        return output.str();
    }
    if (!CheckStatus(OH_JSVM_OpenEnvScope(env, &envScope), "OH_JSVM_OpenEnvScope", output)) {
        finish();
        return output.str();
    }

    OH_LOG_INFO(LOG_APP, "JSVM arraybuffer tests start");
    output << "JSVM arraybuffer tests start\n";

    // 把回调断言文本写回 output（应用私有日志在本设备被过滤，故用 sink 兜底，不改变文档逻辑）。
    g_abSink = &output;
    // 文档各段 srcCallNative
    RunAbSample(env, "GetArraybufferInfo", "getArraybufferInfo(new ArrayBuffer(10));", output);
    RunAbSample(env, "IsArraybuffer", "isArrayBuffer(new ArrayBuffer(8));", output);
    RunAbSample(env, "Detach/IsDetached",
        "let arrayBuffer = new ArrayBuffer(10); detachArraybuffer(arrayBuffer); isDetachedArraybuffer(arrayBuffer);",
        output);
    RunAbSample(env, "CreateArraybuffer", "createArraybuffer(8);", output);
    g_abSink = nullptr;

    OH_LOG_INFO(LOG_APP, "JSVM arraybuffer tests end");
    output << "JSVM arraybuffer tests end\n";
    finish();
    return output.str();
}

napi_value RunArrayBufferTests(napi_env env, napi_callback_info info)
{
    (void)info;
    const std::string result = RunArrayBufferTestsInternal();
    napi_value jsResult = nullptr;
    napi_create_string_utf8(env, result.c_str(), result.size(), &jsResult);
    return jsResult;
}

napi_value Init(napi_env env, napi_value exports)
{
    napi_property_descriptor desc[] = {
        {"runJsvmSmoke", nullptr, RunJsvmSmoke, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runProfilerSnapshot", nullptr, RunProfilerSnapshot, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runDebugOption", nullptr, RunDebugOption, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runArrayBufferTests", nullptr, RunArrayBufferTests, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runCodeCacheTest", nullptr, RunCodeCacheTest, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runTriggerGcTest", nullptr, RunTriggerGcTest, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runWasmTest", nullptr, RunWasmTest, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runThresholdCallbackTest", nullptr, RunThresholdCallbackTest, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"runExternalArrayBufferTest", nullptr, RunExternalArrayBufferTest, nullptr, nullptr, nullptr, napi_default, nullptr},
    };
    napi_define_properties(env, exports, sizeof(desc) / sizeof(desc[0]), desc);
    return exports;
}

} // namespace

NAPI_MODULE(entry, Init)
