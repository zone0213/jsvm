# API26 两篇文档 HAP — 在 API26 电脑上的操作清单

本包用于在**装了 API26 SDK 的电脑 + API26 系统的手机**上,编译并运行两篇 API26 文档:

1. **use-jsvm-threshold-callback.md**(堆快照 + 堆内存阈值回调)
2. **use-jsvm-about-external-arraybuffer.md**(从外部内存创建 ArrayBuffer)

> ⚠️ 前提:这台电脑的 SDK 必须是 API26(已确认:你那台电脑 `apiVersion=26, version=26.0.0.31`,且 4 个 API26 符号在头文件里都在)。手机系统必须是 API26。任一不满足都跑不了。

## 包内容(整个 `jsvm-api26-dist\` 文件夹一起拷过去)

```
jsvm-api26-dist\
└─ jsvm_hap_runner\          ← 源码工程(已接入两篇 API26 示例,含 wasm 等)
   ├─ build-profile.json5     ← 签名/SDK 配置(需按下面改)
   ├─ entry\src\main\cpp\native_bridge.cpp   ← 含 HeapMgmtTest / CreateArrayBufferFromExternal
   ├─ entry\src\main\ets\pages\Index.ets     ← 含两个 API26 按钮
   └─ ...
```

> 说明:本包**不含预编译 HAP**——因为我这台电脑 SDK 是 API24,编不过 API26 代码。**你必须在那台 API26 电脑上自己编译**(下面有命令)。

---

## 第 0 步:确认那台电脑环境(你已经验证过,这里再核对)

```powershell
Get-Content "C:\Program Files\Huawei\DevEco Studio\sdk\default\sdk-pkg.json" -Raw
```
应看到 `"apiVersion": "26"`。若不是 26,这套包编不了,先在 DevEco SDK Manager 装 API26 SDK。

---

## 第 1 步:把工程放好

把 `jsvm-api26-dist\jsvm_hap_runner\` 整个文件夹拷到那台电脑,比如:
```
D:\api26\jsvm_hap_runner\
```

## 第 2 步:处理签名配置(必做,否则编不过)

源码里 `build-profile.json5` 写死了我这台电脑(API24 那台)的签名证书路径,你那台没有这些文件。处理:

**用 DevEco 自动签名(最省事):**
1. DevEco Studio 打开 `D:\api26\jsvm_hap_runner`
2. File → Project Structure → Signing Configs
3. 勾选 **"Automatically generate signature"**,保存

> 这一步 DevEco 会用你那台 API26 电脑的调试证书,把 signingConfig 改成它自己的。

## 第 3 步:命令行编译 + 签名(在那台 API26 电脑的 PowerShell)

```powershell
# 环境变量(按你 DevEco 实际路径,默认就是这个)
$env:DEVECO_SDK_HOME = "C:\Program Files\Huawei\DevEco Studio\sdk"
$env:JAVA_HOME = "C:\Program Files\Huawei\DevEco Studio\jbr"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

cd "D:\api26\jsvm_hap_runner"

& "C:\Program Files\Huawei\DevEco Studio\tools\hvigor\bin\hvigorw.bat" `
    assembleHap --mode module -p product=default -p buildMode=debug --no-daemon
```

**预期**:最后显示 `BUILD SUCCESSFUL`,产物在:
```
D:\api26\jsvm_hap_runner\entry\build\default\outputs\default\entry-default-signed.hap
```

> 若编译报 API26 符号 undeclared:说明那台电脑 SDK 实际不是 26,或 `DEVECO_SDK_HOME` 没指对,回第 0 步核对。

## 第 4 步:装到 API26 手机并运行

手机开开发者选项+USB 调试,USB 连上那台电脑:

```powershell
$hdc = "C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe"

& $hdc list targets                                                                  # 确认连上
& $hdc install -r "D:\api26\jsvm_hap_runner\entry\build\default\outputs\default\entry-default-signed.hap"  # 装包
& $hdc shell "aa start -a EntryAbility -b com.example.jsvm"                          # 启动
```

打开 App,首页往下滚,会看到两个 API26 按钮(橙红色/青色):
- **"ThresholdCallback: 堆快照+阈值回调"**
- **"ExternalArrayBuffer: 外部内存建AB"**

## 第 5 步:点按钮,看结果

### threshold-callback 那篇(点橙色按钮)

详情文本应出现(对照文档"执行结果"):
```
JSVM threshold-callback test start
Set heap threshold callback success
Set repeated callback failed (expected)
Set callback with 0 threshold failed (expected)
== Heap threshold reached ==
Threshold: 1048576 bytes
User data: 305419896
Clear heap threshold callback success
Clear repeated callback failed (expected)
Clear mismatch threshold callback failed (expected)
Heap management test: SUCCESS
JSVM threshold-callback test end
```
同时 `/data/storage/el2/base/temp/` 下应生成 `take.rawheap` 和 `threshold.rawheap` 两个二进制文件(可用 `hdc shell ls /data/storage/el2/base/temp/` 确认)。

### external-arraybuffer 那篇(点青色按钮)

详情文本应出现(对照文档"预期结果"):
```
JSVM external-arraybuffer test start
JSVM CreateArrayBufferFromExternalMemory: success, byteLength=16
  copied=true 或 false
JSVM external-arraybuffer test end
```
关键看 `byteLength=16` 和 `success`(文档说 copied 值随版本变,不依赖)。

## 判定标准

| 文档 | 通过标志 |
|---|---|
| threshold-callback | `Heap management test: SUCCESS` + 生成了 take.rawheap/threshold.rawheap |
| external-arraybuffer | `CreateArrayBufferFromExternalMemory: success, byteLength=16` |

两篇都出现上述标志 = ✅ 跑通。

## 常见问题

- **编译报 `use of undeclared identifier 'OH_JSVM_TakeRawHeapSnapshot'` 等**:那台电脑 SDK 不是 26,或 `DEVECO_SDK_HOME` 没指对 API26 SDK。回第 0 步核对 `apiVersion=26`。
- **编译报 external-arraybuffer 那个符号 undeclared**:确认 `native_bridge.cpp` 第 16 行有 `#define JSVM_EXPERIMENTAL`(在 `#include "ark_runtime/jsvm.h"` 之前)。源码已加,除非被误删。
- **编译报 `Invalid value of 'DEVECO_SDK_HOME'`**:`$env:DEVECO_SDK_HOME` 没设。
- **编译报 `spawn java ENOENT'`**:`$env:JAVA_HOME` 没设或不在 PATH。
- **装包签名不匹配**:第 2 步自动签名没做,或证书路径还指向我那台电脑。重新做第 2 步。
- **threshold-callback 按钮点了但没 SUCCESS**:看详情文本里哪步 FAILED。常见是手机系统其实不是 API26(回第 0 步核对手机 `param get const.ohos.apiversion`)。手机查:`& $hdc shell "param get const.ohos.apiversion"` 应是 26。
- **手机 `const.ohos.apiversion` 不是 26**:手机系统没到 API26,这两篇跑不了。需等手机系统升级到 API26。

## 关键文件位置(在 `jsvm_hap_runner\` 内)

- `entry\src\main\cpp\native_bridge.cpp`:
  - 第 16 行 `#define JSVM_EXPERIMENTAL`(external-arraybuffer 必须)
  - `OnHeapThresholdReached` / `HeapMgmtTest` / `RunThresholdCallbackTest`(threshold-callback)
  - `LoadPixelData` / `PixelDataFinalize` / `CreateArrayBufferFromExternal` / `RunExternalArrayBufferTest`(external-arraybuffer)
- `entry\src\main\cpp\types\libentry\index.d.ts`:导出 `runThresholdCallbackTest` / `runExternalArrayBufferTest`
- `entry\src\main\ets\pages\Index.ets`:两个 API26 按钮
- `build-profile.json5`:签名与 SDK 配置(按第 2 步处理)

## 附:核对手机 API 版本

```powershell
& $hdc shell "param get const.ohos.apiversion"
```
应为 `26`。若为 `24` 等,手机系统不够,这两篇装上也跑不了(运行时 libjsvm.so 没这些符号)。
