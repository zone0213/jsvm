# jsvm-wasm HAP — 在新电脑上的操作清单

验证 OpenHarmony 文档《use-jsvm-about-wasm.md》示例。本包同时给你**预编译好的 HAP**(直接装)和**源码工程**(可改/重签/重编)。

## 包内容(整个 `jsvm-wasm-hap-dist\` 文件夹一起拷过去)

```
jsvm-wasm-hap-dist\
├─ hap\entry-default-signed.hap        ← 已签名 HAP(我机器的 debug profile,无 JIT ACL)
├─ jsvm_hap_runner\                    ← 源码工程(可直接 DevEco 打开重编重签)
└─ README-在新电脑上怎么操作.md        ← 本文件
```

> HAP sha256 = `62A00874598A01C218452A2142D9D6FC2028C08BC1BAE3D94D5A3F382D5C9D54`,1,519,685 字节

---

## 第 0 步:新电脑装环境(只做一次)

1. 装 **DevEco Studio**:https://developer.huawei.com/consumer/cn/deveco-studio/
2. 装完打开一次,让它初始化 SDK(SDK 会装在 `C:\Program Files\Huawei\DevEco Studio\sdk\default`)
3. hdc 工具 DevEco 自带,在 `C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe`

---

## 路线 A:直接装预编译包试跑(最快,3 条命令)

> 适合:只想快速看效果。注意——本包用我机器的 debug profile 签名,**跨机 debug 证书常常装不上**;若装不上,走路线 B 重签。

**复制什么**:把 `jsvm-wasm-hap-dist\hap\entry-default-signed.hap` 拷到新电脑任意位置,比如 `D:\wasm\entry-default-signed.hap`

**命令**(PowerShell,按你 DevEco 实际路径调整 hdc 全路径):

```powershell
$hdc = "C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe"

# 1) 确认手机连上(应输出一串设备号,不是 [Empty])
& $hdc list targets

# 2) 装 HAP(把路径换成你拷过去的实际路径)
& $hdc install -r "D:\wasm\entry-default-signed.hap"

# 3) 启动 App
& $hdc shell "aa start -a EntryAbility -b com.example.jsvm"
```

打开 App,首页往下滚,点紫色按钮 **"Wasm: 编译/实例化/cache"**。

**看结果:**
```powershell
# 抓引擎日志判断
& $hdc shell "hilog -x | grep -iE 'CompileWasmModule|wasm|JIT'"
```
- 出现 `CompileWasmModule status=0` / `add(1,2)=3`(看按钮下方详情文本) → ✅ 跑通(说明那台手机/profile 带 JIT ACL)
- 出现 `Run OH_JSVM_CompileWasmModule failed: ... ACL certificate authorization ...` → ❌ 缺 JIT 权限(普通商用手机多半是这个结果),走路线 B

---

## 路线 B:用源码工程重签重编(推荐,能装能改)

> 适合:路线 A 装不上、或要用自己带 ACL 的 profile、或想改代码。

### 复制什么、放哪

把 **`jsvm_hap_runner\` 整个文件夹**拷到新电脑,比如:
```
D:\wasm\jsvm_hap_runner\
```
(里面有 `build-profile.json5`、`entry\`、`oh-package.json5` 等)

### 先处理签名配置(必做)

源码里的 `build-profile.json5` 写死了我机器的签名证书路径(`C:\Users\admin\.ohos\config\...`),**新电脑上这些文件不存在,直接编会失败**。两种处理:

**B-1 用 DevEco 自动签名(最省事)**
1. DevEco Studio 打开 `D:\wasm\jsvm_hap_runner`
2. File → Project Structure → Signing Configs
3. 勾选 **"Automatically generate signature"**(自动生成调试签名),DevEco 会用你这台新电脑的调试证书签
4. 这会把 `build-profile.json5` 的 signingConfig 改成你这台机器的,保存

**B-2 手动改(不想用自动签名)**
把 `build-profile.json5` 里 `"app" → "signingConfigs"` 整段删掉或改成你这台电脑自己的证书路径。

### 运行什么命令(命令行重编重签)

```powershell
# 设环境变量(按你 DevEco 实际安装路径调整)
$env:DEVECO_SDK_HOME = "C:\Program Files\Huawei\DevEco Studio\sdk"
$env:JAVA_HOME = "C:\Program Files\Huawei\DevEco Studio\jbr"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

cd D:\wasm\jsvm_hap_runner

# 构建 + 签名
& "C:\Program Files\Huawei\DevEco Studio\tools\hvigor\bin\hvigorw.bat" `
    assembleHap --mode module -p product=default -p buildMode=debug --no-daemon
```
成功最后会显示 `BUILD SUCCESSFUL`,产出在:
```
D:\wasm\jsvm_hap_runner\entry\build\default\outputs\default\entry-default-signed.hap
```

然后装跑(同路线 A):
```powershell
$hdc = "C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe"
& $hdc install -r "D:\wasm\jsvm_hap_runner\entry\build\default\outputs\default\entry-default-signed.hap"
& $hdc shell "aa start -a EntryAbility -b com.example.jsvm"
```

### 如果要带 JIT ACL(让 wasm 真跑通)

普通自动签名**没有** JIT ACL,wasm 仍会失败。要带 ACL:

1. 在 `jsvm_hap_runner\entry\src\main\module.json5` 的 `"module": { ... }` 里加:
   ```json5
   "requestPermissions": [
     { "name": "ohos.permission.kernel.ALLOW_EXECUTABLE_FORT_MEMORY" }
   ]
   ```
   > ⚠️ 注意:必须**先**拿到带该 ACL 的 profile,再声明权限;否则**装包会失败**(华为明文告警)。
2. 通过 DevEco 的 ACL 签名向导勾上该 ACL(需你账号有权限),或手动改 SDK 的 `UnsgnedReleasedProfileTemplate.json`:
   ```
   C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\toolchains\lib\UnsgnedReleasedProfileTemplate.json
   ```
   加:
   ```json5
   "acls": { "allowed-acls": ["ohos.permission.kernel.ALLOW_EXECUTABLE_FORT_MEMORY"] }
   ```
3. 重新走上面的 `hvigorw assembleHap` 重签,再装跑。

---

## 判定标准(对照文档"预期输出:无报错")

| 检查项 | 期望(带 ACL 时) |
|---|---|
| CompileWasmModule(bytecode) | status=0 (JSVM_OK) |
| IsWasmModuleObject | true |
| CompileWasmFunction | status=0 |
| 实例化 + 调 add | CallFunction(add)(1,2) status=0 **result=3** |
| CreateWasmCache | status=0, len>0 |

无 ACL 时:第一步 CompileWasmModule 就失败,引擎报 ACL 错——这也是文档"无 JIT 权限会打一行提示日志"的正常表现。

---

## 常见问题

- **路线 A 装不上(签名不匹配/Install Failed)**:跨机 debug 证书不通用,正常。改走路线 B,用新电脑自己的自动签名重编。
- **路线 B 报 `Invalid value of 'DEVECO_SDK_HOME'`**:环境变量没设对,确认 `$env:DEVECO_SDK_HOME` 指向 `...\DevEco Studio\sdk`。
- **路线 B 报 `spawn java ENOENT`**:`JAVA_HOME` 没设或不在 PATH,确认指向 `...\DevEco Studio\jbr` 并加进 PATH。
- **装包失败且加了 requestPermissions**:多半是没拿到 ACL profile 就声明了权限,去掉权限声明或先申请 ACL。
- **设备连不上 hdc**:手机开"开发者选项"+"USB 调试",弹窗点允许;`hdc list targets` 要能看到设备。

---

## 附:源码工程关键文件(在 `jsvm_hap_runner\` 内)

- `entry\src\main\cpp\native_bridge.cpp`:`Wasm_Demo`/`RunWasmTest`(wasm 字节码 + CompileWasmModule/Function/IsWasm/CreateWasmCache 主流程)
- `entry\src\main\cpp\types\libentry\index.d.ts`:导出 `runWasmTest`
- `entry\src\main\ets\pages\Index.ets`:"Wasm: 编译/实例化/cache" 按钮
- `entry\src\main\cpp\CMakeLists.txt`:链接 libjsvm.so/libhilog_ndk.z.so/libace_napi.z.so
- `build-profile.json5`:签名与 SDK 版本配置(需按上面 B-1/B-2 处理)
