import { PreciseStackTestSupport, StackPayload, StackHolder } from './PreciseStackTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals } from '../TestAssertions';

export class PreciseStackSafepointAllocationTest extends PreciseStackTestSupport {

    psF01_liveLocalSurvivesAllocationSafepoints() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    psF02_liveChildGraphSurvivesAllocationSafepoints() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    psF03_clearedLocalIsCollectedAfterAllocationSafepoints() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    psF04_liveLambdaCaptureSurvivesAllocationSafepoints() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    psF05_liveLocalSurvivesLargeAllocationSafepoint() {
        const payload = new StackPayload(1000);
        const holder = new StackHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }
}

