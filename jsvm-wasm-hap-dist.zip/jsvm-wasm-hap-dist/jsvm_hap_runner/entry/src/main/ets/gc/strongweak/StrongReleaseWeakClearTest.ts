// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, setGlobalPayload, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-D group: strong-reference release and WeakReference clearing.
 */
export class StrongReleaseWeakClearTest extends WeakReferenceTestSupport {
    private createAfterLocalStrongSetNull(): WeakReference<Payload> {
        let obj: Payload | null = new Payload(401);
        const weak = new WeakReference(obj);
        obj = null;
        assertNull(obj);
        return weak;
    }
    /**
     * WR-D01
     * Scenario: a local strong reference is set to null.
     * Expectation: after helper returns, weak.value is cleared.
     */
    wrD01_localStrongSetNullClearsWeak() {
        const weak = this.createAfterLocalStrongSetNull();
        this.assertWeakCollected(weak);
    }
    private createAfterHolderStrongClear(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        const obj = new Payload(402);
        const holder = new StrongHolder(obj);
        const weak = new WeakReference(obj);
        holder.ref = null;
        return new WeakOnlyResult(holder, weak);
    }
    /**
     * WR-D02
     * Scenario: holder strong field is cleared.
     * Expectation: the target can be collected.
     */
    wrD02_holderStrongFieldClearClearsWeak() {
        const scenario = this.createAfterHolderStrongClear();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root.ref);
    }
    private createAfterGlobalStrongClear(): WeakReference<Payload> {
        const obj = new Payload(403);
        setGlobalPayload(obj);
        const weak = new WeakReference(obj);
        setGlobalPayload(null);
        return weak;
    }
    /**
     * WR-D03
     * Scenario: global strong reference is cleared.
     * Expectation: weak.value is cleared.
     */
    wrD03_globalStrongClearClearsWeak() {
        const weak = this.createAfterGlobalStrongClear();
        this.assertWeakCollected(weak);
    }
    private createAfterCollectionRemove(): WeakOnlyResult<Payload[], Payload> {
        const obj = new Payload(404);
        const list = [obj];
        const weak = new WeakReference(obj);
        list.remove(obj);
        return new WeakOnlyResult(list, weak);
    }
    /**
     * WR-D04
     * Scenario: object is removed from a strong collection.
     * Expectation: weak.value is cleared.
     */
    wrD04_collectionRemoveClearsWeak() {
        const scenario = this.createAfterCollectionRemove();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    private createAfterCollectionClear(): WeakOnlyResult<Payload[], Payload> {
        const obj = new Payload(405);
        const list = [obj];
        const weak = new WeakReference(obj);
        list.clear();
        return new WeakOnlyResult(list, weak);
    }
    /**
     * WR-D05
     * Scenario: a strong collection is cleared.
     * Expectation: weak.value is cleared.
     */
    wrD05_collectionClearClearsWeak() {
        const scenario = this.createAfterCollectionClear();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    private createAfterArraySlotNull(): WeakOnlyResult<Payload | null[], Payload> {
        const obj = new Payload(406);
        const array = new Array(1).fill(null);
        array[0] = obj;
        const weak = new WeakReference(obj);
        array[0] = null;
        return new WeakOnlyResult(array, weak);
    }
    /**
     * WR-D06
     * Scenario: an array strong slot is set to null.
     * Expectation: weak.value is cleared.
     */
    wrD06_arraySlotNullClearsWeak() {
        const scenario = this.createAfterArraySlotNull();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root[0]);
    }
    private createAfterLambdaStrongCaptureClear(): WeakReference<Payload> {
        const obj = new Payload(407);
        const weak = new WeakReference(obj);
        let block: any = () => obj.id;
        assertEquals(407, block());
        block = null;
        assertNull(block);
        return weak;
    }
    /**
     * WR-D07
     * Scenario: a lambda strongly captures target and then the lambda reference is cleared.
     * Expectation: target can be collected.
     */
    wrD07_lambdaStrongCaptureClearClearsWeak() {
        const weak = this.createAfterLambdaStrongCaptureClear();
        this.assertWeakCollected(weak);
    }
    /**
     * WR-D08
     * Scenario: multiple strong references exist; one holder reference is cleared.
     * Expectation: target remains alive because local strong reference still exists.
     */
    wrD08_releasingOneOfMultipleStrongReferencesDoesNotClearWeak() {
        const obj = new Payload(408);
        const holder = new StrongHolder(obj);
        const weak = new WeakReference(obj);
        holder.ref = null;
        this.forceGc();
        assertEquals(408, obj.id);
        assertNull(holder.ref);
        assertNotNull(weak.value);
    }
    private createAfterAllStrongReferencesReleased(): WeakReference<Payload> {
        let obj: Payload | null = new Payload(409);
        const holder = new StrongHolder(obj);
        const list = [obj];
        const weak = new WeakReference(obj);
        holder.ref = null;
        list.clear();
        obj = null;
        assertNull(obj);
        return weak;
    }
    /**
     * WR-D09
     * Scenario: all strong references are released.
     * Expectation: weak.value is cleared.
     */
    wrD09_releasingAllStrongReferencesClearsWeak() {
        const weak = this.createAfterAllStrongReferencesReleased();
        this.assertWeakCollected(weak);
    }
    private createStrongReplacement(): ReplacementResult<StrongHolder<Payload>, Payload> {
        const oldObj = new Payload(410);
        const holder = new StrongHolder(oldObj);
        const oldWeak = new WeakReference(oldObj);
        const newObj = new Payload(411);
        holder.ref = newObj;
        const newWeak = new WeakReference(newObj);
        return new ReplacementResult(holder, oldWeak, newWeak);
    }
    /**
     * WR-D10
     * Scenario: a strong field is replaced from old target to new target.
     * Expectation: old weak clears; new weak remains alive.
     */
    wrD10_strongReplacementClearsOldWeakAndKeepsNewWeakAlive() {
        const scenario = this.createStrongReplacement();
        this.forceGc();
        scenario.oldWeak.clear();
        assertNull(scenario.oldWeak.value);
        assertNotNull(scenario.newWeak.value);
        assertEquals(411, scenario.root.ref.id);
    }
    /**
     * WR-D11
     * Scenario: a WeakReference variable is replaced while the old target still has a strong reference.
     * Expectation: replacing the WeakReference itself does not affect old target lifetime.
     */
    wrD11_replacingWeakReferenceDoesNotAffectOldTargetWithStrongReference() {
        const oldObj = new Payload(412);
        const newObj = new Payload(413);
        let weak = new WeakReference(oldObj);
        const oldWeakObserver = new WeakReference(oldObj);
        weak = new WeakReference(newObj);
        this.forceGc();
        assertEquals(412, oldObj.id);
        assertEquals(413, newObj.id);
        assertNotNull(oldWeakObserver.value);
        assertNotNull(weak.value);
    }
    private createAfterWeakReferenceReplacementWithoutOldStrong(): WeakReference<Payload> {
        const oldObj = new Payload(414);
        const oldWeakObserver = new WeakReference(oldObj);
        let weak = new WeakReference(oldObj);
        const newObj = new Payload(415);
        weak = new WeakReference(newObj);
        assertEquals(415, weak.value.id);
        return oldWeakObserver;
    }
    /**
     * WR-D12
     * Scenario: WeakReference is changed from old target to new target, and old target has no strong reference.
     * Expectation: old target can be collected.
     */
    wrD12_replacingWeakReferenceAllowsOldTargetCollectionWhenNoStrongExists() {
        const oldWeak = this.createAfterWeakReferenceReplacementWithoutOldStrong();
        this.assertWeakCollected(oldWeak);
    }
}


