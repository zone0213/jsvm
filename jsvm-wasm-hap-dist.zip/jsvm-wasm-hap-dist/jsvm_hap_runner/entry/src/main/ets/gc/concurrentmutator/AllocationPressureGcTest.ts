import { assertEquals, assertNotNull, assertTrue } from '../TestAssertions';
import {
    allocateGarbage,
    assertWeakCollectedEventually,
    forceGc,
    forceGcLoop,
    repeatMutationWithGc,
    runBoundedConcurrentWriters,
    buildChain,
    Holder,
    Node,
    WeakReference,
    assertAllWeakCollectedEventually,
    GC,
} from './ConcurrentGcTestSupport';

export class AllocationPressureGcTest {
    cgH01_singleThreadShortLivedAllocationStorm() {
        allocateGarbage(1024);
        forceGc();
        assertTrue(true);
    }

    cgH02_allocationStormWithLongLivedRoot() {
        const root = new Node(1001);
        const weak = new WeakReference(root);
        allocateGarbage(1024);
        forceGc();
        assertEquals(1001, root.id);
        assertNotNull(weak.value);
    }

    cgH03_allocationStormUpdatingRootField() {
        const holder = new Holder(new Node(1002));
        repeatMutationWithGc(64, (it: number) => {
            holder.ref = new Node(10020 + it);
            allocateGarbage(8);
        });
        assertNotNull(holder.ref);
    }

    async cgH04_multiThreadAllocationStorm() {
        const completed = await runBoundedConcurrentWriters(3, 16, () => allocateGarbage(16));
        assertEquals(3, completed);
    }

    async cgH05_multiThreadAllocationWithGcThread() {
        const completed = await runBoundedConcurrentWriters(2, 16, () => {
            allocateGarbage(16);
            GC.collect();
        });
        assertEquals(2, completed);
    }

    cgH06_allocationStormWithListAddClear() {
        const list: Node[] = [];
        repeatMutationWithGc(64, (it: number) => {
            list.push(new Node(10060 + it));
            if (it % 4 === 0) list.length = 0;
            allocateGarbage(4);
        });
        list.forEach(it => assertTrue(it.id >= 10060));
    }

    cgH07_allocationStormWithMapPutRemove() {
        const map = new Map<number, Node>();
        repeatMutationWithGc(64, (it: number) => {
            map.set(it, new Node(10070 + it));
            if (it % 3 === 0) map.delete(it);
            allocateGarbage(4);
        });
        map.forEach(value => assertTrue(value.id >= 10070));
    }

    cgH08_allocationStormWithWeakObservers() {
        const root = new Node(1008);
        const weak = new WeakReference(root);
        allocateGarbage(2048);
        forceGc();
        assertEquals(1008, root.id);
        assertNotNull(weak.value);
    }

    cgH09_allocationStormThenClearRoot() {
        const holder = new Holder(new Node(1009));
        const weak = new WeakReference(holder.ref!);
        allocateGarbage(512);
        holder.ref = null;
        assertWeakCollectedEventually(weak);
    }

    cgH10_busyLoopSafepointCooperation() {
        const holder = new Holder(new Node(1010));
        const count = repeatMutationWithGc(128, (it: number) => { holder.ref = new Node(10100 + it); });
        assertEquals(128, count);
        assertNotNull(holder.ref);
    }

    cgH11_allocationPressureAttachLargeChain() {
        const holder = new Holder<Node>(null);
        const chain = buildChain(8, 1011);
        const weaks = chain.map(node => new WeakReference(node));
        allocateGarbage(512);
        holder.ref = chain[0];
        forceGc();
        weaks.forEach((weak, i) => assertNotNull(weak.value, `Expected weak[${i}] to remain alive.`));
        assertNotNull(holder.ref);
    }

    cgH12_allocationPressureDetachLargeChain() {
        const chain = buildChain(8, 1020);
        const root = new Holder(chain[0]);
        const suffix = chain.slice(1).map(node => new WeakReference(node));
        allocateGarbage(512);
        if (chain[0]) chain[0].next = null;
        forceGc();
        assertEquals(1020, root.ref!.id);
        assertAllWeakCollectedEventually(suffix);
    }
}

