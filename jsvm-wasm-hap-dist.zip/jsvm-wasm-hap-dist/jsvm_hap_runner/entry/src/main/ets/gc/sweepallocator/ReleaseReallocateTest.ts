import { SweepAllocatorTestSupport } from './SweepAllocatorTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '../TestAssertions';

export class ReleaseReallocateTest extends SweepAllocatorTestSupport {

    sa_h01() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h02() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h03() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h04() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h05() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h06() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h07() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h08() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h09() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h10() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h11() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_h12() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }
}

