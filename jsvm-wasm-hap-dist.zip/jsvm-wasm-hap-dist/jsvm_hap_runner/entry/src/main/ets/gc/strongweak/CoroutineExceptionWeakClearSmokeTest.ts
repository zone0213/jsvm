// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * Minimal reproduction extracted from LS-J06.
 *
 * It keeps only the exception-path allocation pattern:
 * - create a batch of objects,
 * - publish only WeakReference handles,
 * - throw/catch on every iteration,
 * - then require all weak targets to clear after GC.
 */
export class CoroutineExceptionWeakClearSmokeTest extends WeakReferenceTestSupport {
    private createWeaksAfterExceptionBatch(count: number = 32): WeakReference<Payload>[] {
        const weaks = [];
        for (let index = 0; index < count; index++) {
            const payload = new Payload(6000 + index);
            weaks.add(new WeakReference(payload));
            try {
                throw new Error(`cancel-${index}`);
            } catch (_: Throwable) {
            }
        }
        return weaks;
    }
    /**
     * Scenario: each short-lived object is created on an exception path and only a WeakReference escapes.
     * Expectation: all weak targets are cleared after repeated GC.
     */
    weakTargetsCreatedOnExceptionPathAreCleared() {
        const weaks = this.createWeaksAfterExceptionBatch();
        this.assertAllWeakCollected(weaks);
    }
}

