import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';
import {
    arrayClearScenario,
    arrayPutScenario,
    assertAllWeakCollectedEventually,
    assertWeakAlive,
    assertWeakCollectedEventually,
    buildChain,
    buildTree,
    listAddScenario,
    listRemoveScenario,
    mapPutScenario,
    mapRemoveScenario,
    forceGc,
    forceGcLoop,
    runGcAroundMutation,
    repeatMutationWithGc,
    WeakReference,
    Node,
} from './ConcurrentGcTestSupport';

export class ConcurrentContainerMutationTest {
    cgE01_arrayWriteElementDuringGc() {
        forceGc();
        const [array, weak] = arrayPutScenario(701);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(array[0]);
    }

    cgE02_arrayClearElementDuringGc() {
        assertWeakCollectedEventually(arrayClearScenario(702));
    }

    cgE03_arrayReplaceElementDuringGc() {
        const old = new Node(703);
        const array: Array<Node | null> = [null];
        array[0] = old;
        const oldWeak = new WeakReference(old);
        const neu = new Node(704);
        const newWeak = new WeakReference(neu);
        runGcAroundMutation(() => { array[0] = neu; });
        assertWeakCollectedEventually(oldWeak);
        assertWeakAlive(newWeak);
        assertEquals(704, array[0]!.id);
    }

    cgE04_arrayWriteNewChainDuringGc() {
        forceGc();
        const array: Array<Node | null> = [null];
        const chain = buildChain(4, 705);
        const weaks = chain.map(node => new WeakReference(node));
        array[0] = chain[0];
        forceGc();
        assertEquals(705, array[0]!.id);
        weaks.forEach((weak, index) => assertNotNull(weak.value, `Expected weak[${index}] to remain alive.`));
    }

    cgE05_listAddDuringGc() {
        forceGc();
        const [list, weak] = listAddScenario(710);
        forceGc();
        assertNotNull(weak.value);
        assertTrue(list.length > 0);
    }

    cgE06_listRemoveDuringGc() {
        assertWeakCollectedEventually(listRemoveScenario(711));
    }

    cgE07_listClearDuringGc() {
        const nodes = buildChain(4, 720);
        const list = [...nodes];
        const weaks = nodes.map(node => new WeakReference(node));
        runGcAroundMutation(() => { list.length = 0; });
        assertAllWeakCollectedEventually(weaks);
    }

    cgE08_listAddSharedObjectDuringGc() {
        const shared = new Node(730);
        const weak = new WeakReference(shared);
        const l1: Node[] = [];
        const l2: Node[] = [];
        runGcAroundMutation(() => {
            l1.push(shared);
            l2.push(shared);
        });
        assertEquals(730, l1[0].id);
        assertEquals(730, l2[0].id);
        assertNotNull(weak.value);
    }

    cgE09_listRemoveOneSharedEdgeDuringGc() {
        const shared = new Node(731);
        const weak = new WeakReference(shared);
        const l1: Node[] = [shared];
        const l2: Node[] = [shared];
        runGcAroundMutation(() => { l1.splice(l1.indexOf(shared), 1); });
        assertTrue(l1.length === 0);
        assertEquals(731, l2[0].id);
        assertNotNull(weak.value);
    }

    cgE10_listRemoveAllSharedEdgesDuringGc() {
        const shared = new Node(732);
        const weak = new WeakReference(shared);
        const l1: Node[] = [shared];
        const l2: Node[] = [shared];
        runGcAroundMutation(() => { l1.length = 0; l2.length = 0; });
        assertWeakCollectedEventually(weak);
    }

    cgE11_mapPutValueDuringGc() {
        forceGc();
        const [map, weak] = mapPutScenario(740);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(map.get('k'));
    }

    cgE12_mapRemoveValueDuringGc() {
        assertWeakCollectedEventually(mapRemoveScenario(741));
    }

    cgE13_mapReplaceValueDuringGc() {
        const old = new Node(742);
        const map = new Map<string, Node>([['k', old]]);
        const oldWeak = new WeakReference(old);
        const neu = new Node(743);
        const newWeak = new WeakReference(neu);
        forceGc();
        map.set('k', neu);
        forceGc();
        assertEquals(neu, map.get('k'));
        forceGcLoop();
        assertWeakCollectedEventually(oldWeak);
        forceGc();
        assertNotNull(newWeak.value);
        assertEquals(743, map.get('k')!.id);
    }

    cgE14_mapKeyHoldsObjectDuringGc() {
        const key = new Node(744);
        const weak = new WeakReference(key);
        const map = new Map<Node, string>([[key, 'v']]);
        forceGc();
        assertEquals('v', map.get(key));
        assertNotNull(weak.value);
    }

    cgE15_mapRemoveKeyObjectDuringGc() {
        const key = new Node(745);
        const weak = new WeakReference(key);
        const map = new Map<Node, string>([[key, 'v']]);
        runGcAroundMutation(() => { map.delete(key); });
        assertWeakCollectedEventually(weak);
    }

    cgE16_concurrentListAddRemoveWithGc() {
        const list: Node[] = [];
        const count = repeatMutationWithGc(32, (it: number) => {
            if (it % 2 === 0) list.push(new Node(750 + it));
            else if (list.length > 0) list.splice(0, 1);
        });
        assertEquals(32, count);
        list.forEach(item => assertTrue(item.id >= 750));
    }

    cgE17_concurrentMapPutRemoveWithGc() {
        const map = new Map<number, Node>();
        const count = repeatMutationWithGc(32, (it: number) => {
            map.set(it, new Node(760 + it));
            if (it % 2 === 1) map.delete(it - 1);
        });
        assertEquals(32, count);
        map.forEach(value => assertTrue(value.id >= 760));
    }

    cgE18_containerPressureAddClearWithGc() {
        const list: Node[] = [];
        repeatMutationWithGc(64, (it: number) => {
            list.push(new Node(770 + it));
            if (it % 8 === 0) list.length = 0;
        });
        forceGc();
        list.forEach(item => assertTrue(item.id >= 770));
    }
}

