import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue } from '../TestAssertions';

export class ExceptionalBoundaryTestSupport {
    protected forceGc() {
        for (let i = 0; i < 3; i++) {
            GC.collect();
        }
    }

    protected weakCheck(obj: any): WeakReference<any> | null {
        return obj != null ? new WeakReference(obj) : null;
    }
}

