import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue, assertNotNull, assertNull } from '../TestAssertions';

const GC_REPEAT_COUNT = 3;

export class ReachabilityTestSupport {
    beforeTest() {
        this.clearGlobalRoots();
    }

    afterTest() {
        this.clearGlobalRoots();
        this.forceGc();
    }

    protected forceGc() {
        for (let i = 0; i < GC_REPEAT_COUNT; i++) {
            GC.collect();
        }
    }

    protected clearGlobalRoots() {
        globalPayload = null;
        globalAny = null;
        globalMarker = null;
        GlobalHolder.ref = null;
        CompanionRootHolder.ref = null;
    }

    protected assertWeakAlive<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected object to remain reachable, but WeakReference was cleared."
    ): T {
        this.forceGc();
        const value = weak.value;
        assertNotNull(value, message);
        return value;
    }

    protected assertWeakCollected<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected object to become unreachable and be collected."
    ) {
        this.forceGc();
        weak.clear();
        assertNull(weak.value, message);
    }
}

export interface Marker {
    id: number;
}

export class BasePayload {
    id: number;
    constructor(id: number) {
        this.id = id;
    }
}

export class Payload extends BasePayload implements Marker {
    child: Payload | null = null;

    constructor(id: number) {
        super(id);
    }

    toString(): string {
        return `Payload(id=${this.id})`;
    }
}

export class ChildPayload extends BasePayload implements Marker {
    constructor(id: number) {
        super(id);
    }
}

export class DataPayload implements Marker {
    id: number;
    constructor(id: number) {
        this.id = id;
    }
}

export class PayloadHolder {
    ref: Payload | null = null;
    constructor(ref?: Payload | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class AnyHolder {
    ref: any = null;
    constructor(ref?: any) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class InterfaceHolder {
    ref: Marker | null = null;
    constructor(ref?: Marker | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class BaseHolder {
    ref: BasePayload | null = null;
    constructor(ref?: BasePayload | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class TwoLevelHolder {
    child: PayloadHolder | null = null;
    constructor(child?: PayloadHolder | null) {
        if (child !== undefined) this.child = child;
    }
}

export class Box<T> {
    value: T | null = null;
    constructor(value?: T | null) {
        if (value !== undefined) this.value = value;
    }
}

export class LambdaHolder {
    block: (() => number) | null = null;
    constructor(block?: (() => number) | null) {
        if (block !== undefined) this.block = block;
    }
}

export class RootedWeak<R, T> { constructor(public root: R, public weak: WeakReference<T>) {} }

export class ReplacementResult<T> { constructor(public liveObject: T, public oldWeak: WeakReference<T>, public newWeak: WeakReference<T>) {} }

export class HolderReplacementResult<H, T> { constructor(public holder: H, public oldWeak: WeakReference<T>, public newWeak: WeakReference<T>) {} }

export class TwoLevelDisconnectResult { constructor(public root: TwoLevelHolder, public midWeak: WeakReference<PayloadHolder>, public leafWeak: WeakReference<Payload>) {} }

export class LoopReplacementResult { constructor(public liveObject: Payload, public oldWeaks: WeakReference<Payload>[], public liveWeak: WeakReference<Payload>) {} }

export let globalPayload: Payload | null = null;
export let globalAny: any = null;
export let globalMarker: Marker | null = null;

export function setGlobalPayload(value: Payload | null): void { globalPayload = value; }
export function setGlobalAny(value: any): void { globalAny = value; }
export function setGlobalMarker(value: Marker | null): void { globalMarker = value; }

export const GlobalHolder = {
    ref: null as Payload | null
};

export const CompanionRootHolder = {
    ref: null as Payload | null
};





