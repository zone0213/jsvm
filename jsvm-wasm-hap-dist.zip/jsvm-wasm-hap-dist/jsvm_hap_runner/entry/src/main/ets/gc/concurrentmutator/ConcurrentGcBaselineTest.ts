import { assertEquals, assertNotNull, assertTrue } from '../TestAssertions';
import {
    singleThreadBaseline,
    runWorkerMutationWithMainGc,
    runWorkerTask,
    repeatMutationWithGc,
    runBoundedConcurrentWriters,
    runGcAroundMutation,
    allocateGarbage,
    forceGc,
    forceGcLoop,
    SMALL_ITERATIONS,
    globalHolder,
    Holder,
    Node,
    GC,
    WeakReference
} from './ConcurrentGcTestSupport';

/**
 * CG-A group: concurrent GC baseline and synchronization-window tests.
 */
export class ConcurrentGcBaselineTest {

    // CG-A01
    // Scenario: single-thread mutator and manual GC baseline.
    // Expectation: object remains alive after GC.
    cgA01_singleThreadGcBaseline() {
        assertTrue(singleThreadBaseline());
    }

    // CG-A02
    // Scenario: worker holds object while main thread performs GC.
    // Expectation: worker can still access object.
    async cgA02_workerHoldsObjectMainThreadGc() {
        assertTrue(await runWorkerMutationWithMainGc(() => {
            const node = new Node(102);
            const weak = new WeakReference(node);
            GC.collect();
            return node.id === 102 && weak.value != null;
        }));
    }

    // CG-A03
    // Scenario: main holds object while worker thread performs GC.
    // Expectation: main object remains alive.
    async cgA03_mainHoldsObjectWorkerThreadGc() {
        const node = new Node(103);
        const weak = new WeakReference(node);
        assertTrue(await runWorkerTask(() => {
            GC.collect();
            return true;
        }));
        assertEquals(103, node.id);
        assertNotNull(weak.value);
    }

    // CG-A04
    // Scenario: independent worker repeatedly triggers GC while mutator is idle.
    // Expectation: no crash and worker completes.
    async cgA04_gcWorkerLoopWithIdleMutator() {
        assertTrue(await runWorkerTask(() => {
            for (let i = 0; i < 16; i++) GC.collect();
            return true;
        }));
    }

    // CG-A05
    // Scenario: mutator repeatedly writes holder.ref while GC is repeatedly triggered.
    // Expectation: no crash and writes occur.
    cgA05_mutatorLoopWritesWhileGcCollects() {
        const holder = new Holder<Node>(null as any);
        const count = repeatMutationWithGc((it: number) => { holder.ref = new Node(1050 + it); });
        assertEquals(SMALL_ITERATIONS, count);
        assertNotNull(holder.ref);
    }

    // CG-A06
    // Scenario: multiple bounded mutators start and complete write loops.
    // Expectation: all bounded writers complete.
    cgA06_multipleMutatorEmptyWriteBaseline() {
        const completed = runBoundedConcurrentWriters(2, (writer: number, i: number) => {
            globalHolder.ref = new Node(10600 + writer * 100 + i);
        });
        assertEquals(2, completed);
        assertNotNull(globalHolder.ref);
    }

    // CG-A07
    // Scenario: bounded mutation window around GC is exercised.
    // Expectation: mutation completes without deadlock.
    cgA07_readyContinueGateLikeBaseline() {
        let mutated = false;
        runGcAroundMutation(() => { mutated = true; });
        assertTrue(mutated);
    }

    // CG-A08
    // Scenario: single-thread allocation pressure with GC.
    // Expectation: no crash.
    cgA08_allocationPressureBaseline() {
        allocateGarbage();
        forceGc();
        assertTrue(true);
    }

    // CG-A09
    // Scenario: repeated GC collect baseline.
    // Expectation: no crash.
    cgA09_repeatedGcCollectBaseline() {
        forceGcLoop();
        assertTrue(true);
    }

    // CG-A10
    // Scenario: bounded loop simulates timeout-safe concurrent test structure.
    // Expectation: loop completes.
    cgA10_boundedTimeoutStyleBaseline() {
        const count = repeatMutationWithGc(8, () => { allocateGarbage(16); });
        assertEquals(8, count);
    }

}

// Export a default instance for runners that prefer instance methods.
export default new ConcurrentGcBaselineTest();

