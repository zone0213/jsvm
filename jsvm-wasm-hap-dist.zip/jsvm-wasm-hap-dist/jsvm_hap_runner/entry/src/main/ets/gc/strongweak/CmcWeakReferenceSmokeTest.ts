// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * Minimal smoke test for checking whether WeakReference target clearing works
 * when no strong reference to the target escapes.
 */
export class CmcWeakReferenceSmokeTest extends WeakReferenceTestSupport {
    private createWeakOnlyTarget(): WeakReference<Payload> {
        const payload = new Payload(999);
        return new WeakReference(payload);
    }
    weakOnlyTargetIsClearedAfterRepeatedGc() {
        const weak = this.createWeakOnlyTarget();
        for (let _i = 0; _i < 1000; _i++) {
            GC.collect();
        }
        weak.clear();
        assertNull(weak.value);
    }
}

