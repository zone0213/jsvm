import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue, assertNotNull, assertNull } from '../TestAssertions';

const GC_REPEAT_COUNT = 3;

export class RootSetTestSupport {
    beforeTest() {
        this.clearMutableRoots();
        this.forceGc();
    }

    afterTest() {
        this.clearMutableRoots();
        this.forceGc();
    }

    protected forceGc() {
        for (let i = 0; i < GC_REPEAT_COUNT; i++) {
            GC.collect();
        }
    }

    protected clearMutableRoots() {
        globalPayload = null;
        globalAny = null;
        globalMarker = null;
        globalHolder = null;
        globalArray = null;
        globalList = null;
        globalMap = null;
        ObjectRootHolder.payload = null;
        ObjectRootHolder.holder = null;
        CompanionRootHolder.payload = null;
        CompanionRootHolder.holder = null;
        clearableLateinitLikePayload = null;
        threadLocalPayload = null;
        threadLocalAny = null;
        threadLocalMarker = null;
        threadLocalHolder = null;
        threadLocalList = null;
    }

    protected assertWeakAlive<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected object to remain reachable from a root."
    ): T {
        this.forceGc();
        const value = weak.value;
        assertNotNull(value, message);
        return value;
    }

    protected assertWeakCollected<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected object to become unreachable after root disappears."
    ) {
        this.forceGc();
        weak.clear();
        assertNull(weak.value, message);
    }

    protected assertAllWeakAlive<T extends any>(weaks: Iterable<WeakReference<T>>) {
        this.forceGc();
        let index = 0;
        for (const weak of weaks) {
            assertNotNull(weak.value, `Expected weak[${index}] value to remain alive.`);
            index++;
        }
    }

    protected assertAllWeakCollected<T extends any>(weaks: Iterable<WeakReference<T>>) {
        this.forceGc();
        let index = 0;
        for (const weak of weaks) {
            weak.clear();
            assertNull(weak.value, `Expected weak[${index}] value to be cleared.`);
            index++;
        }
    }
}

export interface RootMarker {
    id: number;
}

export class RootPayload implements RootMarker {
    id: number;
    child: RootPayload | null = null;

    constructor(id: number) {
        this.id = id;
    }

    toString(): string {
        return `RootPayload(id=${this.id})`;
    }
}

export class MarkerPayload implements RootMarker {
    id: number;
    constructor(id: number) {
        this.id = id;
    }
}

export class RootHolder<T> {
    ref: T | null = null;
    constructor(ref?: T | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class RootBox<T> {
    value: T | null = null;
    constructor(value?: T | null) {
        if (value !== undefined) this.value = value;
    }
}

export class RootWrapper<T> {
    ref: T | null = null;
    constructor(ref?: T | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export class RootedWeak<R, T> { constructor(public root: R, public weak: WeakReference<T>) {} }

export class MixedRootWeaks<R, T> { constructor(public root: R, public aliveWeaks: WeakReference<T>[], public collectedWeaks: WeakReference<T>[]) {} }

export class ReplacementRoot<R, T> { constructor(public root: R, public oldWeak: WeakReference<T>, public newWeak: WeakReference<T>) {} }

export let globalPayload: RootPayload | null = null;
export let globalAny: any = null;
export let globalMarker: RootMarker | null = null;
export let globalHolder: RootHolder<RootPayload> | null = null;
export let globalArray: RootPayload[] | null = null;
export let globalList: RootPayload[] | null = null;
export let globalMap: Map<string, RootPayload> | null = null;

export const ObjectRootHolder = {
    payload: null as RootPayload | null,
    holder: null as RootHolder<RootPayload> | null
};

export const CompanionRootHolder = {
    payload: null as RootPayload | null,
    holder: null as RootHolder<RootPayload> | null
};

export let clearableLateinitLikePayload: RootPayload | null = null;
export let threadLocalPayload: RootPayload | null = null;
export let threadLocalAny: any = null;
export let threadLocalMarker: RootMarker | null = null;
export let threadLocalHolder: RootHolder<RootPayload> | null = null;
export let threadLocalList: RootPayload[] | null = null;




