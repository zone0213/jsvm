import { SweepAllocatorTestSupport } from './SweepAllocatorTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '../TestAssertions';

export class SweepAllocatorRegressionTest extends SweepAllocatorTestSupport {

    sa_m01() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m02() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m03() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m04() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m05() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m06() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m07() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m08() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m09() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m10() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m11() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_m12() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }
}

