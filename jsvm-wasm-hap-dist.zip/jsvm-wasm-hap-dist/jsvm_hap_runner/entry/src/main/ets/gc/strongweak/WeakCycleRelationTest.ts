// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-I group: weak references in simple cycle-like relations.
 */
export class WeakCycleRelationTest extends WeakReferenceTestSupport {
    /**
     * WR-I01
     * Scenario: root -> parent, parent strongly points to child, and child weakly points to parent.
     * Expectation: parent and child survive because of root -> parent -> child strong path.
     */
    wrI01_oneStrongOneWeakCycleRootParentKeepsBothAlive() {
        const parent = new Payload(901);
        const child = new Payload(902);
        parent.strong = child;
        child.weak = new WeakReference(parent);
        const root = new Root(parent);
        const weakParent = child.weak;
        const weakChild = new WeakReference(child);
        this.forceGc();
        assertEquals(901, root.ref.id);
        assertEquals(902, root.ref.strong.id);
        assertNotNull(weakParent.value);
        assertNotNull(weakChild.value);
    }
    private createRootChildWithChildWeakParent(): WeakOnlyResult<Root<Payload>, Payload> {
        const parent = new Payload(903);
        const child = new Payload(904);
        child.weak = new WeakReference(parent);
        return new WeakOnlyResult(new Root(child), child.weak);
    }
    /**
     * WR-I02
     * Scenario: root -> child, and child weakly points to parent.
     * Expectation: child survives, but parent is not kept alive by weak edge.
     */
    wrI02_oneStrongOneWeakCycleRootChildDoesNotKeepParentAlive() {
        const scenario = this.createRootChildWithChildWeakParent();
        this.forceGc();
        assertEquals(904, scenario.root.ref.id);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    private createOneStrongOneWeakNoRoot(): WeakReference<Payload>[] {
        const parent = new Payload(905);
        const child = new Payload(906);
        parent.strong = child;
        child.weak = new WeakReference(parent);
        return [new WeakReference(parent), new WeakReference(child)];
    }
    /**
     * WR-I03
     * Scenario: parent strongly points to child and child weakly points to parent, with no root.
     * Expectation: both objects can be collected.
     */
    wrI03_oneStrongOneWeakCycleWithoutRootCanBeCollected() {
        const weaks = this.createOneStrongOneWeakNoRoot();
        this.assertAllWeakCollected(weaks);
    }
    private createTwoWeakMutualNoRoot(): WeakReference<Payload>[] {
        const a = new Payload(907);
        const b = new Payload(908);
        a.weak = new WeakReference(b);
        b.weak = new WeakReference(a);
        return [new WeakReference(a), new WeakReference(b)];
    }
    /**
     * WR-I04
     * Scenario: two objects weakly point to each other with no root.
     * Expectation: both objects can be collected.
     */
    wrI04_twoWeakMutualReferencesWithoutRootCanBeCollected() {
        const weaks = this.createTwoWeakMutualNoRoot();
        this.assertAllWeakCollected(weaks);
    }
    private createRootAWithTwoWeakMutual(): MixedWeakResult<Root<Payload>, Payload> {
        const a = new Payload(909);
        const b = new Payload(910);
        a.weak = new WeakReference(b);
        b.weak = new WeakReference(a);
        return new MixedWeakResult(new Root(a), [new WeakReference(a), b.weak], [a.weak, new WeakReference(b)]);
    }
    /**
     * WR-I05
     * Scenario: a and b weakly point to each other, and root points only to a.
     * Expectation: a survives through root; b can be collected.
     */
    wrI05_twoWeakMutualReferencesWithRootACollectsBOnly() {
        const scenario = this.createRootAWithTwoWeakMutual();
        this.forceGc();
        assertEquals(909, scenario.root.ref.id);
        this.assertAllWeakAlive(scenario.aliveWeaks);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
    /**
     * WR-I06
     * Scenario: two objects strongly point to each other and root points to a.
     * Expectation: both objects survive.
     */
    wrI06_twoStrongMutualReferencesWithRootKeepBothAlive() {
        const a = new Payload(911);
        const b = new Payload(912);
        a.strong = b;
        b.strong = a;
        const root = new Root(a);
        const weakA = new WeakReference(a);
        const weakB = new WeakReference(b);
        this.forceGc();
        assertEquals(911, root.ref.id);
        assertEquals(912, root.ref.strong.id);
        assertNotNull(weakA.value);
        assertNotNull(weakB.value);
    }
    private createTwoStrongMutualNoRoot(): WeakReference<Payload>[] {
        const a = new Payload(913);
        const b = new Payload(914);
        a.strong = b;
        b.strong = a;
        return [new WeakReference(a), new WeakReference(b)];
    }
    /**
     * WR-I07
     * Scenario: two objects strongly point to each other, but no root points to the cycle.
     * Expectation: tracing GC can collect the strong cycle.
     */
    wrI07_twoStrongMutualReferencesWithoutRootCanBeCollected() {
        const weaks = this.createTwoStrongMutualNoRoot();
        this.assertAllWeakCollected(weaks);
    }
    /**
     * WR-I08
     * Scenario: weak observers point to a reachable strong cycle.
     * Expectation: observers remain non-null while root keeps the cycle alive.
     */
    wrI08_weakObserversToReachableStrongCycleRemainNonNull() {
        const a = new Payload(915);
        const b = new Payload(916);
        a.strong = b;
        b.strong = a;
        const root = new Root(a);
        const weakA = new WeakReference(a);
        const weakB = new WeakReference(b);
        this.forceGc();
        assertEquals(915, root.ref.id);
        assertNotNull(weakA.value);
        assertNotNull(weakB.value);
    }
    private createStrongCycleAfterRootClear(): WeakReference<Payload>[] {
        const a = new Payload(917);
        const b = new Payload(918);
        a.strong = b;
        b.strong = a;
        const root = new Root(a);
        const weakA = new WeakReference(a);
        const weakB = new WeakReference(b);
        root.ref = null;
        return [weakA, weakB];
    }
    /**
     * WR-I09
     * Scenario: root to a strong cycle is cleared.
     * Expectation: weak observers are cleared after the cycle becomes unreachable.
     */
    wrI09_clearingRootToStrongCycleClearsWeakObservers() {
        const weaks = this.createStrongCycleAfterRootClear();
        this.assertAllWeakCollected(weaks);
    }
    private createWeakToStrongCycleEntryNoRoot(): WeakReference<Payload>[] {
        const a = new Payload(919);
        const b = new Payload(920);
        a.strong = b;
        b.strong = a;
        return [new WeakReference(a), new WeakReference(b)];
    }
    /**
     * WR-I10
     * Scenario: weak observers point to an unreachable strong cycle.
     * Expectation: the cycle is collected and observers clear.
     */
    wrI10_weakToUnreachableStrongCycleEntryClears() {
        const weaks = this.createWeakToStrongCycleEntryNoRoot();
        this.assertAllWeakCollected(weaks);
    }
    /**
     * WR-I11
     * Scenario: root points to a strong cycle entry, and weak observes an internal node.
     * Expectation: internal node survives and weak.value remains non-null.
     */
    wrI11_weakToInternalNodeOfReachableStrongCycleRemainsAlive() {
        const a = new Payload(921);
        const b = new Payload(922);
        a.strong = b;
        b.strong = a;
        const root = new Root(a);
        const weakB = new WeakReference(b);
        this.forceGc();
        assertEquals(921, root.ref.id);
        assertEquals(922, root.ref.strong.id);
        assertNotNull(weakB.value);
    }
    private createWeakEdgeBreaksOnlyPathToSubgraph(): MixedWeakResult<Root<Payload>, Payload> {
        const a = new Payload(923);
        const b = new Payload(924);
        const c = new Payload(925);
        a.weak = new WeakReference(b);
        b.strong = c;
        return new MixedWeakResult(new Root(a), [new WeakReference(a)], [a.weak, new WeakReference(b), new WeakReference(c)]);
    }
    /**
     * WR-I12
     * Scenario: root -> a, a weakly points to b, and b strongly points to c.
     * Expectation: weak edge from a does not keep b or c alive.
     */
    wrI12_weakEdgeBreaksOnlyPathToSubgraph() {
        const scenario = this.createWeakEdgeBreaksOnlyPathToSubgraph();
        this.forceGc();
        assertEquals(923, scenario.root.ref.id);
        this.assertAllWeakAlive(scenario.aliveWeaks);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
}


