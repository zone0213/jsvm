import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/** GT-B group: linear linked graph tests. */
export class LinkedGraphTest extends GraphTopologyTestSupport {

    private chainRoot(length: number, startId: number): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildGraphNodeChain(length, startId);
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-B01: a 2-node chain keeps head and tail alive. */
    gtB01_twoNodeChainKeepsAllNodesAlive() {
        const scenario = this.chainRoot(2, 201);
        this.forceGc();
        assertEquals(201, scenario.root.ref!.id);
        assertEquals(202, scenario.root.ref!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-B02: a 3-node chain keeps head, middle and tail alive. */
    gtB02_threeNodeChainKeepsAllNodesAlive() {
        const scenario = this.chainRoot(3, 210);
        this.forceGc();
        assertEquals(212, scenario.root.ref!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-B03: a 10-node chain keeps representative nodes alive. */
    gtB03_tenNodeChainKeepsHeadMiddleAndTailAlive() {
        const scenario = this.chainRoot(10, 220);
        this.forceGc();
        assertEquals(220, scenario.weaks[0].value!.id);
        assertEquals(225, scenario.weaks[5].value!.id);
        assertEquals(229, scenario.weaks[9].value!.id);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-B04: a 100-node chain keeps head, middle and tail alive. */
    gtB04_hundredNodeChainKeepsRepresentativeNodesAlive() {
        const scenario = this.chainRoot(100, 240);
        this.forceGc();
        assertEquals(240, scenario.weaks[0].value!.id);
        assertEquals(289, scenario.weaks[49].value!.id);
        assertEquals(339, scenario.weaks[99].value!.id);
        assertNotNull(scenario.root.ref);
    }

    private chainAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildGraphNodeChain(100, 350);
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(nodes);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-B05: clearing root allows the entire chain to be collected. */
    gtB05_clearingRootAllowsEntireChainCollection() {
        const scenario = this.chainAfterRootClear();
        assertNull(scenario.root.ref);
        this.assertAllCollected(scenario.weaks);
    }

    private chainAfterHeadNextClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildGraphNodeChain(10, 460);
        const root = new GraphRoot(nodes.first());
        nodes[0].next = null;
        return new MixedWeaks(root, this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-B06: clearing head.next keeps head alive and collects the suffix. */
    gtB06_clearingHeadNextCollectsSuffixOnly() {
        const scenario = this.chainAfterHeadNextClear();
        this.forceGc();
        assertEquals(460, scenario.root.ref!.id);
        assertNull(scenario.root.ref!.next);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private chainAfterMiddleNextClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildGraphNodeChain(100, 500);
        const root = new GraphRoot(nodes.first());
        nodes[49].next = null;
        return new MixedWeaks(root, this.weakRefs(nodes.take(50)), this.weakRefs(nodes.drop(50)));
    }

    /** GT-B07: clearing a middle edge keeps the prefix alive and collects the suffix. */
    gtB07_clearingMiddleNextCollectsSuffixOnly() {
        const scenario = this.chainAfterMiddleNextClear();
        this.forceGc();
        assertEquals(549, scenario.aliveWeaks.last().value!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private chainAfterTailBeforeClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildGraphNodeChain(100, 700);
        const root = new GraphRoot(nodes.first());
        nodes[98].next = null;
        return new MixedWeaks(root, this.weakRefs(nodes.take(99)), this.weakRefs(nodes.drop(99)));
    }

    /** GT-B08: clearing the edge before the tail collects only the tail. */
    gtB08_clearingTailBeforeEdgeCollectsTailOnly() {
        const scenario = this.chainAfterTailBeforeClear();
        this.forceGc();
        assertEquals(798, scenario.aliveWeaks.last().value!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private headSubChainReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        const oldNodes = this.buildGraphNodeChain(10, 820);
        const root = new GraphRoot(oldNodes.first());
        const oldSuffixWeaks = this.weakRefs(oldNodes.drop(1));
        const newNodes = this.buildGraphNodeChain(3, 900);
        root.ref!.next = newNodes.first();
        return new ReplacementWeaks(root, oldSuffixWeaks, this.weakRefs(newNodes));
    }

    /** GT-B09: replacing head.next collects the old suffix and keeps the new suffix alive. */
    gtB09_replacingHeadSubChainCollectsOldSuffixAndKeepsNewSuffixAlive() {
        const scenario = this.headSubChainReplacement();
        this.forceGc();
        assertEquals(900, scenario.root.ref!.next!.id);
        this.assertAllCollected(scenario.oldWeaks);
        this.assertAllAlive(scenario.newWeaks);
    }

    private middleSubChainReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        const oldNodes = this.buildGraphNodeChain(100, 1000);
        const root = new GraphRoot(oldNodes.first());
        const oldSuffixWeaks = this.weakRefs(oldNodes.drop(50));
        const newNodes = this.buildGraphNodeChain(5, 2000);
        oldNodes[49].next = newNodes.first();
        return new ReplacementWeaks(root, oldSuffixWeaks, this.weakRefs(newNodes));
    }

    /** GT-B10: replacing middle.next collects the old suffix and keeps the new suffix alive. */
    gtB10_replacingMiddleSubChainCollectsOldSuffixAndKeepsNewSuffixAlive() {
        const scenario = this.middleSubChainReplacement();
        this.forceGc();
        assertEquals(2000, scenario.newWeaks.first().value!.id);
        this.assertAllCollected(scenario.oldWeaks);
        this.assertAllAlive(scenario.newWeaks);
    }

    private nullTerminatedChainWithOrphans(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const reachable = this.buildGraphNodeChain(3, 3000);
        const orphans = this.buildGraphNodeChain(3, 4000);
        const root = new GraphRoot(reachable.first());
        reachable.last().next = null;
        return new MixedWeaks(root, this.weakRefs(reachable), this.weakRefs(orphans));
    }

    /** GT-B11: a null-terminated chain keeps reachable prefix and collects orphan nodes. */
    gtB11_nullTerminatedChainKeepsPrefixAndCollectsOrphans() {
        const scenario = this.nullTerminatedChainWithOrphans();
        this.forceGc();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private weakOnlyDeepChain(): WeakReference<GraphNode>[] {
        const nodes = this.buildGraphNodeChain(100, 5000);
        return this.weakRefs(nodes);
    }

    /** GT-B12: a helper creates a 100-node chain and only WeakReferences escape. */
    gtB12_weakOnlyDeepChainCanBeCollected() {
        this.assertAllCollected(this.weakOnlyDeepChain());
    }
}
