// @ts-nocheck
import { ReachabilityTestSupport, Payload, ChildPayload, DataPayload, PayloadHolder, AnyHolder, InterfaceHolder, BaseHolder, TwoLevelHolder, Box, LambdaHolder, RootedWeak, ReplacementResult, HolderReplacementResult, TwoLevelDisconnectResult, LoopReplacementResult, Marker, BasePayload, globalPayload, globalAny, globalMarker, GlobalHolder, CompanionRootHolder } from './ReachabilityTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * F group: reachability through generic containers and lambda captures.
 */
export class GenericLambdaReachabilityTest extends ReachabilityTestSupport {
    private createGenericBoxRoot(): RootedWeak<Box<Payload>, Payload> {
        const obj = new Payload(501);
        const box = new Box(obj);
        return new RootedWeak(box, new WeakReference(obj));
    }
    /**
     * RC-F01
     * Scenario: a generic Box<Payload> field strongly references a Payload.
     * Expectation: the object remains reachable through Box.value.
     */
    rcF01_genericBoxFieldKeepsObjectAlive() {
        const scenario = this.createGenericBoxRoot();
        this.forceGc();
        assertEquals(501, scenario.root.value.id);
        assertNotNull(scenario.weak.value);
    }
    private createGenericBoxAfterClear(): RootedWeak<Box<Payload>, Payload> {
        const obj = new Payload(502);
        const box = new Box(obj);
        const weak = new WeakReference(obj);
        box.value = null;
        return new RootedWeak(box, weak);
    }
    /**
     * RC-F02
     * Scenario: a generic Box<Payload> field is cleared.
     * Expectation: the previously contained object can be collected.
     */
    rcF02_clearingGenericBoxFieldAllowsCollection() {
        const scenario = this.createGenericBoxAfterClear();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root.value);
    }
    private createGenericBoxReplacementResult(): HolderReplacementResult<Box<Payload>, Payload> {
        const oldObj = new Payload(503);
        const box = new Box(oldObj);
        const oldWeak = new WeakReference(oldObj);
        const newObj = new Payload(530);
        box.value = newObj;
        const newWeak = new WeakReference(newObj);
        return new HolderReplacementResult(box, oldWeak, newWeak);
    }
    /**
     * RC-F03
     * Scenario: a generic Box<Payload> field is reassigned.
     * Expectation: the old object can be collected, while the new object remains reachable.
     */
    rcF03_genericBoxReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        const result = this.createGenericBoxReplacementResult();
        this.forceGc();
        result.oldWeak.clear();
        assertNull(result.oldWeak.value);
        assertNotNull(result.newWeak.value);
        assertEquals(530, result.holder.value.id);
    }
    private createGenericAnyBoxRoot(): RootedWeak<Box<any>, any> {
        const obj: any = new Payload(504);
        const box = new Box(obj);
        return new RootedWeak(box, new WeakReference(obj));
    }
    /**
     * RC-F04
     * Scenario: a generic Box<Any> field holds a Payload runtime object.
     * Expectation: the runtime object remains reachable through the generic Any field.
     */
    rcF04_genericBoxAnyKeepsRuntimeObjectAlive() {
        const scenario = this.createGenericAnyBoxRoot();
        this.forceGc();
        assertEquals(504, (scenario.root.value as Payload).id);
        assertNotNull(scenario.weak.value);
    }
    private createLambdaCaptureRoot(): RootedWeak<() => number, Payload> {
        const obj = new Payload(505);
        const block = () => obj.id;
        return new RootedWeak(block, new WeakReference(obj));
    }
    /**
     * RC-F05
     * Scenario: a lambda captures a Payload and returns one of its fields.
     * Expectation: the captured object remains reachable through the lambda object.
     */
    rcF05_lambdaCaptureKeepsObjectAlive() {
        const scenario = this.createLambdaCaptureRoot();
        this.forceGc();
        assertEquals(505, scenario.root());
        assertNotNull(scenario.weak.value);
    }
    private createWeakAfterClearingLambda(): WeakReference<Payload> {
        const obj = new Payload(506);
        const weak = new WeakReference(obj);
        let block: (() => number) | null = () => obj.id;
        assertEquals(506, block());
        block = null;
        assertNull(block);
        return weak;
    }
    /**
     * RC-F06
     * Scenario: a nullable lambda variable captures a Payload and is then cleared.
     * Expectation: after the helper stack frame returns, the captured object can be collected.
     */
    rcF06_clearingLambdaAllowsCapturedObjectCollection() {
        const weak = this.createWeakAfterClearingLambda();
        this.assertWeakCollected(weak);
    }
    private createLambdaReturningObjectRoot(): RootedWeak<() => Payload, Payload> {
        const obj = new Payload(507);
        const block = () => obj;
        return new RootedWeak(block, new WeakReference(obj));
    }
    /**
     * RC-F07
     * Scenario: a lambda captures a Payload and returns the captured object.
     * Expectation: the captured object remains reachable through the lambda.
     */
    rcF07_lambdaReturningObjectKeepsObjectAlive() {
        const scenario = this.createLambdaReturningObjectRoot();
        this.forceGc();
        assertEquals(507, scenario.root().id);
        assertNotNull(scenario.weak.value);
    }
    private createLambdaStoredInListRoot(): RootedWeak<MutableList<() => number>, Payload> {
        const obj = new Payload(508);
        const list = [];
        list.add(() => obj.id);
        return new RootedWeak(list, new WeakReference(obj));
    }
    /**
     * RC-F08
     * Scenario: a lambda capturing Payload is stored inside a MutableList.
     * Expectation: the captured object remains reachable through list -> lambda -> payload.
     */
    rcF08_lambdaStoredInCollectionKeepsCapturedObjectAlive() {
        const scenario = this.createLambdaStoredInListRoot();
        this.forceGc();
        assertEquals(508, scenario.root[0]());
        assertNotNull(scenario.weak.value);
    }
    private createLambdaListAfterClear(): RootedWeak<MutableList<() => number>, Payload> {
        const obj = new Payload(509);
        const list = [];
        list.add(() => obj.id);
        const weak = new WeakReference(obj);
        list.clear();
        return new RootedWeak(list, weak);
    }
    /**
     * RC-F09
     * Scenario: a collection holding a lambda capture is cleared.
     * Expectation: after the helper stack frame returns, the captured object can be collected.
     */
    rcF09_removingLambdaFromCollectionAllowsCapturedObjectCollection() {
        const scenario = this.createLambdaListAfterClear();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
}

