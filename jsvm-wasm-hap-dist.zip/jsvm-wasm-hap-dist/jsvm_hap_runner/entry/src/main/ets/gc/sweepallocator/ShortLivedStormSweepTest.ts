import { SweepAllocatorTestSupport } from './SweepAllocatorTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '../TestAssertions';

export class ShortLivedStormSweepTest extends SweepAllocatorTestSupport {

    sa_f01() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f02() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f03() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f04() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f05() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f06() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f07() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f08() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f09() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_f10() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }
}

