// @ts-nocheck
import { ReachabilityTestSupport, Payload, ChildPayload, DataPayload, PayloadHolder, AnyHolder, InterfaceHolder, BaseHolder, TwoLevelHolder, Box, LambdaHolder, RootedWeak, ReplacementResult, HolderReplacementResult, TwoLevelDisconnectResult, LoopReplacementResult, Marker, BasePayload, globalPayload, globalAny, globalMarker, GlobalHolder, CompanionRootHolder } from './ReachabilityTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * B group: function parameter roots and returned-value roots.
 */
export class ParameterReturnReachabilityTest extends ReachabilityTestSupport {
    private checkPayloadParameter(obj: Payload): WeakReference<Payload> {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(obj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B01
     * Scenario: function parameter has static type Payload.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    rcB01_functionParameterKeepsPayloadAlive() {
        const obj = new Payload(101);
        const weak = this.checkPayloadParameter(obj);
        assertEquals(101, obj.id);
        assertNotNull(weak.value);
    }
    private checkAnyParameter(obj: any): WeakReference<any> {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertNotNull(weak.value);
        return weak;
    }
    /**
     * RC-B02
     * Scenario: function parameter has static type Any and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    rcB02_anyTypedFunctionParameterKeepsRuntimeObjectAlive() {
        const obj: any = new Payload(102);
        const weak = this.checkAnyParameter(obj);
        assertEquals(102, (obj as Payload).id);
        assertNotNull(weak.value);
    }
    private checkInterfaceParameter(obj: Marker): WeakReference<Marker> {
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(obj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B03
     * Scenario: function parameter has static type Marker and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    rcB03_interfaceTypedFunctionParameterKeepsRuntimeObjectAlive() {
        const obj: Marker = new Payload(103);
        const weak = this.checkInterfaceParameter(obj);
        assertEquals(103, obj.id);
        assertNotNull(weak.value);
    }
    private checkNullableParameter(obj: Payload | null): WeakReference<Payload> {
        const nonNullObj = obj;
        const weak = new WeakReference(nonNullObj);
        this.forceGc();
        assertEquals(nonNullObj.id, weak.value.id);
        return weak;
    }
    /**
     * RC-B04
     * Scenario: function parameter has nullable static type Payload? and holds a non-null object.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    rcB04_nullableFunctionParameterKeepsObjectAlive() {
        const obj: Payload | null = new Payload(104);
        const weak = this.checkNullableParameter(obj);
        assertEquals(104, obj.id);
        assertNotNull(weak.value);
    }
    private createPayload(id: number): Payload { return new Payload(id); }
    /**
     * RC-B05
     * Scenario: a function returns a Payload and the caller stores the returned value.
     * Expectation: the returned object remains alive through the caller's local root.
     */
    rcB05_returnedValueStoredByCallerKeepsObjectAlive() {
        const obj = this.createPayload(105);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(105, obj.id);
        assertNotNull(weak.value);
    }
    private createReturnedValueButOnlyWeakEscapes(): WeakReference<Payload> {
        const obj = this.createPayload(106);
        return new WeakReference(obj);
    }
    /**
     * RC-B06
     * Scenario: a created returned-like object is not kept by a strong reference;
     * only WeakReference escapes the helper frame.
     * Expectation: the object can be collected.
     */
    rcB06_returnedValueWithoutStrongCallerReferenceCanBeCollected() {
        const weak = this.createReturnedValueButOnlyWeakEscapes();
        this.assertWeakCollected(weak);
    }
    /**
     * RC-B07
     * Scenario: a returned Payload is stored in a caller local variable with static type Any.
     * Expectation: the object remains reachable.
     */
    rcB07_returnedValueStoredAsAnyKeepsObjectAlive() {
        const obj: any = this.createPayload(107);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(107, (obj as Payload).id);
        assertNotNull(weak.value);
    }
    /**
     * RC-B08
     * Scenario: a returned Payload is stored in a caller local variable with static type Marker.
     * Expectation: the object remains reachable.
     */
    rcB08_returnedValueStoredAsInterfaceKeepsObjectAlive() {
        const obj: Marker = this.createPayload(108);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(108, obj.id);
        assertNotNull(weak.value);
    }
}

