import { RootSetTestSupport, RootPayload, RootHolder } from './RootSetTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals } from '../TestAssertions';

export class StackLocalRootTest extends RootSetTestSupport {

    rsA01_localValRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA02_localVarRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA03_localNullableRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA04_localAnyRootKeepsRuntimeObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA05_localInterfaceRootKeepsRuntimeObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA06_localGenericBoxRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA07_localHolderFieldRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA08_localRootWithChildGraphKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA09_localArrayRootKeepsElementAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA10_localListRootKeepsElementAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA11_localMapRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA12_localLambdaCaptureRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA13_localRootSetNullAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA14_localRootReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA15_localBlockEndIsDiagnosticOnly() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsA16_helperReturnRemovesLocalStackRoot() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }
}

