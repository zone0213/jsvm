import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';
import {
    allocateGarbage,
    forceGcLoop,
    Holder,
    LambdaHolder,
    Node,
    WeakReference,
    repeatMutationWithGc,
    runBoundedConcurrentWriters,
    runWorkerMutationWithMainGc,
    runWorkerTask,
    replaceField,
    assertWeakCollectedEventually,
    assertWeakAlive,
} from './ConcurrentGcTestSupport';

export class ThreadLifecycleGcTest {
    cgG01_childStackLocalRootDuringMainGc() {
        return runWorkerMutationWithMainGc(() => {
            const node = new Node(901);
            const weak = new WeakReference(node);
            forceGcLoop();
            return node.id === 901 && weak.value !== null;
        });
    }

    cgG02_childStackParameterRootDuringGc() {
        return runWorkerTask(() => {
            function check(node: Node): boolean {
                const weak = new WeakReference(node);
                forceGcLoop();
                return node.id === 902 && weak.value !== null;
            }
            return check(new Node(902));
        });
    }

    cgG03_childLambdaCaptureRootDuringGc() {
        return runWorkerTask(() => {
            const node = new Node(903);
            const weak = new WeakReference(node);
            const f = () => node.id;
            forceGcLoop();
            return f() === 903 && weak.value !== null;
        });
    }

    cgG04_childHolderRootDuringGc() {
        return runWorkerTask(() => {
            const holder = new Holder(new Node(904));
            const weak = new WeakReference(holder.ref!);
            forceGcLoop();
            return holder.ref!.id === 904 && weak.value !== null;
        });
    }

    cgG05_childStackRootSetNullWhileRunning() {
        const weak = (() => {
            const node = new Node(905);
            return new WeakReference(node);
        })();
        forceGcLoop();
        weak.clear();
        assertNull(weak.value);
    }

    cgG06_childRootReassignmentDuringGc() {
        const r = replaceField(906, 907);
        assertWeakCollectedEventually(r.oldWeak);
        assertWeakAlive(r.newWeak);
        assertNotNull(r.root.ref);
    }

    cgG07_threadExitAllowsObjectCollection() {
        function makeWeak(): WeakReference<Node> {
            const n = new Node(908);
            return new WeakReference(n);
        }
        assertWeakCollectedEventually(makeWeak());
    }

    cgG08_gcInterleavesWithThreadStart() {
        return runWorkerMutationWithMainGc(() => {
            const n = new Node(909);
            return n.id === 909;
        });
    }

    cgG09_gcInterleavesWithThreadExit() {
        return runWorkerMutationWithMainGc(() => {
            allocateGarbage(64);
            return true;
        });
    }

    cgG10_multipleThreadStackRoots() {
        const completed = runBoundedConcurrentWriters(3, 8, (w, i) => {
            const n = new Node(9100 + w * 100 + i);
            assertTrue(n.id >= 9100);
            forceGcLoop();
        });
        assertEquals(3, completed);
    }

    cgG11_childAllocationStormWithStackRoot() {
        return runWorkerTask(() => {
            const root = new Node(911);
            const weak = new WeakReference(root);
            for (let i = 0; i < 256; i++) {
                new Node(i);
            }
            forceGcLoop();
            return root.id === 911 && weak.value !== null;
        });
    }

    cgG12_busyMutatorLoopWithGc() {
        const count = repeatMutationWithGc(64, () => allocateGarbage(8));
        assertEquals(64, count);
    }
}


