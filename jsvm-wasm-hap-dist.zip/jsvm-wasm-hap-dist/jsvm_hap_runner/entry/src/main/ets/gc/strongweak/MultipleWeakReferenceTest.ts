// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-F group: multiple and batch WeakReference tests.
 */
export class MultipleWeakReferenceTest extends WeakReferenceTestSupport {
    private createTwoWeaksSameTarget(): WeakReference<Payload>[] {
        const obj = new Payload(601);
        return [new WeakReference(obj), new WeakReference(obj)];
    }
    /**
     * WR-F01
     * Scenario: two WeakReferences point to the same target with no strong reference.
     * Expectation: both weak values are cleared.
     */
    wrF01_twoWeaksSameTargetWithoutStrongAreCleared() {
        const weaks = this.createTwoWeaksSameTarget();
        this.assertAllWeakCollected(weaks);
    }
    private createThreeWeaksSameTarget(): WeakReference<Payload>[] {
        const obj = new Payload(602);
        return [new WeakReference(obj), new WeakReference(obj), new WeakReference(obj)];
    }
    /**
     * WR-F02
     * Scenario: three WeakReferences point to the same target with no strong reference.
     * Expectation: all weak values are cleared.
     */
    wrF02_threeWeaksSameTargetWithoutStrongAreCleared() {
        const weaks = this.createThreeWeaksSameTarget();
        this.assertAllWeakCollected(weaks);
    }
    private createHundredWeaksSameTarget(): WeakReference<Payload>[] {
        const obj = new Payload(603);
        return Array.from({ length: 100 }, (_, it) => new WeakReference(obj));
    }
    /**
     * WR-F03
     * Scenario: one hundred WeakReferences point to the same target with no strong reference.
     * Expectation: all weak values are cleared.
     */
    wrF03_hundredWeaksSameTargetWithoutStrongAreCleared() {
        const weaks = this.createHundredWeaksSameTarget();
        this.assertAllWeakCollected(weaks);
    }
    /**
     * WR-F04
     * Scenario: one hundred WeakReferences point to the same strongly reachable target.
     * Expectation: all weak values remain non-null.
     */
    wrF04_hundredWeaksSameStrongReachableTargetRemainAlive() {
        const obj = new Payload(604);
        const weaks = Array.from({ length: 100 }, (_, it) => new WeakReference(obj));
        this.forceGc();
        assertEquals(604, obj.id);
        this.assertAllWeakAlive(weaks);
    }
    private createHundredObjectsEachWeakOnly(): WeakReference<Payload>[] {
        const objects = Array.from({ length: 100 }, (_, index) => new Payload(60500 + index));
        return objects.map((it) => new WeakReference(it));
    }
    /**
     * WR-F05
     * Scenario: one hundred objects each have one WeakReference and no strong reference escapes.
     * Expectation: all weak values are cleared.
     */
    wrF05_manyObjectsEachWeakOnlyAreCollected() {
        const weaks = this.createHundredObjectsEachWeakOnly();
        this.assertAllWeakCollected(weaks);
    }
    private createPartialStrongReachability(): MixedWeakResult<Payload[], Payload> {
        const strongObjects = [];
        const aliveWeaks = [];
        const collectedWeaks = [];
        for (let index = 0; index < 100; index++) {
            const obj = new Payload(60600 + index);
            const weak = new WeakReference(obj);
            if (index % 2 === 0) {
                strongObjects.add(obj);
                aliveWeaks.add(weak);
            } else {
                collectedWeaks.add(weak);
            }
        }
        return new MixedWeakResult(strongObjects, aliveWeaks, collectedWeaks);
    }
    /**
     * WR-F06
     * Scenario: even-indexed objects are strongly reachable; odd-indexed objects are weak-only.
     * Expectation: even weak values survive, odd weak values are cleared.
     */
    wrF06_batchWeakReferencesDistinguishStrongReachableAndWeakOnlyTargets() {
        const scenario = this.createPartialStrongReachability();
        this.forceGc();
        assertEquals(50, scenario.root.size);
        this.assertAllWeakAlive(scenario.aliveWeaks);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
    private createAfterReleasingHalfStrongReferences(): MixedWeakResult<Payload[], Payload> {
        return this.createPartialStrongReachability();
    }
    /**
     * WR-F07
     * Scenario: a batch initially creates many objects, but only half remain strongly reachable.
     * Expectation: strongly reachable half survives; weak-only half is cleared.
     */
    wrF07_releasingHalfStrongReferencesClearsOnlyThatHalf() {
        const scenario = this.createAfterReleasingHalfStrongReferences();
        this.forceGc();
        assertEquals(50, scenario.root.size);
        this.assertAllWeakAlive(scenario.aliveWeaks);
        this.assertAllWeakCollected(scenario.collectedWeaks);
    }
    private createWeakListWithRepeatedSameTarget(): WeakReference<Payload>[] {
        const obj = new Payload(608);
        return Array.from({ length: 20 }, (_, it) => new WeakReference(obj));
    }
    /**
     * WR-F08
     * Scenario: a list contains many WeakReferences to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    wrF08_weakListRepeatedSameTargetWithoutStrongClearsAll() {
        const weaks = this.createWeakListWithRepeatedSameTarget();
        this.assertAllWeakCollected(weaks);
    }
    private createWeakMapValuesSameTarget(): Collection<WeakReference<Payload>> {
        const obj = new Payload(609);
        const map = new Map();
        for (let index = 0; index < 20; index++) {
            map.set(`k${index}`, new WeakReference(obj));
        }
        return Array.from(map.values());
    }
    /**
     * WR-F09
     * Scenario: a map contains many WeakReference values to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    wrF09_weakMapValuesSameTargetWithoutStrongClearAll() {
        const weaks = this.createWeakMapValuesSameTarget();
        this.assertAllWeakCollected(weaks);
    }
    private createWeakArraySameTarget(): WeakReference<Payload>[] {
        const obj = new Payload(610);
        const array = Array.from({ length: 20 }, () => new WeakReference(obj));
        return array;
    }
    /**
     * WR-F10
     * Scenario: an array contains many WeakReferences to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    wrF10_weakArraySameTargetWithoutStrongClearAll() {
        const weaks = this.createWeakArraySameTarget();
        this.assertAllWeakCollected(weaks);
    }
}

