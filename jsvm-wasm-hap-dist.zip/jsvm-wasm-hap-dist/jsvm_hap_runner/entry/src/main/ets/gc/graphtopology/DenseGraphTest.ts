import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/** GT-F group: dense graph tests. */
export class DenseGraphTest extends GraphTopologyTestSupport {

    private completeGraphRoot(size: number, startId: number): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildCompleteMultiGraph(size, startId);
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-F01: a 5-node complete graph keeps every node alive. */
    gtF01_fiveNodeCompleteGraphKeepsAllNodesAlive() {
        const scenario = this.completeGraphRoot(5, 10000);
        this.forceGc();
        assertEquals(4, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }

    private completeGraphAfterRootClear(size: number, startId: number): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildCompleteMultiGraph(size, startId);
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(nodes);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-F02: clearing root allows a 5-node complete graph to be collected. */
    gtF02_clearingRootCollectsFiveNodeCompleteGraph() {
        const scenario = this.completeGraphAfterRootClear(5, 10100);
        assertNull(scenario.root.ref);
        this.assertAllCollected(scenario.weaks);
    }

    /** GT-F03: a 10-node complete graph keeps representative nodes alive. */
    gtF03_tenNodeCompleteGraphKeepsRepresentativeNodesAlive() {
        const scenario = this.completeGraphRoot(10, 10200);
        this.forceGc();
        assertEquals(10200, scenario.weaks[0].value!.id);
        assertEquals(10205, scenario.weaks[5].value!.id);
        assertEquals(10209, scenario.weaks[9].value!.id);
    }

    /** GT-F04: clearing root allows a 10-node complete graph to be collected. */
    gtF04_clearingRootCollectsTenNodeCompleteGraph() {
        const scenario = this.completeGraphAfterRootClear(10, 10300);
        this.assertAllCollected(scenario.weaks);
    }

    private highOutDegreeRoot(): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildHighOutDegreeGraph(100, 10400);
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-F05: a high-out-degree center node keeps representative children alive. */
    gtF05_highOutDegreeCenterGraphKeepsChildrenAlive() {
        const scenario = this.highOutDegreeRoot();
        this.forceGc();
        assertEquals(100, scenario.root.ref!.children.size);
        assertEquals(10401, scenario.root.ref!.children[0].id);
        assertEquals(10451, scenario.root.ref!.children[50].id);
        assertEquals(10500, scenario.root.ref!.children[99].id);
        this.assertAllAlive(scenario.weaks);
    }

    private highOutDegreeAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildHighOutDegreeGraph(100, 10550);
        const root = new GraphRoot(nodes.first());
        root.ref!.children.clear();
        return new MixedWeaks(root, this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-F06: clearing high-out-degree children keeps center alive and collects children. */
    gtF06_clearingHighOutDegreeChildrenCollectsChildrenOnly() {
        const scenario = this.highOutDegreeAfterClear();
        this.forceGc();
        assertEquals(0, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    /** GT-F07: clearing one node's outgoing edges in a complete graph does not collect nodes still reachable from other edges. */
    gtF07_clearingOneDenseNodeOutgoingEdgesKeepsGraphAlive() {
        const nodes = this.buildCompleteMultiGraph(5, 10700);
        nodes[1].children.clear();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(0, nodes[1].children.size);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-F08: repeated dense edges keep all shared nodes alive. */
    gtF08_repeatedDenseEdgesKeepSharedNodesAlive() {
        const root = new MultiNode(10800);
        const shared = Array.from({ length: 5 }, (_, index) => new MultiNode(10801 + index));
        for (let _repeat0 = 0; _repeat0 < 3; _repeat0++) {
            root.children.push(...shared);
        }
        const scenario = new RootedWeaks(new GraphRoot(root), this.weakRefs([root, ...shared]));
        this.forceGc();
        assertEquals(15, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }

    private repeatedDenseEdgesAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const root = new MultiNode(10900);
        const shared = Array.from({ length: 5 }, (_, index) => new MultiNode(10901 + index));
        for (let _repeat = 0; _repeat < 3; _repeat++) { root.children.push(...shared); }
        root.children.clear();
        return new MixedWeaks(new GraphRoot(root), this.weakRefs([root]), this.weakRefs(shared));
    }

    /** GT-F09: clearing the only repeated-edge container allows shared nodes to be collected. */
    gtF09_clearingRepeatedDenseEdgesCollectsSharedNodes() {
        const scenario = this.repeatedDenseEdgesAfterClear();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    /** GT-F10: an array-backed complete graph keeps representative nodes alive. */
    gtF10_arrayBackedCompleteGraphKeepsRepresentativeNodesAlive() {
        const nodes = Array.from({ length: 10 }, (_, index) => new ArrayNode(11000 + index, 9));
        nodes.forEach((node, index) => {
            let out = 0;
            nodes.forEach((candidate, candidateIndex) => {
                if (candidateIndex !== index) {
                    node.refs[out++] = candidate;
                }
            });
        });
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(11000, scenario.weaks[0].value!.id);
        assertEquals(11005, scenario.weaks[5].value!.id);
        assertEquals(11009, scenario.weaks[9].value!.id);
        this.assertAllAlive(scenario.weaks);
    }
}
