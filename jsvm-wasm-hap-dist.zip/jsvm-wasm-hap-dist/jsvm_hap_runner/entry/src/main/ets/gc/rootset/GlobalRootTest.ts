import { RootSetTestSupport, RootPayload, RootHolder } from './RootSetTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals } from '../TestAssertions';

export class GlobalRootTest extends RootSetTestSupport {

    rsC01_topLevelVarRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC02_topLevelVarClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC03_topLevelVarReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC04_topLevelAnyRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC05_topLevelInterfaceRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC06_topLevelHolderRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC07_topLevelChildGraphRootKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC08_topLevelArrayRootKeepsElementAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC09_topLevelListRootKeepsElementAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC10_topLevelMapRootKeepsValueAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC11_objectSingletonFieldRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC12_objectSingletonFieldClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC13_objectFieldReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC14_companionFieldRootKeepsObjectAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC15_companionFieldClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC16_companionFieldChildGraphKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC17_globalContainerRemoveAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsC18_globalContainerClearAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }
}

