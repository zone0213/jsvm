import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue, assertNotNull, assertNull } from '../TestAssertions';

const GC_REPEAT_COUNT = 3;

export class WeakReferenceTestSupport {
    beforeTest() {
        this.clearGlobalRoots();
        this.forceGc();
    }

    afterTest() {
        this.clearGlobalRoots();
        this.forceGc();
    }

    protected forceGc() {
        for (let i = 0; i < GC_REPEAT_COUNT; i++) {
            GC.collect();
        }
    }

    protected clearGlobalRoots() {
        globalPayload = null;
        globalAny = null;
        globalMarker = null;
        globalWeak = null;
        ObjectStrongWeakHolder.strong = null;
        ObjectStrongWeakHolder.weak = null;
    }

    protected assertWeakAlive<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected weak reference value to remain alive."
    ): T {
        this.forceGc();
        const value = weak.value;
        assertNotNull(value, message);
        return value;
    }

    protected assertWeakCollected<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected weak reference value to be cleared."
    ) {
        this.forceGc();
        weak.clear();
        weak.clear();
        assertNull(weak.value, message);
    }

    protected assertAllWeakAlive<T extends any>(weaks: Iterable<WeakReference<T>>) {
        let index = 0;
        for (const weak of weaks) {
            assertNotNull(weak.value, `Expected weak[${index}] value to remain alive.`);
            index++;
        }
    }

    protected assertAllWeakCollected<T extends any>(weaks: Iterable<WeakReference<T>>) {
        this.forceGc();
        let index = 0;
        for (const weak of weaks) {
            weak.clear();
            weak.clear();
            assertNull(weak.value, `Expected weak[${index}] value to be cleared.`);
            index++;
        }
    }
}

export interface Marker {
    id: number;
}

export class Payload implements Marker {
    id: number;
    strong: Payload | null = null;
    weak: WeakReference<Payload> | null = null;

    constructor(id: number) {
        this.id = id;
    }

    toString(): string {
        return `Payload(id=${this.id})`;
    }
}

export class MarkerPayload implements Marker {
    id: number;

    constructor(id: number) {
        this.id = id;
    }
}

export class StrongHolder<T> {
    ref: T | null;
    constructor(ref: T | null = null) {
        this.ref = ref;
    }
}

export class WeakHolder<T> {
    weak: WeakReference<T> | null;
    constructor(weak: WeakReference<T> | null = null) {
        this.weak = weak;
    }
}

export class MixedHolder<T> {
    strong: T | null = null;
    weak: WeakReference<T> | null = null;
    constructor(strong: T | null = null, weak: WeakReference<T> | null = null) {
        this.strong = strong;
        this.weak = weak;
    }
}

export class Box<T> {
    value: T | null;
    constructor(value: T | null = null) {
        this.value = value;
    }
}

export class Root<T> {
    ref: T | null;
    constructor(ref: T | null = null) {
        this.ref = ref;
    }
}

export class DataWeakHolder<T> {
    weak: WeakReference<T> | null;
    constructor(weak: WeakReference<T> | null = null) {
        this.weak = weak;
    }
}

export class WeakOnlyResult<R, T> { constructor(public root: R, public weak: WeakReference<T>) {} }

export class MixedWeakResult<R, T> { constructor(public root: R, public aliveWeaks: WeakReference<T>[], public collectedWeaks: WeakReference<T>[]) {} }

export class ReplacementResult<R, T> { constructor(public root: R, public oldWeak: WeakReference<T>, public newWeak: WeakReference<T>) {} }

export let globalPayload: Payload | null = null;
export let globalAny: any = null;
export let globalMarker: Marker | null = null;
export let globalWeak: WeakReference<Payload> | null = null;

export function setGlobalPayload(value: Payload | null): void { globalPayload = value; }
export function setGlobalAny(value: any): void { globalAny = value; }
export function setGlobalMarker(value: Marker | null): void { globalMarker = value; }
export function setGlobalWeak(value: WeakReference<Payload> | null): void { globalWeak = value; }

export const ObjectStrongWeakHolder = {
    strong: null as Payload | null,
    weak: null as WeakReference<Payload> | null
};







