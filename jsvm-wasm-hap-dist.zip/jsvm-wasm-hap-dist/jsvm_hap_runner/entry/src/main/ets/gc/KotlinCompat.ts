declare global {
  interface Array<T> {
    readonly size: number;
    add(value: T): boolean;
    remove(value: T): boolean;
    clear(): void;
    first(): T;
    last(): T;
    take(count: number): T[];
    drop(count: number): T[];
    single(): T;
  }

  interface Map<K, V> {
    remove(key: K): boolean;
  }

  interface Set<T> {
    remove(value: T): boolean;
  }
}

function defineArrayValue(name: string, value: unknown): void {
  if (!(name in Array.prototype)) {
    Object.defineProperty(Array.prototype, name, {
      value,
      configurable: true,
      writable: true
    });
  }
}

if (!Object.getOwnPropertyDescriptor(Array.prototype, 'size')) {
  Object.defineProperty(Array.prototype, 'size', {
    get: function (): number { return this.length; },
    configurable: true
  });
}

defineArrayValue('add', function <T>(this: T[], value: T): boolean {
  this.push(value);
  return true;
});

defineArrayValue('remove', function <T>(this: T[], value: T): boolean {
  const index = this.indexOf(value);
  if (index < 0) return false;
  this.splice(index, 1);
  return true;
});

defineArrayValue('clear', function <T>(this: T[]): void {
  this.length = 0;
});

defineArrayValue('first', function <T>(this: T[]): T {
  return this[0];
});

defineArrayValue('last', function <T>(this: T[]): T {
  return this[this.length - 1];
});

defineArrayValue('take', function <T>(this: T[], count: number): T[] {
  return this.slice(0, count);
});

defineArrayValue('drop', function <T>(this: T[], count: number): T[] {
  return this.slice(count);
});

defineArrayValue('single', function <T>(this: T[]): T {
  if (this.length !== 1) throw new Error(`Expected single element, got ${this.length}`);
  return this[0];
});

if (!('remove' in Map.prototype)) {
  Object.defineProperty(Map.prototype, 'remove', {
    value: function <K, V>(this: Map<K, V>, key: K): boolean { return this.delete(key); },
    configurable: true,
    writable: true
  });
}

if (!('remove' in Set.prototype)) {
  Object.defineProperty(Set.prototype, 'remove', {
    value: function <T>(this: Set<T>, value: T): boolean { return this.delete(value); },
    configurable: true,
    writable: true
  });
}

export {};
