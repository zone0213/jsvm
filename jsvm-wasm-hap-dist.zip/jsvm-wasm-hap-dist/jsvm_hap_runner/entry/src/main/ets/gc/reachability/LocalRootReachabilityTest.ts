// @ts-nocheck
import { ReachabilityTestSupport, Payload, ChildPayload, DataPayload, PayloadHolder, AnyHolder, InterfaceHolder, BaseHolder, TwoLevelHolder, Box, LambdaHolder, RootedWeak, ReplacementResult, HolderReplacementResult, TwoLevelDisconnectResult, LoopReplacementResult, Marker, BasePayload, globalPayload, globalAny, globalMarker, GlobalHolder, CompanionRootHolder } from './ReachabilityTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * A group: local variable roots.
 */
export class LocalRootReachabilityTest extends ReachabilityTestSupport {
    /**
     * RC-A01
     * Scenario: local val directly references a concrete Payload object.
     * Expectation: the object remains reachable while the local val is used after GC.
     */
    rcA01_localValDirectReferenceKeepsObjectAlive() {
        const obj = new Payload(1);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(1, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-A02
     * Scenario: local var directly references a concrete Payload object.
     * Expectation: the object remains reachable while the local var is used after GC.
     */
    rcA02_localVarDirectReferenceKeepsObjectAlive() {
        let obj = new Payload(2);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(2, obj.id);
        assertNotNull(weak.value);
        obj = new Payload(20);
        assertEquals(20, obj.id);
    }
    private createWeakFromLocalObject(): WeakReference<Payload> {
        const obj = new Payload(3);
        return new WeakReference(obj);
    }
    /**
     * RC-A03
     * Scenario: a local object is created inside a helper function and only a WeakReference escapes.
     * Expectation: after the helper stack frame returns, the object can be collected.
     */
    rcA03_localObjectCanBeCollectedAfterFunctionReturns() {
        const weak = this.createWeakFromLocalObject();
        this.assertWeakCollected(weak);
    }
    /**
     * RC-A04
     * Scenario: a local object is created inside an inner block and GC is triggered inside the block.
     * Expectation: the object remains reachable while the block-local variable is still used after GC.
     */
    rcA04_innerBlockLocalObjectKeepsAliveInsideBlock() {
        {
            const obj = new Payload(4);
            const weak = new WeakReference(obj);
            this.forceGc();
            assertEquals(4, obj.id);
            assertNotNull(weak.value);
        }
    }
    /**
     * RC-A05
     * Scenario: an object leaves an inner block, but the enclosing function has not returned.
     * Expectation: this is a diagnostic case only. Kotlin/Native may still keep the old stack slot alive,
     * so the test must not assert deterministic collection here.
     */
    rcA05_innerBlockEndIsDiagnosticAndNotDeterministic() {
        let weak: WeakReference<Payload> | null = null;
        {
            const obj = new Payload(5);
            weak = new WeakReference(obj);
            assertEquals(5, obj.id);
        }
        this.forceGc();
        const observed = weak.value;
        assertTrue(observed == null || observed.id == 5);
    }
    private createWeakAfterLocalNullableSetNull(): WeakReference<Payload> {
        let obj: Payload | null = new Payload(6);
        const weak = new WeakReference(obj);
        obj = null;
        assertNull(obj);
        return weak;
    }
    /**
     * RC-A06
     * Scenario: a local nullable variable is set to null.
     * Expectation: after the helper stack frame returns, the original object can be collected.
     */
    rcA06_localNullableSetNullAllowsCollection() {
        const weak = this.createWeakAfterLocalNullableSetNull();
        this.assertWeakCollected(weak);
    }
    private createLocalReplacementResult(): ReplacementResult<Payload> {
        let obj: Payload | null = new Payload(7);
        const oldWeak = new WeakReference(obj);
        obj = new Payload(70);
        const newObj = obj;
        const newWeak = new WeakReference(newObj);
        return new ReplacementResult(newObj, oldWeak, newWeak);
    }
    /**
     * RC-A07
     * Scenario: a local variable is reassigned from an old object to a new object.
     * Expectation: after the helper stack frame returns, the old object can be collected,
     * while the new object remains alive through the returned strong reference.
     */
    rcA07_localReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        const result = this.createLocalReplacementResult();
        this.forceGc();
        result.oldWeak.clear();
        assertNull(result.oldWeak.value);
        assertNotNull(result.newWeak.value);
        assertEquals(70, result.liveObject.id);
    }
    /**
     * RC-A08
     * Scenario: a local variable has static type Any and runtime type Payload.
     * Expectation: the runtime object remains reachable.
     */
    rcA08_localAnyTypedReferenceKeepsRuntimeObjectAlive() {
        const obj: any = new Payload(8);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertTrue(obj instanceof Payload);
        assertEquals(8, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-A09
     * Scenario: a local variable has static type Marker and runtime type Payload.
     * Expectation: the runtime object remains reachable through the interface-typed reference.
     */
    rcA09_localInterfaceTypedReferenceKeepsRuntimeObjectAlive() {
        const obj: Marker = new Payload(9);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(9, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-A10
     * Scenario: a local variable has static type BasePayload and runtime type ChildPayload.
     * Expectation: the runtime object remains reachable through the base-class-typed reference.
     */
    rcA10_localBaseClassTypedReferenceKeepsRuntimeObjectAlive() {
        const obj: BasePayload = new ChildPayload(10);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(10, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-A11
     * Scenario: a local nullable variable holds a non-null Payload object.
     * Expectation: the object remains reachable through the nullable-typed reference.
     */
    rcA11_localNullableNonNullReferenceKeepsObjectAlive() {
        const obj: Payload | null = new Payload(11);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(11, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * RC-A12
     * Scenario: a local val directly references a data class instance.
     * Expectation: data class instances are scanned and kept alive like normal objects.
     */
    rcA12_localDataClassReferenceKeepsObjectAlive() {
        const obj = new DataPayload(12);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(12, obj.id);
        assertNotNull(weak.value);
    }
}
