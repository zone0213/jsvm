export const runJsvmSmoke: () => string;
export const runProfilerSnapshot: () => string;
export const runDebugOption: (mode: number) => string;
export const runArrayBufferTests: () => string;
export const runCodeCacheTest: () => string;
export const runTriggerGcTest: () => string;
export const runWasmTest: () => string;

declare const nativeBridge: {
  runJsvmSmoke: () => string;
  runProfilerSnapshot: () => string;
  runDebugOption: (mode: number) => string;
  runArrayBufferTests: () => string;
  runCodeCacheTest: () => string;
  runTriggerGcTest: () => string;
  runWasmTest: () => string;
};

export default nativeBridge;
