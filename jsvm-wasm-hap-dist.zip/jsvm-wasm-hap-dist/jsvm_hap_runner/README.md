# GC Reachability DevEco Runner

Open this folder with DevEco Studio, select a real device, and run the `entry` module.

The first page contains a `Run All Tests` button. Tap it to execute the converted ArkTS GC tests on the device and show the summary.

If DevEco Studio asks to sync project files, accept the sync. If your local DevEco SDK uses a different compatible SDK value, adjust `build-profile.json5` from the IDE prompt.
