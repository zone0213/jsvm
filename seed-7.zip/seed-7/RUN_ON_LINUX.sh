#!/bin/bash
# 在 Linux 上验证 .ets 版用例(带 @Sendable + Worker 并发特色)
# 用法: 把整个 seed-7 目录拷到 Linux, 在该目录里 bash RUN_ON_LINUX.sh
# 不需要手机,纯 Linux + ark_js_vm 验证

set -e
echo "=== 1. es2abc 编译 main.ets ==="
es2abc main.ets --extension=ts --module --merge-abc --output main.abc
echo "  -> main.abc 生成 ($(wc -c < main.abc) 字节)"

echo "=== 2. es2abc 编译 worker.ets ==="
es2abc worker.ets --extension=ts --module --merge-abc --output worker.abc
echo "  -> worker.abc 生成 ($(wc -c < worker.abc) 字节)"

echo "=== 3. ark_js_vm 运行 main.abc ==="
echo "    (预期: 跑约30秒GC压力循环, 输出 fuzz-case-done, 正常退出)"
time ark_js_vm --entry-point=main main.abc
echo "=== ark_js_vm 退出码: $? ==="
