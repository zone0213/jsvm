# GC Fuzz 架构与设计方案图

本文档基于当前代码实现整理，目标是用一张主图说明：

- 当前 `pure-kotlin` 用例如何一步一步生成、编译、运行
- 关键文件之间的调用关系和时序
- 新增执行 mode 时应该复用哪些层、扩展哪些文件
- 当前 CFFI 能力在 `pure-kotlin` 路径中如何接入，以及后续扩展应该挂在哪些层

## 1. 核心结论

当前 GC Fuzz 的主链路围绕 `ScenarioProgram` 这个语义 IR 工作：

```text
GCFuzzingTest
  -> SimpleFuzzer
  -> ScenarioRunner.execute(id)
  -> ScenarioModeRegistry
  -> PureKotlinScenarioModeDescriptor
  -> generateScenarioWithMetadata(seed, features)
  -> ScenarioProgram + ScenarioTelemetry
  -> PureKotlinScenarioBackend.lower(...)
  -> ScenarioPreparation.prepare(...)
  -> producePureKotlin(...)
  -> generated/main.kt
  -> topology.json
  -> konanc
  -> app.kexe
  -> run + logs
```

这意味着：

- `Generator.kt` 只负责生成通用语义，不负责 Kotlin 语法
- `ScenarioProgram` 是当前唯一核心中间表示
- 当前注册到 `ScenarioModeRegistry` 的执行 mode 只有 `pure-kotlin`
- `Scenario.kt` 中预留了 `Kotlin / ObjC / Java / Native` 等 target/domain 概念，但当前主执行路径会通过 profile/preparation 规约到 Kotlin 域
- 新执行 mode 不应该修改主生成链路，而应该新增自己的 `mode/profile/backend/translation/execution`
- CFFI 已经有当前实现：`gcfuzzing.cffi=true` 时，`pure-kotlin` 会生成 C bridge、cinterop def，并把 `ForeignRoundTrip` 翻译成 Kotlin/Native `StableRef` + C callback/identity 调用

## 2. 一张主图：模块、调用关系和扩展点

```mermaid
flowchart TB
    subgraph TestEntry["入口与调度"]
        GCFuzzingTest["GCFuzzingTest.kt<br/>真实 fuzz 入口<br/>读取 gcfuzzing.* 参数"]
        SimpleFuzzer["fuzzer/mode/SimpleFuzzer.kt<br/>seed -> ProgramId 序列"]
        ScenarioRunner["fuzzer/mode/ScenarioRunner.kt<br/>StandaloneExecutionHost.execute(id)<br/>构造 ScenarioBackendConfig"]
        ModeRegistry["fuzzer/mode/ScenarioModeRegistry.kt<br/>按 gcfuzzing.executionModel 选择 mode"]
        BackendConfig["fuzzer/mode/ScenarioBackendConfig.kt<br/>stack/thread/timeout/mainLoop 配置"]
    end

    subgraph ModeLayer["语言 Mode 层"]
        ModeDescriptor["fuzzer/mode/ScenarioModeDescriptor.kt<br/>mode 统一接口"]
        PureMode["fuzzer/kotlin/mode/PureKotlinScenarioModeDescriptor.kt<br/>pure-kotlin 总装配"]
        PureGenProfile["fuzzer/kotlin/mode/PureKotlinScenarioGenerationProfile.kt<br/>pure-kotlin feature 开关"]
        PureCffiGenProfile["fuzzer/kotlin/mode/PureKotlinCInteropScenarioGenerationProfile.kt<br/>pure-kotlin + CFFI feature 开关"]
    end

    subgraph SharedCore["通用语义层"]
        ProgramId["fuzzer/core/ProgramId.kt<br/>稳定 case id"]
        ScenarioAst["fuzzer/core/Scenario.kt<br/>ScenarioProgram / Scenario AST<br/>对象图、root、弱引用、并发、GC 语义"]
        FeatureSet["fuzzer/core/ScenarioFeatureSet.kt<br/>生成能力闸门"]
        Preparation["fuzzer/core/ScenarioPreparation.kt<br/>profile 驱动的 normalize<br/>当前主要统一 targetLanguage/domain"]
        BackendInterface["fuzzer/core/ScenarioBackend.kt<br/>backend 抽象边界"]
    end

    subgraph Generation["通用生成层"]
        GenerationProfile["fuzzer/generation/ScenarioGenerationProfile.kt<br/>通用生成 profile 结构"]
        Generator["fuzzer/generation/Generator.kt<br/>generateScenarioWithMetadata(seed, features)<br/>生成 ScenarioProgram + telemetry"]
        Topologies["Topology 模板<br/>cycle / shared node / root migration<br/>weak lifecycle / worker publish 等"]
        Telemetry["ScenarioTelemetry.kt<br/>topology attempts / hits<br/>ScenarioTopologyKind"]
    end

    subgraph KotlinBackend["pure-kotlin 语言层"]
        PureProfile["fuzzer/kotlin/profile/PureKotlinScenarioProfile.kt<br/>pure-kotlin 可接受语义子集"]
        PureCInteropProfile["fuzzer/kotlin/profile/PureKotlinCInteropScenarioProfile.kt<br/>pure-kotlin + C interop profile"]
        PureCffiProfile["fuzzer/kotlin/profile/PureKotlinScenarioCffi.kt<br/>强/弱 store 与 foreign reference kind 校验入口"]
        PureBackend["fuzzer/kotlin/backend/PureKotlinScenarioBackend.kt<br/>lower ScenarioProgram -> PureKotlinOutput"]
        PureLowering["fuzzer/kotlin/backend/PureKotlinScenarioLowering.kt<br/>pure-kotlin 专有 lowering 预留层"]
    end

    subgraph Translation["翻译层"]
        PureTranslation["translation/PureKotlinTranslation.kt<br/>Scenario AST -> Kotlin 源码"]
        PureCInterop["translation/PureKotlinCInterop.kt<br/>生成 cinterop.def / bridge.h / bridge.c<br/>翻译 ForeignRoundTrip runtime"]
        OutputBuilder["translation/OutputFileBuilder.kt<br/>源码文本构建"]
        TranslationUtil["translation/Util.kt<br/>翻译辅助"]
        PureOutput["PureKotlinOutput<br/>filename / contents / args"]
    end

    subgraph Execution["执行层"]
        PureRunner["execution/kotlin/PureKotlinScenarioRunner.kt<br/>保存源码、编译、运行、落日志"]
        GeneratedSource["<resultsRoot>/<runId?>/<caseId>/generated/main.kt"]
        TopologyJson["<resultsRoot>/<runId?>/<caseId>/topology.json"]
        ForeignBridge["generated/cinterop.def<br/>generated/bridge.h<br/>generated/bridge.c<br/>仅 gcfuzzing.cffi=true"]
        CInterop["cinterop + clang<br/>生成 bridge klib / bridge.o<br/>仅 gcfuzzing.cffi=true"]
        Compiler["konanc<br/>-Xbinary=gc=...<br/>-Xallocator=...<br/>-Xbinary=minidumpLocation=..."]
        Executable["app.kexe"]
        RunLogs["run.log 或 run.stdout.log/run.stderr.log/run.exitcode.txt<br/>app.kexe.log 或 konanc.log<br/>cinterop.log / clang.log 仅 CFFI<br/>*.dmp"]
    end

    subgraph Reporting["报告与归档"]
        GradleReport["Gradle test report<br/>index.html"]
        CaseIndex["case-index.html<br/>由 Gradle 任务汇总 run 目录"]
        TopologyReport["topology-summary.html/json/csv<br/>topology-case-hits.csv<br/>规则、图表、case 命中明细"]
        FailureArchive["失败归档<br/>由 Gradle/ops 任务处理，不在 runner 主链路内"]
    end

    subgraph NewLanguage["新增执行 mode 扩展位"]
        NewMode["fuzzer/<lang>/mode/<Lang>ScenarioModeDescriptor.kt"]
        NewGenProfile["fuzzer/<lang>/mode/<Lang>ScenarioGenerationProfile.kt"]
        NewProfile["fuzzer/<lang>/profile/<Lang>ScenarioProfile.kt"]
        NewBackend["fuzzer/<lang>/backend/<Lang>ScenarioBackend.kt"]
        NewTranslation["translation/<Lang>Translation.kt"]
        NewExecution["execution/<lang>/<Lang>ScenarioRunner.kt"]
    end

    GCFuzzingTest --> SimpleFuzzer
    SimpleFuzzer --> ProgramId
    GCFuzzingTest --> ScenarioRunner
    ScenarioRunner --> BackendConfig
    ScenarioRunner --> ModeRegistry
    ModeRegistry --> ModeDescriptor
    ModeDescriptor --> PureMode
    PureMode --> PureGenProfile
    PureMode -. gcfuzzing.cffi=true .-> PureCffiGenProfile
    PureGenProfile --> FeatureSet
    PureCffiGenProfile --> FeatureSet
    PureMode --> Generator
    Generator --> FeatureSet
    Generator --> Topologies
    Generator --> ScenarioAst
    Generator --> Telemetry
    PureMode --> PureBackend
    PureBackend -. implements boundary .-> BackendInterface
    PureBackend --> Preparation
    Preparation --> PureProfile
    Preparation -. cffi enabled .-> PureCInteropProfile
    PureProfile --> PureCffiProfile
    PureCInteropProfile --> PureCffiProfile
    Preparation --> ScenarioAst
    PureBackend --> PureTranslation
    PureTranslation --> OutputBuilder
    PureTranslation --> TranslationUtil
    PureTranslation -. if ForeignRoundTrip exists .-> PureCInterop
    PureTranslation --> PureOutput
    PureMode --> PureRunner
    PureOutput --> PureRunner
    PureRunner --> GeneratedSource
    PureRunner --> TopologyJson
    PureRunner -. cffi enabled .-> ForeignBridge
    PureRunner -. cffi enabled .-> CInterop
    PureRunner --> Compiler
    CInterop -. link klib/object .-> Compiler
    Compiler --> Executable
    PureRunner --> RunLogs
    RunLogs -. Gradle summary task .-> CaseIndex
    TopologyJson -. Gradle summary task .-> TopologyReport
    CaseIndex -. optional .-> GradleReport
    CaseIndex -. optional ops archive .-> FailureArchive

    ModeRegistry -. register .-> NewMode
    NewMode -. uses .-> NewGenProfile
    NewGenProfile -. selects .-> FeatureSet
    NewMode -. calls shared .-> Generator
    NewMode -. calls .-> NewBackend
    NewBackend -. prepare with .-> NewProfile
    NewBackend -. translate .-> NewTranslation
    NewMode -. execute .-> NewExecution
    NewBackend -. consumes shared AST .-> ScenarioAst

    classDef entry fill:#f6f8fa,stroke:#57606a,color:#24292f
    classDef shared fill:#eaf5ff,stroke:#0969da,color:#24292f
    classDef kotlin fill:#fff8c5,stroke:#9a6700,color:#24292f
    classDef exec fill:#dafbe1,stroke:#1a7f37,color:#24292f
    classDef report fill:#ffebe9,stroke:#cf222e,color:#24292f
    classDef ext fill:#f3e8ff,stroke:#8250df,color:#24292f

    class GCFuzzingTest,SimpleFuzzer,ScenarioRunner,ModeRegistry,BackendConfig,ModeDescriptor entry
    class ProgramId,ScenarioAst,FeatureSet,Preparation,BackendInterface,GenerationProfile,Generator,Topologies shared
    class PureMode,PureGenProfile,PureCffiGenProfile,PureProfile,PureCInteropProfile,PureCffiProfile,PureBackend,PureLowering,PureTranslation,PureCInterop,OutputBuilder,TranslationUtil,PureOutput kotlin
    class PureRunner,GeneratedSource,ForeignBridge,CInterop,Compiler,Executable,RunLogs exec
    class GradleReport,CaseIndex,TopologyReport,FailureArchive report
    class NewMode,NewGenProfile,NewProfile,NewBackend,NewTranslation,NewExecution ext
```

## 3. pure-kotlin 用例生成时序

下面这张时序图只看一次 case，例如 `I3725031768` 这样的单个用例。

```mermaid
sequenceDiagram
    autonumber
    participant Test as GCFuzzingTest.kt
    participant Fuzzer as SimpleFuzzer.kt
    participant Runner as ScenarioRunner.kt
    participant Registry as ScenarioModeRegistry.kt
    participant Mode as PureKotlinScenarioModeDescriptor.kt
    participant Gen as Generator.kt
    participant AST as ScenarioProgram
    participant Telemetry as ScenarioTelemetry
    participant Backend as PureKotlinScenarioBackend.kt
    participant Prep as ScenarioPreparation.kt
    participant Trans as PureKotlinTranslation.kt
    participant CFFI as PureKotlinCInterop.kt
    participant Exec as PureKotlinScenarioRunner.kt
    participant CInterop as cinterop / clang
    participant Konanc as konanc
    participant App as app.kexe
    participant Report as Gradle report / optional archive

    Test->>Fuzzer: 根据 seed 生成 ProgramId
    Fuzzer-->>Test: ProgramId.Initial(seed)
    Test->>Runner: execute(id)
    Runner->>Runner: 构造 ScenarioBackendConfig
    Runner->>Registry: resolve(gcfuzzing.executionModel)
    Registry-->>Runner: PureKotlinScenarioModeDescriptor
    Runner->>Mode: execute(test, id, config)
    Mode->>Mode: resolve generated source dir
    Mode->>Gen: generateScenarioWithMetadata(id.seed(), generationProfile.features)
    Gen->>Gen: 选择 definitions / statements / topology
    Gen-->>AST: ScenarioProgram
    Gen-->>Telemetry: topology attempts / hits
    Mode->>Backend: lower(ScenarioProgram, config)
    Backend->>Prep: prepare(program, PureKotlinScenarioProfile 或 PureKotlinCInteropScenarioProfile)
    Prep->>Prep: 统一 targetLanguage/domain，保留强弱引用和 foreign kind
    Prep-->>Backend: prepared ScenarioProgram
    Backend->>Trans: producePureKotlin(PureKotlinConfig)
    Trans->>Trans: render prelude / globals / classes / funcs / main
    opt contains ForeignRoundTrip
        Trans->>CFFI: generatePureKotlinCInteropFiles()
        CFFI-->>Trans: cinterop.def / bridge.h / bridge.c
    end
    Trans-->>Backend: PureKotlinOutput(filename, contents, args)
    Backend-->>Mode: PureKotlinOutput
    Mode->>Exec: output.save(generatedSourceDir)
    Exec->>Exec: generated/main.kt 落盘，CFFI case 额外落 bridge 文件
    Mode->>Telemetry: save(caseDir/topology.json)
    Mode->>Exec: runPureKotlinScenario(name, output, timeout)
    opt gcfuzzing.cffi=true
        Exec->>CInterop: cinterop bridge.def
        Exec->>CInterop: clang -c bridge.c
        CInterop-->>Exec: bridge klib / bridge.o
    end
    Exec->>Konanc: 编译 generated/main.kt
    Konanc-->>Exec: app.kexe + 编译日志
    Exec->>App: 运行 app.kexe
    App-->>Exec: stdout / stderr / exitCode / minidump
    Exec->>Exec: 写 run.log；host CMC + libcrt 路径写 stdout/stderr/exitcode 分离日志
    Report->>Report: Gradle/ops 层生成 case-index、topology-summary 或失败归档
```

## 4. 关键文件职责清单

### 4.1 入口与 mode 编排

| 文件 | 职责 | 是否语言相关 |
|---|---|---|
| `GCFuzzingTest.kt` | daily fuzz 真实入口，驱动 seed、并发、时限、重放 | 否 |
| `fuzzer/mode/SimpleFuzzer.kt` | 生成 `ProgramId` 序列 | 否 |
| `fuzzer/mode/ScenarioRunner.kt` | `execute(id)` 总入口，读取 executionModel，构造 backend config | 否 |
| `fuzzer/mode/ScenarioModeRegistry.kt` | mode 注册与选择 | 否 |
| `fuzzer/mode/ScenarioModeDescriptor.kt` | 每种语言 mode 的统一接口 | 否 |
| `fuzzer/mode/ScenarioBackendConfig.kt` | stack、thread、timeout、mainLoop 等运行配置 | 否 |

### 4.2 通用 AST 与生成

| 文件 | 职责 | 是否语言相关 |
|---|---|---|
| `fuzzer/core/Scenario.kt` | 定义 `ScenarioProgram` 和所有语义节点 | 否 |
| `fuzzer/core/ProgramId.kt` | 稳定 case id | 否 |
| `fuzzer/core/ScenarioFeatureSet.kt` | feature 能力开关 | 否 |
| `fuzzer/core/ScenarioPreparation.kt` | profile 驱动的准备和规约；当前实现主要统一 `targetLanguage`、`domain`，并透传/校验 store 与 foreign reference kind | 框架通用，规则可按语言 |
| `fuzzer/core/ScenarioBackend.kt` | backend 抽象边界 | 否 |
| `fuzzer/generation/Generator.kt` | 根据 seed 和 feature 生成 `ScenarioProgram` | 否 |
| `fuzzer/generation/ScenarioGenerationProfile.kt` | 生成 profile 结构 | 否 |
| `fuzzer/debug/DebugScenarioBackend.kt` | 调试 AST 输出 | 否 |

### 4.3 pure-kotlin 语言层

| 文件 | 职责 | 是否 pure-kotlin 专有 |
|---|---|---|
| `fuzzer/kotlin/mode/PureKotlinScenarioModeDescriptor.kt` | pure-kotlin 总装配：生成 AST、lower、保存源码、执行 | 是 |
| `fuzzer/kotlin/mode/PureKotlinScenarioGenerationProfile.kt` | pure-kotlin 当前打开的 feature 集合 | 是 |
| `fuzzer/kotlin/mode/PureKotlinCInteropScenarioGenerationProfile.kt` | `gcfuzzing.cffi=true` 时使用的 feature 集合，额外打开 `CFFI_CALLBACK_ROUNDTRIP` | 是 |
| `fuzzer/kotlin/profile/PureKotlinScenarioProfile.kt` | pure-kotlin 可接受语义子集 | 是 |
| `fuzzer/kotlin/profile/PureKotlinCInteropScenarioProfile.kt` | pure-kotlin + C interop 可接受语义子集 | 是 |
| `fuzzer/kotlin/profile/PureKotlinScenarioCffi.kt` | store reference kind 与 foreign reference kind 的校验入口；当前实现直接接受并返回原值 | 是 |
| `fuzzer/kotlin/backend/PureKotlinScenarioBackend.kt` | AST 进入 pure-kotlin 后端的入口 | 是 |
| `fuzzer/kotlin/backend/PureKotlinScenarioLowering.kt` | pure-kotlin 专有 lowering 预留层 | 是 |
| `translation/PureKotlinTranslation.kt` | 把 AST 翻译成 Kotlin 源码 | 是 |
| `translation/PureKotlinCInterop.kt` | 当 IR 中包含 `ForeignRoundTrip` 时生成 C bridge 文件，并提供 foreign roundtrip runtime 渲染 | 是 |
| `execution/kotlin/PureKotlinScenarioRunner.kt` | 编译、运行、记录日志和 dump | 是 |

## 5. 当前 pure-kotlin 用例具体怎么生成

以一个 seed 为例，生成过程可以拆成 8 步。

1. `GCFuzzingTest.kt` 决定当前要跑哪个 `ProgramId`

   daily 模式下它会不断从 `SimpleFuzzer` 拿 case id。单 case 重放时，id 对应具体目录名，例如 `I3725031768`。

2. `ScenarioRunner.kt` 读取执行配置

   它读取 `gcfuzzing.executionModel`、`gcfuzzing.softTimeout`、`gcfuzzing.cffi` 等参数，构造 `ScenarioBackendConfig`。`maximumStackDepth`、`mainLoopRepeatCount`、`maxThreadCount` 当前来自 `ScenarioBackendConfig.DEFAULT`。

3. `ScenarioModeRegistry.kt` 选择 pure-kotlin mode

   当前注册的是 `PureKotlinScenarioModeDescriptor`。`pure-kotlin`、`pure_kotlin`、`pure` 和空字符串都会落到这个 mode。

4. `PureKotlinScenarioModeDescriptor.kt` 调用通用生成器

   调用关系是：

   ```text
   generateScenarioWithMetadata(id.seed(), generationProfile.features)
   ```

   mode 会把返回的 `ScenarioProgram` 交给 backend lower，并把 `ScenarioTelemetry` 落盘为 case 目录下的 `topology.json`。当 `gcfuzzing.cffi=true` 时，mode 使用 `PureKotlinCInteropScenarioGenerationProfile`，否则使用 `PureKotlinScenarioGenerationProfile`。传入的 feature 决定 Generator 能生成哪些能力，例如：

   - rich fields
   - shared global roots
   - thread-local roots
   - weak references
   - topology templates
   - worker / concurrent mutation
   - explicit GC trigger
   - foreign callback roundtrip（仅 CFFI profile）

5. `Generator.kt` 生成 `ScenarioProgram`

   Generator 只产出 AST，不产出 Kotlin 文本。它会根据分布生成：

   - class definitions
   - global definitions
   - function definitions
   - alloc/load/store/call
   - block/if/try-finally
   - spawn thread
   - perform GC
   - foreign roundtrip（仅 feature 打开时）
   - topology 模板注入

   生成器有两类输出：普通随机语句流，以及带固定语义的 topology 模板。真正带 oracle 的用例主要来自 topology 模板，例如 weak-dead、single-strong-slot、reachability-consistency、root-migration capsule。普通随机语句流更多用于制造对象图、控制流、并发和 GC 压力。

6. `PureKotlinScenarioBackend.kt` 做 profile preparation

   调用关系是：

   ```text
   ScenarioPreparation.prepare(program, PureKotlinScenarioProfile 或 PureKotlinCInteropScenarioProfile)
   ```

   这一步的意义是把“通用 AST”整理成“pure-kotlin backend 能消费的 AST”。当前实现主要把 definition/op/value/location 的 `targetLanguage` 和 `domain` 统一成 Kotlin，并通过 profile 方法处理 `ScenarioStoreReferenceKind`、`ScenarioForeignReferenceKind`。它不是复杂 lowering，也没有在当前代码中大量拒绝或改写语义。

7. `PureKotlinTranslation.kt` 生成 Kotlin 源码

   它把 `ScenarioProgram` 翻译成 `PureKotlinOutput`：

   - `filename = <moduleName>.kt`，当前 moduleName 为 `main`，所以实际是 `main.kt`
   - `contents = Kotlin 源码`
   - `args = -opt -entry main`

   生成源码会包含：

   - runtime prelude
   - `KotlinIndexAccess`
   - `KotlinArrayBox`
   - `Worker` 并发 scaffold
   - `performGC()`
   - global root
   - class/function/main
   - reachability probe helper 和 `assertReachability`

   需要特别注意：翻译器会识别一部分固定 topology 序列，把它们翻译成专门的 probe helper 调用，而不是逐条机械翻译。这样可以更精确地控制强引用生命周期，避免 Kotlin 局部变量意外保活对象导致 oracle 不稳定。

   如果 IR 中出现 `ForeignRoundTrip`，`producePureKotlin()` 还会通过 `PureKotlinCInterop.kt` 额外生成：

   - `cinterop.def`
   - `bridge.h`
   - `bridge.c`

8. `PureKotlinScenarioRunner.kt` 编译并运行

   它会把生成文件写到：

   ```text
   <resultsRoot>/<runId?>/<caseId>/generated/main.kt
   ```

   其中 `resultsRoot` 默认是当前工作目录下的 `workspace/runs`，也可以通过 `gcfuzzing.resultsRoot` 或 `GCFUZZ_RESULTS_ROOT` 指定；`runId` 来自 `gcfuzzing.runId`，为空时不会多一层 runId 目录。

   非 CFFI case 直接调用 `konanc` 生成：

   ```text
   <resultsRoot>/<runId?>/<caseId>/app.kexe
   ```

   CFFI case 会先调用 `cinterop` 和 `clang`，再把生成的 bridge klib/object 链接进最终程序。

   运行阶段可能写入：

   - `run.log`
   - `run.stdout.log`
   - `run.stderr.log`
   - `run.exitcode.txt`
   - `app.kexe.log`

   其中 `run.stdout.log` / `run.stderr.log` / `run.exitcode.txt` 只在 host CMC + `libcrtPath` 执行路径中直接写出；普通执行路径会把 stdout/stderr/exitCode 合并写入 `run.log`。CFFI case 的编译日志名是 `konanc.log`，并额外有 `cinterop.log`、`clang.log`。minidump 位置通过 `-Xbinary=minidumpLocation=<caseDir>` 配置，是否产生 `*.dmp` 取决于运行时崩溃情况。

## 6. 新增执行 mode 如何接入

新增执行 mode 时，不应该改 `Generator.kt` 主逻辑，也不应该恢复 DSL。标准路径是新增一组平行文件。

```text
tests/.../fuzzer/<lang>/
  mode/
    <Lang>ScenarioModeDescriptor.kt
    <Lang>ScenarioGenerationProfile.kt
  profile/
    <Lang>ScenarioProfile.kt
  backend/
    <Lang>ScenarioBackend.kt
    <Lang>ScenarioLowering.kt

tests/.../translation/
  <Lang>Translation.kt

tests/.../execution/<lang>/
  <Lang>ScenarioRunner.kt
```

接入步骤：

1. 定义 `<Lang>ScenarioGenerationProfile`

   只打开该语言已经支持的 feature。不要为了复用现有用例而一次性打开全部能力。

2. 定义 `<Lang>ScenarioProfile`

   明确该 backend 能接受哪些 AST 语义。当前 `ScenarioPreparation` 只提供基础规约能力；如果某个目标需要更复杂的语义过滤或改写，应该在 profile、backend 或专门 lowering 中显式实现，不要假设 preparation 已经自动完成。

3. 实现 `<Lang>ScenarioBackend`

   标准职责：

   ```text
   ScenarioProgram
     -> ScenarioPreparation.prepare(program, <Lang>ScenarioProfile)
     -> <Lang>ScenarioLowering（如果需要）
     -> <Lang>Translation
     -> <Lang>Output
   ```

4. 实现 `<Lang>Translation`

   把 prepared Scenario AST 翻译成目标语言源码或多文件输出。

5. 实现 `execution/<lang>/<Lang>ScenarioRunner`

   负责保存源码、编译、运行、收集 stdout/stderr/exitCode/dump。

6. 注册 `<Lang>ScenarioModeDescriptor`

   在 `ScenarioModeRegistry.kt` 中注册新 mode，使 `gcfuzzing.executionModel=<lang>` 能命中。

7. 增加测试

   最少应覆盖：

   - generation profile feature 开关
   - preparation/profile 行为
   - backend lower 输出
   - translation 最小源码
   - execution smoke test

## 7. CFFI 支持应该放在哪里

当前代码已经有一条 `pure-kotlin` + C interop 的最小 CFFI 路径：

- `ScenarioOp.ForeignRoundTrip` 表达一次 foreign 往返
- `PureKotlinCInteropScenarioGenerationProfile` 通过 `CFFI_CALLBACK_ROUNDTRIP` 打开生成能力，当前覆盖 callback、repeated callback、identity、wrapped callback、callback-then-identity、nested callback、boxed callback 等同步调用形态
- `PureKotlinTranslation.kt` 在发现 `ForeignRoundTrip` 时生成 foreign runtime 调用
- `PureKotlinCInterop.kt` 生成 `cinterop.def`、`bridge.h`、`bridge.c`
- `PureKotlinScenarioRunner.kt` 在 CFFI case 中先运行 `cinterop` 和 `clang`，再用 `konanc` 链接 klib/object

因此，“不要把 CFFI 塞进 Generator 或 translation”需要更精确地理解：Generator 可以生成通用 CFFI 语义节点，translation 可以负责目标 backend 的源码渲染；不应该做的是在通用 Generator 中写目标语言专属编译、桥接文件布局或 runtime 细节。

后续扩展 CFFI 时推荐分层如下：

| 层 | CFFI 职责 |
|---|---|
| `Scenario.kt` | 增加通用跨语言语义节点，例如 foreign handle、callback、ownership edge；当前已有 `ForeignRoundTrip` |
| `ScenarioFeatureSet.kt` | 增加或复用 CFFI feature 开关；当前已有 `CFFI_CALLBACK_ROUNDTRIP` |
| `ScenarioPreparation.kt` | 做通用规约和 profile 分发；复杂生命周期校验可放在 profile/backend/lowering 中实现 |
| `<Lang>ScenarioProfile.kt` | 声明该语言/CFFI mode 支持哪些跨域语义 |
| `<Lang>ScenarioBackend.kt` | 把通用 AST 分发到多文件、多模块或桥接输出 |
| `<Lang>Translation.kt` | 生成桥接源码、header、binding、stub |
| `execution/<lang>` | 编译多语言产物，设置动态库路径，运行并收集崩溃信息 |

CFFI 的核心不是“多生成一个文件”，而是要显式建模：

- 哪个 runtime 持有哪个对象
- foreign handle 是否强保活
- callback 是否跨线程
- GC 期间 foreign root 是否可见
- native 侧释放和 Kotlin GC 的先后关系

这些约束应该优先进入 profile/backend/lowering/translation/execution，而不是进入通用 Generator 的目标语言分支。

## 8. 当前架构边界

当前应该坚持的边界：

- `Generator.kt` 生成 `ScenarioProgram`，不生成语言源码
- `ScenarioProgram` 表达语义，不表达 Kotlin/ObjC/Java 语法
- topology 模板属于通用生成能力
- 当前注册的执行 mode 只有 `pure-kotlin`；新增 mode 通过 `ScenarioModeRegistry` 接入
- 目标差异收敛到 `mode/profile/backend/translation/execution`
- CFFI 已通过 `ForeignRoundTrip`、`PureKotlinCInteropScenarioGenerationProfile`、`PureKotlinCInterop.kt` 和 runner 中的 `cinterop/clang` 分支接入
- runner 直接负责每个 case 的生成源码、`topology.json`、编译日志、运行日志和 minidump 位置；`case-index.html`、`topology-summary.html/json/csv`、`topology-family-summary.csv`、`topology-case-hits.csv`、`failed-cases-summary.tsv`、失败归档属于 Gradle/ops 层的汇总与归档能力

如果后续新增 mode 时发现需要在 `Generator.kt` 里写大量目标语言判断，说明架构边界正在被打破，应该优先考虑新增 feature、profile、lowering、backend 或 translation 能力。
