# GC Fuzz 并发 Root Lifecycle 演进方案

本文档记录 `gc-fuzzing-tests` 下一步在“并发 root lifecycle”方向建议增加的 8 类代码结构。

这里的目标不是单纯增加线程数量，而是从 Kotlin/Native GC 的业务特征出发，系统制造对象在不同 root source 之间发布、迁移、清理、重新发布时的交错窗口。

## 1. 背景：为什么要做并发 root lifecycle

Kotlin/Native GC 需要在 mutator 持续运行时正确识别对象可达性。对 fuzz 来说，最有价值的输入通常不是复杂语法，而是对象在 root set 中快速变化：

- 对象刚发布到 shared global，另一个线程马上清理。
- 对象从 worker local 转移到 shared global。
- 对象从 shared global 转移到 worker thread-local。
- 对象被多个 owner 同时持有，然后分阶段释放。
- 对象通过 field / array slot / global 多种路径迁移。
- GC 正好插在 publish、clear、handoff、worker exit 之间。

当前工具已经有一些相关 topology，例如：

- `TOPOLOGY_CONCURRENT_ROOT_MIGRATION`
- `TOPOLOGY_CONCURRENT_PUBLISH_CLEAR_GC`
- `TOPOLOGY_WORKER_ALLOC_PUBLISH`
- `TOPOLOGY_MULTI_STAGE_ROOT_HANDOFF`
- `TOPOLOGY_PING_PONG_ROOT_TRANSFER`
- `TOPOLOGY_CONCURRENT_DUPLICATE_HANDOFF`
- `TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF`
- `TOPOLOGY_STALE_OWNER_MUTATION_AFTER_HANDOFF`

下一步应该继续沿着 `ScenarioProgram -> Generator topology -> PureKotlinTranslation` 的路线扩展，不应在 translation 层直接随机拼特殊并发代码。

## 2. Root 来源拆解

并发 root lifecycle 主要应覆盖这些 root 来源：

| Root 来源 | 当前落地形态 | 需要重点制造的生命周期 |
|---|---|---|
| stack / local | `ScenarioValue.LocalRef`、函数局部变量、lambda capture | local 创建、逃逸、清理、被 worker capture |
| shared global | `ScenarioGlobalStorage.Shared` + atomic backing | publish、clear、republish、跨 worker 读写 |
| thread-local global | `ScenarioGlobalStorage.ThreadLocal` + `@ThreadLocal` | worker 内 publish、迁出到 shared、worker 退出清理 |
| object field | `StrongRef` / `WeakRef` field | owner handoff、stale owner mutation、field clear |
| array slot | `ObjectArray` + indexed path | array slot handoff、slot clear、late restore |
| worker root | `ScenarioOp.Spawn` / `SpawnFunction` | worker stack、lambda capture、worker exit 前后 GC |
| foreign root | `ForeignRoundTrip` / `StableRef` | 后续 CFFI 生命周期专题中继续加深 |

## 3. 建议增加的 8 类代码结构

### 3.1 Shared root 短窗口 publish / clear / republish

GC 目标：

- root table 更新。
- atomic store barrier。
- GC 与 mutator 对 shared global 的写入交错。
- clear 后立刻重新 publish 的可达性恢复。

建议代码结构：

```kotlin
val first = Payload()
g0 = first
performGC()
g0 = null
val second = Payload()
g0 = second
performGC()
touch(g0)
```

并发变体：

```kotlin
g0 = payload
spawnThread {
    g0 = null
    performGC()
    g0 = replacement
}
performGC()
touch(g0)
```

建议新增 feature / topology：

- `TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR`
- `TOPOLOGY_CONCURRENT_ROOT_REPUBLISH_AFTER_CLEAR`

实现建议：

- 复用 `chooseStrongSharedGlobalOrNull()`。
- 优先使用 strong shared global，避免 weak 语义干扰。
- 在 clear 和 republish 之间插入 `AllocationBurst`，提高 GC 触发窗口价值。

### 3.2 Thread-local root -> shared root -> thread-local root 迁移

GC 目标：

- thread-local root 扫描。
- worker 本地 root 迁出到 shared global。
- shared root 再迁入另一个 worker 的 thread-local root。
- worker 退出时 `clearThreadLocalRoots()` 与 GC 的交错。

建议代码结构：

```kotlin
@ThreadLocal
var tl: Any? = null

spawnThread {
    val payload = Payload()
    tl = payload
    g0 = tl
    tl = null
    performGC()
}

performGC()
touch(g0)
```

反向变体：

```kotlin
g0 = Payload()

spawnThread {
    tl = g0
    g0 = null
    performGC()
    touch(tl)
}
```

建议新增 feature / topology：

- `TOPOLOGY_THREAD_LOCAL_TO_SHARED_HANDOFF`
- `TOPOLOGY_SHARED_TO_THREAD_LOCAL_HANDOFF`
- `TOPOLOGY_THREAD_LOCAL_CLEAR_ON_WORKER_EXIT`

实现建议：

- 增加选择 thread-local global 的 helper，例如 `chooseThreadLocalGlobalOrNull()`。
- 对需要存引用的场景，优先选择 `StrongRef` thread-local global。
- worker body 结束前已经会调用 `clearThreadLocalRoots()`，可以构造“退出前仍持有 / 退出后清理”的对照结构。

### 3.3 Worker lambda capture 作为 root

GC 目标：

- worker lambda capture 对象是否被正确视为 worker root。
- 主线程清掉 global 后，worker capture 是否仍能保活。
- closure root 与 worker stack scan 的交错。

建议代码结构：

```kotlin
val payload = Payload()
g0 = payload

spawnThread {
    performGC()
    touch(payload)
}

g0 = null
performGC()
```

建议新增 feature / topology：

- `TOPOLOGY_WORKER_CAPTURE_SURVIVES_GLOBAL_CLEAR`
- `TOPOLOGY_CAPTURE_THEN_FIELD_PUBLISH`

实现建议：

- `ScenarioOp.Spawn` 当前翻译时会 fork scope，天然可以表达 worker capture 外层 local。
- topology 中先创建 local，再在 worker body 中直接 `Observe(LocalRef(payloadLocalId))` 或 store 到 sink。
- 主线程随后清 global 并 GC，制造 capture 与 global clear 的保活竞争。

### 3.4 多 owner staggered clear

GC 目标：

- 一个 payload 被多个 root/owner 同时持有时，分阶段释放是否正确。
- field、array slot、global 三类路径的 barrier 是否一致。
- GC 插在每次 clear 之后时，仍存活的 owner 是否足够保活。

建议代码结构：

```kotlin
owner.f0 = payload
arrayOwner.array[0] = payload
g0 = payload

spawnThread {
    owner.f0 = null
    performGC()
}

arrayOwner.array[0] = null
performGC()
touch(g0)
g0 = null
performGC()
```

建议新增 feature / topology：

- `TOPOLOGY_MULTI_ROOT_STAGGERED_CLEAR`
- `TOPOLOGY_FIELD_ARRAY_GLOBAL_STAGGERED_CLEAR`

实现建议：

- 需要保证 class 中有 `StrongRef` field 和 `ObjectArray` field。
- 可复用现有 `chooseClassWithStrongRefFieldOrNull()`、`chooseClassWithArrayFieldOrNull()`。
- 初期作为 stress topology，不加 dead oracle。

### 3.5 Array slot 作为 root handoff 主通道

GC 目标：

- array slot 写屏障。
- array slot clear 与 object field/global handoff 的组合。
- worker 从 shared global 读取 array slot 后转存到 sink。

建议代码结构：

```kotlin
arrayOwner.array[0] = payload
g0 = arrayOwner

spawnThread {
    val copied = g0.array[0]
    sink.f0 = copied
    g0.array[0] = null
    performGC()
}

performGC()
touch(sink.f0)
```

建议新增 feature / topology：

- `TOPOLOGY_CONCURRENT_ARRAY_SLOT_HANDOFF`
- `TOPOLOGY_ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE`

实现建议：

- 当前已有 `TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF`，但主要是顺序路径。
- 新 topology 应该把 array slot 作为 worker 之间 handoff 的主路径。
- 可以增加“clear 后 late restore”变体：先清 slot，GC，再从另一个 owner 恢复 slot。

### 3.6 try/finally 中清 root

GC 目标：

- 异常 / early exit 路径中的 root 清理。
- finally 中 clear + GC 的 safe point。
- `FuzzControlException` 受控退出时，临时对象是否被意外保活或提前回收。

建议代码结构：

```kotlin
try {
    g0 = Payload()
    throw FuzzControlException(g0)
} finally {
    g0 = null
    performGC()
}
```

owner 变体：

```kotlin
try {
    owner.f0 = payload
    g0 = owner
} finally {
    owner.f0 = null
    performGC()
}
```

建议新增 feature / topology：

- `TOPOLOGY_TRY_FINALLY_ROOT_CLEAR`
- `TOPOLOGY_EXCEPTION_ESCAPE_ROOT_HANDOFF`

实现建议：

- 复用现有 `ScenarioOp.TryFinally`、`ScenarioOp.Throw`。
- terminal statement 当前不进入 nested body，需要注意 topology 的 body 位置和 translation 上下文。
- 初期可以只做 `try/finally` stress，不直接加 reachability dead assertion。

### 3.7 Return escape 后跨线程 publish

GC 目标：

- 函数返回值从 callee stack 逃逸到 caller。
- caller local 被 worker capture 或 publish 到 shared global。
- source local 清理后，target root 是否保活。

建议代码结构：

```kotlin
fun make(): Any? = Payload()

var payload = make()
spawnThread {
    g0 = payload
    performGC()
}
payload = null
performGC()
touch(g0)
```

建议新增 feature / topology：

- `TOPOLOGY_RETURN_ESCAPE_WORKER_PUBLISH`
- `TOPOLOGY_RETURN_ESCAPE_CLEAR_SOURCE_AFTER_PUBLISH`

实现建议：

- 当前已有 `TOPOLOGY_FUNCTION_RETURN_ESCAPE` 和特殊 escaping-return function。
- 新 topology 可以复用 function id `0` 的返回对象，再组合 `Spawn` 和 shared global handoff。
- 注意当前普通 `CallFunction` 翻译会生成一个自动 local；如果要稳定引用返回值，可能需要在 IR 层增加“call result store”能力，或沿用现有返回 local 约定并补测试。

### 3.8 引入轻量同步 / 阶段控制 IR

GC 目标：

- 把部分并发 stress 从纯概率交错升级成可复现的阶段性交错。
- 稳定制造 “publish -> worker observe -> clear -> worker copy -> GC” 这类窗口。
- 为未来 oracle capsule 提供可证明的 happens-before 骨架。

建议 IR：

```kotlin
ScenarioOp.Signal(checkpointId)
ScenarioOp.Wait(checkpointId)
ScenarioOp.Yield
```

或者更保守：

```kotlin
ScenarioOp.SchedulePoint(label)
```

建议生成形态：

```text
main:   publish root
main:   signal(published)
worker: wait(published)
main:   clear source
worker: copy to target
worker: signal(copied)
main:   wait(copied)
main:   performGC
worker: observe target
```

建议新增 feature / topology：

- MVP 已落地：`ScenarioOp.Signal(checkpointId)`、`ScenarioOp.Wait(checkpointId)`、`ScenarioOp.Yield`
- 已落地：`TOPOLOGY_WORKER_PUBLISH_MAIN_CLEAR_BARRIER`
- 已落地：`TOPOLOGY_ARRAY_SLOT_CLEAR_RESTORE_BARRIER`
- 后续可继续扩展：`TOPOLOGY_CONTROLLED_ROOT_HANDOFF`
- 后续可继续扩展：`TOPOLOGY_CONTROLLED_CLEAR_DURING_COPY`

实现建议：

- translation 可用 `AtomicInt` 做 checkpoint 状态。
- `Wait` 必须有 soft timeout / termination check，避免 hang。
- 初期只在 targeted topology 中使用，不放进普通随机 statement 池。

## 4. 推荐落地顺序

当前落地状态：

- 已落地：`thread-local <-> shared` handoff。
- 已落地：worker lambda capture 作为 root。
- 已落地：multi-root staggered clear。
- 已落地：array slot concurrent handoff。
- 已落地：shared root republish after clear。
- 已落地：try/finally root clear。
- 已落地：return escape worker publish。
- 已落地：thread-local clear on worker exit。
- 已落地：array slot clear with late restore。
- MVP 已落地：`Wait/Signal/Yield` 轻量调度 IR，仅支持 targeted topology 内的 bounded checkpoint 协调。
- 已落地：worker publish main clear barrier。
- 已落地：array slot clear restore barrier。

原因：

- 前 4 项可以大多复用现有 IR 和 translation，收益高、风险低。
- 第 5 到第 9 项进一步扩展 root 生命周期覆盖，已按 stress topology 落地。
- 轻量调度 IR MVP 已使用 bounded wait 和 termination check 防 hang，后续新增同步 topology 必须沿用该约束。

轻量调度 IR 后续增强项：

- 扩展 `Wait` 语义，支持等待指定 value、等待多 checkpoint、等待 signal 次数或超时 fallback。
- 扩展 `Yield` 语义，支持多次 yield、yield with allocation pressure、yield until checkpoint。
- 引入 phase/barrier 类 IR，用于表达多个 worker 同时 publish、部分 clear、部分 restore 的阶段性交错。
- 抽象 reusable 调度组合器，例如 publish-clear-window、clear-restore-window、worker-exit-window，减少每个 topology 手写 checkpoint 协议。
- 在证明配对生成和 hang 保护足够后，再考虑把调度 IR 安全注入普通 random statement 池。

ScenarioOp 反哺 topology 的后续迁移项：

- 选择 worker exit 语义明确的 topology，试点使用 `ScenarioOp.Spawn(join = true)`，目标是稳定表达“worker local/thread-local root 消失后主线程再 GC”的窗口。
- 选择 local root 生命周期明确的 topology，试点使用 `ScenarioOp.ScopedRoot`，目标是把 root drop 从普通 `Block` 语义中显式拆出来。
- 这两类迁移会改变最终用例的并发时序或 local root 生命周期，不作为低风险批量迁移处理；每个 topology 必须单独评估并跑真实 fuzz smoke。

## 5. 实现边界

新增能力应遵守现有架构边界：

- 在 `ScenarioFeature` 中增加 feature gate。
- 在 `Generator.kt` 中增加 topology kind 和生成模板。
- 如果现有 IR 够用，优先复用 `CreateObject`、`Store`、`Spawn`、`PerformGc`、`Observe`。
- 如果需要可控调度，再扩展 `ScenarioOp`，不要在 translation 中偷偷加随机逻辑。
- 在 `GeneratorTopologyTest` 中增加“可生成该 topology”的覆盖测试。
- 对 reachability oracle 保持保守，新增结构初期先作为 stress topology。

## 6. 总结

并发 root lifecycle 的演进重点是系统制造 root 来源之间的迁移窗口：

- local / stack 到 shared global。
- shared global 到 thread-local。
- worker capture 到 field / array slot。
- 多 owner 同时持有再分阶段释放。
- clear 后 republish。
- worker exit 前后 thread-local 清理。
- GC 插在每个 publish、clear、handoff 之间。

这些结构比增加更多随机语句更直接地覆盖 Kotlin/Native GC 的核心风险面：root 扫描、write barrier、weak processing、worker root 合并、thread-local 清理和并发 mutator 交错。
