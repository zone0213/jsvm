# GC Fuzz 当前能力、限制与扩展路线

本文档按当前代码实现重新梳理 `gc-fuzzing-tests` 的测试能力。重点回答三件事：

1. 当前实际具备哪些 fuzz / 测试能力。
2. 当前能力边界和限制在哪里。
3. 下一步应该优先扩展哪些测试能力。

核心能力以 `ScenarioProgram`、`Generator`、profile/backend/translation/execution 当前能表达和执行什么为准。

## 1. 当前实现基线

当前正式主链路是：

```text
GCFuzzingTest
  -> SimpleFuzzer
  -> ScenarioModeRegistry
  -> PureKotlinScenarioModeDescriptor
  -> generateScenario(seed, features)
  -> ScenarioProgram
  -> PureKotlinScenarioBackend
  -> PureKotlinTranslation
  -> konanc
  -> app.kexe
  -> run
```

当前正式执行 mode：

- `pure-kotlin`
- alias：空字符串、`pure-kotlin`、`pure_kotlin`、`pure`

当前可选能力：

- `gcfuzzing.cffi=true` 时，`pure-kotlin` 切换到 `PureKotlinCInteropScenarioGenerationProfile`，可以生成 `ForeignRoundTrip`，并通过 `cinterop` + `clang` + `konanc` 执行。

当前 smoke/experimental 路径：

- `fuzzer/kotlincffi` / `translation/KotlinCInteropTranslation.kt` 是固定 Kotlin/C interop smoke，不消费 `ScenarioProgram`，不属于正式随机 fuzz 主链路。

## 2. 当前已具备的核心测试能力

### 2.1 Scenario IR 能力

当前共享 IR `ScenarioProgram` 已能表达：

- class / function / global definitions。
- shared global 和 thread-local global。
- strong reference field。
- weak reference field。
- Int / Boolean 这类 scalar-like field。
- object-array-like field。
- local/global value 和 path-based field access。
- object allocation。
- store / observe。
- function call、return、throw。
- block、if、try-finally。
- explicit GC。
- worker spawn / spawn function。
- allocation burst。
- weak reachability observation 和 alive/dead expectation。
- foreign roundtrip。

这意味着当前工具不是直接随机拼 Kotlin 源码，而是先生成 GC 语义 IR，再由 backend/translation 落到 Kotlin Native。

### 2.2 普通随机程序生成能力

当前生成器已经能随机组合：

- 多个 class/global/function。
- 大小不同的 body。
- 多字段 class，字段数量可覆盖小对象到大对象。
- local/global 混合读写。
- 随机 path 访问。
- alloc/load/store/call。
- block/if/try-finally。
- return/throw terminal statement。
- worker spawn。
- explicit GC。
- allocation burst。
- CFFI roundtrip，需 `gcfuzzing.cffi=true`。

这类能力主要用于制造覆盖面和运行时压力。它允许一定比例的无效 id/path，由翻译层容错为 `null` 或跳过无效 store，因此它的定位不是精确 oracle，而是压力输入。

### 2.3 字段与 root 能力

当前 `pure-kotlin` translation 已能落地：

- shared global：atomic backing。
- thread-local global：`@ThreadLocal` backing，并在 worker 退出时清理。
- strong field：`AtomicReference<Any?>`。
- weak field：`WeakReference` backing。
- Int / Boolean field：`AtomicInt` / `AtomicBoolean` 或本地 backing。
- object array field：`KotlinArrayBox` + `AtomicArray`。
- path access：通过 `KotlinIndexAccess.loadKotlinField/storeKotlinField` 统一访问。

这些能力能覆盖：

- root publish / clear。
- shared root 与 thread-local root 的差异。
- strong edge 和 weak edge。
- scalar field 与 object-like field 混合。
- array slot 图结构。

### 2.4 结构化控制流能力

当前默认 profile 已打开：

- `STRUCTURED_CONTROL_FLOW`
- `TERMINAL_STATEMENTS`
- `ESCAPING_RETURN_FUNCTION`

生成器能制造：

- 嵌套 block。
- if 分支。
- try-finally，并在 finally 中插入 GC 和 allocation burst。
- function call。
- return escape。
- throw，经 `FuzzControlException` 转成受控退出。

限制：

- nested body 当前不生成 terminal statement，避免在 lambda/worker 这类翻译上下文中产生不合适的 return/throw。

### 2.5 并发与 root handoff 能力

当前默认 profile 已包含多种并发和 root 迁移 topology：

- concurrent root migration。
- concurrent publish / clear / GC。
- worker alloc publish。
- multi-stage root handoff。
- ping-pong root transfer。
- concurrent duplicate handoff。
- local/global array handoff。
- stale owner mutation after handoff。

这些能力主要打：

- mutator 与 GC 交错。
- shared root 发布与撤销。
- worker 中分配后发布。
- source owner 清理后 target owner 保活。
- 多阶段 root 转移。
- stale owner 上的延迟写。
- array slot 参与 handoff。

这是当前最有价值、也最应该继续加深的方向。

### 2.6 对象图与脏图 topology

当前默认 profile 已包含：

- cycle。
- shared node。
- global reattach。
- old root churn。
- root migration。
- delete edge then GC。
- weak ref lifecycle。
- array slot graph。
- graph mutation sequence。
- function return escape。

这些 topology 的作用是制造更接近 GC 边界条件的对象图变化：

- 环。
- 多 owner 共享 payload。
- global root 重新挂接。
- 旧 root 替换。
- 断边后 GC。
- weak ref 伴随 strong root 清理。
- array slot 与 object field 混合。
- field slot 与 array slot 混合 mutation barrier。
- 大对象多 strong-field 批量改写。
- 多阶段对象图 mutation。
- old root churn + allocation burst。
- shared node 在多个 owner 间反复重连。
- cycle 创建后局部断边，再通过新 root 恢复可达。

### 2.7 Weak reference 压力能力

当前已经具备：

- weak field。
- weak global。
- weak reachability observation。
- weak ref lifecycle topology。
- weak value 在 global publish/clear 后被 observe。

当前 weak 能力更偏 stress，而不是全部都有强 oracle。它适合发现 weak 处理中的崩溃、runtime assert、状态不一致，也适合后续扩展成更稳定的 oracle capsule。

### 2.8 Reachability oracle 能力

代码中已实现 reachability oracle 相关 IR、生成模板、translation probe 和 runtime assertion。

当前已实现的 oracle capsule 包括：

- `single-strong-slot`
- `reachability-consistency`
- `root-migration`
- `weak-dead-capsule`

但是这些 oracle feature 当前没有在 `PureKotlinScenarioGenerationProfile` 默认打开：

- `ORACLE_SINGLE_STRONG_SLOT`
- `ORACLE_REACHABILITY_CONSISTENCY`
- `ORACLE_ROOT_MIGRATION_CAPSULE`
- `ORACLE_WEAK_DEAD_CAPSULE`

当前默认 profile 打开的是若干 stress topology，例如 `TOPOLOGY_REACHABILITY_CONSISTENCY`、`TOPOLOGY_ROOT_MIGRATION` 等；带强 alive/dead 断言的 oracle capsule 仍处于“代码存在、测试存在、默认随机生成未打开”的状态。

原因：

- reachability oracle 对强引用生命周期非常敏感。
- 在复杂随机程序中，如果 capsule 不够隔离，容易出现额外强引用链导致 false positive。
- 断言如 `dead-after-clear` 必须证明所有强引用都已清除，否则失败不可信。

当前策略：

- 保留 oracle 实现。
- 保留 translation probe。
- 保留测试。
- 默认 fuzz 先以 stress topology 为主。
- 后续按更严格的 capsule 准入规则逐步恢复 oracle 默认生成。

### 2.9 Pure Kotlin + C interop 能力

`gcfuzzing.cffi=true` 时，当前已具备：

- 生成 `ForeignRoundTrip`。
- reference kind：
  - `Handle`
  - `Strong`
  - `Weak`
- interaction pattern：
  - `Callback`
  - `RepeatedCallback`
  - `Identity`
  - `WrappedCallback`
  - `CallbackThenIdentity`
  - `NestedCallback`
  - `BoxedCallback`
  - `BoxedIdentity`
  - `BoxedRepeatedCallback`
- repetitions：1 到 16 的分布。
- CFFI stress topology：
  - `TOPOLOGY_CFFI_CALLBACK_AFTER_GC`：Kotlin object 发布到 global root，GC 后通过 C callback 触碰 payload，再 observe root。
  - `TOPOLOGY_CFFI_IDENTITY_HANDOFF`：Kotlin object 经过 C identity roundtrip 后发布到 global root，再 GC/observe。
- 生成 bridge 文件：
  - `cinterop.def`
  - `bridge.h`
  - `bridge.c`
- 执行链路：
  - `cinterop`
  - `clang`
  - `konanc`
  - app run
- Kotlin runtime 使用 `StableRef` 包装 payload，并通过 C callback 回到 Kotlin 访问 payload。
- C bridge 不是随机 C AST，但已经不是单一 callback：当前提供同步 callback、重复 callback、identity、C wrapper 间接调用、callback 后 identity 再 callback、递归 wrapper 后 callback，以及用 `gcfuzz_box_t` 栈上 struct 包装 payload 再传回的 boxed 调用模板。

当前 CFFI 能力的定位：

- 已打通基础 roundtrip、callback、C 侧 payload struct 包装和多种同步 C 调用形态压力。
- 已开始把 CFFI 放进 targeted topology，而不是只作为普通随机 statement。
- 能与普通对象图、GC、worker、allocation burst 混合。
- 还不是完整 CFFI 生命周期模型。

## 3. 当前能力限制

### 3.1 执行 mode 限制

当前正式 mode 只有 `pure-kotlin`。

限制：

- `ScenarioTargetLanguage.ObjC`、`Java`、`Native` 当前主要是 IR 预留概念。
- 当前主 backend 会把目标规约到 Kotlin。
- 还没有正式的 ObjC/Java/Native 或其他目标 backend 主链路。

### 3.2 Preparation / profile 限制

当前 `ScenarioPreparation` 主要做统一 target/domain。

限制：

- 不是复杂能力裁剪器。
- 不会自动证明某个 target backend 支持所有语义。
- 不会自动修复不稳定 oracle。
- 新 backend 如果不支持某类语义，需要自己在 profile/backend/lowering 中显式处理。

### 3.3 普通随机语句流的 oracle 限制

普通随机语句流会制造大量噪声，包括无效 id/path。

限制：

- 它适合 crash、assert、timeout、runtime failure 发现。
- 它不适合直接承载强 reachability alive/dead 断言。
- 若要做语义 oracle，必须通过 capsule 或等价隔离机制实现。

### 3.4 Reachability oracle 稳定性限制

当前最需要谨慎的能力就是 reachability oracle。

限制：

- `Dead` 断言必须证明没有剩余强引用。
- `Alive` 断言必须证明存在稳定强引用。
- 普通 shared global / random local / 开放世界 worker 都不能作为唯一真值来源。
- translation 如果逐条机械翻译，可能因局部变量生命周期导致误保活；因此当前使用 probe helper 规避一部分风险。

结论：

- oracle 不是不能做。
- 但默认 fuzz 中的 oracle 必须比 stress topology 更保守。

### 3.5 CFFI 覆盖限制

当前 CFFI 已经能 roundtrip，并覆盖多种同步 C 调用形态和栈上 payload struct 包装，但生命周期模型还浅。

未覆盖或覆盖不足：

- foreign side delayed handle。
- callback 延迟到本地 strong root 清理之后。
- repeated callback 中间插入 Kotlin GC 触发点。
- foreign side 长时间持有并跨多个 GC epoch。
- foreign weak/strong/handle 与本地 object graph handoff 的系统组合。
- foreign callback 跨 worker/thread 的复杂场景。
- native side release timing 与 Kotlin GC 的先后关系。
- 当前 C bridge 仍是有限同步模板池，只包含调用内的栈上 box，不包含跨调用 C side store/load/clear 状态，也不包含 native allocation/free 生命周期。

### 3.6 并发调度限制

当前 worker spawn 是主要压力来源；轻量 `Signal/Wait/Yield` checkpoint IR 的 MVP 已落地，可以在 targeted topology 中钉住部分 publish/clear/GC 窗口，但它仍不是完整 deterministic scheduler。

限制：

- 只能表达少量 checkpoint happens-before，不能系统枚举所有 interleaving。
- 还不支持多 checkpoint wait、phase/barrier、signal 计数和 timeout fallback。
- bounded wait 可以避免 hang，但也意味着极端调度异常时会退化为 probabilistic stress。
- 更适合 controlled stress，而不是 deterministic schedule oracle。

### 3.7 ScenarioOp 反哺 topology 的迁移限制

当前已新增更显式的操作 IR：

- `Clear`：表达 root/slot 生命周期清理。
- `StoreBatch`：表达连续 mutation / barrier 压力窗口。
- `GcEpoch`：表达连续多轮 GC epoch。
- `ScopedRoot`：表达 local root 的作用域生命周期。
- `Spawn(join = true)`：表达 worker 退出前后的 bounded join 生命周期窗口。

已完成的低风险迁移：

- topology 中大量 `Store(..., NullValue)` 已迁移为 `Clear`。
- 部分 dirty graph / barrier topology 的连续非 clear store 已迁移为 `StoreBatch`。

暂缓迁移的内容：

- 不继续把非连续 GC 序列强行改成 `GcEpoch`，因为两次 GC 之间存在 allocation、observe、publish/clear、checkpoint 或 worker handoff 时，合并会改变用例时序。
- 不继续把普通 `Block` 改成 `ScopedRoot`，因为这会改变 local root 生命周期表达，可能影响最终可达性窗口。
- 不继续把 fire-and-forget `Spawn` 改成 `Spawn(join = true)`，因为这会改变并发 interleaving，从并发压力转成 worker-exit 生命周期压力。

后续如果继续迁移，应按 topology 逐个评估，并优先补命中率/运行结果对比，而不是批量替换。

### 3.8 结果判断限制

当前稳定判断主要来自：

- 编译失败。
- 运行失败。
- timeout。
- runtime crash / assert。
- minidump。
- reachability assertion，当前默认 oracle capsule 未打开。

限制：

- 非 crash 语义错误的自动识别能力还有限。
- 除 reachability 外，还缺少更多稳定 oracle 类型。

## 4. 下一步测试能力扩展方向

### 4.1 第一优先级：并发 root lifecycle 深化

已落地的深化项包括：

- thread-local/shared handoff。
- worker lambda capture root。
- multi-root staggered clear。
- concurrent array slot handoff。
- shared root clear 后 republish。
- try/finally root clear。
- return escape 后 worker publish。
- worker exit 时 thread-local root 清理压力。
- array slot clear 后 late restore。
- worker publish 后 main clear barrier。
- array slot clear 后 worker GC、main late restore barrier。

后续继续增强：

- 多 owner 同时持有和交替释放。
- worker 分配后延迟 publish。
- stale owner mutation after root migration 的更多变体。
- 更多基于 `Signal/Wait/Yield` 的 publish / clear / copy 调度窗口。
- 基于 phase/barrier 的多 worker root lifecycle 阶段性交错。
- 选择少量 worker-exit 语义明确的 topology，试点迁移到 `Spawn(join = true)`，并对比迁移前后的 hit rate、timeout rate 和失败样本。
- 选择少量 local-root 语义明确的 topology，试点使用 `ScopedRoot` 表达 root drop，再决定是否扩大迁移。

目标：

- 更集中打 root-set 更新、stack scan、barrier、worker root 合并。
- 保持 stress 属性，不急于给所有场景附加强 oracle。

### 4.2 第二优先级：脏对象图与 barrier 压力增强

已落地：

- field slot 与 array slot 混合 mutation。
- 大对象多字段批量改写。
- old root churn + allocation burst。
- graph mutation sequence 的多阶段变体。
- shared node 在多个 owner 间反复重连。
- cycle 创建后局部断边，再通过新 root 恢复可达。

继续增强：

- 抽象 graph mutation sequence builder，复用 build / clear / reconnect / reroot 阶段。
- 扩大 `StoreBatch` 在 dirty graph / barrier topology 中的使用，但 batch 内只放非 clear store。
- 只在真正连续多轮 GC 的 topology 中使用 `GcEpoch`；不要合并带 allocation、observe、publish/clear 或 checkpoint 的 GC 序列。
- 对高价值 stress topology 补可选 alive oracle capsule。
- 做命中率和失败样本盘点，调权重而不是盲目增加更多重复模板。

目标：

- 让 collector 更频繁遇到“图正在变脏”的状态。
- 提高 write barrier、marking、sweeping、weak processing 交错覆盖。

### 4.3 第三优先级：weak reference 边界增强

stress topology 已落地：

- weak + root handoff。
- weak + array slot。
- weak + thread-local root。
- weak global 与 strong global 交替 publish/clear。
- weak target 被晚到 strong root 短暂拉回。
- weak observation 建立后，在多个 GC epoch 中反复检查 observe 结果。

目标：

- 已先加强 weak stress。
- 后续再挑选最可证明的 weak 场景升级成 oracle capsule。

### 4.4 第四优先级：Kotlin 类型系统生成能力增强

当前 ScenarioDefinition 已支持 interface 定义和 class implementor，并已补入第二批 Kotlin 类型结构 MVP：sealed hierarchy、singleton object root、inner class outer capture。ScenarioType.InterfaceRef/ClassRef/SingletonRef、类型化强引用字段和 function return 已可表达第一批接口多态及部分 class-typed root 语义。除此之外，abstract base/subclass 字段布局、闭包捕获、泛型 holder、完整 companion/static 场景、sealed interface、suspend state machine 等仍未覆盖，类型系统压力仍偏薄。

第一批进展：

- 已完成 interface + 多实现类：生成接口定义、至少两个 concrete implementor、interface-typed local/global/field/function return，并通过 interface dispatch 返回 payload。
- 已完成实现闭环：feature/profile/capability/validator、Debug backend、Pure Kotlin translation、generator/translation/execution 测试和本地 Kotlin/Native smoke 均已接入。
- 当前边界：接口协议固定为无参 dispatchPayload(): Any?；尚未生成多方法接口、接口继承、default method、泛型接口或跨语言 backend。
- 待完成 abstract base + subclass layout：base class 和 subclass 都持有引用字段，用 base-typed root 指向 subclass object，覆盖继承字段扫描和 override 调用。
- function type / lambda / closure capture：生成闭包捕获 local/global/object，把 closure 存入 global、array slot、worker result 或 function return，再在 GC 后调用。
- generic holder / generic return escape：生成 `Box<T>` / generic function，把引用经 erased generic field、generic return、cast path 逃逸。

第二批进展：

- 已完成 sealed class MVP：生成 sealed base、两个 concrete subclass、class-typed global root，并通过 `SealedDispatch` 的 `when` 分支返回 subclass payload。
- 已完成 object singleton MVP：生成 `ScenarioDefinition.SingletonObject`、singleton value/location、singleton field store/access，把 object 字段纳入长期 root 覆盖。
- 已完成 inner class MVP：生成 nested inner class、显式 `CreateInnerObject` outer 输入，并通过 `OuterDispatch` 返回 hidden outer payload。
- 已接入实现闭环：feature/profile/capability/validator、Debug backend、Pure Kotlin translation、Structural Coverage、generator/translation/execution 测试和本地 Kotlin/Native smoke。
- 当前边界：sealed interface、sealed exhaustive oracle、companion object、worker 访问 singleton、inner 多层嵌套和 outer clear/restore oracle 尚未覆盖。

第二批剩余增强：

- sealed interface：用 `when` 分支制造不同 implementor 到 root 的重新挂接。
- companion object：把 companion/static object 字段纳入 old root churn、clear/restore、worker 访问。
- nested 多层结构：扩展到多层 inner/nested 组合和跨 worker hidden capture root。

第三批建议落地：

- suspend function / minimal continuation：优先使用 `startCoroutine` / 自定义 `Continuation` / 人工 suspension point，测试挂起帧里的引用 root；暂不优先引入完整 coroutine scheduler。
- value class / enum with reference fields：作为 box/unbox、singleton root 和 generated method 的补充覆盖，待前两批稳定后再评估。

实现要求：

- 先引入最小 `ScenarioType` / class-kind 模型，而不是只在 translation 中拼 Kotlin 语法。
- local/global/field/function return 应能记录声明类型，避免源码看似多态、IR 语义仍全部退化为 `Any?`。
- 新类型能力必须接入 capability/profile/validator，unsupported backend 应明确拒绝或 prepare，而不是在 translator 中静默跳过。
- 新 topology 应优先验证 typed root、runtime concrete object、dispatch return、closure capture 和 subclass field scan 这些 GC 相关假设。
- interface 多态当前以启用 feature 后的结构锚点进入每个 case，并计入 body budget；后续类型能力先用小流量 targeted topology 打通，再决定是否进入普通随机 statement mix。

目标：

- 覆盖 interface dispatch、virtual dispatch、继承字段布局、closure object、erased generic holder、singleton root 和 suspend frame root。
- 把“源码语法多样性”转化为真实的 root/heap/escape/layout 压力。

### 4.5 第五优先级：CFFI 生命周期模型加深

继续增强 `pure-kotlin + cffi`：

- foreign delayed handle。
- delayed callback。
- repeated callback 中穿插 GC。
- foreign strong / weak / handle 与本地 owner 清理交错。
- foreign identity 返回值再进入本地对象图。
- foreign callback 期间触发本地 allocation burst。
- foreign payload 指向 array slot 或 nested field。
- C side store/load/clear 状态。
- C side native allocation/free 包装 payload。

目标：

- 先把 `pure-kotlin + cffi` 做深。
- 不急于扩一批新语言 backend。
- CFFI 新语义必须先进入 `ScenarioProgram`，不能只在 translation 中随机插桥接代码。

### 4.6 第六优先级：reachability oracle 稳定回归

oracle 回归方向：

- 先恢复 `weak-dead-capsule` 这种最小封闭场景。
- 再恢复 `single-strong-slot`。
- 再恢复 `root-migration` alive-only 子集。
- 最后考虑 `reachability-consistency` 的 alive/dead 双 checkpoint。

回归要求：

- 每个 oracle 都必须是 capsule 或 hybrid。
- `Dead` 断言必须证明强引用清除完整。
- `Alive` 断言必须证明强引用稳定存在。
- translation 必须有 probe 或等价隔离机制。
- generator test 必须验证 oracle 使用的是合法 `StrongRef` slot。
- execution/daily 先小流量打开，观察 false positive。

目标：

- oracle 失败必须可信。
- 优先减少 false positive，而不是盲目扩大 oracle 覆盖。

### 4.7 第七优先级：新增非 reachability oracle

中期可以考虑新增更稳定的非 reachability oracle：

- field roundtrip consistency：store 后 observe 应读到同一 scalar 或引用形态。
- array slot consistency：指定 slot store/load 的一致性。
- weak monotonicity sanity：没有重新引入 strong root 时，weak value 不应从 dead 回到 alive。
- CFFI identity sanity：identity roundtrip 返回的 handle 应能被 callback 访问。
- callback count sanity：repeated callback 次数与预期一致。

注意：

- 这些 oracle 也必须先进入 IR 或 prepared semantic contract。
- 不应只靠 translation 里的局部 check 拼出来。

### 4.8 第八优先级：执行与调度控制增强

可以探索：

- 更明确的 worker join / synchronization op。
- controlled yield / checkpoint。
- GC-before / GC-after mutation hint。
- bounded thread count 下的更系统 interleaving。
- timeout 前的 soft termination 更细粒度观测。

目标：

- 从纯概率并发 stress，逐步补充部分可控 schedule stress。

## 5. 暂不建议优先投入的方向

当前不建议优先做：

- 一次性接入多个新语言 backend。
- 为多语言预埋过重抽象。
- 把 `kotlincffi` smoke 扩成正式顶层 mode。
- 在 Generator 中写目标语言分支。
- 在 reporting 层补功能缺口。
- 为了追求更多 oracle 覆盖，放松 oracle capsule 证明条件。
- 只增加 `data class`、`typealias`、annotation 等 GC 语义增益很小的语法变体。
- 在没有最小 continuation 模型前直接接入完整 coroutine scheduler。

原因：

- 当前最有价值的覆盖仍在 Kotlin Native GC 的 root/heap/weak/worker/CFFI 交错，以及类型系统导致的 root/escape/layout 变化。
- 新 backend 会扩大维护面，但不一定提升当前发现 GC 问题的效率。
- 不稳定 oracle 会消耗排查成本，降低 fuzz 信号质量。
- 只堆语法而不进入 IR 类型语义，会增加维护成本但不一定提高 bug 发现效率。

## 6. 能力路线总结

当前真实状态：

- `pure-kotlin` 主链路已经可用。
- 生成器已经具备对象图、root、weak、控制流、并发、allocation burst、CFFI roundtrip 等能力。
- 默认 profile 已经包含大量 stress topology。
- `pure-kotlin + cffi` 基础链路已经打通。
- Kotlin 类型系统第一批中的 interface 多态闭环已落地；继承、闭包、泛型及协程仍待实现。
- 强 reachability oracle 已有实现和测试，但默认随机生成未打开。

下一步最值得投入：

1. 并发 root lifecycle。
2. 脏对象图与 barrier 压力。
3. weak reference 边界。
4. Kotlin 类型系统生成能力。
5. `pure-kotlin + cffi` 生命周期模型。
6. reachability oracle 稳定回归。
7. 非 reachability oracle。
8. 更可控的调度和 GC checkpoint。

一句话概括：

当前 `gcfuzz` 已经是一个围绕 `ScenarioProgram` 的 Kotlin Native GC stress fuzzer；下一步重点不是堆更多语法，而是把 root 生命周期、脏图、weak、类型系统、CFFI 和可信 oracle 做深。
