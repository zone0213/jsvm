# GC Fuzz IR 是如何生成的

本文只解释一件事：`gc-fuzzing-tests` 如何从 seed、profile 和 feature set 生成 `ScenarioProgram` IR。

它不展开 IR 如何翻译成 Kotlin 源码，也不展开源码如何编译执行。后续流程见同目录下：

- `GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`

重点代码：

- `tests/.../fuzzer/generation/Generator.kt`
- `tests/.../fuzzer/core/Scenario.kt`
- `tests/.../fuzzer/core/ScenarioFeatureSet.kt`
- `tests/.../fuzzer/core/ScenarioCapability.kt`
- `tests/.../fuzzer/generation/ScenarioGenerationCapabilities.kt`
- `tests/.../fuzzer/kotlin/mode/PureKotlinScenarioGenerationProfile.kt`
- `tests/.../fuzzer/kotlin/mode/PureKotlinCInteropScenarioGenerationProfile.kt`

## 1. 生成入口

IR 生成入口是：

```kotlin
internal fun generateScenario(
    seed: UInt,
    features: ScenarioFeatureSet = ScenarioModeRegistry.resolveGenerationProfile(
        executionModel = System.getProperty("gcfuzzing.executionModel"),
        enableCInterop = System.getProperty("gcfuzzing.cffi")?.toBoolean() == true,
    ).features,
    capabilities: ScenarioGenerationCapabilities = ScenarioGenerationCapabilities.pureKotlin(features),
): ScenarioProgram = generateScenarioWithMetadata(seed, features, capabilities).program
```

它做三件事：

1. 根据 execution model 和 `gcfuzzing.cffi` 选择 generation profile。
2. 从 profile 取出 `ScenarioFeatureSet`。
3. 根据 feature set 和 backend 能力得到 `ScenarioGenerationCapabilities`。
4. 用 seed 初始化 `Generator`，生成 `ScenarioProgram`。

因此 IR 生成由两个输入共同决定：

- seed：决定所有随机选择，保证同一个 seed 可复现。
- feature set：决定本轮 fuzz 想探索哪些 IR 能力、topology、oracle 或 CFFI 结构。
- capability profile：决定当前 backend/language 实际支持哪些 op、field、global storage、lifecycle 和 topology。

## 2. 生成结果：ScenarioProgram

生成器最终产物是：

```kotlin
internal class ScenarioProgram(
    val definitions: List<ScenarioDefinition>,
    val mainBody: ScenarioBody,
)
```

可以把它看成一个目标语言无关的 GC 测试剧本：

- `definitions` 定义可用的 class、function、global root。
- `mainBody` 定义主流程中的对象创建、引用写入、GC、并发、观察和 oracle 检查。

典型 definition：

```kotlin
ScenarioDefinition.Class(...)
ScenarioDefinition.Function(...)
ScenarioDefinition.Global(...)
```

典型 operation：

```kotlin
ScenarioOp.CreateObject(...)
ScenarioOp.Store(...)
ScenarioOp.Clear(...)
ScenarioOp.CompareAndSet(...)
ScenarioOp.StoreBatch(...)
ScenarioOp.Observe(...)
ScenarioOp.PerformGc(...)
ScenarioOp.GcEpoch(...)
ScenarioOp.Spawn(...)
ScenarioOp.SpawnWithResult(...)
ScenarioOp.ScopedRoot(...)
ScenarioOp.TryFinally(...)
ScenarioOp.ForeignRoundTrip(...)
ScenarioOp.AllocationBurst(...)
```

IR 本身不包含 Kotlin 语法、C 语法、`StableRef`、`Worker` API 或编译参数。这是重要边界：生成层只产出共享语义，不直接拼接目标语言代码。

## 3. Generator 的内部状态

`Generator` 内部最重要的状态是：

```kotlin
private val random = kotlin.random.Random(seed)
private var nextObservationId: Int = 0
```

- `random` 控制所有分布选择、id 选择、topology 选择和 body 结构。
- `nextObservationId` 用于给 reachability observation 分配稳定 id。

还有一个 body 级状态：

```kotlin
private inner class BodyGenerationState(initialLocals: Int)
```

它记录当前 body 中可用的 local 信息：

- `readableLocals`：可以作为读取来源的 local。
- `mutableLocals`：可以作为 store 目标的 local。
- `fieldfulMutableLocals`：已知有字段、适合生成 field store 的 local。
- `objectLocals`：local id 到 class id 的映射，方便 topology 精确选择字段能力。

`BodyGenerationState.fork()` 会复制当前 local 环境给 nested body 或 worker body。nested body 内新增 local 不会反向污染外层 body，但可以读取/使用外层已有 local，从而自然表达 lambda capture、worker capture 等 root 形态。

## 4. 随机分布模型

`Generator.Distributions` 是 IR 形状的集中概率模型。

它决定：

- 生成多少 definition。
- class 里有多少 field。
- function 有多少 parameter。
- body 有多少 statement。
- 普通 statement 类型权重。
- path 长度。
- local/global 访问权重。
- field kind 权重。
- global storage 权重。
- CFFI reference kind 和 interaction pattern。
- targeted topology 类型权重。

例如普通 statement 分布：

```kotlin
val statement = Distribution.weighted(
    StatementKind.ALLOC to 4,
    StatementKind.ALLOCATION_BURST to 1,
    StatementKind.LOAD to 2,
    StatementKind.STORE to 4,
    StatementKind.CALL to 2,
    StatementKind.FOREIGN_ROUNDTRIP to 3,
    StatementKind.SPAWN_THREAD to 2,
    StatementKind.BLOCK to 1,
    StatementKind.IF to 1,
    StatementKind.TRY_FINALLY to 1,
    StatementKind.PERFORM_GC to 2,
    StatementKind.GC_EPOCH to 1,
)
```

这意味着普通随机流会自然混入：

- 对象分配。
- 引用读写。
- 函数调用。
- worker spawn。
- block / if / try-finally。
- 显式 GC。
- allocation burst。

`PERFORM_GC` 权重相对较高（约占 statement 总权重的 7%），因为 GC bug 集中发生在 GC 触发时刻；适度提升 GC 触发密度比扩大 body 体积更能提升 bug 命中率。`ALLOCATION_BURST` 和 `GC_EPOCH` 仍保持较低权重，避免 ALLOCATION_BURST 每次 8-64 个对象分配放大单 case 运行时间，从而抵消 body 缩短带来的 case 数密度收益。整体 GC 类操作（`PERFORM_GC` + `ALLOCATION_BURST` + `GC_EPOCH`）约占 statement 总权重的 14%，相比原始分布（约 11%）有温和提升。后续是否继续提升 GC 类操作权重，应由 cases/minute、valid mutation/minute、unique failure/minute 等 A/B 数据决定，不能只靠"GC 操作越多 bug 越容易触发"的假设。

但是否真正允许某类 statement，还要看 feature。例如没有 `CFFI_CALLBACK_ROUNDTRIP` 时，随机选到 `FOREIGN_ROUNDTRIP` 会退化成普通 observe/load。

## 5. Definition 如何生成

`genProgram()` 的结构很短：

```kotlin
fun genProgram(): ScenarioProgram = ScenarioProgram(
    definitions = genDefinitions(),
    mainBody = genBody(),
)
```

definition 生成分三类：

```kotlin
private fun genDefinitions(): List<ScenarioDefinition> {
    return generatedGlobals + generatedClasses + generatedFunctions
}
```

当前 id 顺序是：

1. globals
2. classes
3. functions

这个顺序很重要，因为后续 IR 中的 `globalId`、`classId`、`functionId` 都按生成器内部的 definition 集合索引来引用。

### 5.1 definition 数量

definition 数量先由随机分布生成，再保证每类至少有一个：

```kotlin
val counts = DefinitionKind.entries.associateWith { 1 } + randomCounts
```

随后根据 topology 需要提高 global 数量下限：

```kotlin
DefinitionKind.GLOBAL to counts.getValue(DefinitionKind.GLOBAL).coerceAtLeast(minimumGlobalDefinitions())
```

这样可以避免某些 topology 因缺少必要 global root 永远无法生成。

### 5.2 class 生成和材料修复

普通 class 由随机 target language 和随机 fields 组成：

```kotlin
ScenarioDefinition.Class(
    genLanguage(),
    genFields()
)
```

但 targeted topology 通常需要确定的材料。例如：

- strong field。
- object array field。
- finalizer class。
- non-finalizer marker class。

所以 `genClasses()` 会在随机 class 基础上做保守修复：

- 如果 array topology 启用但没有 array field，改写第一个 class，补 `ObjectArray` 和 `StrongRef`。
- 如果任意 topology 启用但没有 strong ref field，给第一个 class 补 `StrongRef`。
- 如果 finalizer topology 启用，保证存在带 finalizer lifecycle 的 class。
- 如果 finalizer topology 需要 marker class，保证至少有一个 non-finalizer class。

这类修复不改变 IR 层次边界；它仍然只生成 `ScenarioDefinition.Class`，没有把 Kotlin finalizer/cleaner API 写进 generator。

### 5.3 global 生成和 mandatory roots

普通 global 由随机语言、引用 field 和 storage 组成：

```kotlin
ScenarioDefinition.Global(
    genLanguage(),
    chooseRefKind(),
    storage,
)
```

当 `ADVANCED_GLOBAL_STORAGE` 启用时，strong/weak global 可以随机成为：

- `ScenarioGlobalStorage.Shared`
- `ScenarioGlobalStorage.ThreadLocal`

但一些 topology 需要确定的 root 类型，所以 `genGlobals()` 会先 prepend mandatory globals：

- strong shared global：稳定表达 shared root publish/handoff/liveness。
- weak global：表达 weak lifecycle。
- thread-local strong global：表达 thread-local/shared handoff。

之后再生成剩余随机 globals。

### 5.4 function 生成和 escaping return

普通 function 包含：

- 随机 target language。
- 随机参数数量。
- 随机 body。
- 默认 return value。

当 `ESCAPING_RETURN_FUNCTION` 启用时，生成器会额外把 function id `0` 固定为 escaping-return helper：

```kotlin
fun make(): Any? {
    val l0 = Payload()
    return l0
}
```

IR 中对应：

```kotlin
ScenarioBodyWithReturn(
    ScenarioBody(listOf(ScenarioOp.CreateObject(0, classId))),
    ScenarioValue.LocalRef(0),
)
```

这样 `TOPOLOGY_FUNCTION_RETURN_ESCAPE` 可以稳定复用 function id `0`，制造 callee stack 到 caller local/global 的逃逸路径。

## 6. Body 如何生成

body 入口：

```kotlin
fun genBody(initialLocals: Int = 0): ScenarioBody
```

`initialLocals` 用于 function body：参数会作为初始 readable local 进入 `BodyGenerationState`。

主 statement loop 是：

```kotlin
while (statements.size < targetSize) {
    val remaining = targetSize - statements.size
    if (allowTerminalStatements && remaining <= 2 && random.nextDouble() < 0.18) {
        statements += genTerminalOp(state)
        break
    }
    if (allowStructuredStatements && remaining >= 4 && random.nextDouble() < 0.28) {
        val topologyStatements = genTopologyScenario(state, remaining)
        if (topologyStatements != null) {
            statements += topologyStatements
            continue
        }
    }
    statements += genScenarioStatement(state, allowStructuredStatements)
}
```

它的行为是：

1. 如果接近 body 尾部，可能生成 `Return` 或 `Throw`，然后结束当前 body。
2. 如果允许 structured statement，并且剩余空间足够，每个位置有一定概率尝试插入 targeted topology。
3. 如果 topology 没选中或当前状态/剩余空间不满足，就生成一个普通随机 statement。

注意：`0.28` 是每个 statement loop 位置尝试 topology 的概率，不是“28% 的程序包含 topology”，也不是“topology 占全部语句 28%”。一个 topology 可能展开成多条 IR statement，一个程序也可能包含 0 个、1 个或多个 topology。

## 7. 普通 statement 如何生成

普通 statement 从 `StatementKind` 分布中选择：

```kotlin
private fun genScenarioStatement(...): ScenarioOp = when (distributions.statement.next(random)) {
    StatementKind.ALLOC -> genAlloc(state)
    StatementKind.ALLOCATION_BURST -> genAllocationBurst()
    StatementKind.LOAD -> genLoad(state)
    StatementKind.STORE -> genStore(state)
    StatementKind.CLEAR -> genClear(state)
    StatementKind.STORE_BATCH -> genStoreBatch(state)
    StatementKind.CALL -> genCall(state)
    StatementKind.FOREIGN_ROUNDTRIP -> ...
    StatementKind.SPAWN_THREAD -> genSpawnThread(state)
    StatementKind.SPAWN_JOIN -> genSpawnJoin(state)
    StatementKind.BLOCK -> ...
    StatementKind.SCOPED_ROOT -> genScopedRoot(state)
    StatementKind.IF -> ...
    StatementKind.TRY_FINALLY -> ...
    StatementKind.PERFORM_GC -> ScenarioOp.PerformGc()
    StatementKind.GC_EPOCH -> genGcEpoch()
}
```

几个关键点：

- `genAlloc()` 会创建对象，并把 local 记录进 `BodyGenerationState`。
- `genLoad()` 实际生成 `ScenarioOp.Observe(...)`，同时推进 local id 空间。
- `genStore()` / `genClear()` 生成 local 或 global 写目标。GLOBAL 路径固定为空（global 是 single-slot）；LOCAL 路径在已知 object local 时优先选择真实 field id，仍保留少量随机无效 id/path 作为压力输入。
- `genClear()` 生成显式 root/slot clear，语义上等价于写入 `null`，但 IR 层能区分普通 store 和生命周期清理。
- `genStoreBatch()` 生成一组连续 store，用于把 field/array/global mutation 作为一个 barrier 压力窗口表达。
- `genGcEpoch()` 生成多轮 GC，可选择在轮次之间 yield，用于 weak/finalizer/root handoff 等跨 epoch 压力。
- `genCall()` 会生成 function call，并预留一个 unknown local，配合 backend 的 call result 约定。
- `genScopedRoot()` 生成一个只在 nested body 内可见的 local root，nested body 结束后 root 生命周期自然结束。
- `genBlock()`、`genIf()`、`genTryFinally()` 使用 fork 出来的 nested state，nested body 不允许继续嵌套 structured statement，也不允许 terminal statement。
- `genSpawnThread()` 当前生成 `SpawnFunction`，即调用随机 function；targeted topology 里也会直接生成 `ScenarioOp.Spawn`，表达 inline worker body。
- `genSpawnJoin()` 生成 `ScenarioOp.Spawn(join = true)`，translation 使用 bounded join helper，避免把 worker 退出生命周期建模成无限等待。

普通随机流故意允许部分无效 path 或不存在字段。translator/backend 会把它们翻译成安全的空值访问、默认值或 no-op 风格代码。这类无效访问用于压力覆盖，但不能作为强 oracle 真值来源。

## 8. Value、Location 和 Path

IR 里读和写分开建模。

读值：

```kotlin
ScenarioValue.LocalRef(localId, path)
ScenarioValue.GlobalRef(globalId, path)
ScenarioValue.NullValue
ScenarioValue.DefaultValue
```

写目标：

```kotlin
ScenarioLocation.Local(localId, path)
ScenarioLocation.Global(globalId, path)
```

`ScenarioPath` 是一串 accessor id：

```kotlin
internal class ScenarioPath(val accessors: List<ScenarioEntityId>)
```

例如：

- 空 path：直接访问 local/global 本身。
- `[0]`：访问第 0 个字段。
- `[arrayFieldId, 0]`：访问某个 object-array 字段的第 0 个 slot。
- 随机长 path：制造深链访问、无效字段和空链路压力。

普通随机流现在的路径生成策略：

- GLOBAL value/location：path 为空（global 是 single-slot）。
- LOCAL value/location：在已知 object local 时优先用真实 field id 作为单段 path；当 body 早期还没有可读 local，或所选 local 不是已建模对象时，回退到 `genPath()`。

targeted topology 通常使用更稳定的 helper：

```kotlin
genFieldPath()       // [0]
fieldPath(fieldId)   // [fieldId]
```

这样 topology 能稳定表达它想覆盖的 GC 结构，而普通随机流也优先做有意义的引用动作，仅在 fallback 路径上保留少量无效 path 作为压力输入。

## 9. Targeted topology 如何混入

targeted topology 是生成器里手写的结构化 IR 模板，用于稳定制造 GC 风险窗口。

选择流程：

```kotlin
private fun genTopologyScenario(state, remaining): List<ScenarioOp>? =
    topologyAttemptOrder()
        .take(MAX_TOPOLOGY_ATTEMPTS)
        .firstNotNullOfOrNull { topologyKind -> genTopologyScenario(topologyKind, state, remaining) }
```

`topologyAttemptOrder()` 的策略是：

1. 先从 weighted family distribution 中选一个 primary family。
2. 再从该 family 的 weighted topology distribution 中选一个 primary topology。
3. 如果 primary topology 当前 feature 启用，就优先尝试。
4. 再把其他 enabled stress topology 打乱作为 fallback。
5. 默认不从 `ORACLE` family 里选 primary 或 fallback；只有当前 profile 只启用了 ORACLE topology 时才退化到 ORACLE。
6. 最多尝试 `MAX_TOPOLOGY_ATTEMPTS = 5` 个。

当前默认 stress family 权重：

| Family | Weight |
|---|---:|
| `ROOT_LIFECYCLE` | 30 |
| `DIRTY_GRAPH_BARRIER` | 20 |
| `WEAK_REFERENCE` | 15 |
| `BASIC_GRAPH` | 15 |
| `FINALIZATION` | 10 |
| `CFFI` | 10 |

`ORACLE` family 仍保留 family/report 分类，但默认 stress 选择不打开。

每个 topology 还有自己的前置条件：

- `remaining` 是否足够放下模板。
- 是否存在 strong shared global。
- 是否存在 weak global。
- 是否存在 strong field class。
- 是否存在 array field class。
- 是否存在 thread-local strong global。
- 是否存在 finalizer class。

如果当前 topology 不满足条件，就返回 `null`，生成器尝试下一个 fallback。所有 fallback 都失败时，回到普通随机 statement。

当前 topology 模板优先使用显式 GC 语义 op：

- 清理 root、field slot、array slot 时使用 `ScenarioOp.Clear(...)`，不再把这类生命周期事件隐藏成普通 `Store(..., NullValue)`。
- 多条连续普通 store mutation 可以用 `ScenarioOp.StoreBatch(...)` 表达 barrier 压力窗口；batch 内不混入 `Clear`，避免丢失 clear 语义。
- `ScenarioOp.GcEpoch(...)` 只用于确实要表达连续多轮 GC epoch 的场景；如果两次 GC 之间还有 allocation、observe、publish/clear 或 checkpoint，不应为了“看起来统一”强行合并。

## 10. Feature gate 和 capability filter

每个 topology 都映射到一个 feature：

```kotlin
private fun ScenarioTopologyKind.requiredFeature(): ScenarioFeature = when (this) {
    ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR -> ScenarioFeature.TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR
    ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR -> ScenarioFeature.TOPOLOGY_TRY_FINALLY_ROOT_CLEAR
    ...
}
```

profile 通过 feature set 决定本轮想启用哪些 fuzz 能力。feature gate 不是 backend 支持矩阵；它表达的是“想探索什么”。

backend/language 支持边界由 capability profile 表达：

- `ScenarioCapabilityProfile` 描述共享 IR 原子能力，例如 `ScenarioOpKind`、`ScenarioFieldKind`、`ScenarioGlobalStorageKind`、`ScenarioClassLifecycleKind`、reference kind、target language 和 domain。
- `ScenarioGenerationCapabilities` 在 core capability 之外补充 `supportedTopologies`。
- `ScenarioTopologyKind.requiredCapabilities()` 描述每个 topology 依赖的 op、field、global storage 和 lifecycle。
- generator 最终使用 `feature gate + capability filter` 的交集生成 IR：普通 statement 会过滤 unsupported op，topology 会同时检查 `requiredFeature()`、`supportedTopologies` 和 `requiredCapabilities()`。
- backend lower 前还会通过 `ScenarioCapabilityValidator` 校验 prepared program，防止手写 IR、repro 或未来 shrinker 绕过 generator。

这层拆分后，`ScenarioFeature` 继续控制 fuzz 策略，capability profile 控制目标 backend 能否承接该策略。

当前只声明 Pure Kotlin 和 Pure Kotlin + CFFI 能力；`ObjC`、`Java`、`Native` 仍是 IR 预留概念，尚未建立正式 profile 子集。

pure-kotlin profile 启用：

- rich fields。
- structured control flow。
- terminal statements。
- advanced global storage。
- escaping return function。
- 大部分 `TOPOLOGY_*` stress 模板。
- finalizer topology。

pure-kotlin + CFFI profile 在此基础上额外启用：

- `CFFI_CALLBACK_ROUNDTRIP`
- `TOPOLOGY_CFFI_CALLBACK_AFTER_GC`
- `TOPOLOGY_CFFI_IDENTITY_HANDOFF`

oracle capsule 相关 feature 通常不在默认 profile 中启用，因为它们对 reachability 真值要求更强，维护成本和误报风险更高。

## 11. 当前重点 topology 类型

当前 generator 支持的 topology 按 `ScenarioTopologyFamily` 分组。family 同时用于报告治理和两级 topology 选择权重。

`ORACLE`：

- `SINGLE_STRONG_SLOT_CAPSULE`
- `REACHABILITY_CONSISTENCY`
- `REACHABILITY_CONSISTENCY_CAPSULE`
- `WEAK_DEAD_CAPSULE`
- `ROOT_MIGRATION_CAPSULE`

`BASIC_GRAPH`：

- `CYCLE`
- `SHARED_NODE`
- `GLOBAL_REATTACH`
- `OLD_ROOT_CHURN`
- `ROOT_MIGRATION`
- `DELETE_EDGE_THEN_GC`
- `ARRAY_SLOT_GRAPH`
- `GRAPH_MUTATION_SEQUENCE`

`DIRTY_GRAPH_BARRIER`：

- `MIXED_FIELD_ARRAY_MUTATION_BARRIER`
- `LARGE_OBJECT_MULTI_FIELD_REWRITE`
- `OLD_ROOT_CHURN_WITH_ALLOCATION_BURST`
- `GRAPH_MUTATION_MULTI_PHASE_SEQUENCE`
- `SHARED_NODE_RECONNECT_BETWEEN_OWNERS`
- `CYCLE_BREAK_AND_REROOT`

`WEAK_REFERENCE`：

- `WEAK_REF_LIFECYCLE`
- `WEAK_ROOT_HANDOFF`
- `WEAK_ARRAY_SLOT`
- `WEAK_THREAD_LOCAL_ROOT`
- `WEAK_STRONG_GLOBAL_ALTERNATING`
- `WEAK_LATE_STRONG_RESCUE`
- `WEAK_MULTI_EPOCH_OBSERVE`

`ROOT_LIFECYCLE`：

- `CONCURRENT_ROOT_MIGRATION`
- `CONCURRENT_PUBLISH_CLEAR_GC`
- `WORKER_ALLOC_PUBLISH`
- `MULTI_STAGE_ROOT_HANDOFF`
- `PING_PONG_ROOT_TRANSFER`
- `CONCURRENT_DUPLICATE_HANDOFF`
- `LOCAL_GLOBAL_ARRAY_HANDOFF`
- `STALE_OWNER_MUTATION_AFTER_HANDOFF`
- `THREAD_LOCAL_SHARED_HANDOFF`
- `WORKER_CAPTURE_ROOT`
- `MULTI_ROOT_STAGGERED_CLEAR`
- `CONCURRENT_ARRAY_SLOT_HANDOFF`
- `ROOT_REPUBLISH_AFTER_CLEAR`
- `TRY_FINALLY_ROOT_CLEAR`
- `RETURN_ESCAPE_WORKER_PUBLISH`
- `THREAD_LOCAL_CLEAR_ON_WORKER_EXIT`
- `ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE`
- `WORKER_PUBLISH_MAIN_CLEAR_BARRIER`
- `ARRAY_SLOT_CLEAR_RESTORE_BARRIER`
- `WORKER_RESULT_ESCAPE`
- `WORKER_RESULT_THEN_CLEAR_GC`
- `NESTED_WORKER_ROOT_HANDOFF`
- `CAS_ROOT_CONTENTION`

`FINALIZATION`：

- `FINALIZER_GLOBAL_PUBLISH`

`CFFI`：

- `CFFI_CALLBACK_AFTER_GC`
- `CFFI_IDENTITY_HANDOFF`

这些 topology 初期大多是 stress template，而不是 dead oracle。也就是说，它们的目标是制造高价值 GC 交错和引用生命周期，不直接断言对象必须死。

## 12. 材料修复为什么重要

如果完全依赖随机生成，某些 topology 很容易因为缺少材料而长期无法命中。例如：

- 没有 strong shared global，无法做稳定 root handoff。
- 没有 array field，无法做 array slot handoff。
- 没有 thread-local strong global，无法做 thread-local/shared handoff。
- 没有 finalizer class，无法做 finalizer stress。

所以 generator 会根据 enabled topology feature 做 capability repair。

这不是强行让某个 topology 每个程序都出现，而是保证“如果随机选择到了这个 topology，它有合理概率成功落地”。实际是否出现仍由：

- body size。
- topology 尝试概率。
- topology family weight。
- family 内 topology weight。
- `remaining`。
- fallback 顺序。
- seed。

共同决定。

## 13. 新增 IR 生成能力的推荐路径

新增一个普通 stress topology 时，推荐顺序是：

1. 在 `ScenarioFeature` 增加 feature gate。
2. 在 profile 中决定哪些 execution mode 启用该 feature，并同步 `ScenarioCapabilityProfile` / `ScenarioGenerationCapabilities`。
3. 在 `ScenarioTopologyKind` 增加 topology 类型。
4. 在 `ScenarioTopologyKind.requiredFeature()` 建立映射。
5. 在 `ScenarioTopologyKind.family` 建立 family 映射。
6. 在 `ScenarioTopologyKind.requiredCapabilities()` 声明该 topology 依赖的 op、field、global storage 和 lifecycle。
7. 在 `Distributions.topologyFamily` 或 `Distributions.topologyKindByFamily` 中检查是否需要调整权重。
8. 如有必要，在 `needs*()` 和 definition repair 中保证材料。
9. 在 `genTopologyScenario(...)` dispatch 中接入生成函数。
10. 实现 `genXxxTopology(...)`，输出 `List<ScenarioOp>`。
11. 如果 topology 需要可控并发窗口，可以使用 `ScenarioOp.Signal(checkpointId)`、`ScenarioOp.Wait(checkpointId)` 和 `ScenarioOp.Yield`，但 `Wait` 必须由 translation/runtime helper 提供 bounded wait，避免 hang。
12. 确认 generator telemetry 会记录该 topology 的 attempts/hits，并在 `topology.json` 中暴露 enabled family。
13. 在 `build.gradle.kts` 的 `topologyRules` 和 `topologyFamilies` 中补充该 topology 的规则和 family，保证 `topology-summary.html/json/csv`、`topology-family-summary.csv` 和 `topology-case-hits.csv` 能展示 family、规则和命中情况。
14. 在 `GeneratorTopologyTest` 增加可生成性测试，并覆盖缺少 required capability 时该 topology 不会启用。
15. 如果新增了 IR 节点，再补 capability validator、preparation/backend/translation 测试。

如果现有 `ScenarioOp` 足够表达新结构，应优先复用现有 IR。只有在确实无法表达新语义时，才新增 `ScenarioOp`。

## 14. 新增 topology 时的边界

必须保持这些边界：

- Generator 只生成 `ScenarioProgram`。
- Generator 不能拼 Kotlin 源码。
- Generator 不能引用 `StableRef`、`createCleaner`、`Worker`、C header 等 backend 细节。
- profile/preparation/backend/translation 负责目标 mode 支持边界。
- 新 topology 初期应优先作为 stress template。
- 涉及 dead/alive oracle 时，必须确保引用路径和可达性真值是强语义，不要用随机无效 path 作为 oracle 依据。

## 15. 一个具体例子：root republish after clear

`TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR` 的 IR 生成目标是制造 shared root 短窗口：

```text
create first payload
publish to shared global
GC
worker:
  clear shared global
  allocation burst
  create replacement
  republish replacement to shared global
  GC
main:
  allocation burst
  GC
  observe shared global
  clear shared global
```

它在 IR 中只使用：

- `CreateObject`
- `Store`
- `Spawn`
- `AllocationBurst`
- `PerformGc`
- `Observe`

因此它不需要新增 `ScenarioOp`，也不需要 translation 特判。

## 16. 一个具体例子：try/finally root clear

`TOPOLOGY_TRY_FINALLY_ROOT_CLEAR` 的 IR 生成目标是制造 finally 清理路径：

```text
create owner
create payload
owner.field = payload
global = owner
try:
  observe global.field
  allocation burst
  GC
finally:
  owner.field = null
  global = null
  GC
allocation burst
GC
observe owner.field
```

它复用现有 `ScenarioOp.TryFinally`，初期不放 `Throw` 到 try body 里。原因是当前 generator 已有规则：terminal control flow 不进入 nested body，避免 worker/block/try-finally 中出现不可控退出路径。

如果未来要测试异常逃逸路径，可以单独新增 `TOPOLOGY_EXCEPTION_ESCAPE_ROOT_HANDOFF`，并同时审视 terminal statement、translation 和 oracle 边界。

## 17. 第一批类型系统：接口多态

`INTERFACE_POLYMORPHISM` 引入了最小、共享的类型语义，而不是在 Kotlin translator 中临时拼接接口代码：

- `ScenarioDefinition.Interface` 表示一个带 `dispatchPayload()` 协议的接口。
- `ScenarioDefinition.Class.interfaces` 和 `dispatchFieldId` 表示实现关系及 dispatch 返回的 payload 槽。
- `ScenarioType.InterfaceRef` 与 `ScenarioField.TypedStrongRef` 表示 interface-typed local/global/field/function return。
- `ScenarioOp.InterfaceDispatch` 表示经接口引用取得 payload，结果保存到新的 local。

启用该 feature 后，生成器保证至少一个接口、两个 concrete implementor、一个 interface-typed global，以及 local/global/field 三条 dispatch 路径；这些锚点计入 body budget，不放大单 case 的大小。

该能力写入 `topology.json` 的 `structuralHits.INTERFACE_POLYMORPHISM`，并在 summary 报告的 `Structural Coverage` 区域展示；它不计入 `topologyHits`，避免污染 targeted topology 的 attempts/hits 语义。

## 18. 第二批类型系统：sealed / object / inner

第二批类型系统能力继续使用共享 IR 表达，不在 Kotlin translator 中私自拼语法：

- `ScenarioClassKind.Sealed`、`ScenarioDefinition.Class.superClassId` 和 `sealedPayloadFieldId` 表示 sealed base 与 concrete subclass 的 override payload。
- `ScenarioType.ClassRef` 表示 class-typed local/global/field/function return。
- `ScenarioDefinition.SingletonObject`、`ScenarioValue.SingletonRef` 和 `ScenarioLocation.Singleton` 表示 object singleton 及其字段 root。
- `ScenarioDefinition.Class.nestedInClassId`、`outerCaptureFieldId` 和 `ScenarioOp.CreateInnerObject` 表示 inner class 及显式 outer 输入。
- `ScenarioOp.SealedDispatch`、`ScenarioOp.SingletonAccess`、`ScenarioOp.OuterDispatch` 分别表示 sealed dispatch、singleton field 读取和 inner object 经 hidden outer capture 返回 payload。

启用第二批 feature 后，generator 会以小流量 structural anchor 注入这些结构；当只显式传入第二批 feature 做 targeted 验证时，结构会稳定生成，便于测试和复现。

这些能力分别写入 `structuralHits.SEALED_HIERARCHY`、`structuralHits.SINGLETON_OBJECT_ROOT` 和 `structuralHits.INNER_CLASS_OUTER_CAPTURE`；它们不计入 `topologyHits`。

## 19. 总结

IR 生成不是简单随机拼语句，而是三层组合：

1. profile/feature 决定允许生成什么。
2. distribution 决定普通随机流和 topology 的概率形状。
3. targeted topology + material repair 保证高价值 GC 结构能稳定进入 fuzz 输入空间。

这样的设计让 gc-fuzz 同时保留两类价值：

- 随机噪声：覆盖大量不可预期组合。
- 目标结构：稳定制造 GC root、write barrier、weak processing、finalizer、worker 和 CFFI 的高风险窗口。
