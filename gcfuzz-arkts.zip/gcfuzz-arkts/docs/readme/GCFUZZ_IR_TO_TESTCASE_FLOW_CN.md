# GC Fuzz：从 IR 到源码、落盘和执行

本文说明 `gc-fuzzing-tests` 中 `ScenarioProgram` IR 在生成之后，如何经过 backend、preparation、translator，最终变成可编译运行的 Kotlin/Native fuzz case。

IR 如何从 seed/profile/features 生成，见同目录：

- `GCFUZZ_IR_GENERATION_CN.md`

本文重点回答：

- `ScenarioProgram` 进入 backend 后发生什么。
- `PureKotlinScenarioBackend` 和 `ScenarioPreparation` 的职责是什么。
- translator 如何把 IR 映射成 `main.kt`。
- CFFI case 为什么会额外生成 `cinterop.def`、`bridge.h`、`bridge.c`。
- 生成文件如何落盘、编译和执行。

重点代码：

- `tests/.../fuzzer/kotlin/mode/PureKotlinScenarioModeDescriptor.kt`
- `tests/.../fuzzer/kotlin/backend/PureKotlinScenarioBackend.kt`
- `tests/.../fuzzer/core/ScenarioPreparation.kt`
- `tests/.../translation/PureKotlinTranslation.kt`
- `tests/.../translation/PureKotlinCInterop.kt`
- `tests/.../execution/kotlin/PureKotlinScenarioRunner.kt`

## 1. 总体链路

一次 pure-kotlin fuzz case 的主链路在 `PureKotlinScenarioModeDescriptor.execute()`：

```kotlin
val generated = generateScenarioWithMetadata(id.seed(), generationProfile.features)
val output = PureKotlinScenarioBackend.lower(generated.program, config)
output.save(generatedSourceDir)
generated.telemetry.save(generatedSourceDir.parentFile.resolve("topology.json"), name)
host.runPureKotlinScenario(name, output, host.executionTimeout)
```

从 IR 生成之后开始，流程是：

1. `ScenarioProgram` 进入 `PureKotlinScenarioBackend.lower(...)`。
2. backend 用 `PureKotlinScenarioProfile` 调用 `ScenarioPreparation.prepare(...)`。
3. preparation 把目标语言/domain 归一化到当前 backend 支持的语义边界。
4. backend 调用 `producePureKotlin(...)`。
5. translator 生成 `PureKotlinOutput`。
6. `PureKotlinOutput.save(...)` 把文件写入 case 的 `generated/` 目录。
7. `ScenarioTelemetry.save(...)` 把 topology attempted/hit 信息写入 case 目录的 `topology.json`。
8. runner 调用 `konanc` 编译。
9. runner 执行 `app.kexe` 并收集日志。

如果 IR 中包含 `ScenarioOp.ForeignRoundTrip`，流程会多两步：

- 编译前先生成并运行 `cinterop`。
- 使用 `clang` 编译 C bridge，再把 bridge klib/object 链接进最终程序。

## 2. 输入和输出

translator 的输入是：

```kotlin
internal class ScenarioProgram(
    val definitions: List<ScenarioDefinition>,
    val mainBody: ScenarioBody,
)
```

translator 的输出是：

```kotlin
class PureKotlinOutput(
    val files: Map<String, String>,
    val entryFileName: String,
    val args: List<String>,
    val cInterop: PureKotlinCInteropSupport? = null,
)
```

`PureKotlinOutput` 只描述要写哪些文件和编译参数，不直接执行编译。

普通 pure-kotlin case 的文件通常是：

```text
generated/
  main.kt
```

CFFI case 的文件通常是：

```text
generated/
  main.kt
  cinterop.def
  bridge.h
  bridge.c
```

最终 case 目录大致是：

```text
I123456789/
  generated/
    main.kt
    cinterop.def      # 仅 CFFI case
    bridge.h          # 仅 CFFI case
    bridge.c          # 仅 CFFI case
  topology.json       # topology attempted/hit telemetry and structural coverage hits
  interop/bridge...   # 仅 CFFI case
  bridge.o            # 仅 CFFI case
  app.kexe
  konanc.log
  run.log
  cinterop.log        # 仅 CFFI case
  clang.log           # 仅 CFFI case
```

run 结束后，Gradle reporting 会基于所有 case 的 `topology.json` 生成：

```text
topology-summary.html      # 人看的 structural coverage、topology 规则、覆盖图和 case 命中明细
topology-summary.json      # 机器可读 summary，包含 structural coverage、每个 family、topology 和 case
structural-summary.csv     # 每个 structural kind 的 total hits / case hit rate
topology-family-summary.csv # 每个 topology family 的 attempts / hits / case hit rate
topology-summary.csv       # 每个 topology 的 family / attempts / hits / case hit rate
topology-case-hits.csv     # 每个 case 命中了哪些 family 和 topology
```

## 3. Backend 和 Preparation

`PureKotlinScenarioBackend.lower(...)` 的职责不是直接拼 Kotlin 源码，而是建立 IR 和 translator 之间的边界：

```text
ScenarioProgram
  -> ScenarioPreparation.prepare(...)
  -> ScenarioCapabilityValidator.validate(...)
  -> producePureKotlin(...)
  -> PureKotlinOutput
```

`ScenarioPreparation` 做的是保守归一化：

- 把 definition 的 target language 归一到当前 backend profile。
- 把 op/value/location 的 domain 归一到当前 backend profile。
- 保留共享 IR 的语义结构。
- 不静默删除会改变语义或 oracle 真值的节点。

`ScenarioCapabilityValidator` 在 lower 前检查 prepared program 是否被当前 profile 支持：

- op 必须在 `ScenarioCapabilityProfile.supportedOps` 中。
- field、global storage、class lifecycle 必须在当前 profile 支持集合中。
- store/foreign reference kind 必须被当前 profile 接受。
- target language 和 domain 必须已经归一到当前 backend profile。

这个边界很重要：

- Generator 不知道 Kotlin 源码如何输出。
- Translator 不反向决定 IR 如何生成。
- Backend/Profile 声明当前执行 mode 支持哪些共享语义。

## 4. Translator 入口

入口在 `PureKotlinTranslation.kt`：

```kotlin
internal fun ScenarioProgram.producePureKotlin(config: PureKotlinConfig): PureKotlinOutput {
    val hasCInterop = containsCInterop()
    val context = PureKotlinScenarioTranslationContext(config, this, hasCInterop)
    context.translate()
    val entryFileName = "${config.moduleName}.kt"
    val files = linkedMapOf(entryFileName to context.contents.toString())
    val cInterop = if (hasCInterop) {
        val generated = generatePureKotlinCInteropFiles()
        files.putAll(generated.files)
        generated.support
    } else {
        null
    }
    return PureKotlinOutput(...)
}
```

这段逻辑可以理解为：

```text
ScenarioProgram
  -> 无 ForeignRoundTrip：生成 main.kt
  -> 有 ForeignRoundTrip：生成 main.kt + C interop 文件
```

CFFI 是否启用不是只看 profile，而是扫描 IR 中有没有 `ScenarioOp.ForeignRoundTrip`。

## 5. CFFI 检测

`containsCInterop()` 会递归扫描：

- main body
- function body
- block
- if
- try-finally
- spawn body

只要任意位置出现：

```kotlin
ScenarioOp.ForeignRoundTrip(...)
```

这个 case 就会变成 CFFI case，并额外生成 C bridge 相关文件。

## 6. Program 级翻译顺序

`PureKotlinScenarioTranslationContext.translate()` 的顺序是：

```text
renderPrelude(...)
translate definitions
translateObservationDeclarations()
translateThreadLocalCleanup()
translateMainFunction()
```

对应生成内容：

1. prelude：imports、GC helper、worker helper、reachability helper、CFFI helper。
2. global/class/function definition。
3. reachability observation storage。
4. thread-local cleanup helper。
5. `main()`。

definition 翻译顺序保持 IR 中的 id 顺序，保证 `g0`、`Class0`、`f0` 这类名字和 IR id 对齐。

## 7. Global 如何翻译

IR：

```kotlin
ScenarioDefinition.Global(
    targetLanguage = ...,
    field = ScenarioField.StrongRef,
    storage = ScenarioGlobalStorage.Shared,
)
```

会翻译成类似：

```kotlin
private var g0: Any? = null
```

如果是 thread-local storage：

```kotlin
@ThreadLocal
private var g0: Any? = null
```

如果是 weak field，translator 会使用 weak-reference backing，读写时保持 weak 语义。

## 8. Field 如何翻译

field 翻译核心是把 IR 的字段模型映射到 Kotlin class 属性。

常见映射：

```text
ScenarioField.StrongRef       -> Any?
ScenarioField.WeakRef         -> WeakReference<Any>?
ScenarioField.IntValue        -> Int
ScenarioField.BooleanValue    -> Boolean
ScenarioField.ObjectArray(n)  -> Array<Any?>
```

`StrongRef` 是普通强引用路径。

`WeakRef` 需要通过 helper 封装读写，避免把 weak slot 误翻译成强引用字段。

`ObjectArray` 用来覆盖 array slot root、array slot clear、late handoff 等 GC 风险面。

## 9. Class 如何翻译

IR class：

```kotlin
ScenarioDefinition.Class(
    targetLanguage = ...,
    fields = listOf(...),
    lifecycle = ...
)
```

会翻译成 Kotlin class：

```kotlin
private class Class0(
    var f0: Any?,
    var f1: Any?,
)
```

如果 class 带 finalizer lifecycle，translator 会生成 Kotlin/Native cleaner：

```kotlin
private val lifecycleCleaner = createCleaner(Unit) {
    ...
}
```

这里的关键边界是：IR 只表达 `ScenarioClassLifecycle.Finalizer(body)`，不表达 `createCleaner` 这个 Kotlin/Native API。具体如何落成 cleaner，是 `PureKotlinTranslation.kt` 的职责。

## 10. Function 和 Main 如何翻译

IR function：

```kotlin
ScenarioDefinition.Function(
    parameters = ...,
    body = ScenarioBodyWithReturn(...),
)
```

会翻译成：

```kotlin
private fun f0(p0: Any?, p1: Any?): Any? {
    ...
    return ...
}
```

IR main body 会进入：

```kotlin
fun main() {
    try {
        ...
    } finally {
        clearThreadLocalRoots()
    }
}
```

`finally` 中的 cleanup 用于清理 thread-local roots，避免不同 fuzz case 或 worker 生命周期之间出现不必要的保活。

## 11. Body 如何翻译

`ScenarioBody` 是一组 `ScenarioOp`：

```kotlin
internal class ScenarioBody(
    val statements: List<ScenarioOp>,
)
```

translator 会顺序翻译每条 op。

structured op 递归翻译子 body：

- `Block`
- `ScopedRoot`
- `If`
- `TryFinally`
- `Spawn`

这意味着 generator 里产生的 nested body、scoped root body、worker body、finally body 都会走同一套 value/location/statement 翻译规则。

## 12. 普通 Statement 映射

### CreateObject

IR：

```kotlin
ScenarioOp.CreateObject(localId, classId, args)
```

源码形态：

```kotlin
var l0: Any? = alloc { Class3(arg0, arg1) }
```

`alloc` helper 用于包裹对象创建，方便统一制造 allocation 行为。

### AllocationBurst

IR：

```kotlin
ScenarioOp.AllocationBurst(classId, count)
```

源码形态：

```kotlin
repeat(count) {
    alloc { Class3(...) }
}
```

它用于扰动 heap shape，提高 GC 触发窗口价值。

### Observe

IR：

```kotlin
ScenarioOp.Observe(value)
```

源码形态：

```kotlin
var l10: Any? = ...
```

observe 的目标是强制读取某个路径，避免生成代码完全被优化掉，也让 path traversal 真正发生。

### Store

IR：

```kotlin
ScenarioOp.Store(location, value, referenceKind)
```

源码形态可能是：

```kotlin
l0?.storeField(0, value)
g0 = value
g0?.storeField(0, value)
```

如果是 weak store，translator 会调用 weak 写入 helper，保持 weak semantics。

### Clear

IR：

```kotlin
ScenarioOp.Clear(location)
```

源码形态：

```kotlin
g0 = null
l0?.storeField(0, null)
```

`Clear` 语义上等价于向 location 写入 `null`，但 IR 层把 root/slot 生命周期清理显式化，方便 topology、报告和后续 oracle 识别死亡窗口。

### StoreBatch

IR：

```kotlin
ScenarioOp.StoreBatch(listOf(store0, store1, ...))
```

源码形态：

```kotlin
l0?.storeField(0, a)
l0?.storeField(1, b)
g0 = c
```

translation 当前直接按顺序展开为多条 store。它的价值在 IR 层：把一组连续 field/array/global mutation 视为同一个 barrier 压力窗口。

topology 中只应把连续的非 clear store 放进 `StoreBatch`。清理 root 或 slot 应继续使用 `Clear`，这样 IR walker、debug backend 和后续报告可以明确识别死亡窗口。

### PerformGc

IR：

```kotlin
ScenarioOp.PerformGc()
```

源码形态：

```kotlin
performGC()
```

### GcEpoch

IR：

```kotlin
ScenarioOp.GcEpoch(count, yieldBetween)
```

源码形态：

```kotlin
repeat(count) {
    performGC()
    yieldCheckpoint()
}
```

`yieldBetween = false` 时只重复 `performGC()`。这个 op 用于表达跨多个 GC epoch 的 weak observe、finalizer 触发机会和 root handoff 稳定性压力。

### Signal / Wait / Yield

IR：

```kotlin
ScenarioOp.Signal(checkpointId)
ScenarioOp.Wait(checkpointId)
ScenarioOp.Yield
```

源码形态：

```kotlin
signalCheckpoint(checkpointId)
waitCheckpoint(checkpointId)
yieldCheckpoint()
```

这些 op 用于 targeted topology 中制造轻量、可统计的并发窗口，例如 worker publish 后主线程再 GC，或 array slot clear 后 worker 先 GC、主线程再 restore。

translation 会在 prelude 中生成 checkpoint runtime：

- `checkpoints: AtomicArray<Int>`
- `signalCheckpoint(id)`
- `waitCheckpoint(id)`
- `yieldCheckpoint()`

`waitCheckpoint` 必须是 bounded wait，并检查 `shouldTerminate()`，避免 worker 没有运行、case 早停或 checkpoint 顺序异常时造成无限 hang。

### CallFunction

IR：

```kotlin
ScenarioOp.CallFunction(functionId, args)
```

源码形态：

```kotlin
var l12: Any? = f3(arg0, arg1)
```

### SpawnFunction / Spawn

`SpawnFunction` 表达调用某个已有 function 的 worker：

```kotlin
spawnThread {
    f3(arg0, arg1)
}
```

`Spawn` 表达 inline worker body：

```kotlin
spawnThread {
    ...
}
```

如果 `ScenarioOp.Spawn(join = true)`，translation 会使用：

```kotlin
spawnThreadAndJoin {
    ...
}
```

`spawnThreadAndJoin` 是 bounded join helper：主线程只短暂等待 worker 完成并持续处理队列；超出 bounded window 会返回，避免 fuzz case hang。targeted topology 通常使用 `Spawn`，因为它需要精确控制 worker body 中的 publish、clear、GC 和 observe 顺序。

### ScopedRoot

IR：

```kotlin
ScenarioOp.ScopedRoot(localId, value, body)
```

源码形态：

```kotlin
run {
    var l10: Any? = value
    ...
}
```

`ScopedRoot` 用于显式表达 local root 生命周期。`body` 结束后，`l10` 离开 Kotlin 作用域，后续 GC 可以观察这个 root drop 之后的对象图状态。

### Block / If / TryFinally

IR：

```kotlin
ScenarioOp.Block(body)
ScenarioOp.If(condition, thenBody, elseBody)
ScenarioOp.TryFinally(body, finallyBody)
```

源码形态：

```kotlin
run {
    ...
}

if (condition != null) {
    ...
} else {
    ...
}

try {
    ...
} finally {
    ...
}
```

### Return / Throw

IR：

```kotlin
ScenarioOp.Return(value)
ScenarioOp.Throw(value)
```

源码形态：

```kotlin
return value
throw FuzzControlException(value)
```

当前 generator 会避免 terminal statement 进入 nested body，降低 worker/block/finally 中不可控退出路径带来的误报风险。

## 13. Value、Location 和 Path 如何翻译

读值：

```kotlin
ScenarioValue.LocalRef(localId, path)
ScenarioValue.GlobalRef(globalId, path)
ScenarioValue.NullValue
ScenarioValue.DefaultValue
```

写目标：

```kotlin
ScenarioLocation.Local(localId, path)
ScenarioLocation.Global(globalId, path)
```

空 path 访问 local/global 本身：

```text
l0
g0
```

非空 path 会被翻译成安全路径访问：

```text
l0?.loadField(0)?.loadField(1)
g0?.loadField(0)
```

写 path 会翻译成：

```text
l0?.storeField(0, value)
g0?.storeField(0, value)
```

普通随机 path 可以是不存在的字段或很深的链路。translator 必须让这些访问安全落地，不能因为随机无效路径直接导致生成源码不可编译。

## 14. 为什么有些 IR 不逐条直译

translator 不是机械地把每个 IR 节点转成一行源码。原因是 Kotlin 源码需要额外运行时支撑：

- safe field load/store helper。
- weak field/global helper。
- object array slot helper。
- worker spawn helper。
- GC helper。
- reachability observation helper。
- CFFI bridge helper。
- thread-local cleanup helper。

例如 `ScenarioField.WeakRef` 不是简单的 `var f0: Any?`，而是需要 weak backing 和读写封装。

又比如 `ScenarioOp.ForeignRoundTrip` 在 Kotlin 里是一个 helper call，但它同时要求生成 C bridge 文件和 cinterop 配置。

## 15. CFFI IR 如何翻译

IR：

```kotlin
ScenarioOp.ForeignRoundTrip(
    value = ...,
    referenceKind = ScenarioForeignReferenceKind.Strong,
    pattern = ScenarioForeignInteractionPattern.Callback,
    repetitions = 1,
)
```

Kotlin 侧会翻译成 bridge helper 调用。不同 `referenceKind` 表示不同抽象语义：

- `Handle`：外部以 handle 方式持有或传回。
- `Strong`：外部交互期间应保持强可达。
- `Weak`：外部交互只应表达弱观察。

不同 `pattern` 表示不同交互形态：

- callback
- repeated callback
- identity
- wrapped callback
- nested callback
- boxed callback / identity

这些都是共享 IR 语义。Generator 不知道 C header 怎么写；C bridge 文件由 `PureKotlinCInterop.kt` 生成。

## 16. CFFI Bridge 文件如何生成

当 `containsCInterop()` 为 true 时，`producePureKotlin(...)` 调用：

```kotlin
generatePureKotlinCInteropFiles()
```

它会生成：

```text
cinterop.def
bridge.h
bridge.c
```

runner 之后会：

1. 调用 `cinterop` 生成 bridge klib。
2. 调用 `clang` 编译 `bridge.c`。
3. 调用 `konanc` 编译 `main.kt`，并链接 bridge klib/object。

这保证 CFFI 仍然是 pure-kotlin 主执行 mode 的可选能力，而不是另一条独立 generator/backend 主链路。

## 17. Reachability Oracle 如何落地

oracle 相关 IR：

```kotlin
ScenarioOp.CreateReachabilityObservation(...)
ScenarioOp.CheckReachabilityObservation(...)
ScenarioOp.CheckReachability(...)
```

translator 会生成 weak observation storage 和检查 helper。

典型语义：

- 创建 weak observation。
- 显式 GC。
- 检查 observation 是 alive 或 dead。

oracle capsule 的要求比普通 stress topology 更高：它必须使用强语义可证明的引用路径，不能把随机无效 path 当成 alive/dead 真值来源。

## 18. 输出如何落盘

`PureKotlinOutput.save(root)` 负责落盘：

```kotlin
fun PureKotlinOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}
```

它只写 translator 产出的文件，不负责编译。

因此职责边界是：

```text
translator -> PureKotlinOutput(files)
save       -> generated/ 文件
runner     -> cinterop/clang/konanc/run
```

## 19. 编译和执行

`PureKotlinScenarioRunner.kt` 负责执行。

普通 case：

```text
generated/main.kt
  -> konanc
  -> app.kexe
  -> run
```

CFFI case：

```text
generated/cinterop.def + bridge.h
  -> cinterop
generated/bridge.c
  -> clang
generated/main.kt + bridge klib/object
  -> konanc
  -> app.kexe
  -> run
```

日志文件通常包括：

- `konanc.log`
- `run.log`
- `cinterop.log`，仅 CFFI case
- `clang.log`，仅 CFFI case

## 20. 一个完整小例子

IR：

```kotlin
ScenarioProgram(
    definitions = listOf(
        ScenarioDefinition.Global(Kotlin, StrongRef, Shared),
        ScenarioDefinition.Class(Kotlin, listOf(StrongRef)),
    ),
    mainBody = ScenarioBody(
        listOf(
            ScenarioOp.CreateObject(0, 0),
            ScenarioOp.Store(Global(0), LocalRef(0)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(GlobalRef(0)),
            ScenarioOp.Store(Global(0), NullValue),
        )
    )
)
```

可能生成的 Kotlin 关键片段：

```kotlin
private var g0: Any? = null

private class Class0(
    var f0: Any?,
)

fun main() {
    var l0: Any? = alloc { Class0(null) }
    g0 = l0
    performGC()
    var l1: Any? = g0
    g0 = null
}
```

这里 IR 只描述：

- 创建对象。
- 发布到 global root。
- GC。
- 观察 global。
- 清 global。

具体的 Kotlin class、global 变量、helper、safe load/store 都由 translator 决定。

## 21. 接口多态的翻译边界

接口多态仍遵循单向链路：

```text
ScenarioDefinition.Interface / ScenarioType.InterfaceRef
  -> PureKotlin translator
  -> interface InterfaceN { fun dispatchPayload(): Any? }
  -> ClassN : KotlinIndexAccess, InterfaceN
  -> (receiver as? InterfaceN)?.dispatchPayload()
```

类型化 global 和 field 以 Kotlin `InterfaceN?` 声明；通用 IR store 在写入这些槽位时由 translator 作安全转换。Generator 只生成 `InterfaceDispatch` 语义，不能直接生成 Kotlin 方法调用。

## 22. 第二批类型系统的翻译边界

sealed / object / inner 能力也遵循单向链路：

```text
ScenarioClassKind.Sealed / ScenarioType.ClassRef
  -> sealed class ClassN + concrete subclasses
  -> when (receiver as? ClassN) { is Subclass -> sealedPayload() }

ScenarioDefinition.SingletonObject / SingletonRef / Singleton location
  -> object ObjectN : KotlinIndexAccess
  -> ObjectN.loadKotlinField(...) / ObjectN.storeKotlinField(...)

ScenarioDefinition.Class.nestedInClassId / CreateInnerObject / OuterDispatch
  -> inner class ClassN inside outer ClassM
  -> (outer as? ClassM)?.ClassN(...)
  -> (inner as? ClassM.ClassN)?.outerPayload()
```

普通 `CreateObject` 只面向可直接构造的 concrete top-level class；inner class 必须通过 `CreateInnerObject` 显式携带 outer，sealed base 不应被普通 alloc 实例化。

## 23. 设计边界

理解这条链路时，最重要的是保持分层：

- `ScenarioProgram` 是共享语义中心。
- `Generator` 只生成 IR。
- `Profile/Preparation` 处理目标 backend 的支持边界。
- `Backend` 选择 translation 和 output 形态。
- `Translator` 生成源码文本。
- `Runner` 负责编译和执行。

禁止的方向：

- Generator 拼 Kotlin 或 C 源码。
- Translator 反向决定对象图如何生成。
- Runner 修改 IR 语义。
- Reporting 影响生成或翻译。

这个边界让后续新增 topology、CFFI 变体、finalizer、oracle 或未来新 backend 时，不需要复制整条 fuzz 主链路。
