# GC Fuzz 新增语言 Backend 开发指南

本文是 `GCFUZZ_DEVELOPMENT_SPEC_CN.md` 的配套开发指南，说明如何在 gc-fuzz 中新增一门语言支持，开启真正的多语言 fuzz。

规约优先级：

1. `GCFUZZ_DEVELOPMENT_SPEC_CN.md` 是主 spec，定义必须遵守的分层边界、禁止事项、oracle/CFFI/验证规则。
2. 本文只提供新增语言 backend 的推荐落地步骤和示例。
3. 如果本文与主 spec 冲突，以主 spec 为准。

核心原则：**不要在 `Generator.kt` 里生成目标语言代码，也不要为新语言复制一套 generator。** 新语言应该复用现有 `ScenarioProgram` IR，通过新的 profile/backend/translator/runner 接入。

## 1. 当前架构边界

当前链路是：

```text
Generator.kt
  -> 生成通用 ScenarioProgram IR

ScenarioPreparation
  -> 按目标 profile 规约 targetLanguage/domain/reference kind

<Language>Backend
  -> 把 ScenarioProgram lower 成某语言输出

<Language>Translation
  -> 把 IR 翻译成源码文件

<Language>Runner
  -> 编译、链接、运行、收集日志

ScenarioModeRegistry
  -> 注册 executionModel
```

现在正式执行 mode 只有 `pure-kotlin`。IR 中虽然已经预留了：

```kotlin
ScenarioTargetLanguage.Kotlin
ScenarioTargetLanguage.ObjC
ScenarioTargetLanguage.Java

ScenarioDomain.Kotlin
ScenarioDomain.ObjC
ScenarioDomain.Java
ScenarioDomain.Native
```

但有 enum 不代表有真实执行能力。新增语言必须补齐 mode/backend/translator/runner。

## 2. 推荐开发顺序

新增一门语言应按这个顺序做：

1. 定义第一阶段能力边界。
2. 新增 `ScenarioPreparationProfile`。
3. 新增 `ScenarioGenerationProfile`。
4. 新增 `<Lang>ScenarioBackend`。
5. 新增 `<Lang>Translation`。
6. 新增 `<Lang>Output` 和 `save(...)`。
7. 新增 `<Lang>ScenarioRunner`。
8. 新增 `<Lang>ScenarioModeDescriptor`。
9. 注册到 `ScenarioModeRegistry`。
10. 增加 backend/translation/execution 测试。
11. 再逐步打开 topology、并发、oracle、CFFI。

## 3. 第一阶段能力边界

第一版不要追求支持所有 IR。建议只支持最小 stress 子集：

- `ScenarioDefinition.Class`
- `ScenarioDefinition.Global`
- `ScenarioOp.CreateObject`
- `ScenarioOp.Store`
- `ScenarioOp.Observe`
- `ScenarioOp.PerformGc`
- `ScenarioOp.AllocationBurst`

第一版建议关闭：

- `Spawn`
- `If`
- `TryFinally`
- `Return`
- `Throw`
- `ForeignRoundTrip`
- reachability oracle
- 复杂 topology
- 跨语言双向 handoff

目标是先做到：

```bash
-Dgcfuzzing.executionModel=<new-lang>
```

可以生成、编译、运行最小 fuzz case。

## 4. 新增 Preparation Profile

参考当前 pure-kotlin：

```kotlin
internal object PureKotlinScenarioProfile : ScenarioPreparationProfile {
    override val targetLanguage: ScenarioTargetLanguage = ScenarioTargetLanguage.Kotlin
    override val domain: ScenarioDomain = ScenarioDomain.Kotlin
    override val capabilities: ScenarioCapabilityProfile =
        ScenarioCapabilityProfile.pureKotlin(enableCInterop = false)

    override fun prepareStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind =
        PureKotlinScenarioCffi.validateStoreReferenceKind(referenceKind)

    override fun prepareForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind =
        PureKotlinScenarioCffi.validateForeignReferenceKind(referenceKind)
}
```

新增 ObjC 示例：

```kotlin
internal object ObjCScenarioProfile : ScenarioPreparationProfile {
    override val targetLanguage: ScenarioTargetLanguage = ScenarioTargetLanguage.ObjC
    override val domain: ScenarioDomain = ScenarioDomain.ObjC
    override val capabilities: ScenarioCapabilityProfile = ObjCScenarioCapabilities.core

    override fun prepareStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind =
        ScenarioStoreReferenceKind.Strong

    override fun prepareForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind =
        ScenarioForeignReferenceKind.Handle
}
```

第一阶段要保守。如果目标语言还不支持 weak，就不要把 weak 原样放过去，可以规约成 strong，或者先不打开生成 weak 的 feature。

同时必须显式声明 `ScenarioCapabilityProfile`。它是目标 backend 支持矩阵，不是 fuzz 策略开关。新增语言时不要只在 translator 里处理失败；profile/backend lower 前必须能说明哪些 op、field、global storage、class lifecycle、reference kind、target/domain 被支持。

## 5. 新增 Generation Profile

`ScenarioGenerationProfile` 决定这个 mode 能生成哪些 IR 能力。

第一版建议极简：

```kotlin
internal object ObjCScenarioGenerationProfile : ScenarioGenerationProfile {
    override val features: ScenarioFeatureSet = ScenarioFeatureSet.NONE
    override val capabilities: ScenarioGenerationCapabilities =
        ScenarioGenerationCapabilities(
            core = ObjCScenarioCapabilities.core,
            supportedTopologies = emptySet(),
        )
}
```

如果目标语言 translator 已能处理 richer fields，可以加：

```kotlin
ScenarioFeature.RICH_FIELDS
```

第一版不建议打开：

```kotlin
ScenarioFeature.CFFI_CALLBACK_ROUNDTRIP
ScenarioFeature.STRUCTURED_CONTROL_FLOW
ScenarioFeature.TERMINAL_STATEMENTS
ScenarioFeature.ORACLE_*
ScenarioFeature.TOPOLOGY_*
```

如果打开某个 feature，还必须同步 `ScenarioGenerationCapabilities`。普通 op 是否可进入随机 statement 池由 core capability 决定；targeted topology 是否可生成由 `supportedTopologies` 和 `ScenarioTopologyKind.requiredCapabilities()` 共同决定。feature 开启但 capability 未声明支持时，generator 应过滤掉该能力。

每打开一个 feature，都必须确认：

- generator 可能生成哪些 IR。
- preparation 是否能规约这些 IR。
- translator 是否能翻译。
- runner 是否能编译运行。
- test 是否覆盖。

## 6. 新增 Backend

当前 backend 接口很小：

```kotlin
internal interface ScenarioBackend<T> {
    fun lower(program: ScenarioProgram): T
}
```

新语言 backend 应该负责：

1. 调用 `ScenarioPreparation.prepare(...)`。
2. 使用新语言 profile 规约 IR。
3. 调用新语言 translator。
4. 返回 `<Lang>Output`。

示例：

```kotlin
internal object ObjCScenarioBackend {
    fun lower(program: ScenarioProgram, config: ScenarioBackendConfig): ObjCOutput {
        val prepared = ScenarioPreparation.prepare(program, ObjCScenarioProfile)
        return prepared.program.produceObjC(
            ObjCConfig(
                moduleName = "main",
                maximumStackDepth = config.maximumStackDepth,
                mainLoopRepeatCount = config.mainLoopRepeatCount,
                softTimeout = config.softTimeout,
            )
        )
    }
}
```

backend 不应该：

- 自己随机生成 IR。
- 自己写源码字符串细节。
- 自己调用编译器。

## 7. 新增 Output 和 save

参考 `PureKotlinOutput`，新语言需要类似结构：

```kotlin
class ObjCOutput(
    val files: Map<String, String>,
    val entryFileName: String,
    val args: List<String>,
) {
    val filename: String
        get() = entryFileName

    val contents: String
        get() = files.getValue(entryFileName)
}
```

落盘函数：

```kotlin
fun ObjCOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}
```

translator 只返回 `ObjCOutput`，不直接写文件。

## 8. 新增 Translator

新增文件示例：

```text
tests/.../translation/ObjCTranslation.kt
```

提供入口：

```kotlin
internal fun ScenarioProgram.produceObjC(config: ObjCConfig): ObjCOutput
```

第一阶段 translator 可只支持最小 op：

```kotlin
when (op) {
    is ScenarioOp.CreateObject -> translateCreateObject(op)
    is ScenarioOp.Store -> translateStore(op)
    is ScenarioOp.Observe -> translateObserve(op)
    is ScenarioOp.PerformGc -> translatePerformGc()
    is ScenarioOp.AllocationBurst -> translateAllocationBurst(op)
    else -> translateNoop()
}
```

translator 必须保证输出源码可编译。

对不支持的 IR，第一阶段可以：

- 降级成 no-op。
- 降级成 `null`。
- 在 generation profile 中暂时关闭对应 feature。

不要在 translation 阶段随机插入 IR 不知道的行为。translation 应该是 IR 的确定性映射。

## 9. 新增 Runner

新增文件示例：

```text
tests/.../execution/objc/ObjCScenarioRunner.kt
```

runner 负责：

1. 找到 case build dir。
2. 找到 generated source dir。
3. 调编译器。
4. 生成 executable / dylib / framework。
5. 运行产物。
6. 写 compile/run log。
7. 处理 timeout。
8. 必要时处理 crash/minidump。

示例形态：

```kotlin
internal fun StandaloneExecutionHost.runObjCScenario(
    testName: String,
    output: ObjCOutput,
    executionTimeout: Duration,
) {
    val baseDir = sessionBuildDir.resolve(testName)
    val generatedSourceDir = baseDir.resolve("generated")
    val executable = baseDir.resolve("app")

    runTool(
        executable = "...compiler...",
        args = listOf(
            generatedSourceDir.resolve(output.entryFileName).absolutePath,
            "-o",
            executable.absolutePath,
        ),
        logFile = baseDir.resolve("compile.log"),
        timeout = 5.minutes,
        toolName = "compile",
    )

    runTool(
        executable = executable.absolutePath,
        args = emptyList(),
        logFile = baseDir.resolve("run.log"),
        timeout = executionTimeout,
        toolName = "run",
    )
}
```

runner 不应该修改源码语义。

## 10. 新增 ModeDescriptor

mode descriptor 是新语言执行链路的入口。

示例：

```kotlin
internal object ObjCScenarioModeDescriptor : ScenarioModeDescriptor {
    override val aliases: Set<String> = setOf("objc", "objective-c")
    override val generationProfile = ObjCScenarioGenerationProfile

    override fun execute(
        host: StandaloneExecutionHost,
        id: ProgramId,
        config: ScenarioBackendConfig,
    ) {
        val name = id.toString()
        val generatedSourceDir = host.resolveObjCScenarioGeneratedSourceDir(name)
        val generated = generateScenarioWithMetadata(id.seed(), generationProfile.features)
        val output = ObjCScenarioBackend.lower(generated.program, config)
        output.save(generatedSourceDir)
        generated.telemetry.save(generatedSourceDir.parentFile.resolve("topology.json"), name)
        host.runObjCScenario(name, output, host.executionTimeout)
    }
}
```

这一层串起来：

```text
seed
 -> generateScenario
 -> ObjCScenarioBackend.lower
 -> output.save
 -> runObjCScenario
```

## 11. 注册到 ScenarioModeRegistry

当前 registry 只有 pure-kotlin：

```kotlin
private val descriptors: List<ScenarioModeDescriptor> = listOf(
    PureKotlinScenarioModeDescriptor,
)
```

新增后：

```kotlin
private val descriptors: List<ScenarioModeDescriptor> = listOf(
    PureKotlinScenarioModeDescriptor,
    ObjCScenarioModeDescriptor,
)
```

之后即可使用：

```bash
-Dgcfuzzing.executionModel=objc
```

## 12. 测试要求

至少增加三类测试。

### 12.1 Backend smoke

确认最小 IR 能 lower 成源码：

```kotlin
@Test
fun objcBackendLowersMinimalProgram() {
    val program = ScenarioProgram(...)
    val output = ObjCScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
    assertTrue("main.m" in output.files)
}
```

### 12.2 Translation test

手写 IR，断言源码关键片段：

```kotlin
@Test
fun objcTranslationStoresGlobalRoot() {
    val output = ScenarioProgram(...).produceObjC(...)
    assertContains(output.contents, "...")
}
```

### 12.3 Execution smoke

手写最小 program：

```text
CreateObject
Store global
PerformGc
Observe
```

跑真实编译执行。

不要一开始直接跑随机 fuzz。否则失败时很难判断是：

- generator 生成了不支持的 IR。
- translator 输出错。
- runner 编译参数错。
- 工具链环境错。
- 语言 runtime 生命周期模型不匹配。

## 13. 禁止事项

新增语言时不要做：

1. 不要在 `Generator.kt` 里生成目标语言源码。
2. 不要复制一份 generator 给新语言。
3. 不要一开始打开所有 topology。
4. 不要一开始打开 reachability oracle。
5. 不要让 translation 阶段随机插入 IR 无感知行为。
6. 不要把 smoke 路径当正式 mode。
7. 不要让 runner 隐式修复源码语义。
8. 不要把目标语言编译细节塞进通用 IR。

## 14. 推荐路线图

### 阶段 1：最小语言 mode

支持：

- class
- global
- create object
- store
- observe
- perform GC
- allocation burst

关闭：

- CFFI
- worker
- oracle
- topology
- structured control flow

目标：

```bash
-Dgcfuzzing.executionModel=<new-lang>
```

能生成、编译、运行 1 分钟。

### 阶段 2：对象图能力

逐步打开：

- `RICH_FIELDS`
- field path load/store
- array slot，如果目标语言能稳定表达
- stronger global root model

目标：覆盖对象图和 root handoff。

### 阶段 3：targeted topology

逐个打开：

- cycle
- shared node
- global reattach
- graph mutation sequence
- array slot graph

每打开一个 topology，都需要补：

- generator/topology test
- translation test
- execution smoke

### 阶段 4：并发

再考虑：

- worker/thread
- concurrent publish/clear
- duplicate handoff

### 阶段 5：oracle

最后才考虑：

- weak-dead capsule
- reachability consistency
- root migration capsule

oracle 对语言生命周期、translator 生成方式、runtime root 模型要求最高，必须最后做。

## 15. 语言选择建议

如果目标是增强 Kotlin/Native GC fuzz，优先级建议：

1. ObjC
   - 与 Kotlin/Native Apple interop、ARC、NSObject 生命周期交错最相关。

2. C
   - 适合作为 native side stress，可以和现有 CFFI bridge 能力合并扩展。

3. Swift
   - Apple 生态价值高，但工具链和 interop 表达更复杂。

4. Java
   - 对 Kotlin/Native GC 的直接价值较低，除非目标是某个平台桥接或跨 runtime 行为。

建议第一门真正多语言 backend 优先选 ObjC 或 C。

## 16. 最小落地 checklist

新增语言第一版完成标准：

- [ ] 新增 `<Lang>ScenarioProfile`。
- [ ] 新增 `<Lang>ScenarioGenerationProfile`。
- [ ] 新增 `<Lang>ScenarioCapabilityProfile` / generation capability 支持矩阵。
- [ ] 新增 `<Lang>ScenarioBackend`。
- [ ] 新增 `<Lang>Translation`。
- [ ] 新增 `<Lang>Output.save(...)`。
- [ ] 新增 `<Lang>ScenarioRunner`。
- [ ] 新增 `<Lang>ScenarioModeDescriptor`。
- [ ] 注册到 `ScenarioModeRegistry`。
- [ ] backend smoke test 通过。
- [ ] capability 负向测试通过：unsupported op/topology 不生成，手写 unsupported IR 在 backend lower 前 fail-fast。
- [ ] translation test 通过。
- [ ] execution smoke test 通过。
- [ ] `-Dgcfuzzing.executionModel=<new-lang>` 可端到端运行。
