# GC Fuzz 工具开发规范

本文档定义 `gc-fuzzing-tests` 后续开发必须遵守的工程规则。它不是架构介绍，而是用于约束代码演进、评审设计和避免分层退化的 spec。

本文档中的关键词含义：

- **必须**：违反即视为架构或实现错误。
- **禁止**：不得在正式实现中采用；临时实验也必须有明确隔离和清理计划。
- **应该**：默认遵守，例外需要在代码评审中解释。
- **可以**：允许采用，但仍需满足所在层的边界。

适用范围：

- 维护当前 `pure-kotlin` 主链路。
- 扩展测试用例生成能力，尤其是 GC topology 和 reachability oracle。
- 在主体执行 mode 下扩展 CFFI 能力。
- 新增第二种或第三种执行 mode。
- 评审生成器、IR、backend、translation、execution、reporting 是否发生错误耦合。

## 1. 当前实现基线

当前正式主链路是：

```text
GCFuzzingTest
  -> SimpleFuzzer
  -> StandaloneExecutionHost.execute(id)
  -> ScenarioModeRegistry
  -> PureKotlinScenarioModeDescriptor
  -> generateScenario(seed, features)
  -> ScenarioProgram
  -> PureKotlinScenarioBackend.lower(...)
  -> ScenarioPreparation.prepare(...)
  -> producePureKotlin(...)
  -> generated/main.kt
  -> konanc
  -> app.kexe
  -> run
```

当前代码事实：

- `ScenarioProgram` 是唯一共享语义中心。
- 当前注册到 `ScenarioModeRegistry` 的正式执行 mode 只有 `pure-kotlin`。
- `Scenario.kt` 里有 `Kotlin / ObjC / Java / Native` 等 target/domain 概念，但当前正式执行路径会通过 profile/preparation 统一到 Kotlin 域。
- `ScenarioCapabilityProfile` 和 `ScenarioGenerationCapabilities` 用于表达当前 backend/language 支持的 IR 原子能力和 topology 集合；当前只声明 Pure Kotlin 与 Pure Kotlin + CFFI 能力。
- `gcfuzzing.cffi=true` 是 `pure-kotlin` 的可选能力，会启用 `PureKotlinCInteropScenarioGenerationProfile`，并允许生成 `ForeignRoundTrip`。
- `translation/PureKotlinCInterop.kt` 已经提供当前 `pure-kotlin + C interop` 的 bridge 文件生成能力。
- `fuzzer/kotlincffi` 和 `translation/KotlinCInteropTranslation.kt` 是固定样例 smoke 通道，不是正式注册的主执行 mode，也不消费 `ScenarioProgram`。

## 2. 总体原则

### 2.1 语义中心原则

共享语义必须进入 `ScenarioProgram`。

`ScenarioProgram` 可以表达：

- 对象图。
- local/global root。
- shared / thread-local global。
- strong / weak reference。
- primitive-like field 和 object-array-like field。
- 显式 GC。
- function call / return / throw。
- block / if / try-finally。
- worker spawn 和并发 mutation。
- allocation burst。
- foreign roundtrip 这类跨域抽象交互。
- reachability observation 和 alive/dead expectation。

`ScenarioProgram` 禁止表达：

- Kotlin 语法。
- C 语法。
- C header / cinterop def 具体格式。
- `StableRef`、`COpaquePointer`、`staticCFunction` 等 Kotlin/Native C interop 细节。
- 某个 compiler/linker 的命令行参数。
- reporting 或 archive 的文件布局。

### 2.2 单向依赖原则

依赖方向必须保持单向：

```text
ScenarioFeatureSet / ScenarioProgram
  -> Generator
  -> Preparation/Profile
  -> Mode
  -> Backend
  -> Translation
  -> Execution
  -> Reporting
```

禁止反向依赖：

- `Generator` 依赖 Kotlin translation 细节。
- `Scenario.kt` 依赖某个 backend 的输出类型。
- `translation` 反向决定对象图该怎么生成。
- `execution` 反向 patch `ScenarioProgram`。
- `reporting` 反向改变生成或执行语义。

### 2.3 主体 mode + 可选能力原则

CFFI 是主体执行 mode 下的可选能力，不是长期顶层主模式。

推荐形态：

- `pure-kotlin`
- `pure-kotlin + cffi`
- `<future-mode>`
- `<future-mode> + cffi`

禁止把固定 CFFI smoke 长期发展成正式主架构。当前 `kotlincffi` 相关代码只能被视为 smoke/experimental 验证通道；正式 fuzz 能力必须回到 `ScenarioProgram`、profile、backend、translation、execution 这一条主链路。

### 2.4 共享层去语言耦合原则

共享层允许表达“跨域交互”这种语言无关语义。

共享层禁止出现：

- `StableRef`
- `staticCFunction`
- `COpaquePointer`
- Kotlin `Worker` API 名称。
- ObjC retain/release API 名称。
- JNI local/global ref API 名称。
- 任意语言的 import、header、binding、build flag。

## 3. 分层规范

### 3.1 共享语义层

典型位置：

- `fuzzer/core/Scenario.kt`
- `fuzzer/core/ScenarioFeatureSet.kt`
- `fuzzer/core/ProgramId.kt`

职责：

- 定义共享 IR。
- 定义共享 operation、value、location、field、domain、reference kind。
- 定义 feature 开关。
- 定义语言无关 oracle 语义。

允许：

- 新增语言无关的 `ScenarioOp`。
- 新增语言无关的 `ScenarioField`。
- 新增语言无关的 feature。
- 新增跨域交互的抽象 reference kind 或 interaction pattern。
- 新增 reachability observation/checkpoint 这类共享 oracle 节点。

禁止：

- 加入 Kotlin/C/ObjC/JNI 等语法或 runtime API。
- 加入某个 backend 的输出文件结构。
- 加入某个 runner 的编译命令。
- 为某个目标 mode 特判修改共享 IR 语义。

评审标准：

- 删除某个目标 mode 目录后，共享语义层仍应自洽。
- 新字段或新 op 的含义必须能脱离具体语言解释。

### 3.2 生成层

典型位置：

- `fuzzer/generation/Generator.kt`
- `fuzzer/generation/ScenarioGenerationProfile.kt`
- `fuzzer/generation/Utils.kt`

职责：

- 基于 seed 和 `ScenarioFeatureSet` 生成 `ScenarioProgram`。
- 基于 `ScenarioGenerationCapabilities` 过滤当前 backend/language 不支持的 statement kind 和 topology。
- 只依赖共享语义。
- 产出可被不同 backend 消费的程序语义。
- 维护普通随机语句流和 targeted topology 模板。

必须：

- `Generator` 的最终输出必须始终是 `ScenarioProgram`。
- 新增生成能力必须由 `ScenarioFeature` 控制，除非它是所有 mode 都应无条件接受的基础语义。
- `ScenarioFeature` 只表示 fuzz 意图；不得把它当作唯一 backend 支持矩阵。新增 op、field、global storage、lifecycle 或 topology 时，必须同步 capability profile。
- 新增 topology 时必须明确它是 stress template、oracle capsule 还是 hybrid template。
- 涉及 reachability oracle 的 topology 必须满足第 5 节的 oracle 规范。
- 生成器应继续允许随机噪声和无效 id/path 作为压力输入，但不能把无效引用作为强 oracle 真值来源。

允许：

- 调整 class/global/function/body/path/statement 分布。
- 增加新的对象图、root churn、weak lifecycle、worker handoff、allocation burst 模式。
- 生成 `ForeignRoundTrip` 这类共享 CFFI 语义节点。
- 为 foreign roundtrip 增加语言无关的 reference kind / interaction pattern / repetition 参数。

禁止：

- 根据 execution mode 拼接不同源码。
- 在 `Generator` 中判断“如果是 Kotlin 就这样生成”。
- 直接生成 C 文件、header、imports、def。
- 为 CFFI 复制一套 generator 主链路。
- 为某个目标 backend 的翻译便利而污染共享 IR。

评审标准：

- 新增目标 mode 时不应复制一份 generator。
- `Generator.kt` 中出现目标语言名通常应视为设计异味，除非它只是使用共享 `ScenarioTargetLanguage` 这类 IR 枚举。

### 3.3 Preparation / Profile 层

典型位置：

- `fuzzer/core/ScenarioPreparation.kt`
- `fuzzer/<mode>/profile/*.kt`

职责：

- 在共享 IR 和目标 backend 之间建立边界。
- 声明目标 backend 当前支持哪些共享语义。
- 统一 target/domain 或做保守规约。
- 对不支持的语义进行明确失败、降级或交给 backend/lowering 处理。

当前实现基线：

- `ScenarioPreparation` 当前主要把 definition/op/value/location 的 `targetLanguage` 和 `domain` 统一到 profile 指定值。
- `PureKotlinScenarioProfile` 和 `PureKotlinCInteropScenarioProfile` 当前直接接受 store reference kind 和 foreign reference kind。
- 当前 preparation 不是复杂 lowering，也没有自动裁剪所有不支持语义。
- backend lower 前必须用 capability validator 或等价检查确认 prepared program 没有超出当前 profile 支持范围。

必须：

- 如果某个新 backend 不支持某类共享语义，必须在 profile、preparation、backend 或 lowering 中显式处理。
- profile 必须声明支持的 op、field、global storage、class lifecycle、reference kind 和 target/domain；不允许只依赖 translator 在深处失败。
- 不允许静默吞掉会改变 oracle 真值的语义。
- preparation 的输入输出仍应是 `ScenarioProgram` 或明确的 prepared program 包装。

允许：

- 将 domain 归一化到当前主体 mode。
- 拒绝当前目标不支持的 reference kind / interaction pattern。
- 对目标不支持但语义可保持的模式做保守降级。

禁止：

- 直接输出源码。
- 直接运行编译器。
- 在这里塞入语言文件模板。
- 把共享 IR 改写成某种目标语言专属 AST。

### 3.4 Mode 层

典型位置：

- `fuzzer/mode/ScenarioModeRegistry.kt`
- `fuzzer/mode/ScenarioModeDescriptor.kt`
- `fuzzer/<mode>/mode/*ModeDescriptor.kt`
- `fuzzer/<mode>/mode/*GenerationProfile.kt`

职责：

- 注册和选择执行 mode。
- 选择 generation profile。
- 组装 backend config。
- 驱动生成、lower、保存源码和执行。
- 根据配置决定是否启用 CFFI。

必须：

- 正式执行 mode 必须通过 `ScenarioModeRegistry` 注册。
- mode 只做装配，不承载共享语义。
- `gcfuzzing.cffi=true` 这类开关应选择 profile/backend 能力，而不是分叉一套生成主链路。

允许：

- 为同一主体 mode 提供多个 alias。
- 为实验 smoke 提供独立测试入口。
- 在 mode descriptor 中选择 `PureKotlinScenarioGenerationProfile` 或 `PureKotlinCInteropScenarioGenerationProfile` 这类 profile。

禁止：

- 在 registry 中堆业务逻辑。
- 把 mode 当成新的语义层。
- 为某个 CFFI 能力长期分叉出独立顶层主 mode。

### 3.5 Backend 层

典型位置：

- `fuzzer/<mode>/backend/*`

职责：

- 消费 prepared `ScenarioProgram`。
- 进入目标 mode 专有流程。
- 调用目标 lowering，如果需要。
- 产出 translation 可消费的 output。

必须：

- 正式 backend 必须消费 `ScenarioProgram`。
- backend config 只能影响运行边界和目标能力开关，不能反向改变共享生成语义。
- 如果 backend 发现无法保持 oracle 语义，必须失败或禁用相应 feature。

允许：

- 引入目标 mode 的 output 结构。
- 决定是否附带 CFFI 辅助产物。
- 做目标专有 lowering。

禁止：

- 反向修改共享 generator。
- 将目标专属概念提升为共享层必须概念。
- 把固定 smoke 逻辑长期留在正式 backend 中。

### 3.6 Translation 层

典型位置：

- `translation/*`

职责：

- 将 prepared IR 或 backend output 翻译成源码和辅助文件。
- 生成语言 runtime prelude。
- 生成桥接源码、header、def、binding、stub。
- 对已知 oracle capsule 做目标语言内的 probe lowering。

必须：

- translation 不得新发明共享语义。
- translation 对 oracle capsule 的特殊处理必须保持 IR 中已有的 observation/checkpoint/expectation 语义。
- 如果 translation 需要模式匹配固定 op 序列来生成 probe，必须有 translation test 覆盖。

允许：

- 生成 `main.kt`。
- 生成 `cinterop.def`、`bridge.h`、`bridge.c`。
- 生成 imports/helper/runtime glue。
- 把 reachability oracle 序列翻译成隔离 probe，以控制目标语言局部变量生命周期。

禁止：

- 在 translation 阶段随机插入共享 IR 无感知的 CFFI 行为。
- 在 translation 阶段决定对象图结构。
- 用 translation 特判替代 profile/backend 的能力边界。

### 3.7 Execution 层

典型位置：

- `execution/<mode>/*`
- `execution/ProcessRunner.kt`
- `execution/StandaloneExecutionHost.kt`

职责：

- 保存 translation 产物。
- 调用真实工具链编译、链接、执行。
- 记录编译日志、运行日志和 minidump 位置。

允许：

- 调用 `konanc`。
- 调用 `cinterop`。
- 调用 `clang`。
- 设置 linker option、runtime environment、codesign。
- 记录 `run.log`、`run.stdout.log`、`run.stderr.log`、`run.exitcode.txt`、`konanc.log`、`cinterop.log`、`clang.log` 等。

禁止：

- 重新决定程序语义。
- 在执行层改写共享 IR。
- 在运行前 patch 生成源码来绕过架构问题。

评审标准：

- execution 只关心“如何编译运行”，不关心“该生成什么语义”。

### 3.8 Reporting 层

典型位置：

- `build.gradle.kts` 中 case index / archive / summary 逻辑。
- ops/daily 脚本。

职责：

- 汇总 case 结果。
- 留存源码、日志、dump、归档。
- 生成 index、summary 和对比报告。

允许：

- 生成 `case-index.html`。
- 汇总 compile/run 失败。
- 归档失败用例。

禁止：

- 决定生成语义。
- 修改 mode 行为。
- 在报告层特判掩盖真实失败。

## 4. 新增执行 mode 规范

新增 `<mode>` 时，标准目录结构应为：

```text
tests/.../fuzzer/<mode>/
  mode/
    <Mode>ScenarioModeDescriptor.kt
    <Mode>ScenarioGenerationProfile.kt
  profile/
    <Mode>ScenarioProfile.kt
  backend/
    <Mode>ScenarioBackend.kt
    <Mode>ScenarioLowering.kt   # 如果需要

tests/.../translation/
  <Mode>Translation.kt

tests/.../execution/<mode>/
  <Mode>ScenarioRunner.kt
```

新增语言 backend 的具体落地步骤、第一阶段能力边界、runner 示例和 checklist，见配套指南：

- `GCFUZZ_ADD_LANGUAGE_BACKEND_CN.md`

必须修改：

1. 新增 mode descriptor。
2. 新增 generation profile。
3. 新增 profile。
4. 新增 backend。
5. 新增 translation。
6. 新增 execution runner。
7. 在 `ScenarioModeRegistry` 注册正式 mode。
8. 增加 generator/profile/backend/translation/execution 测试。

可能修改：

1. `Scenario.kt`，前提是新增共享语义。
2. `ScenarioFeatureSet.kt`，前提是新增共享 feature。
3. `ScenarioPreparation.kt`，前提是新增通用规约规则。
4. `Generator.kt`，前提是新增共享生成能力或 topology。
5. `build.gradle.kts` 和文档，前提是新增可运行任务或报告入口。

禁止：

- 在 `Generator` 中加入目标 mode 分支来输出源码。
- 在共享 IR 中加入目标语言专属语法结构。
- 修改现有 `pure-kotlin` backend 内部逻辑来兼容新 mode。
- 复制整个 `pure-kotlin` 实现后只改字符串作为正式接入方式。

## 5. 测试用例生成规范

### 5.1 普通随机语句流

普通随机语句流用于制造覆盖面和压力，包括：

- alloc/load/store/call。
- block/if/try-finally。
- spawn function / spawn body。
- explicit GC。
- allocation burst。
- 随机 local/global/path。
- foreign roundtrip。

规则：

- 可以产生无效 id/path，由 translation 容错为 `null` 或跳过无效 store。
- 不得把无效 id/path 作为 reachability oracle 真值来源。
- nested body 不应生成不适合目标翻译上下文的 terminal statement；当前生成器已通过 `allowTerminalStatements=false` 约束嵌套 body。
- 新 statement kind 必须有 translation 和测试覆盖。

### 5.2 Targeted Topology

targeted topology 用于制造特定 GC 压力模式。当前包括但不限于：

- cycle。
- shared node。
- global reattach。
- old root churn。
- root migration。
- delete edge then GC。
- weak ref lifecycle。
- weak root handoff。
- weak array slot。
- weak thread-local root。
- weak / strong global alternating。
- weak late strong rescue。
- weak multi-epoch observe。
- concurrent publish / clear / GC。
- array slot graph。
- graph mutation sequence。
- mixed field / array mutation barrier。
- large object multi-field rewrite。
- old root churn with allocation burst。
- graph mutation multi-phase sequence。
- shared node reconnect between owners。
- cycle break and reroot。
- worker alloc publish。
- multi-stage root handoff。
- ping-pong root transfer。
- concurrent duplicate handoff。
- local/global array handoff。
- stale owner mutation after handoff。

规则：

- 每个 topology 必须绑定 feature。
- topology 必须能在 `ScenarioProgram` 中表达，不得绕过 IR 直接写源码。
- 如果 topology 只制造压力，不应携带强 alive/dead reachability 断言。
- 如果 topology 携带 reachability oracle，必须符合 5.3。

### 5.3 Reachability Oracle

reachability oracle 必须明确分类。

#### Stress Template

用途：

- 制造复杂对象图。
- 制造 root churn / root handoff。
- 制造并发发布、迁移、回收压力。
- 制造 GC 前后复杂时序。

允许：

- 使用 shared global。
- 使用 thread-local global。
- 引入 worker。
- 引入开放世界干扰。

禁止：

- 在开放世界共享 root 干扰下直接附加“首次 GC 后必死”这类强断言。
- 用普通随机 local 活性作为 dead/alive 的唯一证明。

#### Oracle Capsule

用途：

- 在大程序中插入局部封闭、真值可证明的 oracle 片段。
- 用最小共享语义表达 observation、checkpoint、expectation。

必须：

1. oracle 真值链自闭合。
2. 被观测对象的强 root 生命周期由 capsule 自己控制。
3. checkpoint 之间不依赖开放世界普通 local/shared global 活性。
4. `Alive` 断言能说明强引用如何稳定保留。
5. `Dead` 断言能说明强引用如何完全清除。
6. backend/translation 能 lowering 成隔离 probe 或等价机制。

禁止：

- 用普通 shared strong root 作为 oracle 唯一真值来源。
- 用普通 local 存活性作为 oracle 唯一真值来源。
- 让外部线程在 oracle 建立期间自由获得额外强引用，同时仍假设首次 GC 必死。

#### Hybrid Template

用途：

- 表达“复杂外层 + 局部可证明片段”。

必须：

- 强 reachability 断言只属于已隔离的 capsule 内核。
- 复杂外层不得破坏 capsule 的真值链。

禁止：

- 整个复杂模板共享一套开放世界状态，并在任意位置插入强 alive/dead 断言。

### 5.4 当前正式 Oracle Capsule

当前正式 oracle capsule 包括：

1. `single-strong-slot`
   - 目标：验证一个明确 `StrongRef` 槽对 payload 的保活和释放。
   - 真值链：`owner.strongField = payload`，建立 weak observation，GC 后 alive；清除 strong field，再 GC 后 dead。
   - 约束：只能使用单跳 `StrongRef` 槽。

2. `reachability-consistency`
   - 目标：验证 publish 后可达、clear 后死亡的一致性。
   - 正式断言部分必须保持 `single-strong-slot` 等价的强引用槽真值链。
   - 任意 path stress 可以存在，但不能替代 oracle capsule 的强边证明。

3. `root-migration`
   - 目标：验证 payload 从 source strong slot 迁移到 target strong slot 后，在 source/root 清除后仍存活。
   - 约束：source slot 和 target slot 都必须是单跳 `StrongRef`。
   - 断言 `target-alive-after-gc` 时，payload 的稳定真值来源必须是 target 侧强边。

4. `weak-dead-capsule`
   - 目标：验证只有 weak observation、没有强 root 时，首次 GC 后对象死亡。
   - 约束：对象创建和 observation 必须封闭在 capsule 中，不能泄漏额外强引用。

### 5.5 Oracle 翻译规范

当前 `PureKotlinTranslation.kt` 会识别部分固定 op 序列并翻译成 probe helper，而不是逐条机械翻译。

新增 oracle translation 必须：

- 有固定、可测试的 IR 序列或显式 IR 节点。
- 有 translation test 覆盖 probe 生成。
- 有 generator topology test 覆盖生成器确实能产出该模式。
- 说明为什么 probe 不会意外延长或缩短被观测对象生命周期。

## 6. CFFI 开发规范

### 6.1 当前 CFFI 基线

当前正式 CFFI 路径是 `pure-kotlin + gcfuzzing.cffi=true`：

- `ScenarioOp.ForeignRoundTrip` 表达共享语义。
- `ScenarioForeignReferenceKind` 表达 `Handle / Strong / Weak`。
- `ScenarioForeignInteractionPattern` 表达 `Callback / RepeatedCallback / Identity / WrappedCallback / CallbackThenIdentity / NestedCallback / BoxedCallback / BoxedIdentity / BoxedRepeatedCallback`。
- `PureKotlinCInteropScenarioGenerationProfile` 打开 `CFFI_CALLBACK_ROUNDTRIP`。
- `PureKotlinCInteropScenarioGenerationProfile` 可以打开 CFFI stress topology，例如 `TOPOLOGY_CFFI_CALLBACK_AFTER_GC`、`TOPOLOGY_CFFI_IDENTITY_HANDOFF`。
- `PureKotlinCInterop.kt` 生成 `cinterop.def`、`bridge.h`、`bridge.c`。
- `PureKotlinScenarioRunner.kt` 调用 `cinterop`、`clang`、`konanc`。

`kotlincffi` smoke 路径：

- 生成固定样例。
- 不消费 `ScenarioProgram`。
- 不在 `ScenarioModeRegistry` 中作为正式 mode 注册。
- 只能用于工具链 smoke 或迁移验证，不得作为正式 fuzz 架构继续扩展。

### 6.2 CFFI 建模规则

共享层只允许表达语言无关问题：

- foreign roundtrip。
- callback / repeated callback / identity。
- wrapped callback / callback-then-identity / nested callback 这类同步 foreign 调用形态。
- boxed callback / boxed identity / boxed repeated callback 这类调用内 C struct payload 包装形态。
- handle / strong / weak 一类抽象引用方式。
- repetition count。
- CFFI topology 必须通过 `ScenarioOp.ForeignRoundTrip` 等共享 IR 节点表达，不得在 translation 阶段临时插入隐藏的 CFFI 行为。
- 只制造 CFFI 与 GC 交错压力、但不携带 alive/dead 断言的 CFFI topology，应归类为 stress template。
- 后续如需要，可增加 ownership edge、release timing、cross-thread callback 等抽象语义。

共享层禁止直接出现：

- Kotlin `StableRef`。
- ObjC block。
- JNI local/global ref API。
- C header 名称。
- cinterop def 内容。

### 6.3 CFFI 接入步骤

新增 CFFI 能力必须按顺序考虑：

1. 共享语义：是否需要新增 `ScenarioOp`、reference kind、interaction pattern 或 feature。
2. Generation profile：哪些 mode 可以生成该 CFFI 语义。
3. Profile/preparation/backend：目标 mode 是否支持该语义；不支持时如何失败或降级。
4. Translation：如何生成 bridge、binding、runtime helper。
5. Execution：如何编译、链接、设置运行环境。
6. Tests：translation、execution、generator/profile 行为是否覆盖。

禁止：

- 在 translation 中随机插 CFFI 代码而 IR 无感知。
- 为某个 CFFI 单独复制 generator 主链路。
- 用独立 CFFI smoke 长期替代主体 mode + CFFI 开关。
- 为当前 Kotlin/C 方便，把共享 IR 改成 Kotlin 专属模型。

## 7. Smoke / Experimental 规范

smoke 通道可以存在，但必须隔离。

允许：

- 固定最小样例。
- 单独 backend。
- 单独 translation。
- 单独 execution test。

必须：

- 命名或文档明确标注 smoke/experimental。
- 不得注册为正式 fuzz 主 mode，除非已经接入 `ScenarioProgram` 主链路。
- 不得反向侵入共享层设计。
- 不得作为 daily 主覆盖的长期替代品。

正式支持的最低条件：

1. 可通过 mode 选择。
2. 共享 IR 可表达相应语义。
3. backend 消费共享 IR。
4. translation 生成真实产物。
5. execution 真实编译运行。
6. 有 generator/profile/backend/translation/execution 测试。
7. 能进入 daily 或至少能通过正式任务稳定运行。

## 8. 测试与开发后验证要求

新增或修改能力时，测试覆盖必须和风险匹配。

### 8.1 Generator 测试

需要覆盖：

- 新 feature 打开后，生成器能在合理 seed 范围内产出目标 topology/op。
- 新 oracle capsule 使用合法强引用槽或合法 observation 来源。
- nested body 不产生目标 translation 无法接受的 terminal control flow。
- CFFI feature 关闭时不会生成 `ForeignRoundTrip`。

参考位置：

- `test/generator/GeneratorTopologyTest.kt`

### 8.2 Translation 测试

需要覆盖：

- 新 op 的源码渲染。
- 新 field/reference kind 的渲染。
- oracle probe 的模式匹配和 helper 调用。
- CFFI bridge 文件生成和 Kotlin runtime 调用。

参考位置：

- `test/translation/PureKotlinScenarioTranslationTest.kt`
- `test/translation/KotlinCInteropScenarioTranslationTest.kt`

### 8.3 Backend/Profile 测试

需要覆盖：

- profile 选择是否正确。
- unsupported semantics 是否显式失败、降级或保持语义。
- `enableCInterop` 对 backend 输出的影响。

参考位置：

- `test/backend/PureKotlinScenarioBackendTest.kt`

### 8.4 Execution 测试

需要覆盖：

- 最小 case 能编译运行。
- CFFI case 能完成 bridge 编译、链接和运行。
- 日志和输出目录符合 runner 约定。

参考位置：

- `test/execution/PureKotlinScenarioExecutionTest.kt`
- `test/execution/KotlinCInteropScenarioExecutionTest.kt`

### 8.5 开发后验证原则

开发完成后必须按改动范围运行验证，不能只依赖代码可编译。

基本原则：

- 文档-only 改动至少运行 `git diff --check`。
- 共享 IR、feature、generator、profile、backend、translation、execution 任一层改动，至少运行对应单元测试。
- 影响 `ScenarioProgram` 结构、topology、root lifecycle、finalizer、weak、oracle 或 CFFI 的改动，必须运行一次默认开启 CFFI 的真实 fuzz smoke。
- 影响 CFFI 的改动，必须额外运行 CFFI translation/execution；真实 fuzz smoke 默认已经覆盖主体 mode + CFFI 路径。
- 如果某个测试因为本地缺少 Kotlin/Native home、clang、cinterop 或设备环境无法运行，必须在变更说明中明确写出未运行原因。

### 8.6 通用验证命令

所有非纯文档改动，至少运行：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.generator.GeneratorTopologyTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.PureKotlinScenarioTranslationTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.PureKotlinScenarioBackendTest
git diff --check
```

说明：

- `GeneratorTopologyTest` 验证 feature/topology 能在合理 seed 范围内真实生成。
- `PureKotlinScenarioTranslationTest` 验证 IR 到 Kotlin 源码的关键渲染。
- `PureKotlinScenarioBackendTest` 验证 backend/preparation/profile 边界。
- `git diff --check` 验证空白和 patch 格式问题。

如果改动包含 debug backend，额外运行：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.ScenarioDebugBackendTest
```

### 8.7 按改动类型选择验证

#### 8.7.1 仅修改文档

最低验证：

```bash
git diff --check
```

如文档中包含命令、路径或测试名，应该用 `rg --files` 或 `rg -n` 确认引用仍存在。

#### 8.7.2 修改 `Scenario.kt` / `ScenarioFeatureSet.kt`

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.generator.GeneratorTopologyTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.PureKotlinScenarioTranslationTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.PureKotlinScenarioBackendTest
git diff --check
```

如果新增 `ScenarioOp`、`ScenarioValue`、`ScenarioLocation`、`ScenarioField` 或 lifecycle 语义，还必须补 translation/backend 测试覆盖该节点如何被处理。

新增 `ScenarioOp` 时必须同步检查：

- `Scenario.kt` 的 IR 定义是否表达共享语义，而不是目标语言 API。
- `ScenarioFeatureSet` 和 generation profile 是否需要 feature gate。
- `ScenarioCapabilityProfile`、`ScenarioGenerationCapabilities` 和 capability validator 是否同步支持或拒绝该语义。
- `ScenarioPreparation` 是否递归处理 value/location/body/domain/reference kind。
- 所有 backend/translator 是否显式处理该 op；不能依赖默认 `else` 静默吞掉新语义。
- `DebugScenarioBackend` 是否能渲染该 op，方便失败 case 人工排查。
- `estimateLocalsCount()`、`endsWithTerminalStatement()`、CFFI/C interop 扫描等 IR walker 是否同步更新。
- `docs/readme/GCFUZZ_IR_GENERATION_CN.md`、`docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md` 和本 spec 是否同步更新。

如果新增或修改调度类 IR，例如 `Signal`、`Wait`、`Yield`：

- `Wait` 的 translation/runtime helper 必须是 bounded wait，并检查 termination/soft-timeout 状态，禁止引入无限等待。
- 调度 IR 初期只能由 targeted topology 使用，不应直接进入普通随机 statement 池，除非已有额外 hang 防护和覆盖证明。
- 必须补真实 fuzz smoke，验证 Kotlin/Native runtime 下不会因为 checkpoint 顺序、worker 限流或提前 termination 造成系统性 timeout。

如果新增 worker join、epoch wait 或任何可能阻塞的 runtime helper，必须采用 bounded wait，并在等待循环中检查 termination 或 soft-timeout 状态。

#### 8.7.3 修改 generator / topology / generation profile

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.generator.GeneratorTopologyTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.PureKotlinScenarioBackendTest
git diff --check
```

如果新增 topology：

- 必须在 `GeneratorTopologyTest` 中验证该 topology 能生成。
- 如果 topology 需要特定 class/global/field 材料，必须验证 generator 会提供这些材料。
- 如果 topology 是 oracle capsule，必须验证 oracle slot 使用合法 strong edge 或合法 weak observation 来源。
- topology 中的 root/slot 清理必须优先使用 `ScenarioOp.Clear`，不得继续用普通 `Store(..., NullValue)` 隐藏生命周期语义。
- topology 中连续的非 clear store mutation 可以使用 `ScenarioOp.StoreBatch` 表达 barrier 压力；`StoreBatch` 不应混入 clear 事件。
- 只有连续多轮 GC epoch 才应使用 `ScenarioOp.GcEpoch`；如果两次 GC 之间有 allocation、observe、publish/clear、checkpoint 或 worker handoff，不应合并。
- 必须同步 `ScenarioTopologyKind`、`ScenarioTopologyKind.family`、generator telemetry 计数和 fuzz run reporting；报告中必须能看到该 topology 的 family、规则说明、attempts、total hits、case hits 和 example cases。
- 必须同步 `ScenarioTopologyKind.requiredCapabilities()` 和 `ScenarioGenerationCapabilities.supportedTopologies` 或等价支持矩阵，不能出现 feature 开启但目标 backend 不支持时仍可生成该 topology。
- 必须补负向测试，验证缺少该 topology 依赖的 op、field、global storage 或 lifecycle 时，generator 不会把它列为 enabled topology。
- 必须检查 `build.gradle.kts` 中 topology coverage report 的 `topologyRules` 和 `topologyFamilies` 是否覆盖新增 topology；不允许出现新增 topology 已生成但报告规则或 family 显示为缺失描述的状态。
- family 汇总报告必须能展示每个 family 的 topology 数、attempts、total hits、case hits、case hit rate、emit success rate 和 example cases。

#### 8.7.4 修改 preparation / backend / profile

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.PureKotlinScenarioBackendTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.PureKotlinScenarioTranslationTest
git diff --check
```

如果改动会影响 generated program 的可执行性，还应运行一次真实 fuzz smoke，见 8.8。

如果改动涉及 capability profile、generation capability 或 validator，还必须补充负向测试：

- generator 在 capability 禁用时不生成对应 ordinary op 或 topology。
- backend/preparation 对手写 unsupported IR fail-fast，并在错误信息中包含 unsupported capability。

#### 8.7.5 修改 translation / prelude / helper

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.PureKotlinScenarioTranslationTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend.PureKotlinScenarioBackendTest
git diff --check
```

如果改动影响 runtime helper、worker、GC、weak、finalizer、thread-local cleanup、safe load/store 或 generated `main.kt` 的可编译性，必须运行 execution smoke：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution.PureKotlinScenarioExecutionTest \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt
```

#### 8.7.6 修改 CFFI 语义、CFFI translation 或 CFFI execution

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.generator.GeneratorTopologyTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.PureKotlinScenarioTranslationTest
./gradlew :gc-fuzzing-tests:test --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.KotlinCInteropScenarioTranslationTest
git diff --check
```

如果本地有 Kotlin/Native home 和 C toolchain，还必须运行：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution.PureKotlinScenarioExecutionTest \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt

./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution.KotlinCInteropScenarioExecutionTest \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt
```

说明：

- `PureKotlinScenarioExecutionTest` 中包含 `pureKotlinForeignRoundTrip` 这类主体 mode + CFFI 能力验证。
- `KotlinCInteropScenarioExecutionTest` 是固定 smoke/experimental 通道，只能作为工具链补充验证，不能替代主体 mode + CFFI 验证。

#### 8.7.7 修改 execution runner、build、archive 或 reporting

最低验证：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution.PureKotlinScenarioExecutionTest \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt
git diff --check
```

如果改动涉及 CFFI 编译、链接、日志或 bridge 产物，额外运行 CFFI execution 验证。

### 8.8 真实 fuzz smoke

凡是影响生成语义、translation、runtime helper、execution 或 GC 业务结构的改动，必须至少运行一次短时真实 fuzz。

默认端到端 smoke 必须开启 CFFI，覆盖主体 mode + C bridge 编译、链接和运行路径：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.GCFuzzingTest.simple \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt \
  -Dgcfuzzing.executionModel=pure-kotlin \
  -Dgcfuzzing.cffi=true \
  -Dgcfuzzing.gc=cms \
  -Dgcfuzzing.timelimit=1m \
  -Dgcfuzzing.parallelism=1 \
  -Dgcfuzzing.seed=1 \
  -Dgcfuzzing.executionTimeout=30s
```

如果改动需要验证非 CFFI 退化路径，再额外运行：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.GCFuzzingTest.simple \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt \
  -Dgcfuzzing.executionModel=pure-kotlin \
  -Dgcfuzzing.cffi=false \
  -Dgcfuzzing.gc=cms \
  -Dgcfuzzing.timelimit=1m \
  -Dgcfuzzing.parallelism=1 \
  -Dgcfuzzing.seed=1 \
  -Dgcfuzzing.executionTimeout=30s
```

如果需要复现单个失败 case：

```bash
./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.GCFuzzingTest.simple \
  -Dkn.nativeHome=/path/to/kotlin-native-prebuilt \
  -Dgcfuzzing.executionModel=pure-kotlin \
  -Dgcfuzzing.single.id=I123456789 \
  -Dgcfuzzing.executionTimeout=30s
```

真实 fuzz smoke 的目的不是证明覆盖充分，而是验证：

- generated source 能落盘。
- `konanc` 能编译。
- `app.kexe` 能运行。
- runner 日志和 case 目录符合预期。
- 新增 topology/helper 不会在真实 Kotlin/Native runtime 下立即失败。

### 8.9 可接受的验证收敛策略

本地开发时可以按风险递增运行：

1. 先跑目标单测，例如 generator 或 translation。
2. 再跑 backend/preparation 相关测试。
3. 最后跑真实 fuzz smoke。

提交或交付说明中必须列出实际运行过的命令和结果。

不得把 disabled oracle capsule 测试作为已验证能力来报告；如果临时启用 disabled 测试验证某个 oracle 改动，必须明确说明是临时验证。

### 8.10 类型系统生成能力

新增类型系统语义时，必须新增共享 IR、feature gate、capability profile/validator 和各 backend 的显式翻译或 fail-fast；不得以 \`Any?\` 或 translator 私有代码伪造已支持的类型。

第一批 interface 多态至少应表达：接口定义、至少两个 concrete implementor、interface-typed local/global/field/function return，以及通过接口协议返回 payload 的 dispatch 操作。类型化 store 必须保持 target-language 的静态类型可编译。

第二批类型系统 MVP 至少应表达：

- sealed class hierarchy：sealed base、至少两个 concrete subclass、class-typed root，以及通过 `when`/virtual dispatch 返回 subclass payload。
- singleton object root：object/singleton definition、singleton value/location、singleton field store/access。
- inner class outer capture：inner class definition、显式 outer 输入、inner object 对 hidden outer root 的 dispatch/access。

第二批及后续类型结构默认应以小流量 structural anchor 进入普通 fuzz case；专门 generator/translation/execution 测试可以只启用对应 feature，使结构稳定生成。普通 `CreateObject` 不得随机实例化 sealed base 或 inner class；inner class 必须通过专门 IR 显式携带 outer。

#### 8.10.1 Structural Coverage 报告规约

新增类型系统、结构锚点或非 topology 的高价值生成能力时，必须同步 `Structural Coverage` 报告；不能只打开 `ScenarioFeature` 而没有 case 级命中可见性。

这类能力包括但不限于：

- interface 多态
- sealed hierarchy
- abstract/base + subclass layout
- singleton / object declaration root
- inner class outer capture
- function type / lambda / closure capture
- generic holder / variance / nullable nesting
- suspend/async state machine

Structural coverage 必须遵守以下规则：

- 每个新增 structural kind 必须有稳定名字，写入 `topology.json` 的 `structuralHits`。
- `structuralHits` 必须基于实际生成后的 `ScenarioProgram` 统计，而不是只根据 feature gate 是否开启统计。
- hit 值必须表达可解释的结构强度；例如 interface 多态用实际 `InterfaceDispatch` 次数，而不是固定写 `1`。
- summary 报告必须在 `Structural Coverage` 区域展示该 kind 的规则说明、total hits、case hits、case hit rate 和 example cases。
- CSV/JSON 输出必须同步更新；当前至少包括 `topology-summary.json` 的 `structuralCoverage` 和 `structural-summary.csv`。
- case 级明细必须能看出某个 case 命中了哪些 structural kind。
- 新增 structural kind 必须补 generator/telemetry 测试，验证命中统计来自实际 IR，并验证 `topology.json` 包含该 structural hit。
- 不得把 structural kind 塞进 `ScenarioTopologyKind`、`topologyAttempts` 或 `topologyHits`，除非它本身确实是 targeted topology 且有 attempts/hits 失败语义。

新增 structural kind 时必须检查：

- `ScenarioStructuralCoverageKind` 是否新增枚举值。
- `collectStructuralHits(...)` 是否从 IR walker 统计该结构，且覆盖 nested body、function body、finalizer body 等相关位置。
- `build.gradle.kts` 中 structural coverage report 是否补充规则说明。
- `docs/readme/GCFUZZ_IR_GENERATION_CN.md` 和 `docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md` 是否说明该 structural kind 如何进入报告。

### 8.11 文档一致性验证

新增或修改功能时，必须同步检查资料是否仍与实现一致。文档更新不是可选收尾，而是开发完成条件之一。

文档目录职责：

- `docs/readme/`：解释工具如何工作、IR 如何生成、IR 如何进入 testcase/translation/execution。
- `docs/spec/`：定义开发必须遵守的规约、禁止事项、验证要求和新增 backend 指南。
- `docs/GCFUZZ_ARCHITECTURE_DESIGN_CN.md`：说明当前架构、模块关系、主链路和扩展点。
- `docs/roadmap/`：记录能力盘点、限制、路线图和专题演进计划。

按改动类型更新文档：

| 改动类型 | 必须检查/更新的文档 |
|---|---|
| 新增 `ScenarioOp` / `ScenarioValue` / `ScenarioLocation` / `ScenarioField` / lifecycle | `docs/readme/GCFUZZ_IR_GENERATION_CN.md`、`docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`、`docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md` |
| 新增 `ScenarioFeature`、generation profile 能力或 capability profile 能力 | `docs/readme/GCFUZZ_IR_GENERATION_CN.md`、`docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md` |
| 新增 structural kind / 类型系统结构锚点 | `docs/readme/GCFUZZ_IR_GENERATION_CN.md`、`docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`、`docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md`、`build.gradle.kts` structural coverage 规则 |
| 新增 targeted topology | `docs/readme/GCFUZZ_IR_GENERATION_CN.md`、相关 `docs/roadmap/*`、`ScenarioTopologyKind` family 映射、telemetry/report 规则表、必要时更新 `docs/GCFUZZ_ARCHITECTURE_DESIGN_CN.md` |
| 新增或调整 reachability oracle | `docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md`、`docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`、相关 `docs/roadmap/*` |
| 新增 finalizer / weak / thread-local / root lifecycle 语义 | `docs/readme/*`、相关 `docs/roadmap/*`、必要时更新主 spec 的验证要求 |
| 新增 CFFI reference kind / interaction pattern / bridge 能力 | `docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md`、`docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`、`docs/GCFUZZ_ARCHITECTURE_DESIGN_CN.md` |
| 新增 execution mode 或语言 backend | `docs/spec/GCFUZZ_DEVELOPMENT_SPEC_CN.md`、`docs/spec/GCFUZZ_ADD_LANGUAGE_BACKEND_CN.md`、`docs/GCFUZZ_ARCHITECTURE_DESIGN_CN.md` |
| 修改 runner、输出目录、日志、archive/reporting | `docs/readme/GCFUZZ_IR_TO_TESTCASE_FLOW_CN.md`、`docs/GCFUZZ_ARCHITECTURE_DESIGN_CN.md`、必要时主 spec |
| 调整 roadmap 优先级或能力状态 | 对应 `docs/roadmap/*` |

一致性检查建议：

```bash
rg -n "TOPOLOGY_|ORACLE_|FOREIGN_|ScenarioOp|ScenarioField|ScenarioFeature|executionModel|gcfuzzing\\." gc-fuzzing-tests/docs
rg -n "enum class ScenarioFeature|sealed interface ScenarioOp|sealed interface ScenarioField|enum class ScenarioTopologyKind|ScenarioStructuralCoverageKind|requiredCapabilities|ScenarioCapabilityProfile|ScenarioGenerationCapabilities|topologyRules|structuralRules" gc-fuzzing-tests/tests gc-fuzzing-tests/build.gradle.kts
git diff --check -- gc-fuzzing-tests/docs
```

评审时必须确认：

- 文档没有描述已删除或改名的 feature/topology/op。
- 文档没有漏掉新增的 public-facing feature、topology、execution flag、输出文件或验证命令。
- 新增 structural kind 没有漏掉 `structuralHits`、summary JSON/CSV/HTML 和 case 级明细。
- topology coverage report 没有漏掉新增 topology，且规则说明、case 命中明细、图表数据与 telemetry 字段一致。
- roadmap 中“当前已具备能力”和实现一致。
- spec 中的禁止事项、验证要求没有被新实现绕过。
- readme 中的生成/translation/execution 流程仍能对应当前代码。

## 9. 代码评审清单

涉及生成器、IR、多 mode 或 CFFI 的改动，评审至少检查：

1. 新增的是共享语义还是目标私有语法？
2. 共享语义是否进入 `ScenarioProgram`？
3. 目标私有行为是否限制在 profile/backend/translation/execution 层？
4. `Generator` 是否仍然只输出 `ScenarioProgram`？
5. 新生成能力是否受 `ScenarioFeature` 控制？
6. 新生成能力是否同步了 capability profile 和 validator 负向测试？
7. 新 topology 是否明确 stress/oracle/hybrid 分类？
8. reachability oracle 是否有自闭合真值链？
9. translation 是否只翻译已有 IR，不发明新语义？
10. execution 是否只负责编译运行，不 patch 语义？
11. CFFI 是否通过主体 mode 开关启用，而不是独立长期主模式？
12. smoke 代码是否明确隔离，没有进入正式主链路？
13. 是否补齐 generator/profile/backend/translation/execution 中必要的测试？
14. 是否按 8.10 更新相关 readme/spec/architecture/roadmap 文档？
15. 文档中的 feature/topology/op/命令是否与当前实现一致？

## 10. 最终硬规则

必须长期遵守：

1. `ScenarioProgram` 是唯一共享语义中心。
2. `Generator` 只生成共享 IR，不生成源码。
3. topology 可以制造复杂压力，但强 reachability oracle 必须 capsule 化或等价隔离。
4. CFFI 是主体 mode 的可选能力，不是独立顶层长期模式。
5. 目标私有细节只能存在于 profile/backend/translation/execution 层。
6. smoke 可以存在，但不得替代正式 `ScenarioProgram` 主链路。

违反这些规则的实现，即使短期能跑，也应视为架构错误。
