import java.io.File
import java.nio.file.Files
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random
import kotlin.text.Regex
import org.gradle.api.GradleException
import org.gradle.api.tasks.testing.TestDescriptor
import org.gradle.api.tasks.testing.TestListener
import org.gradle.api.tasks.testing.TestOutputEvent
import org.gradle.api.tasks.testing.TestResult

plugins {
    kotlin("jvm")
}

dependencies {
    testImplementation(kotlin("test"))
    testImplementation(platform("org.junit:junit-bom:5.10.2"))
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    named("main") {
        kotlin.setSrcDirs(emptyList<String>())
        resources.setSrcDirs(emptyList<String>())
    }
    named("test") {
        kotlin.srcDir("tests")
        resources.srcDir("testData")
    }
}

fun generateCaseIndexReport(runDirFile: File, runId: String) {
    fun escapeHtml(value: String): String =
        value
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    val caseDirs = runDirFile.listFiles()
        ?.filter { it.isDirectory && it.name.startsWith("I") }
        ?.sortedBy { it.name }
        .orEmpty()

    if (caseDirs.isEmpty()) return

    val detailPages = runDirFile.walkTopDown()
        .filter { it.isFile && it.extension == "html" && it.name != "index.html" }
        .map { it.relativeTo(runDirFile).path.replace(File.separatorChar, '/') to it.readText() }
        .toList()

    data class CaseRow(
        val caseId: String,
        val compileStatus: String,
        val runStatus: String,
        val summary: String,
        val artifactsPath: String,
        val detailPath: String?,
    ) {
        fun toHtml(): String {
            val compileClass = if (compileStatus == "OK") "ok" else "fail"
            val runClass = if (runStatus == "OK") "ok" else if (runStatus == "NOT_RUN") "muted" else "fail"
            val detailLink = detailPath?.let { """<a href="$it">open</a>""" } ?: """<span class="muted">n/a</span>"""
            return """
                <tr>
                <td><code>$caseId</code></td>
                <td class="$compileClass">$compileStatus</td>
                <td class="$runClass">$runStatus</td>
                <td>${escapeHtml(summary)}</td>
                <td><a href="$artifactsPath/">dir</a></td>
                <td>$detailLink</td>
                </tr>
            """.trimIndent()
        }
    }

    fun firstMatchingLine(text: String, markers: List<String>): String =
        text.lineSequence()
            .map { it.trim() }
            .firstOrNull { line -> markers.any { marker -> marker in line } }
            ?: "Failed"

    fun readFirstExistingText(caseDir: File, fileNames: List<String>): String =
        fileNames
            .asSequence()
            .map(caseDir::resolve)
            .firstOrNull(File::exists)
            ?.readText()
            .orEmpty()

    fun parseExitCode(logText: String): String? =
        Regex("""(?m)^exitCode=(\d+)\s*$""")
            .find(logText)
            ?.groupValues
            ?.get(1)
            ?: Regex("""Exit code:\s*(\d+)\s*\((?:OK|FAIL)\)""")
                .find(logText)
                ?.groupValues
                ?.get(1)

    fun decodeHtmlEntities(value: String): String =
        value
            .replace("&quot;", "\"")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")

    fun normalizeSummaryLine(value: String): String =
        decodeHtmlEntities(value)
            .replace(Regex("""\s+"""), " ")
            .trim()

    fun extractCaseDetailContext(detailText: String, caseId: String): String {
        val markerIndex = listOf("($caseId)", "[$caseId]", "/$caseId/")
            .map { detailText.indexOf(it) }
            .firstOrNull { it >= 0 }
            ?: return detailText
        val endIndex = minOf(detailText.length, markerIndex + 12_000)
        return detailText.substring(markerIndex, endIndex)
    }

    fun findFirstInterestingLine(text: String, predicate: (String) -> Boolean): String? =
        text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .firstOrNull(predicate)
            ?.let(::normalizeSummaryLine)

    fun findInterestingContextLine(text: String, predicate: (String) -> Boolean): String? {
        val lines = text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        lines.forEachIndexed { index, line ->
            if (!predicate(line)) return@forEachIndexed
            val nextLine = lines.getOrNull(index + 1)
            return if (line.endsWith(":") && nextLine != null) {
                normalizeSummaryLine("$line $nextLine")
            } else {
                normalizeSummaryLine(line)
            }
        }
        return null
    }

    fun summarizeRunFailure(caseId: String, stdErrText: String, detailText: String): String {
        val caseDetailText = extractCaseDetailContext(detailText, caseId)
        val stderrLines = stdErrText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        val detailLines = caseDetailText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val preferredStdErr = stderrLines.firstOrNull { !it.startsWith("Minidump written to") }
        if (preferredStdErr != null) return normalizeSummaryLine(preferredStdErr)
        if (stderrLines.isNotEmpty()) return normalizeSummaryLine(stderrLines.take(2).joinToString(" | "))

        detailLines.forEachIndexed { index, line ->
            if (line == "========== BEGIN: STDERR ==========") {
                detailLines.drop(index + 1)
                    .firstOrNull { candidate ->
                        candidate != "========== END: STDERR ==========" &&
                            !candidate.startsWith("Minidump written to")
                    }
                    ?.let { return normalizeSummaryLine(it) }
            }
        }

        findInterestingContextLine(caseDetailText) { "Uncaught Kotlin exception:" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Reachability oracle failed" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "SIGABRT" in it || "SIGSEGV" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Signal 6" in it || "segmentation fault" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Crash reason:" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "EXC_BAD_ACCESS" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Illegal thread state switch" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "AssertionError" in it && caseId in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Caused by:" in it && "Exit code is" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Out of Memory" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Failed to write minidump" in it }?.let { return it }
        findFirstInterestingLine(caseDetailText) { "Minidump written to" in it }?.let { return "Minidump written" }

        return "No explicit summary"
    }

    val rows = caseDirs.map { caseDir ->
        val compileText = readFirstExistingText(caseDir, listOf("app.kexe.log", "konanc.log"))
        val compileExitCode = parseExitCode(compileText)
        val compileStatus = if (compileExitCode == "0") "OK" else "FAIL"
        val runLogText = readFirstExistingText(caseDir, listOf("run.log"))
        val runStdErrText = caseDir.resolve("run.stderr.log").takeIf(File::exists)?.readText().orEmpty()
        val runExitCodeText = caseDir.resolve("run.exitcode.txt").takeIf(File::exists)?.readText()?.trim().orEmpty()
        val detailPage = detailPages.firstOrNull { (_, text) -> caseDir.name in text }
        val detailPath = detailPage?.first
        val detailText = detailPage?.second.orEmpty()
        val runExitCode = runExitCodeText.ifBlank {
            parseExitCode(runLogText).orEmpty()
        }.ifBlank {
            Regex("""Finished executing .*?/${Regex.escape(caseDir.name)}/app\.kexe\s+in .*? exit code (\d+)""")
                .findAll(detailText)
                .lastOrNull()
                ?.groupValues
                ?.get(1)
                .orEmpty()
        }.ifBlank { null }
        val runStatus = when {
            compileStatus != "OK" -> "NOT_RUN"
            runExitCode == "0" -> "OK"
            runExitCode != null -> "FAIL($runExitCode)"
            else -> "UNKNOWN"
        }
        val summary = when {
            compileStatus != "OK" -> firstMatchingLine(compileText, listOf("error:", "Undefined symbols", "COMPILATION_ERROR", "stderr:", "exitCode="))
            runStatus == "OK" -> "Passed"
            else -> summarizeRunFailure(caseDir.name, runStdErrText, detailText)
        }
        CaseRow(
            caseId = caseDir.name,
            compileStatus = compileStatus,
            runStatus = runStatus,
            summary = summary,
            artifactsPath = caseDir.relativeTo(runDirFile).path.replace(File.separatorChar, '/'),
            detailPath = detailPath,
        )
    }

    val passedCount = rows.count { it.compileStatus == "OK" && it.runStatus == "OK" }
    val compileFailedCount = rows.count { it.compileStatus != "OK" }
    val runFailedCount = rows.count { it.compileStatus == "OK" && it.runStatus != "OK" }
    val compileStatuses = rows.map { it.compileStatus }.distinct().sorted()
    val compileOptionsHtml = compileStatuses.joinToString("\n") { status ->
        """<option value="${escapeHtml(status)}">${escapeHtml(status)}</option>"""
    }

    runDirFile.resolve("case-index.html").writeText(
        """
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="utf-8"/>
        <title>GC Fuzz Case Index</title>
        <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 24px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #d0d7de; padding: 8px 10px; text-align: left; vertical-align: top; }
        th { background: #f6f8fa; }
        .filters th { background: #ffffff; }
        .filters input, .filters select {
            box-sizing: border-box;
            width: 100%;
            padding: 6px 8px;
            border: 1px solid #d0d7de;
            border-radius: 6px;
            font: inherit;
        }
        .toolbar {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
            margin: 16px 0;
        }
        .ok { color: #1a7f37; font-weight: 600; }
        .fail { color: #cf222e; font-weight: 600; }
        .muted { color: #57606a; }
        code { white-space: nowrap; }
        </style>
        </head>
        <body>
        <h1>GC Fuzz Case Index</h1>
        <p class="muted">runId=$runId, indexedCases=${rows.size}</p>
        <p class="muted">passed=$passedCount, compileFailed=$compileFailedCount, runFailed=$runFailedCount</p>
        <p><a href="index.html">Gradle Report</a> | <a href="topology-summary.html">Topology Coverage</a></p>
        <div class="toolbar">
        <span id="visibleCount" class="muted">visibleCases=${rows.size}</span>
        <button type="button" id="resetFilters">Reset filters</button>
        </div>
        <table id="caseTable">
        <thead>
        <tr>
        <th>Case</th>
        <th>Compile</th>
        <th>Run</th>
        <th>Summary</th>
        <th>Artifacts</th>
        <th>Detail</th>
        </tr>
        <tr class="filters">
        <th><input id="filterCase" type="text" placeholder="Filter case"/></th>
        <th>
        <select id="filterCompile">
        <option value="">All</option>
        $compileOptionsHtml
        </select>
        </th>
        <th>
        <select id="filterRun">
        <option value="">All</option>
        <option value="OK">OK</option>
        <option value="FAIL">FAIL</option>
        </select>
        </th>
        <th><input id="filterSummary" type="text" placeholder="Filter summary"/></th>
        <th></th>
        <th></th>
        </tr>
        </thead>
        <tbody id="caseTableBody">
        ${rows.joinToString("\n") { it.toHtml() }}
        </tbody>
        </table>
        <script>
        (() => {
            const caseInput = document.getElementById("filterCase");
            const compileSelect = document.getElementById("filterCompile");
            const runSelect = document.getElementById("filterRun");
            const summaryInput = document.getElementById("filterSummary");
            const visibleCount = document.getElementById("visibleCount");
            const resetButton = document.getElementById("resetFilters");
            const rows = Array.from(document.querySelectorAll("#caseTableBody tr"));
            const rowData = rows.map((row) => {
                const cells = row.cells;
                const runText = cells[2].textContent.trim().toLowerCase();
                return {
                    row,
                    caseText: cells[0].textContent.trim().toLowerCase(),
                    compileText: cells[1].textContent.trim().toLowerCase(),
                    runText,
                    runCategory: runText === "ok" ? "ok" : "fail",
                    summaryText: cells[3].textContent.trim().toLowerCase(),
                };
            });

            const normalize = (value) => value.trim().toLowerCase();
            let applyTimer = null;

            const applyFilters = () => {
                const caseFilter = normalize(caseInput.value);
                const compileFilter = normalize(compileSelect.value);
                const runFilter = normalize(runSelect.value);
                const summaryFilter = normalize(summaryInput.value);
                let visible = 0;

                rowData.forEach(({ row, caseText, compileText, runCategory, summaryText }) => {
                    const matches =
                        (!caseFilter || caseText.includes(caseFilter)) &&
                        (!compileFilter || compileText === compileFilter) &&
                        (!runFilter || runCategory === runFilter) &&
                        (!summaryFilter || summaryText.includes(summaryFilter));

                    row.style.display = matches ? "" : "none";
                    if (matches) visible += 1;
                });

                visibleCount.textContent = `visibleCases=${'$'}{visible}`;
            };

            const scheduleApplyFilters = () => {
                if (applyTimer !== null) {
                    window.clearTimeout(applyTimer);
                }
                applyTimer = window.setTimeout(() => {
                    applyTimer = null;
                    applyFilters();
                }, 120);
            };

            caseInput.addEventListener("input", scheduleApplyFilters);
            summaryInput.addEventListener("input", scheduleApplyFilters);
            compileSelect.addEventListener("change", applyFilters);
            runSelect.addEventListener("change", applyFilters);

            resetButton.addEventListener("click", () => {
                caseInput.value = "";
                compileSelect.value = "";
                runSelect.value = "";
                summaryInput.value = "";
                applyFilters();
            });

            applyFilters();
        })();
        </script>
        </body>
        </html>
        """.trimIndent()
    )
}

fun generateTopologyCoverageReport(runDirFile: File, runId: String) {
    fun escapeHtml(value: String): String =
        value
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    fun escapeJson(value: String): String = buildString {
        value.forEach { character ->
            when (character) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(character)
            }
        }
    }

    fun parseStringList(text: String, fieldName: String): List<String> {
        val section = Regex(
            """"${Regex.escape(fieldName)}"\s*:\s*\[(.*?)]""",
            setOf(RegexOption.DOT_MATCHES_ALL)
        ).find(text)?.groupValues?.get(1) ?: return emptyList()
        return Regex(""""([^"]+)"""")
            .findAll(section)
            .map { it.groupValues[1] }
            .toList()
    }

    fun parseCountMap(text: String, fieldName: String): Map<String, Int> {
        val section = Regex(
            """"${Regex.escape(fieldName)}"\s*:\s*\{(.*?)}""",
            setOf(RegexOption.DOT_MATCHES_ALL)
        ).find(text)?.groupValues?.get(1) ?: return emptyMap()
        return Regex(""""([^"]+)"\s*:\s*(\d+)""")
            .findAll(section)
            .associate { match -> match.groupValues[1] to match.groupValues[2].toInt() }
    }

    val topologyRules = linkedMapOf(
        "SINGLE_STRONG_SLOT_CAPSULE" to "Create a payload in one strong slot, observe it alive, clear the slot, then collect.",
        "REACHABILITY_CONSISTENCY" to "Publish through a strong root and verify reachability remains consistent across GC checkpoints.",
        "REACHABILITY_CONSISTENCY_CAPSULE" to "Isolate a reachability oracle capsule with a strong owner slot and explicit checkpoints.",
        "WEAK_DEAD_CAPSULE" to "Keep only a weak observation path and verify the object becomes dead after GC.",
        "CYCLE" to "Create a cyclic object graph and collect under cyclic reachability pressure.",
        "SHARED_NODE" to "Build multiple owners that share the same node and observe it through shared edges.",
        "GLOBAL_REATTACH" to "Detach and reattach a graph through a shared global root around GC.",
        "OLD_ROOT_CHURN" to "Repeatedly replace an old global root to stress stale root cleanup.",
        "ROOT_MIGRATION" to "Move a payload from one root/slot to another and collect after the source is cleared.",
        "ROOT_MIGRATION_CAPSULE" to "Run root migration inside an oracle capsule with controlled strong slots.",
        "DELETE_EDGE_THEN_GC" to "Delete an object edge and immediately collect to stress graph update barriers.",
        "CONCURRENT_ROOT_MIGRATION" to "Move root ownership across worker/main interactions while GC can interleave.",
        "WEAK_REF_LIFECYCLE" to "Publish, weakly observe, clear strong reachability, then collect weak lifecycle state.",
        "CONCURRENT_PUBLISH_CLEAR_GC" to "Publish and clear shared roots concurrently with explicit GC checkpoints.",
        "ARRAY_SLOT_GRAPH" to "Use ObjectArray slots as graph edges and collect while slot paths are observed.",
        "GRAPH_MUTATION_SEQUENCE" to "Apply a sequence of graph mutations across stores, clears, and GC checkpoints.",
        "FUNCTION_RETURN_ESCAPE" to "Return an object from a generated function and let it escape through a caller local.",
        "WORKER_ALLOC_PUBLISH" to "Allocate inside a worker and publish the object to a shared global root.",
        "MULTI_STAGE_ROOT_HANDOFF" to "Move a root through several intermediate slots before final observation.",
        "PING_PONG_ROOT_TRANSFER" to "Transfer root ownership back and forth between shared slots around GC.",
        "CONCURRENT_DUPLICATE_HANDOFF" to "Duplicate root handoff paths concurrently and clear redundant owners.",
        "LOCAL_GLOBAL_ARRAY_HANDOFF" to "Handoff a local payload through an array slot and a global root.",
        "STALE_OWNER_MUTATION_AFTER_HANDOFF" to "Mutate an old owner after handoff to stress stale owner/slot handling.",
        "THREAD_LOCAL_SHARED_HANDOFF" to "Move a root between thread-local and shared globals across worker boundaries.",
        "WORKER_CAPTURE_ROOT" to "Capture an existing root in a worker closure and observe it after worker/GC interleaving.",
        "MULTI_ROOT_STAGGERED_CLEAR" to "Publish through multiple roots and clear them in staggered order around GC.",
        "CONCURRENT_ARRAY_SLOT_HANDOFF" to "Handoff an array-slot payload between worker and main with GC checkpoints.",
        "ROOT_REPUBLISH_AFTER_CLEAR" to "Clear a shared root, collect, then republish the same payload through another path.",
        "TRY_FINALLY_ROOT_CLEAR" to "Clear roots in finally blocks while GC/allocation pressure surrounds control flow exit.",
        "RETURN_ESCAPE_WORKER_PUBLISH" to "Return an escaped local, publish it from a worker, clear the caller local, then collect.",
        "THREAD_LOCAL_CLEAR_ON_WORKER_EXIT" to "Publish via thread-local state, let the worker exit, then observe shared reachability.",
        "ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE" to "Clear an array slot, collect, restore it from a backup slot, then observe.",
        "WORKER_PUBLISH_MAIN_CLEAR_BARRIER" to "Use Signal/Wait checkpoints so main collects after worker publish and before worker clears the shared root.",
        "ARRAY_SLOT_CLEAR_RESTORE_BARRIER" to "Use Signal/Wait checkpoints so a worker collects after an array slot clear and before main restores it from backup.",
        "MIXED_FIELD_ARRAY_MUTATION_BARRIER" to "Mutate strong field and ObjectArray slot edges together around GC to compare barrier paths.",
        "LARGE_OBJECT_MULTI_FIELD_REWRITE" to "Rewrite several strong-reference fields in one large owner around allocation pressure and GC.",
        "OLD_ROOT_CHURN_WITH_ALLOCATION_BURST" to "Repeatedly rewrite a shared-rooted field with allocation bursts and GC between replacements.",
        "GRAPH_MUTATION_MULTI_PHASE_SEQUENCE" to "Run build, clear, reconnect, and observe graph mutation phases around GC checkpoints.",
        "SHARED_NODE_RECONNECT_BETWEEN_OWNERS" to "Move one shared node through several owners by clearing old edges and reconnecting new ones.",
        "CYCLE_BREAK_AND_REROOT" to "Break a cycle edge, keep the target through a new root, then reconnect and collect.",
        "WEAK_ROOT_HANDOFF" to "Create a weak alias while moving a strong root from one owner slot to another.",
        "WEAK_ARRAY_SLOT" to "Create a weak alias to an ObjectArray slot and observe it across slot clear and GC.",
        "WEAK_THREAD_LOCAL_ROOT" to "Create a weak alias while the strong root is handed off from thread-local to shared global state.",
        "WEAK_STRONG_GLOBAL_ALTERNATING" to "Alternate strong and weak global publication across clear, allocation, and GC phases.",
        "WEAK_LATE_STRONG_RESCUE" to "Clear a strong global, then attempt to republish it from the weak slot before observing both roots.",
        "WEAK_MULTI_EPOCH_OBSERVE" to "Observe a weak global across multiple GC epochs before and after strong root clearing.",
        "FINALIZER_GLOBAL_PUBLISH" to "Drop a finalizable object and let finalization publish a marker to a shared root.",
        "WORKER_RESULT_ESCAPE" to "Spawn a worker that returns an object via future; the result escapes into a caller local and becomes a new root.",
        "WORKER_RESULT_THEN_CLEAR_GC" to "Worker returns an object, caller publishes it, GC, then clears and observes again.",
        "NESTED_WORKER_ROOT_HANDOFF" to "Inner worker returns to outer worker, outer returns to main, testing multi-layer worker root merging.",
        "CAS_ROOT_CONTENTION" to "Multiple workers contend on a shared global root via compare-and-set, with GC interleaving.",
        "CFFI_CALLBACK_AFTER_GC" to "Publish a Kotlin object, collect, then touch it through a C callback roundtrip.",
        "CFFI_IDENTITY_HANDOFF" to "Send a root through a foreign identity roundtrip before publishing and collecting.",
    )

    val topologyFamilies = linkedMapOf(
        "SINGLE_STRONG_SLOT_CAPSULE" to "ORACLE",
        "REACHABILITY_CONSISTENCY" to "ORACLE",
        "REACHABILITY_CONSISTENCY_CAPSULE" to "ORACLE",
        "WEAK_DEAD_CAPSULE" to "ORACLE",
        "ROOT_MIGRATION_CAPSULE" to "ORACLE",
        "CYCLE" to "BASIC_GRAPH",
        "SHARED_NODE" to "BASIC_GRAPH",
        "GLOBAL_REATTACH" to "BASIC_GRAPH",
        "OLD_ROOT_CHURN" to "BASIC_GRAPH",
        "ROOT_MIGRATION" to "BASIC_GRAPH",
        "DELETE_EDGE_THEN_GC" to "BASIC_GRAPH",
        "ARRAY_SLOT_GRAPH" to "BASIC_GRAPH",
        "GRAPH_MUTATION_SEQUENCE" to "BASIC_GRAPH",
        "CONCURRENT_ROOT_MIGRATION" to "ROOT_LIFECYCLE",
        "CONCURRENT_PUBLISH_CLEAR_GC" to "ROOT_LIFECYCLE",
        "FUNCTION_RETURN_ESCAPE" to "ROOT_LIFECYCLE",
        "WORKER_ALLOC_PUBLISH" to "ROOT_LIFECYCLE",
        "MULTI_STAGE_ROOT_HANDOFF" to "ROOT_LIFECYCLE",
        "PING_PONG_ROOT_TRANSFER" to "ROOT_LIFECYCLE",
        "CONCURRENT_DUPLICATE_HANDOFF" to "ROOT_LIFECYCLE",
        "LOCAL_GLOBAL_ARRAY_HANDOFF" to "ROOT_LIFECYCLE",
        "STALE_OWNER_MUTATION_AFTER_HANDOFF" to "ROOT_LIFECYCLE",
        "THREAD_LOCAL_SHARED_HANDOFF" to "ROOT_LIFECYCLE",
        "WORKER_CAPTURE_ROOT" to "ROOT_LIFECYCLE",
        "MULTI_ROOT_STAGGERED_CLEAR" to "ROOT_LIFECYCLE",
        "CONCURRENT_ARRAY_SLOT_HANDOFF" to "ROOT_LIFECYCLE",
        "ROOT_REPUBLISH_AFTER_CLEAR" to "ROOT_LIFECYCLE",
        "TRY_FINALLY_ROOT_CLEAR" to "ROOT_LIFECYCLE",
        "RETURN_ESCAPE_WORKER_PUBLISH" to "ROOT_LIFECYCLE",
        "THREAD_LOCAL_CLEAR_ON_WORKER_EXIT" to "ROOT_LIFECYCLE",
        "ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE" to "ROOT_LIFECYCLE",
        "WORKER_PUBLISH_MAIN_CLEAR_BARRIER" to "ROOT_LIFECYCLE",
        "ARRAY_SLOT_CLEAR_RESTORE_BARRIER" to "ROOT_LIFECYCLE",
        "MIXED_FIELD_ARRAY_MUTATION_BARRIER" to "DIRTY_GRAPH_BARRIER",
        "LARGE_OBJECT_MULTI_FIELD_REWRITE" to "DIRTY_GRAPH_BARRIER",
        "OLD_ROOT_CHURN_WITH_ALLOCATION_BURST" to "DIRTY_GRAPH_BARRIER",
        "GRAPH_MUTATION_MULTI_PHASE_SEQUENCE" to "DIRTY_GRAPH_BARRIER",
        "SHARED_NODE_RECONNECT_BETWEEN_OWNERS" to "DIRTY_GRAPH_BARRIER",
        "CYCLE_BREAK_AND_REROOT" to "DIRTY_GRAPH_BARRIER",
        "WEAK_REF_LIFECYCLE" to "WEAK_REFERENCE",
        "WEAK_ROOT_HANDOFF" to "WEAK_REFERENCE",
        "WEAK_ARRAY_SLOT" to "WEAK_REFERENCE",
        "WEAK_THREAD_LOCAL_ROOT" to "WEAK_REFERENCE",
        "WEAK_STRONG_GLOBAL_ALTERNATING" to "WEAK_REFERENCE",
        "WEAK_LATE_STRONG_RESCUE" to "WEAK_REFERENCE",
        "WEAK_MULTI_EPOCH_OBSERVE" to "WEAK_REFERENCE",
        "FINALIZER_GLOBAL_PUBLISH" to "FINALIZATION",
        "WORKER_RESULT_ESCAPE" to "ROOT_LIFECYCLE",
        "WORKER_RESULT_THEN_CLEAR_GC" to "ROOT_LIFECYCLE",
        "NESTED_WORKER_ROOT_HANDOFF" to "ROOT_LIFECYCLE",
        "CAS_ROOT_CONTENTION" to "ROOT_LIFECYCLE",
        "CFFI_CALLBACK_AFTER_GC" to "CFFI",
        "CFFI_IDENTITY_HANDOFF" to "CFFI",
    )

    val structuralRules = linkedMapOf(
        "INTERFACE_POLYMORPHISM" to "Generate an interface, multiple concrete implementors, interface-typed roots/slots/returns, and dispatch through the interface payload method.",
        "SEALED_HIERARCHY" to "Generate a sealed base class with concrete subclasses and dispatch through a sealed-typed root using a when branch.",
        "SINGLETON_OBJECT_ROOT" to "Generate an object singleton with reference fields and access it as a long-lived root.",
        "INNER_CLASS_OUTER_CAPTURE" to "Generate an inner class instance that implicitly captures its outer object and dispatches back to the outer payload.",
    )

    data class CaseTopologyTelemetry(
        val caseId: String,
        val enabledTopologies: Set<String>,
        val attempts: Map<String, Int>,
        val hits: Map<String, Int>,
        val structuralHits: Map<String, Int>,
    ) {
        val hitTopologies: List<String>
            get() = hits.filterValues { it > 0 }.keys.sorted()

        val hitFamilies: List<String>
            get() = hitTopologies.mapNotNull { topologyFamilies[it] }.distinct().sorted()

        val hitStructuralKinds: List<String>
            get() = structuralHits.filterValues { it > 0 }.keys.sorted()
    }

    data class TopologyCoverageRow(
        val family: String,
        val name: String,
        val attempts: Int,
        val totalHits: Int,
        val casesHit: Int,
        val examples: List<String>,
    )

    data class FamilyCoverageRow(
        val family: String,
        val topologyCount: Int,
        val attempts: Int,
        val totalHits: Int,
        val casesHit: Int,
        val examples: List<String>,
    )

    data class StructuralCoverageRow(
        val name: String,
        val totalHits: Int,
        val casesHit: Int,
        val examples: List<String>,
    )

    val caseTelemetry = runDirFile.listFiles()
        ?.asSequence()
        ?.filter { it.isDirectory && it.name.startsWith("I") }
        ?.mapNotNull { caseDir ->
            val telemetryFile = caseDir.resolve("topology.json")
            if (!telemetryFile.isFile) return@mapNotNull null
            val text = telemetryFile.readText()
            CaseTopologyTelemetry(
                caseId = caseDir.name,
                enabledTopologies = parseStringList(text, "enabledTopologies").toSet(),
                attempts = parseCountMap(text, "topologyAttempts"),
                hits = parseCountMap(text, "topologyHits"),
                structuralHits = parseCountMap(text, "structuralHits"),
            )
        }
        ?.toList()
        .orEmpty()

    if (caseTelemetry.isEmpty()) return

    val topologyNames = caseTelemetry
        .flatMap { it.enabledTopologies + it.attempts.keys + it.hits.keys }
        .plus(topologyRules.keys)
        .distinct()
        .sorted()
    val missingRuleNames = topologyNames.filter { it !in topologyRules }
    require(missingRuleNames.isEmpty()) {
        "Missing topology rule descriptions: ${missingRuleNames.joinToString(", ")}"
    }
    val missingFamilyNames = topologyNames.filter { it !in topologyFamilies }
    require(missingFamilyNames.isEmpty()) {
        "Missing topology family descriptions: ${missingFamilyNames.joinToString(", ")}"
    }
    val structuralNames = caseTelemetry
        .flatMap { it.structuralHits.keys }
        .plus(structuralRules.keys)
        .distinct()
        .sorted()
    val missingStructuralRuleNames = structuralNames.filter { it !in structuralRules }
    require(missingStructuralRuleNames.isEmpty()) {
        "Missing structural coverage descriptions: ${missingStructuralRuleNames.joinToString(", ")}"
    }

    val rows = topologyNames.map { topologyName ->
        val attempts = caseTelemetry.sumOf { it.attempts[topologyName] ?: 0 }
        val totalHits = caseTelemetry.sumOf { it.hits[topologyName] ?: 0 }
        val hitCases = caseTelemetry.filter { (it.hits[topologyName] ?: 0) > 0 }
        TopologyCoverageRow(
            family = topologyFamilies.getValue(topologyName),
            name = topologyName,
            attempts = attempts,
            totalHits = totalHits,
            casesHit = hitCases.size,
            examples = hitCases.take(5).map { it.caseId },
        )
    }.sortedWith(compareBy<TopologyCoverageRow> { it.family }.thenBy { it.name })

    val familyRows = rows
        .groupBy { it.family }
        .map { (family, familyTopologies) ->
            val hitCases = caseTelemetry.filter { case ->
                case.hitTopologies.any { topologyFamilies[it] == family }
            }
            FamilyCoverageRow(
                family = family,
                topologyCount = familyTopologies.size,
                attempts = familyTopologies.sumOf { it.attempts },
                totalHits = familyTopologies.sumOf { it.totalHits },
                casesHit = hitCases.size,
                examples = hitCases.take(5).map { it.caseId },
            )
        }
        .sortedBy { it.family }

    val structuralRows = structuralNames.map { structuralName ->
        val totalHits = caseTelemetry.sumOf { it.structuralHits[structuralName] ?: 0 }
        val hitCases = caseTelemetry.filter { (it.structuralHits[structuralName] ?: 0) > 0 }
        StructuralCoverageRow(
            name = structuralName,
            totalHits = totalHits,
            casesHit = hitCases.size,
            examples = hitCases.take(5).map { it.caseId },
        )
    }.sortedBy { it.name }

    val totalCases = caseTelemetry.size
    fun rate(numerator: Int, denominator: Int): String =
        if (denominator == 0) "0.0000" else "%.4f".format(numerator.toDouble() / denominator.toDouble())

    runDirFile.resolve("structural-summary.csv").writeText(
        buildString {
            appendLine("kind,rule,totalHits,casesHit,caseHitRate,examples")
            structuralRows.forEach { row ->
                appendLine(
                    listOf(
                        row.name,
                        structuralRules[row.name].orEmpty(),
                        row.totalHits.toString(),
                        row.casesHit.toString(),
                        rate(row.casesHit, totalCases),
                        row.examples.joinToString("|"),
                    ).joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" }
                )
            }
        }
    )

    runDirFile.resolve("topology-summary.csv").writeText(
        buildString {
            appendLine("family,topology,rule,attempts,totalHits,casesHit,caseHitRate,emitSuccessRate,examples")
            rows.forEach { row ->
                appendLine(
                    listOf(
                        row.family,
                        row.name,
                        topologyRules[row.name].orEmpty(),
                        row.attempts.toString(),
                        row.totalHits.toString(),
                        row.casesHit.toString(),
                        rate(row.casesHit, totalCases),
                        rate(row.totalHits, row.attempts),
                        row.examples.joinToString("|"),
                    ).joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" }
                )
            }
        }
    )

    runDirFile.resolve("topology-family-summary.csv").writeText(
        buildString {
            appendLine("family,topologyCount,attempts,totalHits,casesHit,caseHitRate,emitSuccessRate,examples")
            familyRows.forEach { row ->
                appendLine(
                    listOf(
                        row.family,
                        row.topologyCount.toString(),
                        row.attempts.toString(),
                        row.totalHits.toString(),
                        row.casesHit.toString(),
                        rate(row.casesHit, totalCases),
                        rate(row.totalHits, row.attempts),
                        row.examples.joinToString("|"),
                    ).joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" }
                )
            }
        }
    )

    runDirFile.resolve("topology-case-hits.csv").writeText(
        buildString {
            appendLine("caseId,hitCount,hitFamilies,hitTopologies")
            caseTelemetry.sortedBy { it.caseId }.forEach { case ->
                appendLine(
                    listOf(
                        case.caseId,
                        case.hitTopologies.size.toString(),
                        case.hitFamilies.joinToString("|"),
                        case.hitTopologies.joinToString("|"),
                    ).joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" }
                )
            }
        }
    )

    runDirFile.resolve("topology-summary.json").writeText(
        buildString {
            appendLine("{")
            appendLine("""  "runId": "${escapeJson(runId)}",""")
            appendLine("""  "totalCases": $totalCases,""")
            appendLine("""  "structuralCoverage": [""")
            structuralRows.forEachIndexed { index, row ->
                appendLine("    {")
                appendLine("""      "name": "${escapeJson(row.name)}",""")
                appendLine("""      "rule": "${escapeJson(structuralRules[row.name].orEmpty())}",""")
                appendLine("""      "totalHits": ${row.totalHits},""")
                appendLine("""      "casesHit": ${row.casesHit},""")
                appendLine("""      "caseHitRate": ${rate(row.casesHit, totalCases)},""")
                appendLine(
                    """      "examples": [${row.examples.joinToString(", ") { "\"${escapeJson(it)}\"" }}]"""
                )
                append("    }")
                if (index != structuralRows.lastIndex) appendLine(",") else appendLine()
            }
            appendLine("  ],")
            appendLine("""  "families": [""")
            familyRows.forEachIndexed { index, row ->
                appendLine("    {")
                appendLine("""      "name": "${escapeJson(row.family)}",""")
                appendLine("""      "topologyCount": ${row.topologyCount},""")
                appendLine("""      "attempts": ${row.attempts},""")
                appendLine("""      "totalHits": ${row.totalHits},""")
                appendLine("""      "casesHit": ${row.casesHit},""")
                appendLine("""      "caseHitRate": ${rate(row.casesHit, totalCases)},""")
                appendLine("""      "emitSuccessRate": ${rate(row.totalHits, row.attempts)},""")
                appendLine(
                    """      "examples": [${row.examples.joinToString(", ") { "\"${escapeJson(it)}\"" }}]"""
                )
                append("    }")
                if (index != familyRows.lastIndex) appendLine(",") else appendLine()
            }
            appendLine("  ],")
            appendLine("""  "topologies": [""")
            rows.forEachIndexed { index, row ->
                appendLine("    {")
                appendLine("""      "family": "${escapeJson(row.family)}",""")
                appendLine("""      "name": "${escapeJson(row.name)}",""")
                appendLine("""      "rule": "${escapeJson(topologyRules[row.name].orEmpty())}",""")
                appendLine("""      "attempts": ${row.attempts},""")
                appendLine("""      "totalHits": ${row.totalHits},""")
                appendLine("""      "casesHit": ${row.casesHit},""")
                appendLine("""      "caseHitRate": ${rate(row.casesHit, totalCases)},""")
                appendLine("""      "emitSuccessRate": ${rate(row.totalHits, row.attempts)},""")
                appendLine(
                    """      "examples": [${row.examples.joinToString(", ") { "\"${escapeJson(it)}\"" }}]"""
                )
                append("    }")
                if (index != rows.lastIndex) appendLine(",") else appendLine()
            }
            appendLine("  ],")
            appendLine("""  "caseCoverage": [""")
            caseTelemetry.sortedBy { it.caseId }.forEachIndexed { index, case ->
                appendLine("    {")
                appendLine("""      "caseId": "${escapeJson(case.caseId)}",""")
                appendLine("""      "hitCount": ${case.hitTopologies.size},""")
                appendLine(
                    """      "hitFamilies": [${case.hitFamilies.joinToString(", ") { "\"${escapeJson(it)}\"" }}],"""
                )
                appendLine(
                    """      "hitTopologies": [${case.hitTopologies.joinToString(", ") { "\"${escapeJson(it)}\"" }}],"""
                )
                appendLine(
                    """      "structuralHits": {${case.structuralHits.entries.sortedBy { it.key }.joinToString(", ") { "\"${escapeJson(it.key)}\": ${it.value}" }}}"""
                )
                append("    }")
                if (index != caseTelemetry.lastIndex) appendLine(",") else appendLine()
            }
            appendLine("  ]")
            appendLine("}")
        }
    )

    val maxCasesHit = maxOf(1, rows.maxOfOrNull { it.casesHit } ?: 0)
    val maxTotalHits = maxOf(1, rows.maxOfOrNull { it.totalHits } ?: 0)
    val maxFamilyCasesHit = maxOf(1, familyRows.maxOfOrNull { it.casesHit } ?: 0)
    val maxFamilyTotalHits = maxOf(1, familyRows.maxOfOrNull { it.totalHits } ?: 0)
    val maxStructuralCasesHit = maxOf(1, structuralRows.maxOfOrNull { it.casesHit } ?: 0)
    val maxStructuralTotalHits = maxOf(1, structuralRows.maxOfOrNull { it.totalHits } ?: 0)
    val structuralRowsHtml = structuralRows.joinToString("\n") { row ->
        val caseBarWidth = row.casesHit * 100 / maxStructuralCasesHit
        val hitBarWidth = row.totalHits * 100 / maxStructuralTotalHits
        """
        <tr>
        <td><code>${escapeHtml(row.name)}</code></td>
        <td>${escapeHtml(structuralRules.getValue(row.name))}</td>
        <td>${row.totalHits}</td>
        <td>${row.casesHit}</td>
        <td><div class="bar"><span style="width: ${caseBarWidth}%"></span></div><code>${rate(row.casesHit, totalCases)}</code></td>
        <td><div class="bar alt"><span style="width: ${hitBarWidth}%"></span></div></td>
        <td>${escapeHtml(row.examples.joinToString(", "))}</td>
        </tr>
        """.trimIndent()
    }
    val familyRowsHtml = familyRows.joinToString("\n") { row ->
        val caseBarWidth = row.casesHit * 100 / maxFamilyCasesHit
        val hitBarWidth = row.totalHits * 100 / maxFamilyTotalHits
        """
        <tr>
        <td><code>${escapeHtml(row.family)}</code></td>
        <td>${row.topologyCount}</td>
        <td>${row.attempts}</td>
        <td>${row.totalHits}</td>
        <td>${row.casesHit}</td>
        <td><div class="bar"><span style="width: ${caseBarWidth}%"></span></div><code>${rate(row.casesHit, totalCases)}</code></td>
        <td><div class="bar alt"><span style="width: ${hitBarWidth}%"></span></div><code>${rate(row.totalHits, row.attempts)}</code></td>
        <td>${escapeHtml(row.examples.joinToString(", "))}</td>
        </tr>
        """.trimIndent()
    }
    val rowHtml = rows.joinToString("\n") { row ->
        val caseBarWidth = row.casesHit * 100 / maxCasesHit
        val hitBarWidth = row.totalHits * 100 / maxTotalHits
        """
        <tr>
        <td><code>${escapeHtml(row.family)}</code></td>
        <td><code>${escapeHtml(row.name)}</code></td>
        <td>${escapeHtml(topologyRules.getValue(row.name))}</td>
        <td>${row.attempts}</td>
        <td>${row.totalHits}</td>
        <td>${row.casesHit}</td>
        <td><div class="bar"><span style="width: ${caseBarWidth}%"></span></div><code>${rate(row.casesHit, totalCases)}</code></td>
        <td><div class="bar alt"><span style="width: ${hitBarWidth}%"></span></div><code>${rate(row.totalHits, row.attempts)}</code></td>
        <td>${escapeHtml(row.examples.joinToString(", "))}</td>
        </tr>
        """.trimIndent()
    }
    val caseRowsHtml = caseTelemetry.sortedBy { it.caseId }.joinToString("\n") { case ->
        """
        <tr>
        <td><code>${escapeHtml(case.caseId)}</code></td>
        <td>${case.hitTopologies.size}</td>
        <td>${escapeHtml(case.hitFamilies.joinToString(", "))}</td>
        <td>${escapeHtml(case.hitTopologies.joinToString(", "))}</td>
        <td>${escapeHtml(case.hitStructuralKinds.joinToString(", "))}</td>
        </tr>
        """.trimIndent()
    }
    runDirFile.resolve("topology-summary.html").writeText(
        """
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="utf-8"/>
        <title>GC Fuzz Topology Coverage</title>
        <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 24px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #d0d7de; padding: 8px 10px; text-align: left; vertical-align: top; }
        th { background: #f6f8fa; }
        input { box-sizing: border-box; width: 100%; padding: 6px 8px; border: 1px solid #d0d7de; border-radius: 6px; font: inherit; }
        .bar { display: inline-block; width: 120px; height: 10px; margin-right: 8px; background: #eaeef2; vertical-align: middle; }
        .bar span { display: block; height: 100%; background: #2da44e; }
        .bar.alt span { background: #0969da; }
        .muted { color: #57606a; }
        code { white-space: nowrap; }
        </style>
        </head>
        <body>
        <h1>GC Fuzz Topology Coverage</h1>
        <p class="muted">runId=${escapeHtml(runId)}, telemetryCases=$totalCases</p>
        <p><a href="case-index.html">Case Index</a> | <a href="topology-summary.json">JSON</a> | <a href="structural-summary.csv">Structural CSV</a> | <a href="topology-family-summary.csv">Family CSV</a> | <a href="topology-summary.csv">Topology CSV</a> | <a href="topology-case-hits.csv">Case Hits CSV</a></p>
        <h2>Structural Coverage</h2>
        <table>
        <thead>
        <tr>
        <th>Kind</th>
        <th>Rule</th>
        <th>Total Hits</th>
        <th>Cases Hit</th>
        <th>Case Hit Rate</th>
        <th>Hit Volume</th>
        <th>Examples</th>
        </tr>
        </thead>
        <tbody>
        $structuralRowsHtml
        </tbody>
        </table>
        <h2>Topology Family Coverage</h2>
        <table>
        <thead>
        <tr>
        <th>Family</th>
        <th>Topologies</th>
        <th>Attempts</th>
        <th>Total Hits</th>
        <th>Cases Hit</th>
        <th>Case Hit Rate</th>
        <th>Emit Success Rate</th>
        <th>Examples</th>
        </tr>
        </thead>
        <tbody>
        $familyRowsHtml
        </tbody>
        </table>
        <h2>Topology Rules And Coverage</h2>
        <table>
        <thead>
        <tr>
        <th>Family</th>
        <th>Topology</th>
        <th>Rule</th>
        <th>Attempts</th>
        <th>Total Hits</th>
        <th>Cases Hit</th>
        <th>Case Hit Rate</th>
        <th>Emit Success Rate</th>
        <th>Examples</th>
        </tr>
        </thead>
        <tbody>
        $rowHtml
        </tbody>
        </table>
        <h2>Case Coverage</h2>
        <p class="muted">Every generated case with telemetry is listed here. Use the filter to search by case id or topology name.</p>
        <input id="caseFilter" type="text" placeholder="Filter cases or topology names"/>
        <table id="caseTable">
        <thead>
        <tr>
        <th>Case</th>
        <th>Hit Count</th>
        <th>Hit Families</th>
        <th>Hit Topologies</th>
        <th>Structural Hits</th>
        </tr>
        </thead>
        <tbody>
        $caseRowsHtml
        </tbody>
        </table>
        <script>
        (() => {
            const input = document.getElementById("caseFilter");
            const rows = Array.from(document.querySelectorAll("#caseTable tbody tr"));
            input.addEventListener("input", () => {
                const query = input.value.toLowerCase();
                rows.forEach(row => {
                    row.style.display = row.innerText.toLowerCase().includes(query) ? "" : "none";
                });
            });
        })();
        </script>
        </body>
        </html>
        """.trimIndent()
    )
}

tasks.test {
    useJUnitPlatform()
    addTestOutputListener { _: TestDescriptor, event: TestOutputEvent ->
        event.message
            .lineSequence()
            .map { it.trimEnd() }
            .filter { it.startsWith("[gcfuzz]") }
            .forEach { logger.lifecycle(it) }
    }

    fun findGCFuzzingProperty(name: String): Any? =
        project.findProperty(name) ?: System.getProperty(name)

    fun findToolchainProperty(name: String): Any? =
        project.findProperty(name) ?: System.getProperty(name)

    findGCFuzzingProperty("gcfuzzing.libcrtPath")?.toString()?.takeIf { it.isNotBlank() }?.let {
        environment("LIBCRT_PATH", it)
    }

    val defaultRunId = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"))

    findGCFuzzingProperty("gcfuzzing.single.id")?.let {
        systemProperty("gcfuzzing.single.id", it)
    }
    findGCFuzzingProperty("gcfuzzing.softTimeout")?.let {
        systemProperty("gcfuzzing.softTimeout", it)
    }
    findGCFuzzingProperty("gcfuzzing.executionModel")?.let {
        systemProperty("gcfuzzing.executionModel", it)
    }
    findGCFuzzingProperty("gcfuzzing.cffi")?.let {
        systemProperty("gcfuzzing.cffi", it)
    }
    findGCFuzzingProperty("gcfuzzing.gc")?.let {
        systemProperty("gcfuzzing.gc", it)
    }
    findGCFuzzingProperty("gcfuzzing.libcrtPath")?.let {
        systemProperty("gcfuzzing.libcrtPath", it)
    }
    findGCFuzzingProperty("gcfuzzing.parallelCompilation")?.let {
        systemProperty("gcfuzzing.parallelCompilation", it)
    }
    findGCFuzzingProperty("gcfuzzing.parallelism")?.let {
        systemProperty("gcfuzzing.parallelism", it)
    }
    findGCFuzzingProperty("gcfuzzing.incrementalCompilation")?.let {
        systemProperty("gcfuzzing.incrementalCompilation", it)
    }
    findGCFuzzingProperty("gcfuzzing.asan")?.let {
        systemProperty("gcfuzzing.asan", it)
    }
    findGCFuzzingProperty("gcfuzzing.buildType")?.let {
        systemProperty("gcfuzzing.buildType", it)
    }
    findGCFuzzingProperty("gcfuzzing.ohos.serial")?.let {
        systemProperty("gcfuzzing.ohos.serial", it)
    }
    findGCFuzzingProperty("gcfuzzing.ohos.remoteDir")?.let {
        systemProperty("gcfuzzing.ohos.remoteDir", it)
    }
    findGCFuzzingProperty("gcfuzzing.target")?.let {
        systemProperty("gcfuzzing.target", it)
    }
    findToolchainProperty("kn.nativeHome")?.let {
        systemProperty("kn.nativeHome", it)
    }
    findToolchainProperty("kotlin.internal.native.test.nativeHome")?.let {
        systemProperty("kotlin.internal.native.test.nativeHome", it)
    }

    systemProperty("gcfuzzing.timelimit", findGCFuzzingProperty("gcfuzzing.timelimit") ?: "1h")
    systemProperty("gcfuzzing.seed", findGCFuzzingProperty("gcfuzzing.seed") ?: Random.nextInt())

    val runId = (findGCFuzzingProperty("gcfuzzing.runId") ?: defaultRunId).toString()
    systemProperty("gcfuzzing.runId", runId)
    val defaultResultsRoot = rootProject.layout.projectDirectory.dir("workspace/runs").asFile.absoluteFile
    val resultsRootDir = (
        findGCFuzzingProperty("gcfuzzing.resultsRoot")?.toString()
            ?.takeIf { it.isNotBlank() }
            ?.let(::File)
            ?.absoluteFile
            ?: defaultResultsRoot
    )
    systemProperty("gcfuzzing.resultsRoot", resultsRootDir.absolutePath)

    val runDirFile = resultsRootDir.resolve(runId)
    reports.html.required = true
    reports.html.outputLocation.set(layout.dir(providers.provider { runDirFile }))
    environment("GCFUZZ_RESULTS_ROOT", resultsRootDir.absolutePath)
    runDirFile.mkdirs()

    ignoreFailures = true
    var failedTestCount = 0L
    addTestListener(object : TestListener {
        override fun beforeSuite(suite: TestDescriptor) = Unit

        override fun afterSuite(suite: TestDescriptor, result: TestResult) {
            if (suite.parent == null) {
                failedTestCount = result.failedTestCount
            }
        }

        override fun beforeTest(testDescriptor: TestDescriptor) = Unit

        override fun afterTest(testDescriptor: TestDescriptor, result: TestResult) = Unit
    })

    val standardReportDir = layout.buildDirectory.dir("reports/tests/$name").get().asFile
    val standardReportPath = standardReportDir.toPath()
    if (Files.isSymbolicLink(standardReportPath)) {
        Files.deleteIfExists(standardReportPath)
    } else if (standardReportDir.exists()) {
        standardReportDir.deleteRecursively()
    }
    standardReportDir.parentFile.mkdirs()
    Files.createSymbolicLink(standardReportPath, runDirFile.toPath())

    systemProperty("kotlin.internal.native.test.optimizationMode", "OPT")

    doLast {
        generateCaseIndexReport(runDirFile, runId)
        generateTopologyCoverageReport(runDirFile, runId)
        if (failedTestCount > 0) {
            throw GradleException("There were failing tests. See the report at: ${runDirFile.resolve("index.html").toURI()}")
        }
    }

    doNotTrackState(
        "Fuzzer is randomized + certain race conditions can manifest unreproducibly even from the fixed seed"
    )
    notCompatibleWithConfigurationCache("Uses dynamic listeners and post-processing to preserve per-case fuzz reports")
}
