/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.mode.ArkTsScenarioModeDescriptor
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.mode.PureKotlinCInteropScenarioGenerationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.mode.PureKotlinScenarioGenerationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.mode.PureKotlinScenarioModeDescriptor

internal object ScenarioModeRegistry {
    private val descriptors: List<ScenarioModeDescriptor> = listOf(
        PureKotlinScenarioModeDescriptor,
        ArkTsScenarioModeDescriptor,
    )

    fun resolve(executionModel: String?): ScenarioModeDescriptor {
        val normalizedExecutionModel = executionModel?.lowercase().orEmpty()
        return descriptors.firstOrNull { descriptor -> normalizedExecutionModel in descriptor.aliases }
            ?: error("Unknown gcfuzzing.executionModel: $executionModel")
    }

    fun resolveGenerationProfile(executionModel: String?, enableCInterop: Boolean): ScenarioGenerationProfile {
        val descriptor = resolve(executionModel)
        return when {
            descriptor === PureKotlinScenarioModeDescriptor && enableCInterop -> PureKotlinCInteropScenarioGenerationProfile
            else -> descriptor.generationProfile
        }
    }
}
