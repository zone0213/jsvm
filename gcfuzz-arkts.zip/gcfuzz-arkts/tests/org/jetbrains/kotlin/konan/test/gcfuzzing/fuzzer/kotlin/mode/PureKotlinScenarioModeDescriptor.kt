/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlin.resolvePureKotlinScenarioGeneratedSourceDir
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlin.runPureKotlinScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ProgramId
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioModeDescriptor
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenarioWithMetadata
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend.PureKotlinScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save

internal object PureKotlinScenarioModeDescriptor : ScenarioModeDescriptor {
    override val aliases: Set<String> = setOf("", "pure-kotlin", "pure_kotlin", "pure")
    override val generationProfile = PureKotlinScenarioGenerationProfile

    override fun execute(
        host: StandaloneExecutionHost,
        id: ProgramId,
        config: ScenarioBackendConfig,
    ) {
        val name = id.toString()
        val generatedSourceDir = host.resolvePureKotlinScenarioGeneratedSourceDir(name)
        val generationProfile = if (config.enableCInterop) {
            PureKotlinCInteropScenarioGenerationProfile
        } else {
            generationProfile
        }
        val generated = generateScenarioWithMetadata(id.seed(), generationProfile.features)
        val output = PureKotlinScenarioBackend.lower(generated.program, config)
        output.save(generatedSourceDir)
        generated.telemetry.save(generatedSourceDir.parentFile.resolve("topology.json"), name)
        host.runPureKotlinScenario(name, output, host.executionTimeout)
    }
}

private fun ProgramId.seed(): UInt = when (this) {
    is ProgramId.Initial -> seed
}
