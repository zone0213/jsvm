/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.execution

import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.time.Duration

internal data class ProcessExecutionResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
)

internal class ProcessExecutionException(
    val command: List<String>,
    val exitCode: Int?,
    val stdout: String,
    val stderr: String,
) : RuntimeException("Command failed: $command exitCode=${exitCode ?: "TIMEOUT"}")

internal object ProcessRunner {
    fun run(
        command: List<String>,
        timeout: Duration,
        workingDirectory: File? = null,
        environment: Map<String, String> = emptyMap(),
    ): ProcessExecutionResult {
        val process = ProcessBuilder(command)
            .directory(workingDirectory)
            .apply {
                if (environment.isNotEmpty()) {
                    this.environment().putAll(environment)
                }
            }
            .start()

        val stdoutReader = process.stdoutReader()
        val stderrReader = process.stderrReader()
        val finished = process.waitFor(timeout.inWholeMilliseconds, TimeUnit.MILLISECONDS)
        if (!finished) {
            process.destroyForcibly()
        }

        val stdout = stdoutReader.joinAndGet()
        val stderr = stderrReader.joinAndGet()
        if (!finished) {
            throw ProcessExecutionException(command, null, stdout, stderr)
        }

        val exitCode = process.exitValue()
        if (exitCode != 0) {
            throw ProcessExecutionException(command, exitCode, stdout, stderr)
        }

        return ProcessExecutionResult(exitCode, stdout, stderr)
    }

    private fun Process.stdoutReader(): ReaderHandle = inputStream.readerHandle()

    private fun Process.stderrReader(): ReaderHandle = errorStream.readerHandle()

    private fun InputStream.readerHandle(): ReaderHandle {
        val builder = StringBuilder()
        val worker = thread(start = true, isDaemon = true) {
            bufferedReader().useLines { lines ->
                lines.forEach {
                    builder.appendLine(it)
                }
            }
        }
        return ReaderHandle(worker, builder)
    }

    private data class ReaderHandle(
        val worker: Thread,
        val output: StringBuilder,
    ) {
        fun joinAndGet(): String {
            worker.join()
            return output.toString()
        }
    }
}
