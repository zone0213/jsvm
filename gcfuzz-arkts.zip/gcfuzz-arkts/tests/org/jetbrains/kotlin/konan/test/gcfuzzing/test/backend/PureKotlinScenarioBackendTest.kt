/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDomain
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend.PureKotlinScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend.PureKotlinScenarioLowering
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.withExecutionModel
import org.junit.jupiter.api.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class PureKotlinScenarioBackendTest {
    @Test
    fun scenarioPureKotlinBackendIsDeterministicForMultipleSeeds() {
        withExecutionModel("pure-kotlin") {
            listOf(0u, 1u, 2u, 3u, 7u, 11u, 19u, 23u, 31u, 127u).forEach { seed ->
                assertPureKotlinBackendIsDeterministic(seed)
            }
        }
    }

    private fun assertPureKotlinBackendIsDeterministic(seed: UInt) {
        val scenario = generateScenario(seed)
        val first = PureKotlinScenarioBackend.lower(scenario)
        val second = PureKotlinScenarioBackend.lower(scenario)

        assertEquals(first.filename, second.filename, "filename mismatch for seed=$seed")
        assertEquals(first.args, second.args, "args mismatch for seed=$seed")
        assertEquals(first.contents, second.contents, "contents mismatch for seed=$seed")
    }

    @Test
    fun scenarioPureKotlinBackendProducesStandaloneMainKt() {
        withExecutionModel("pure-kotlin") {
            (32u..47u).forEach { seed ->
                val output = PureKotlinScenarioBackend.lower(generateScenario(seed))
                assertEquals("main.kt", output.filename, "filename mismatch for seed=$seed")
                assertEquals(listOf("-opt", "-entry", "main"), output.args, "args mismatch for seed=$seed")
                assertTrue("fun main()" in output.contents, "Expected a main entrypoint for seed=$seed")
                assertTrue("interface KotlinIndexAccess" in output.contents, "Expected Kotlin heap helpers for seed=$seed")
                assertTrue("performGC" in output.contents, "Expected GC helper usage for seed=$seed")
            }
        }
    }

    @Test
    fun scenarioPureKotlinLoweringNormalizesTargetsAndDomains() {
        val lowered = PureKotlinScenarioLowering.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(
                        ScenarioTargetLanguage.ObjC,
                        listOf(ScenarioField.StrongRef),
                    ),
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Java,
                        ScenarioField.StrongRef,
                        ScenarioGlobalStorage.ThreadLocal,
                    ),
                    ScenarioDefinition.Function(
                        ScenarioTargetLanguage.ObjC,
                        emptyList(),
                        ScenarioBodyWithReturn(
                            body = ScenarioBody(
                                listOf(
                                    ScenarioOp.CreateObject(
                                        localId = 0,
                                        classId = 0,
                                        domain = ScenarioDomain.Native,
                                    ),
                                    ScenarioOp.Store(
                                        location = ScenarioLocation.Global(
                                            globalId = 1,
                                            path = ScenarioPath(emptyList()),
                                            domain = ScenarioDomain.Java,
                                        ),
                                        value = ScenarioValue.LocalRef(
                                            localId = 0,
                                            domain = ScenarioDomain.ObjC,
                                        ),
                                    ),
                                    ScenarioOp.CallFunction(
                                        functionId = 2,
                                        args = listOf(ScenarioValue.GlobalRef(1, domain = ScenarioDomain.Native)),
                                        domain = ScenarioDomain.Java,
                                    ),
                                    ScenarioOp.PerformGc(ScenarioDomain.Native),
                                ),
                            ),
                            returnValue = ScenarioValue.GlobalRef(1, domain = ScenarioDomain.ObjC),
                        ),
                    ),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.SpawnFunction(
                            functionId = 2,
                            args = listOf(ScenarioValue.GlobalRef(1, domain = ScenarioDomain.Native)),
                            domain = ScenarioDomain.ObjC,
                        ),
                        ScenarioOp.Observe(
                            ScenarioValue.GlobalRef(1, domain = ScenarioDomain.Java),
                        ),
                    ),
                ),
            )
        )

        lowered.definitions.forEach { definition ->
            assertEquals(ScenarioTargetLanguage.Kotlin, definition.targetLanguage)
        }

        val function = lowered.definitions.filterIsInstance<ScenarioDefinition.Function>().single()
        val createObject = function.body.body.statements[0] as ScenarioOp.CreateObject
        val store = function.body.body.statements[1] as ScenarioOp.Store
        val call = function.body.body.statements[2] as ScenarioOp.CallFunction
        val performGc = function.body.body.statements[3] as ScenarioOp.PerformGc
        val mainSpawn = lowered.mainBody.statements[0] as ScenarioOp.SpawnFunction
        val mainObserve = lowered.mainBody.statements[1] as ScenarioOp.Observe

        assertEquals(ScenarioDomain.Kotlin, createObject.domain)
        assertEquals(ScenarioDomain.Kotlin, (store.location as ScenarioLocation.Global).domain)
        assertEquals(ScenarioDomain.Kotlin, (store.value as ScenarioValue.LocalRef).domain)
        assertEquals(ScenarioDomain.Kotlin, call.domain)
        assertEquals(ScenarioDomain.Kotlin, (call.args.single() as ScenarioValue.GlobalRef).domain)
        assertEquals(ScenarioDomain.Kotlin, performGc.domain)
        assertEquals(ScenarioDomain.Kotlin, (function.body.returnValue as ScenarioValue.GlobalRef).domain)
        assertEquals(ScenarioDomain.Kotlin, mainSpawn.domain)
        assertEquals(ScenarioDomain.Kotlin, (mainSpawn.args.single() as ScenarioValue.GlobalRef).domain)
        assertEquals(ScenarioDomain.Kotlin, (mainObserve.value as ScenarioValue.GlobalRef).domain)
        assertEquals(ScenarioStoreReferenceKind.Strong, store.referenceKind)
    }

    @Test
    fun scenarioPureKotlinLoweringPreservesWeakReferences() {
        val weakLowered = PureKotlinScenarioLowering.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.WeakRef,
                    ),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Store(
                            location = ScenarioLocation.Global(0),
                            value = ScenarioValue.NullValue,
                            referenceKind = ScenarioStoreReferenceKind.Weak,
                        ),
                    ),
                ),
            )
        )

        val weakStore = weakLowered.mainBody.statements.single() as ScenarioOp.Store
        assertEquals(ScenarioStoreReferenceKind.Weak, weakStore.referenceKind)
    }

    @Test
    fun scenarioPureKotlinBackendRejectsUnsupportedForeignRoundTripWithoutCffi() {
        val scenario = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.ForeignRoundTrip(ScenarioValue.DefaultValue),
                ),
            ),
        )

        val failure = assertFailsWith<IllegalStateException> {
            PureKotlinScenarioBackend.lower(scenario)
        }
        assertTrue(
            "unsupported op FOREIGN_ROUNDTRIP" in failure.message.orEmpty(),
            "Expected unsupported ForeignRoundTrip to fail in capability validation",
        )
    }
}
