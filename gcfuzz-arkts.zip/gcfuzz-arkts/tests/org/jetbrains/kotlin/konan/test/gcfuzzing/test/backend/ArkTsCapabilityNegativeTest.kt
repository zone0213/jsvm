/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.junit.jupiter.api.Test
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class ArkTsCapabilityNegativeTest {
    @Test
    fun unsupportedSpawnOpFailsFastAtLower() {
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.ArkTs, listOf(ScenarioField.StrongRef)),
            ),
            mainBody = ScenarioBody(
                listOf(ScenarioOp.Spawn(body = listOf(ScenarioOp.PerformGc())))
            )
        )
        val failure = assertFailsWith<IllegalStateException> { ArkTsScenarioBackend.lower(program) }
        assertTrue(failure.message!!.contains("not supported"), "expected capability failure, got: ${failure.message}")
    }

    @Test
    fun unsupportedWeakFieldFailsFastAtLower() {
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.ArkTs,
                    listOf(ScenarioField.WeakRef),
                ),
            ),
            mainBody = ScenarioBody(listOf(ScenarioOp.PerformGc()))
        )
        assertFailsWith<IllegalStateException> { ArkTsScenarioBackend.lower(program) }
    }

    @Test
    fun unsupportedThreadLocalGlobalFailsFastAtLower() {
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Global(
                    ScenarioTargetLanguage.ArkTs,
                    ScenarioField.StrongRef,
                    ScenarioGlobalStorage.ThreadLocal,
                ),
            ),
            mainBody = ScenarioBody(listOf(ScenarioOp.PerformGc()))
        )
        assertFailsWith<IllegalStateException> { ArkTsScenarioBackend.lower(program) }
    }
}
