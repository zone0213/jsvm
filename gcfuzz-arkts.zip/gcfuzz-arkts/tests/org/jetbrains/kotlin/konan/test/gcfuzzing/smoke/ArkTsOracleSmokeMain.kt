@file:JvmName("ArkTsOracleSmokeMain")
package org.jetbrains.kotlin.konan.test.gcfuzzing

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save
import java.io.File

// Hand-written IR shaped like the WEAK_DEAD_CAPSULE topology: a payload created inside a Block
// with a WeakRef observation, then required to die after GC. This exercises the
// CreateReachabilityObservation / CheckReachabilityObservation translation path + the
// registerObservation wiring directly, since the generator's topologyAttemptOrder rarely
// routes to ORACLE capsules when non-ORACLE families are also enabled.
fun main(args: Array<String>) {
    val program = ScenarioProgram(
        definitions = listOf(
            ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.ArkTs,
                fields = listOf(ScenarioField.StrongRef),
            )
        ),
        mainBody = ScenarioBody(
            statements = listOf(
                ScenarioOp.Block(
                    body = listOf(
                        ScenarioOp.CreateObject(localId = 0, classId = 0, args = emptyList()),
                        ScenarioOp.CreateReachabilityObservation(
                            observationId = 0,
                            value = ScenarioValue.LocalRef(0, ScenarioPath(emptyList())),
                            kind = ScenarioReachabilityObservationKind.Weak,
                        ),
                    )
                ),
                ScenarioOp.PerformGc(),
                ScenarioOp.CheckReachabilityObservation(
                    observationId = 0,
                    expectation = ScenarioReachabilityExpectation.Dead,
                    label = "weak-dead-capsule.dead-after-first-gc",
                ),
            )
        )
    )
    val output = ArkTsScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
    val dir = File(System.getenv("GCFUZZ_OUTDIR") ?: "C:\\Users\\admin\\AppData\\Local\\Temp\\gcfuzz-oracle-smoke").apply { mkdirs() }
    output.save(dir)
    val src = dir.resolve(output.filename)
    println("wrote: $src (${src.length()} bytes)")
    val txt = src.readText()
    println("registerObservation call count: " + Regex("registerObservation\\(").findAll(txt).count())
    println("let oX:WeakRef count: " + Regex("let o\\d+: WeakRef").findAll(txt).count())
    println("assertReachability count: " + Regex("\\bassertReachability\\(").findAll(txt).count())
    println("---- relevant lines ----")
    txt.lineSequence().forEachIndexed { i, line ->
        if (line.contains("registerObservation") || line.contains("let o0") || line.contains("assertReachability")) {
            println("L${i + 1}: ${line.trim()}")
        }
    }
}
