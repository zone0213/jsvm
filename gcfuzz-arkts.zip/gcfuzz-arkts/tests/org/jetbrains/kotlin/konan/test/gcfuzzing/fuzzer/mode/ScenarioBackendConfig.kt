/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode

import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

internal class ScenarioBackendConfig(
    val maximumStackDepth: Int,
    val mainLoopRepeatCount: Int,
    val maxThreadCount: Int,
    val softTimeout: Duration,
    val enableCInterop: Boolean,
) {
    fun withCInterop(enabled: Boolean): ScenarioBackendConfig = ScenarioBackendConfig(
        maximumStackDepth = maximumStackDepth,
        mainLoopRepeatCount = mainLoopRepeatCount,
        maxThreadCount = maxThreadCount,
        softTimeout = softTimeout,
        enableCInterop = enabled,
    )

    companion object {
        val DEFAULT = ScenarioBackendConfig(
            maximumStackDepth = 500,
            mainLoopRepeatCount = 20000,
            maxThreadCount = 100,
            softTimeout = 30.seconds,
            enableCInterop = false,
        )
    }
}
