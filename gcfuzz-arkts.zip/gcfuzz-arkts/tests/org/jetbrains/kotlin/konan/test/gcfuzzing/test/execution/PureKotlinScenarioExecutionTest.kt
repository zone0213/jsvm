/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlin.resolvePureKotlinScenarioGeneratedSourceDir
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlin.runPureKotlinScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignInteractionPattern
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioParameter
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend.PureKotlinScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.globalLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.globalValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.localLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.localValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.requiredTestName
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.standaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation.secondBatchTypeSystemScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInfo

class PureKotlinScenarioExecutionTest {
    private fun runPureKotlinTest(name: String, scenario: ScenarioProgram) {
        val host = standaloneExecutionHost()
        val output = PureKotlinScenarioBackend.lower(scenario, ScenarioBackendConfig.DEFAULT)
        val generatedDir = host.resolvePureKotlinScenarioGeneratedSourceDir(name)
        output.save(generatedDir)
        host.runPureKotlinScenario(name, output, host.executionTimeout)
    }

    private inline fun runPureKotlinTest(testInfo: TestInfo, block: () -> ScenarioProgram) =
        runPureKotlinTest(testInfo.requiredTestName(), block())

    @Test
    fun pureKotlinInterfacePolymorphismSmoke(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Global(
                    ScenarioTargetLanguage.Kotlin,
                    ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0)),
                ),
                ScenarioDefinition.Interface(ScenarioTargetLanguage.Kotlin),
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef, ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0))),
                    interfaces = listOf(0),
                    dispatchFieldId = 0,
                ),
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef),
                    interfaces = listOf(0),
                    dispatchFieldId = 0,
                ),
                ScenarioDefinition.Function(
                    ScenarioTargetLanguage.Kotlin,
                    emptyList(),
                    ScenarioBodyWithReturn(
                        ScenarioBody(listOf(ScenarioOp.CreateObject(0, 0, declaredType = ScenarioType.InterfaceRef(0)))),
                        ScenarioValue.LocalRef(0),
                    ),
                    returnType = ScenarioType.InterfaceRef(0),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(0, 0, declaredType = ScenarioType.InterfaceRef(0)),
                    ScenarioOp.Store(ScenarioLocation.Global(0), ScenarioValue.LocalRef(0)),
                    ScenarioOp.CreateObject(1, 1, declaredType = ScenarioType.InterfaceRef(0)),
                    ScenarioOp.Store(localLocation(0, 1), ScenarioValue.LocalRef(1)),
                    ScenarioOp.InterfaceDispatch(2, ScenarioValue.LocalRef(0), 0),
                    ScenarioOp.InterfaceDispatch(3, ScenarioValue.GlobalRef(0), 0),
                    ScenarioOp.InterfaceDispatch(4, ScenarioValue.LocalRef(0, ScenarioPath(listOf(1))), 0),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(2)),
                )
            ),
        )
    }

    @Test
    fun pureKotlinSecondBatchTypeSystemSmoke(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        secondBatchTypeSystemScenario()
    }

    @Test
    fun pureKotlinGeneratedSecondBatchTypeSystemSmoke(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        generateScenario(
            seed = 11u,
            features = ScenarioFeatureSet.of(
                ScenarioFeature.SEALED_HIERARCHY,
                ScenarioFeature.SINGLETON_OBJECT_ROOT,
                ScenarioFeature.INNER_CLASS_OUTER_CAPTURE,
            ),
        )
    }

    @Test
    fun pureKotlinSmoke(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef, ScenarioField.WeakRef),
                ),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ScenarioDefinition.Function(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioParameter),
                    ScenarioBodyWithReturn(
                        body = ScenarioBody(
                            listOf(
                                ScenarioOp.CreateObject(
                                    localId = 1,
                                    classId = 0,
                                    args = listOf(localValue(0), ScenarioValue.DefaultValue),
                                ),
                                ScenarioOp.Store(globalLocation(0), localValue(1)),
                                ScenarioOp.SpawnFunction(0, listOf(globalValue(0))),
                            )
                        ),
                        returnValue = localValue(1, 1),
                    ),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CallFunction(0, listOf(ScenarioValue.DefaultValue)),
                    ScenarioOp.Observe(globalValue(0)),
                )
            ),
        )
    }

    @Test
    fun pureKotlinAdvancedSmoke(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(
                        ScenarioField.IntValue,
                        ScenarioField.StrongRef,
                        ScenarioField.ObjectArray(3),
                        ScenarioField.BooleanValue,
                    ),
                ),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef, ScenarioGlobalStorage.Shared),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef, ScenarioGlobalStorage.ThreadLocal),
                ScenarioDefinition.Function(
                    ScenarioTargetLanguage.Kotlin,
                    emptyList(),
                    ScenarioBodyWithReturn(
                        body = ScenarioBody(
                            listOf(
                                ScenarioOp.CreateObject(
                                    localId = 0,
                                    classId = 0,
                                    args = listOf(
                                        ScenarioValue.DefaultValue,
                                        ScenarioValue.DefaultValue,
                                        ScenarioValue.DefaultValue,
                                        ScenarioValue.DefaultValue,
                                    ),
                                ),
                                ScenarioOp.Store(globalLocation(0), localValue(0)),
                                ScenarioOp.Store(globalLocation(1), localValue(0)),
                                ScenarioOp.Store(globalLocation(0, 2, 0), globalValue(1)),
                                ScenarioOp.Observe(globalValue(0, 2, 0)),
                                ScenarioOp.Throw(globalValue(0)),
                            )
                        ),
                        returnValue = ScenarioValue.DefaultValue,
                    ),
                ),
                ScenarioDefinition.Function(
                    ScenarioTargetLanguage.Kotlin,
                    emptyList(),
                    ScenarioBodyWithReturn(
                        body = ScenarioBody(
                            listOf(
                                ScenarioOp.Store(globalLocation(1), globalValue(0)),
                                ScenarioOp.Return(globalValue(1)),
                            )
                        ),
                        returnValue = ScenarioValue.DefaultValue,
                    ),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CallFunction(0, emptyList()),
                    ScenarioOp.CallFunction(1, emptyList()),
                    ScenarioOp.Observe(globalValue(0)),
                )
            ),
        )
    }

    @Test
    fun pureKotlinRepeatedScenarioLocalAssignment(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef),
                ),
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(localId = 0, classId = 0),
                    ScenarioOp.CreateObject(localId = 0, classId = 1),
                    ScenarioOp.Observe(localValue(0)),
                )
            ),
        )
    }

    @Test
    fun pureKotlinForeignRoundTrip(testInfo: TestInfo) {
        val scenario = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.Kotlin,
                    listOf(ScenarioField.StrongRef),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(localId = 0, classId = 0),
                    ScenarioOp.ForeignRoundTrip(
                        localValue(0),
                        referenceKind = ScenarioForeignReferenceKind.Strong,
                        pattern = ScenarioForeignInteractionPattern.Identity,
                        repetitions = 2,
                    ),
                    ScenarioOp.ForeignRoundTrip(
                        localValue(0),
                        referenceKind = ScenarioForeignReferenceKind.Weak,
                        pattern = ScenarioForeignInteractionPattern.RepeatedCallback,
                        repetitions = 5,
                    ),
                    ScenarioOp.ForeignRoundTrip(
                        ScenarioValue.DefaultValue,
                        referenceKind = ScenarioForeignReferenceKind.Handle,
                        pattern = ScenarioForeignInteractionPattern.Callback,
                        repetitions = 1,
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(localValue(0)),
                )
            ),
        )
        val output = PureKotlinScenarioBackend.lower(
            scenario,
            ScenarioBackendConfig.DEFAULT.withCInterop(true),
        )
        val host = standaloneExecutionHost()
        val name = testInfo.requiredTestName()
        val generatedDir = host.resolvePureKotlinScenarioGeneratedSourceDir(name)
        output.save(generatedDir)
        host.runPureKotlinScenario(name, output, host.executionTimeout)
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinReachabilityOracleAliveAfterGc(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(0, 0),
                    ScenarioOp.CreateObject(1, 1),
                    ScenarioOp.Store(globalLocation(0), localValue(0)),
                    ScenarioOp.Store(globalLocation(0, 0), localValue(1)),
                    ScenarioOp.CreateReachabilityObservation(
                        0,
                        globalValue(0, 0),
                        ScenarioReachabilityObservationKind.Weak,
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Alive,
                        "alive-after-gc",
                    ),
                )
            ),
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinWeakDeadCapsuleOracleDiesAfterGc(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.Block(
                        listOf(
                            ScenarioOp.CreateObject(0, 0),
                            ScenarioOp.CreateReachabilityObservation(
                                0,
                                localValue(0),
                                ScenarioReachabilityObservationKind.Weak,
                            ),
                        )
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Dead,
                        "weak-dead-capsule.dead-after-first-gc",
                    ),
                )
            ),
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinReachabilityConsistencyObservationAliveThenDead(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.Block(
                        listOf(
                            ScenarioOp.CreateObject(0, 0),
                            ScenarioOp.CreateObject(1, 1),
                            ScenarioOp.Store(localLocation(0, 0), localValue(1)),
                            ScenarioOp.Store(globalLocation(0), localValue(0)),
                            ScenarioOp.CreateReachabilityObservation(
                                0,
                                globalValue(0, 0),
                                ScenarioReachabilityObservationKind.Weak,
                            ),
                        )
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Alive,
                        "reachability-consistency.alive-after-publish",
                    ),
                    ScenarioOp.Store(globalLocation(0, 0), ScenarioValue.NullValue),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Dead,
                        "reachability-consistency.dead-after-clear",
                    ),
                )
            ),
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinSingleStrongSlotObservationAliveThenDead(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.BooleanValue, ScenarioField.StrongRef)),
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.Block(
                        listOf(
                            ScenarioOp.CreateObject(0, 0),
                            ScenarioOp.CreateObject(1, 1),
                            ScenarioOp.Store(localLocation(0, 1), localValue(1)),
                            ScenarioOp.Store(globalLocation(0), localValue(0)),
                            ScenarioOp.CreateReachabilityObservation(
                                0,
                                globalValue(0, 1),
                                ScenarioReachabilityObservationKind.Weak,
                            ),
                        )
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Alive,
                        "single-strong-slot.alive-after-publish",
                    ),
                    ScenarioOp.Store(globalLocation(0, 1), ScenarioValue.NullValue),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Dead,
                        "single-strong-slot.dead-after-clear",
                    ),
                )
            ),
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinRootMigrationObservationRemainsAliveAfterGc(testInfo: TestInfo) = runPureKotlinTest(testInfo) {
        ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(0, 0),
                    ScenarioOp.CreateObject(1, 1),
                    ScenarioOp.CreateObject(2, 2),
                    ScenarioOp.Store(localLocation(0, 0), localValue(1)),
                    ScenarioOp.Store(globalLocation(0), localValue(0)),
                    ScenarioOp.Store(localLocation(2, 0), globalValue(0, 0)),
                    ScenarioOp.Store(localLocation(0, 0), ScenarioValue.NullValue),
                    ScenarioOp.Store(globalLocation(0), ScenarioValue.NullValue),
                    ScenarioOp.CreateReachabilityObservation(
                        0,
                        localValue(2, 0),
                        ScenarioReachabilityObservationKind.Weak,
                    ),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.CheckReachabilityObservation(
                        0,
                        ScenarioReachabilityExpectation.Alive,
                        "root-migration.target-alive-after-gc",
                    ),
                )
            ),
        )
    }
}
