/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinitionKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFieldKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorageKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignInteractionPattern
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOpKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioParameter
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.kind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioModeRegistry

internal fun <T> generate(
    seed: UInt,
    scenarioBackend: ScenarioBackend<T>,
): T = scenarioBackend.lower(generateScenario(seed))

// Builds a backend-independent scenario program using the active execution mode profile.
internal fun generateScenario(
    seed: UInt,
    features: ScenarioFeatureSet = defaultGenerationProfile().features,
    capabilities: ScenarioGenerationCapabilities = ScenarioGenerationCapabilities.pureKotlin(features),
): ScenarioProgram = generateScenarioWithMetadata(seed, features, capabilities).program

// Builds a scenario program and returns generation-time metadata that cannot be recovered reliably from translated code.
internal fun generateScenarioWithMetadata(
    seed: UInt,
    features: ScenarioFeatureSet = defaultGenerationProfile().features,
    capabilities: ScenarioGenerationCapabilities = ScenarioGenerationCapabilities.pureKotlin(features),
): GeneratedScenario = Generator(seed = seed.toInt(), features = features, capabilities = capabilities).genGeneratedScenario()

private fun defaultGenerationProfile(): ScenarioGenerationProfile =
    ScenarioModeRegistry.resolveGenerationProfile(
        executionModel = System.getProperty("gcfuzzing.executionModel"),
        enableCInterop = System.getProperty("gcfuzzing.cffi")?.toBoolean() == true,
    )

private class Generator(
    seed: Int = 0,
    val distributions: Distributions = Distributions(),
    private val features: ScenarioFeatureSet = ScenarioFeatureSet.NONE,
    private val capabilities: ScenarioGenerationCapabilities = ScenarioGenerationCapabilities.pureKotlin(features),
) {
    private companion object {
        const val MAX_TOPOLOGY_ATTEMPTS = 5
    }

    private val random = kotlin.random.Random(seed)
    private var nextObservationId: Int = 0
    private var nextCheckpointId: Int = 0
    private val topologyAttempts = mutableMapOf<ScenarioTopologyKind, Int>()
    private val topologyHits = mutableMapOf<ScenarioTopologyKind, Int>()
    private val supportedStatementKinds = StatementKind.entries.filter { it.isSupportedBy(capabilities) }
    private val forceSecondBatchStructuralFeatures = ScenarioTopologyKind.entries.none { it.requiredFeature() in features }
    private val emitSealedHierarchy = shouldEmitSecondBatchStructuralFeature(ScenarioFeature.SEALED_HIERARCHY, percent = 10)
    private val emitSingletonObjectRoot = shouldEmitSecondBatchStructuralFeature(ScenarioFeature.SINGLETON_OBJECT_ROOT, percent = 10)
    private val emitInnerClassOuterCapture = shouldEmitSecondBatchStructuralFeature(ScenarioFeature.INNER_CLASS_OUTER_CAPTURE, percent = 10)

    // Centralized probability model for program shape, statement mix, topology selection, and CFFI variants.
    class Distributions {
        val numDefinitions = CumulativeFun.uniform(
            0.0 to 8,
            0.2 to 16,
            0.7 to 36,
            0.95 to 72,
            1.0 to 96,
        )
        val language = Distribution.uniform(
            ScenarioTargetLanguage.Kotlin,
            ScenarioTargetLanguage.ObjC,
            ScenarioTargetLanguage.Java
        )
        val definition = Distribution.uniform<DefinitionKind>()
        val numFields = CumulativeFun.uniform(
            0.0 to 0,
            0.05 to 1,
            0.4 to 3,
            0.82 to 8,
            0.97 to 20,
            1.0 to 256,
        )
        val numParameters = CumulativeFun.uniform(
            0.0 to 0,
            0.9 to 4,
            0.99 to 12,
            1.0 to 32
        )
        val bodySize = CumulativeFun.uniform(
            0.0 to 8,
            0.7 to 16,
            1.0 to 32,
        )
        val statement = Distribution.weighted(
            StatementKind.ALLOC to 4,
            StatementKind.ALLOCATION_BURST to 1,
            StatementKind.LOAD to 2,
            StatementKind.STORE to 4,
            StatementKind.CLEAR to 2,
            StatementKind.STORE_BATCH to 1,
            StatementKind.CALL to 2,
            StatementKind.FOREIGN_ROUNDTRIP to 3,
            StatementKind.SPAWN_THREAD to 2,
            StatementKind.SPAWN_JOIN to 1,
            StatementKind.SPAWN_WITH_RESULT to 1,
            StatementKind.BLOCK to 1,
            StatementKind.SCOPED_ROOT to 1,
            StatementKind.IF to 1,
            StatementKind.TRY_FINALLY to 1,
            StatementKind.PERFORM_GC to 2,
            StatementKind.GC_EPOCH to 1,
            StatementKind.COMPARE_AND_SET to 1,
        )
        val pathLength = CumulativeFun.uniform(
            0.0 to 0,
            0.2 to 1,
            0.7 to 4,
            0.95 to 8,
            1.0 to 24
        )
        val access = Distribution.weighted(
            AccessKind.LOCAL to 2,
            AccessKind.GLOBAL to 3,
        )
        val refKind = Distribution.weighted(
            ScenarioField.StrongRef to 3,
            ScenarioField.WeakRef to 2,
        )
        val advancedFieldKind = Distribution.weighted(
            ScenarioField.StrongRef to 4,
            ScenarioField.WeakRef to 2,
            ScenarioField.IntValue to 2,
            ScenarioField.BooleanValue to 1,
            ScenarioField.ObjectArray(4) to 2,
        )
        val globalStorage = Distribution.weighted(
            ScenarioGlobalStorage.Shared to 5,
            ScenarioGlobalStorage.ThreadLocal to 2,
        )
        val foreignReferenceKind = Distribution.weighted(
            ScenarioForeignReferenceKind.Handle to 5,
            ScenarioForeignReferenceKind.Strong to 3,
            ScenarioForeignReferenceKind.Weak to 2,
        )
        val foreignInteractionPattern = Distribution.weighted(
            ScenarioForeignInteractionPattern.Callback to 3,
            ScenarioForeignInteractionPattern.RepeatedCallback to 4,
            ScenarioForeignInteractionPattern.Identity to 2,
            ScenarioForeignInteractionPattern.WrappedCallback to 2,
            ScenarioForeignInteractionPattern.CallbackThenIdentity to 2,
            ScenarioForeignInteractionPattern.NestedCallback to 2,
            ScenarioForeignInteractionPattern.BoxedCallback to 2,
            ScenarioForeignInteractionPattern.BoxedIdentity to 2,
            ScenarioForeignInteractionPattern.BoxedRepeatedCallback to 2,
        )
        val foreignRepetitions = CumulativeFun.uniform(
            0.0 to 1,
            0.45 to 2,
            0.8 to 4,
            0.95 to 8,
            1.0 to 16,
        )
        val topologyFamily = Distribution.weighted(
            ScenarioTopologyFamily.ROOT_LIFECYCLE to 30,
            ScenarioTopologyFamily.DIRTY_GRAPH_BARRIER to 20,
            ScenarioTopologyFamily.WEAK_REFERENCE to 15,
            ScenarioTopologyFamily.BASIC_GRAPH to 15,
            ScenarioTopologyFamily.FINALIZATION to 10,
            ScenarioTopologyFamily.CFFI to 10,
        )
        val topologyKindByFamily = mapOf(
            ScenarioTopologyFamily.BASIC_GRAPH to Distribution.weighted(
                ScenarioTopologyKind.CYCLE to 3,
                ScenarioTopologyKind.SHARED_NODE to 3,
                ScenarioTopologyKind.GLOBAL_REATTACH to 3,
                ScenarioTopologyKind.OLD_ROOT_CHURN to 3,
                ScenarioTopologyKind.ROOT_MIGRATION to 3,
                ScenarioTopologyKind.DELETE_EDGE_THEN_GC to 3,
                ScenarioTopologyKind.ARRAY_SLOT_GRAPH to 4,
                ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE to 4,
            ),
            ScenarioTopologyFamily.ROOT_LIFECYCLE to Distribution.weighted(
                ScenarioTopologyKind.CONCURRENT_ROOT_MIGRATION to 3,
                ScenarioTopologyKind.CONCURRENT_PUBLISH_CLEAR_GC to 3,
                ScenarioTopologyKind.FUNCTION_RETURN_ESCAPE to 3,
                ScenarioTopologyKind.WORKER_ALLOC_PUBLISH to 4,
                ScenarioTopologyKind.MULTI_STAGE_ROOT_HANDOFF to 4,
                ScenarioTopologyKind.PING_PONG_ROOT_TRANSFER to 4,
                ScenarioTopologyKind.CONCURRENT_DUPLICATE_HANDOFF to 3,
                ScenarioTopologyKind.LOCAL_GLOBAL_ARRAY_HANDOFF to 4,
                ScenarioTopologyKind.STALE_OWNER_MUTATION_AFTER_HANDOFF to 4,
                ScenarioTopologyKind.THREAD_LOCAL_SHARED_HANDOFF to 4,
                ScenarioTopologyKind.WORKER_CAPTURE_ROOT to 4,
                ScenarioTopologyKind.MULTI_ROOT_STAGGERED_CLEAR to 4,
                ScenarioTopologyKind.CONCURRENT_ARRAY_SLOT_HANDOFF to 4,
                ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR to 4,
                ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR to 4,
                ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH to 4,
                ScenarioTopologyKind.THREAD_LOCAL_CLEAR_ON_WORKER_EXIT to 4,
                ScenarioTopologyKind.ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE to 4,
                ScenarioTopologyKind.WORKER_PUBLISH_MAIN_CLEAR_BARRIER to 4,
                ScenarioTopologyKind.ARRAY_SLOT_CLEAR_RESTORE_BARRIER to 4,
                ScenarioTopologyKind.WORKER_RESULT_ESCAPE to 4,
                ScenarioTopologyKind.WORKER_RESULT_THEN_CLEAR_GC to 4,
                ScenarioTopologyKind.NESTED_WORKER_ROOT_HANDOFF to 4,
                ScenarioTopologyKind.CAS_ROOT_CONTENTION to 4,
            ),
            ScenarioTopologyFamily.DIRTY_GRAPH_BARRIER to Distribution.weighted(
                ScenarioTopologyKind.MIXED_FIELD_ARRAY_MUTATION_BARRIER to 5,
                ScenarioTopologyKind.LARGE_OBJECT_MULTI_FIELD_REWRITE to 4,
                ScenarioTopologyKind.OLD_ROOT_CHURN_WITH_ALLOCATION_BURST to 5,
                ScenarioTopologyKind.GRAPH_MUTATION_MULTI_PHASE_SEQUENCE to 5,
                ScenarioTopologyKind.SHARED_NODE_RECONNECT_BETWEEN_OWNERS to 5,
                ScenarioTopologyKind.CYCLE_BREAK_AND_REROOT to 4,
            ),
            ScenarioTopologyFamily.WEAK_REFERENCE to Distribution.weighted(
                ScenarioTopologyKind.WEAK_REF_LIFECYCLE to 4,
                ScenarioTopologyKind.WEAK_ROOT_HANDOFF to 4,
                ScenarioTopologyKind.WEAK_ARRAY_SLOT to 4,
                ScenarioTopologyKind.WEAK_THREAD_LOCAL_ROOT to 4,
                ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING to 4,
                ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE to 4,
                ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE to 4,
            ),
            ScenarioTopologyFamily.FINALIZATION to Distribution.weighted(
                ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH to 4,
            ),
            ScenarioTopologyFamily.CFFI to Distribution.weighted(
                ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC to 4,
                ScenarioTopologyKind.CFFI_IDENTITY_HANDOFF to 4,
            ),
            ScenarioTopologyFamily.ORACLE to Distribution.weighted(
                ScenarioTopologyKind.SINGLE_STRONG_SLOT_CAPSULE to 2,
                ScenarioTopologyKind.REACHABILITY_CONSISTENCY to 4,
                ScenarioTopologyKind.REACHABILITY_CONSISTENCY_CAPSULE to 2,
                ScenarioTopologyKind.WEAK_DEAD_CAPSULE to 2,
                ScenarioTopologyKind.ROOT_MIGRATION_CAPSULE to 2,
            ),
        )
    }

    enum class DefinitionKind {
        CLASS, FUNCTION, GLOBAL, INTERFACE, SINGLETON
    }

    enum class StatementKind {
        ALLOC,
        ALLOCATION_BURST,
        LOAD,
        STORE,
        CLEAR,
        STORE_BATCH,
        CALL,
        FOREIGN_ROUNDTRIP,
        SPAWN_THREAD,
        SPAWN_JOIN,
        SPAWN_WITH_RESULT,
        BLOCK,
        SCOPED_ROOT,
        IF,
        TRY_FINALLY,
        PERFORM_GC,
        GC_EPOCH,
        COMPARE_AND_SET,
    }

    private fun StatementKind.isSupportedBy(capabilities: ScenarioGenerationCapabilities): Boolean = when (this) {
        StatementKind.ALLOC -> capabilities.core.supports(ScenarioOpKind.CREATE_OBJECT)
        StatementKind.ALLOCATION_BURST -> capabilities.core.supports(ScenarioOpKind.ALLOCATION_BURST)
        StatementKind.LOAD -> capabilities.core.supports(ScenarioOpKind.OBSERVE)
        StatementKind.STORE -> capabilities.core.supports(ScenarioOpKind.STORE)
        StatementKind.CLEAR -> capabilities.core.supports(ScenarioOpKind.CLEAR)
        StatementKind.STORE_BATCH -> capabilities.core.supports(ScenarioOpKind.STORE_BATCH) && capabilities.core.supports(ScenarioOpKind.STORE)
        StatementKind.CALL -> capabilities.core.supports(ScenarioOpKind.CALL_FUNCTION)
        StatementKind.FOREIGN_ROUNDTRIP -> capabilities.core.supports(ScenarioOpKind.FOREIGN_ROUNDTRIP)
        StatementKind.SPAWN_THREAD -> capabilities.core.supports(ScenarioOpKind.SPAWN_FUNCTION)
        StatementKind.SPAWN_JOIN -> capabilities.core.supports(ScenarioOpKind.SPAWN)
        StatementKind.SPAWN_WITH_RESULT -> capabilities.core.supports(ScenarioOpKind.SPAWN_WITH_RESULT)
        StatementKind.BLOCK -> capabilities.core.supports(ScenarioOpKind.BLOCK)
        StatementKind.SCOPED_ROOT -> capabilities.core.supports(ScenarioOpKind.SCOPED_ROOT)
        StatementKind.IF -> capabilities.core.supports(ScenarioOpKind.IF)
        StatementKind.TRY_FINALLY -> capabilities.core.supports(ScenarioOpKind.TRY_FINALLY)
        StatementKind.PERFORM_GC -> capabilities.core.supports(ScenarioOpKind.PERFORM_GC)
        StatementKind.GC_EPOCH -> capabilities.core.supports(ScenarioOpKind.GC_EPOCH)
        StatementKind.COMPARE_AND_SET -> capabilities.core.supports(ScenarioOpKind.COMPARE_AND_SET)
    }

    enum class AccessKind {
        LOCAL, GLOBAL
    }

    // Tracks local ids that are safe or useful to reference while generating one body.
    private inner class BodyGenerationState(initialLocals: Int) {
        private var nextLocalId: Int = initialLocals
        private val readableLocals = mutableListOf<Int>().apply {
            addAll(0 until initialLocals)
        }
        private val mutableLocals = mutableListOf<Int>()
        private val fieldfulMutableLocals = mutableListOf<Int>()
        private val objectLocals = mutableMapOf<Int, Int>()

        // Registers a newly created local and records whether it can later be used as an object/field owner.
        fun allocateLocal(fieldCount: Int, classId: Int? = null): Int {
            val id = nextLocalId++
            readableLocals += id
            mutableLocals += id
            if (fieldCount > 0) {
                fieldfulMutableLocals += id
            }
            if (classId != null) {
                objectLocals[id] = classId
            }
            return id
        }

        // Reserves a local id without adding it to readableLocals/mutableLocals. Used by operations
        // whose concrete type is not modeled by the generator (e.g. CallFunction result, genLoad's
        // id-space advancement). Subsequent statements cannot reference these locals as values,
        // because translators may not declare a matching slot for an untyped result. This keeps
        // readableLocals containing only CreateObject-declared locals and function parameters,
        // so genScenarioValue/genScenarioLocation only pick from locals that translators can resolve.
        fun allocateUnknownLocal(): Int = nextLocalId++

        // Picks an already-defined local, or null if this body has not created/read any local yet.
        fun chooseReadableLocalOrNull(random: kotlin.random.Random): Int? = readableLocals.randomOrNullCompat(random)
        // Picks a local that can appear on the left side of a store.
        fun chooseMutableLocalOrNull(random: kotlin.random.Random): Int? = mutableLocals.randomOrNullCompat(random)
        // Picks a mutable local with at least one field, useful for generating meaningful field paths.
        fun chooseFieldfulMutableLocalOrNull(random: kotlin.random.Random): Int? = fieldfulMutableLocals.randomOrNullCompat(random)
        // Picks a local whose class id is known, so field capabilities can be inspected.
        fun chooseObjectLocalOrNull(random: kotlin.random.Random): Int? = objectLocals.keys.toList().randomOrNullCompat(random)
        // Returns the class id backing a known object local, or null when the local is not modeled as an object.
        fun classIdOf(localId: Int): Int? = objectLocals[localId]
        // True when localId is a real readable local in this body (covers both object locals and unknown locals
        // reserved by genLoad/genCall). Used to distinguish "known local without class info" from "invalid id stress
        // fallback returned by chooseLocal()".
        fun isKnownLocal(localId: Int): Boolean = localId in readableLocals
        // Returns the next local id without leaking a scoped declaration back to the parent body.
        fun nextScopedLocalId(): Int = nextLocalId
        // Declares a local only in a forked body, used by ScenarioOp.ScopedRoot.
        fun forkWithScopedLocal(localId: Int): BodyGenerationState =
            fork().apply {
                readableLocals += localId
                mutableLocals += localId
                nextLocalId = maxOf(nextLocalId, localId + 1)
            }
        // Finds an object local that has a field matching the requested shape.
        fun chooseObjectLocalWithFieldOrNull(
            random: kotlin.random.Random,
            predicate: (ScenarioField) -> Boolean,
        ): Pair<Int, Int>? = objectLocals.entries
            .mapNotNull { (localId, classId) ->
                generatedClasses[classId].fields
                    .indexOfFirst(predicate)
                    .takeIf { it >= 0 }
                    ?.let { fieldId -> localId to fieldId }
            }
            .randomOrNullCompat(random)

        // Copies the current local environment for nested bodies without leaking new nested locals back outward.
        fun fork(): BodyGenerationState =
            BodyGenerationState(
                nextLocalId,
                readableLocals.toMutableList(),
                mutableLocals.toMutableList(),
                fieldfulMutableLocals.toMutableList(),
                objectLocals.toMutableMap(),
            )

        // Local helper for optional random selection on Kotlin versions without randomOrNull(random).
        private fun <T> List<T>.randomOrNullCompat(random: kotlin.random.Random): T? =
            if (isEmpty()) null else this[random.nextInt(size)]

        private constructor(
            nextLocalId: Int,
            readableLocals: MutableList<Int>,
            mutableLocals: MutableList<Int>,
            fieldfulMutableLocals: MutableList<Int>,
            objectLocals: MutableMap<Int, Int>,
        ) : this(0) {
            this.nextLocalId = nextLocalId
            this.readableLocals.clear()
            this.readableLocals += readableLocals
            this.mutableLocals.clear()
            this.mutableLocals += mutableLocals
            this.fieldfulMutableLocals.clear()
            this.fieldfulMutableLocals += fieldfulMutableLocals
            this.objectLocals.clear()
            this.objectLocals.putAll(objectLocals)
        }
    }

    // Allocates a stable id used to pair reachability-observation creation and later checks.
    private fun allocateObservationId(): Int = nextObservationId++

    // File-level helper for optional random selection with an explicit RNG.
    private fun <T> List<T>.randomOrNullCompat(random: kotlin.random.Random): T? =
        if (isEmpty()) null else this[random.nextInt(size)]

    // Decides how many globals/classes/functions this program will contain, with feature-driven minimums.
    private val numDefinitions: Map<DefinitionKind, Int> = run {
        val randomCounts = (1 until distributions.numDefinitions.next(random) + 1)
            .map { distributions.definition.next(random) }
            .groupBy { it }
            .mapValues { it.value.size }
        val counts = DefinitionKind.entries.associateWith { 1 } + randomCounts
        counts +
            (DefinitionKind.GLOBAL to counts.getValue(DefinitionKind.GLOBAL).coerceAtLeast(minimumGlobalDefinitions())) +
            (DefinitionKind.INTERFACE to counts.getValue(DefinitionKind.INTERFACE).coerceAtLeast(if (needsInterfacePolymorphism()) 1 else 0)) +
            (DefinitionKind.SINGLETON to counts.getValue(DefinitionKind.SINGLETON).coerceAtLeast(if (needsSingletonObjectRoot()) 1 else 0)) +
            (DefinitionKind.CLASS to counts.getValue(DefinitionKind.CLASS).coerceAtLeast(minimumClassDefinitions()))
    }

    private fun minimumClassDefinitions(): Int = maxOf(
        if (needsInterfacePolymorphism()) 2 else 1,
        if (needsSealedHierarchy()) 10 else 1,
        if (needsInnerClassOuterCapture()) 12 else 1,
    )

    // Definitions are lazy because classes/globals/functions refer to each other during generation.
    private val generatedGlobals by lazy { genGlobals() }
    private val generatedInterfaces by lazy { genInterfaces() }
    private val generatedSingletons by lazy { genSingletons() }
    private val generatedClasses by lazy { genClasses() }
    private val generatedFunctions by lazy {
        buildList {
            if (needsInterfacePolymorphism()) add(genInterfaceReturnFunction())
            if (ScenarioFeature.ESCAPING_RETURN_FUNCTION in features) add(genEscapingReturnFunction())
            repeat(numDefinitions.getValue(DefinitionKind.FUNCTION)) { add(genFunction()) }
        }
    }

    // Emits definitions in the id order expected by generated references: globals, interfaces, singletons, classes, then functions.
    private fun genDefinitions(): List<ScenarioDefinition> {
        return generatedGlobals + generatedInterfaces + generatedSingletons + generatedClasses + generatedFunctions
    }

    // Builds the complete IR program: definitions plus a fuzzed main body.
    fun genProgram(): ScenarioProgram = ScenarioProgram(
        definitions = genDefinitions(),
        mainBody = genMainBody(),
    )

    fun genGeneratedScenario(): GeneratedScenario {
        val program = genProgram()
        return GeneratedScenario(
            program = program,
            telemetry = ScenarioTelemetry(
                enabledFeatures = ScenarioFeature.entries.filter { it in features }.toSet(),
                enabledTopologies = enabledScenarioTopologyKinds().toSet(),
                topologyAttempts = topologyAttempts.toMap(),
                topologyHits = topologyHits.toMap(),
                structuralHits = collectStructuralHits(program),
            ),
        )
    }

    private fun genMainBody(): ScenarioBody =
        if (needsStructuralExercise()) {
            val seed = genStructuralExercise()
            val targetSize = distributions.bodySize.next(random)
            val state = BodyGenerationState(seed.maxOf { it.localIdAfterStructuralExercise() } + 1)
            ScenarioBody(
                seed + genBody(
                    state = state,
                    targetSize = (targetSize - seed.size).coerceAtLeast(1),
                    allowStructuredStatements = ScenarioFeature.STRUCTURED_CONTROL_FLOW in features,
                    allowTerminalStatements = ScenarioFeature.TERMINAL_STATEMENTS in features,
                ).statements
            )
        } else {
            genBody()
        }

    private fun ScenarioOp.localIdAfterStructuralExercise(): Int = when (this) {
        is ScenarioOp.CreateObject -> localId
        is ScenarioOp.InterfaceDispatch -> localId
        is ScenarioOp.SealedDispatch -> localId
        is ScenarioOp.SingletonAccess -> localId
        is ScenarioOp.CreateInnerObject -> localId
        is ScenarioOp.OuterDispatch -> localId
        else -> -1
    }

    // Generates a class definition with a random target language marker and random field layout.
    fun genClass(): ScenarioDefinition.Class {
        val lang = genLanguage()
        return ScenarioDefinition.Class(
            lang,
            genFields()
        )
    }

    private fun genInterfaces(): List<ScenarioDefinition.Interface> =
        if (needsInterfacePolymorphism()) {
            List(numDefinitions.getValue(DefinitionKind.INTERFACE)) { ScenarioDefinition.Interface(genLanguage()) }
        } else {
            emptyList()
        }

    private fun genSingletons(): List<ScenarioDefinition.SingletonObject> =
        if (needsSingletonObjectRoot()) {
            List(numDefinitions.getValue(DefinitionKind.SINGLETON)) {
                ScenarioDefinition.SingletonObject(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef))
            }
        } else {
            emptyList()
        }

    // Generates classes and repairs the set so enabled topologies have required field shapes.
    private fun genClasses(): List<ScenarioDefinition.Class> {
        val classes = List(numDefinitions.getValue(DefinitionKind.CLASS)) { genClass() }.toMutableList()
        if (needsFinalizerClass() && classes.size < 2) {
            classes += ScenarioDefinition.Class(genLanguage(), listOf(ScenarioField.StrongRef))
        }
        if (needsArrayFieldClass() && needsMultiStrongRefFieldClass() && classes.none { it.hasArrayField() && it.strongRefFieldIds().size >= 4 }) {
            classes.replaceFirstClassFields(listOf(ScenarioField.ObjectArray(4)) + List(8) { ScenarioField.StrongRef })
        } else if (needsArrayFieldClass() && classes.none { it.hasArrayField() }) {
            classes.replaceFirstClassFields(listOf(ScenarioField.ObjectArray(4), ScenarioField.StrongRef))
        } else if (needsMultiStrongRefFieldClass() && classes.none { it.strongRefFieldIds().size >= 4 }) {
            classes.replaceFirstClassFields(List(8) { ScenarioField.StrongRef })
        }
        if (needsStrongRefFieldClass() && classes.none { it.fields.any { field -> field is ScenarioField.StrongRef } }) {
            val firstClass = classes.first()
            classes[0] = firstClass.withFields(firstClass.fields + ScenarioField.StrongRef)
        }
        if (needsFinalizerClass() && classes.none { it.lifecycle is ScenarioClassLifecycle.Finalizer }) {
            val firstClass = classes.first()
            val markerClassId = 1
            val markerLocalId = 0
            val finalizerGlobalId = chooseStrongSharedGlobalOrNull() ?: 0
            classes[0] = firstClass.withLifecycle(
                ScenarioClassLifecycle.Finalizer(
                    ScenarioBody(
                        listOf(
                            ScenarioOp.CreateObject(markerLocalId, markerClassId),
                            ScenarioOp.Store(globalLocation(finalizerGlobalId), ScenarioValue.LocalRef(markerLocalId)),
                            ScenarioOp.AllocationBurst(markerClassId, 8),
                        )
                    )
                ),
            )
        }
        if (needsInterfacePolymorphism()) {
            while (classes.size < 2) {
                classes += ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList())
            }
            (0..1).forEach { classId ->
                val clazz = classes[classId]
                val fields = clazz.fields.toMutableList()
                if (fields.isEmpty()) fields += ScenarioField.StrongRef
                if (fields.none { it is ScenarioField.TypedStrongRef }) {
                    fields += ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0))
                }
                classes[classId] = ScenarioDefinition.Class(
                    targetLanguage = clazz.targetLanguage,
                    fields = fields,
                    lifecycle = clazz.lifecycle,
                    interfaces = (clazz.interfaces + 0).distinct(),
                    dispatchFieldId = 0,
                    kind = clazz.kind,
                    superClassId = clazz.superClassId,
                    sealedPayloadFieldId = clazz.sealedPayloadFieldId,
                    nestedInClassId = clazz.nestedInClassId,
                    outerCaptureFieldId = clazz.outerCaptureFieldId,
                )
            }
        }
        if (needsSealedHierarchy()) {
            classes.ensureClassCount(10)
            classes[7] = ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                fields = emptyList(),
                kind = ScenarioClassKind.Sealed,
            )
            classes[8] = ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                fields = listOf(ScenarioField.StrongRef),
                superClassId = 7,
                sealedPayloadFieldId = 0,
            )
            classes[9] = ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                fields = listOf(ScenarioField.StrongRef),
                superClassId = 7,
                sealedPayloadFieldId = 0,
            )
        }
        if (needsInnerClassOuterCapture()) {
            classes.ensureClassCount(12)
            classes[10] = ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                fields = listOf(ScenarioField.StrongRef),
            )
            classes[11] = ScenarioDefinition.Class(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                fields = listOf(ScenarioField.StrongRef),
                nestedInClassId = 10,
                outerCaptureFieldId = 0,
            )
        }
        if (classes.any { it.fields.isNotEmpty() }) return classes

        val firstClass = classes.first()
        return buildList<ScenarioDefinition.Class> {
            add(ScenarioDefinition.Class(firstClass.targetLanguage, listOf(ScenarioField.StrongRef), firstClass.lifecycle))
            addAll(classes.drop(1))
        }
    }

    // Rewrites the first generated class to guarantee a structural capability required by a topology.
    private fun MutableList<ScenarioDefinition.Class>.replaceFirstClassFields(fields: List<ScenarioField>) {
        val firstClass = first()
        this[0] = firstClass.withFields(fields)
    }

    private fun MutableList<ScenarioDefinition.Class>.ensureClassCount(size: Int) {
        while (this.size < size) {
            this += ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef))
        }
    }

    private fun ScenarioDefinition.Class.withFields(fields: List<ScenarioField>): ScenarioDefinition.Class =
        ScenarioDefinition.Class(
            targetLanguage = targetLanguage,
            fields = fields,
            lifecycle = lifecycle,
            interfaces = interfaces,
            dispatchFieldId = dispatchFieldId,
            kind = kind,
            superClassId = superClassId,
            sealedPayloadFieldId = sealedPayloadFieldId,
            nestedInClassId = nestedInClassId,
            outerCaptureFieldId = outerCaptureFieldId,
        )

    private fun ScenarioDefinition.Class.withLifecycle(lifecycle: ScenarioClassLifecycle): ScenarioDefinition.Class =
        ScenarioDefinition.Class(
            targetLanguage = targetLanguage,
            fields = fields,
            lifecycle = lifecycle,
            interfaces = interfaces,
            dispatchFieldId = dispatchFieldId,
            kind = kind,
            superClassId = superClassId,
            sealedPayloadFieldId = sealedPayloadFieldId,
            nestedInClassId = nestedInClassId,
            outerCaptureFieldId = outerCaptureFieldId,
        )

    private fun ScenarioDefinition.Class.hasArrayField(): Boolean =
        fields.any { it is ScenarioField.ObjectArray }

    private fun ScenarioDefinition.Class.strongRefFieldIds(): List<Int> =
        fields.mapIndexedNotNull { index, field -> if (field is ScenarioField.StrongRef) index else null }

    // Generates globals and prepends mandatory roots required by enabled topology/oracle templates.
    private fun genGlobals(): List<ScenarioDefinition.Global> {
        val guaranteed = buildList {
            if (needsInterfacePolymorphism()) {
                add(
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0)),
                        ScenarioGlobalStorage.Shared,
                    )
                )
            }
            if (needsSealedHierarchy()) {
                add(
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.TypedStrongRef(ScenarioType.ClassRef(7)),
                        ScenarioGlobalStorage.Shared,
                    )
                )
            }
            if (needsStrongSharedGlobal()) {
                add(ScenarioDefinition.Global(genLanguage(), ScenarioField.StrongRef, ScenarioGlobalStorage.Shared))
            }
            if (needsWeakGlobal()) {
                add(ScenarioDefinition.Global(genLanguage(), ScenarioField.WeakRef, ScenarioGlobalStorage.Shared))
            }
            if (needsThreadLocalStrongGlobal()) {
                add(ScenarioDefinition.Global(genLanguage(), ScenarioField.StrongRef, ScenarioGlobalStorage.ThreadLocal))
            }
            if (isEmpty() && needsSharedGlobal()) {
                add(ScenarioDefinition.Global(genLanguage(), chooseRefKind(), ScenarioGlobalStorage.Shared))
            }
        }
        val randomCount = numDefinitions.getValue(DefinitionKind.GLOBAL) - guaranteed.size
        return guaranteed + List(randomCount) { genGlobal() }
    }

    // Generates a normal function body with randomized parameters and a default return value.
    fun genFunction(): ScenarioDefinition.Function {
        val lang = genLanguage()
        val parameters = genParameters()
        return ScenarioDefinition.Function(
            lang,
            parameters,
            genBodyWithReturn(parameters.size),
        )
    }

    // Special helper function used by the return-escape topology; function id 0 returns a fresh object.
    private fun genEscapingReturnFunction(): ScenarioDefinition.Function {
        val classId = chooseClass()
        return ScenarioDefinition.Function(
            ScenarioTargetLanguage.Kotlin,
            emptyList(),
            ScenarioBodyWithReturn(
                ScenarioBody(listOf(ScenarioOp.CreateObject(0, classId))),
                ScenarioValue.LocalRef(0, ScenarioPath(emptyList())),
            ),
        )
    }

    private fun genInterfaceReturnFunction(): ScenarioDefinition.Function =
        ScenarioDefinition.Function(
            targetLanguage = ScenarioTargetLanguage.Kotlin,
            parameters = emptyList(),
            body = ScenarioBodyWithReturn(
                ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(
                            localId = 0,
                            classId = 0,
                            declaredType = ScenarioType.InterfaceRef(0),
                        )
                    )
                ),
                ScenarioValue.LocalRef(0),
            ),
            returnType = ScenarioType.InterfaceRef(0),
        )

    // Generates one global slot, optionally using thread-local storage when the profile supports it.
    fun genGlobal(): ScenarioDefinition.Global {
        val lang = genLanguage()
        val field = chooseRefKind()
        val storage = if (
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE in features &&
            ScenarioGlobalStorageKind.THREAD_LOCAL in capabilities.core.supportedGlobalStorage &&
            (field is ScenarioField.StrongRef || field is ScenarioField.WeakRef)
        ) {
            distributions.globalStorage.next(random)
        } else {
            ScenarioGlobalStorage.Shared
        }
        return ScenarioDefinition.Global(lang, field, storage)
    }

    // Chooses a target-language marker; pure-kotlin backends later normalize unsupported targets.
    fun genLanguage(): ScenarioTargetLanguage = distributions.language.next(random)

    // Generates a field layout for one class.
    fun genFields(): List<ScenarioField> =
        List(distributions.numFields.next(random)) { chooseFieldKind() }

    // Generates formal parameters for one function.
    fun genParameters(): List<ScenarioParameter> =
        List(distributions.numParameters.next(random)) { ScenarioParameter }

    // Generates a function body and uses DefaultValue as the generic return expression.
    fun genBodyWithReturn(initialLocals: Int = 0) = ScenarioBodyWithReturn(genBody(initialLocals), ScenarioValue.DefaultValue)

    // Generates a standalone statement body with feature-controlled structured/terminal statements.
    fun genBody(initialLocals: Int = 0): ScenarioBody {
        val targetSize = distributions.bodySize.next(random)
        val state = BodyGenerationState(initialLocals)
        return genBody(
            state,
            targetSize,
            allowStructuredStatements = ScenarioFeature.STRUCTURED_CONTROL_FLOW in features,
            allowTerminalStatements = ScenarioFeature.TERMINAL_STATEMENTS in features,
        )
    }

    // Delegates body generation once the target size and body state are known.
    private fun genBody(
        state: BodyGenerationState,
        targetSize: Int,
        allowStructuredStatements: Boolean,
        allowTerminalStatements: Boolean,
    ): ScenarioBody = ScenarioBody(
        genScenarioStatements(
            state = state,
            targetSize = targetSize,
            allowStructuredStatements = allowStructuredStatements,
            allowTerminalStatements = allowTerminalStatements,
        )
    )

    // Emits an early return or throw when terminal statements are enabled.
    private fun genTerminalOp(state: BodyGenerationState): ScenarioOp =
        if (random.nextBoolean()) ScenarioOp.Return(genScenarioValue(state))
        else ScenarioOp.Throw(genScenarioValue(state))

    // Chooses a basic reference-like field kind.
    private fun chooseRefKind(): ScenarioField =
        generateSequence { distributions.refKind.next(random) }
            .first { capabilities.core.supports(it.kind) }
    // Chooses either a basic reference field or a richer scalar/array field depending on profile features.
    private fun chooseFieldKind(): ScenarioField =
        generateSequence {
            if (ScenarioFeature.RICH_FIELDS in features) distributions.advancedFieldKind.next(random) else chooseRefKind()
        }.first { capabilities.core.supports(it.kind) }

    // Picks ids from the generated definition ranges; these ids intentionally reference IR definition order.
    private fun chooseClass(): Int =
        generatedClasses.indices.filter { generatedClasses[it].isDirectlyConstructible() }.randomOrNullCompat(random) ?: 0
    private fun chooseFunction(): Int = random.nextInt(0, numDefinitions[DefinitionKind.FUNCTION]!!)
    private fun chooseGlobal(): Int = random.nextInt(0, numDefinitions[DefinitionKind.GLOBAL]!!)
    // Picks any shared global root, used by topology templates that depend on cross-thread visibility.
    private fun chooseSharedGlobalOrNull(): Int? =
        generatedGlobals.indices.filter { generatedGlobals[it].storage is ScenarioGlobalStorage.Shared }.randomOrNullCompat(random)
    // Picks a shared strong global root when a topology must keep a payload alive.
    private fun chooseStrongSharedGlobalOrNull(): Int? =
        generatedGlobals.indices.filter {
            generatedGlobals[it].storage is ScenarioGlobalStorage.Shared && generatedGlobals[it].field is ScenarioField.StrongRef
        }.randomOrNullCompat(random)
    // Picks a thread-local strong global root for worker-local handoff stress.
    private fun chooseThreadLocalStrongGlobalOrNull(): Int? =
        generatedGlobals.indices.filter {
            generatedGlobals[it].storage is ScenarioGlobalStorage.ThreadLocal && generatedGlobals[it].field is ScenarioField.StrongRef
        }.randomOrNullCompat(random)
    // Picks a weak global slot for weak-reference lifecycle stress.
    private fun chooseWeakGlobalOrNull(): Int? =
        generatedGlobals.indices.filter { generatedGlobals[it].field is ScenarioField.WeakRef }.randomOrNullCompat(random)
    // Generates a deliberately unconstrained local id to keep invalid-reference stress in ordinary statements.
    private fun chooseLocal(): Int = random.nextInt(0, Int.MAX_VALUE)
    // Picks a class that can be used as a field owner.
    private fun chooseClassWithFieldsOrNull(): Int? =
        generatedClasses.indices.filter { generatedClasses[it].isDirectlyConstructible() && generatedClasses[it].fields.isNotEmpty() }.randomOrNullCompat(random)
    // Picks a class and field id for a strong-reference edge required by stable reachability templates.
    private fun chooseClassWithStrongRefFieldOrNull(): Pair<Int, Int>? =
        generatedClasses.indices.mapNotNull { classId ->
            val clazz = generatedClasses[classId]
            val fieldId = clazz.fields.indexOfFirst { it is ScenarioField.StrongRef }
            if (clazz.isDirectlyConstructible() && fieldId >= 0) classId to fieldId else null
        }.randomOrNullCompat(random)
    // Picks a class with enough strong-reference fields for bulk rewrite topology templates.
    private fun chooseClassWithStrongRefFieldsOrNull(minFields: Int): Pair<Int, List<Int>>? =
        generatedClasses.indices.mapNotNull { classId ->
            val clazz = generatedClasses[classId]
            val fieldIds = clazz.strongRefFieldIds()
            if (clazz.isDirectlyConstructible() && fieldIds.size >= minFields) classId to fieldIds else null
        }.randomOrNullCompat(random)
    // Picks a class and field id for an object-array edge.
    private fun chooseClassWithArrayFieldOrNull(): Pair<Int, Int>? =
        generatedClasses.indices.mapNotNull { classId ->
            val clazz = generatedClasses[classId]
            val fieldId = clazz.fields.indexOfFirst { it is ScenarioField.ObjectArray }
            if (clazz.isDirectlyConstructible() && fieldId >= 0) classId to fieldId else null
        }.randomOrNullCompat(random)

    private fun ScenarioDefinition.Class.isDirectlyConstructible(): Boolean =
        kind == ScenarioClassKind.Concrete && nestedInClassId == null
    // Picks a class with finalizer lifecycle attached.
    private fun chooseFinalizerClassOrNull(): Int? =
        generatedClasses.indices.filter { generatedClasses[it].lifecycle is ScenarioClassLifecycle.Finalizer }.randomOrNullCompat(random)
    // Picks a class without finalizer lifecycle, useful for marker objects allocated by finalizers.
    private fun chooseNonFinalizerClassOrNull(): Int? =
        generatedClasses.indices.filter { generatedClasses[it].lifecycle is ScenarioClassLifecycle.None }.randomOrNullCompat(random)

    // Returns the modeled field count of a generated class, used to classify new locals.
    private fun classFieldCount(classId: Int): Int = generatedClasses[classId].fields.size
    // Object-like fields are meaningful CFFI payloads because callbacks can touch object graphs through them.
    private fun ScenarioField.isForeignObjectLike(): Boolean =
        this is ScenarioField.StrongRef || this is ScenarioField.WeakRef || this is ScenarioField.ObjectArray

    // Scalar-like fields exercise primitive payload paths through the same CFFI machinery.
    private fun ScenarioField.isForeignScalarLike(): Boolean =
        this is ScenarioField.IntValue || this is ScenarioField.BooleanValue

    // Creates a new object and records the resulting local as readable, mutable, and class-known.
    private fun genAlloc(state: BodyGenerationState): ScenarioOp.CreateObject {
        val classId = chooseClass()
        val localId = state.allocateLocal(fieldCount = classFieldCount(classId), classId = classId)
        return ScenarioOp.CreateObject(localId, classId, args = genScenarioArgs(state))
    }

    // Emits a compact allocation storm to perturb heap shape and GC scheduling.
    private fun genAllocationBurst(): ScenarioOp.AllocationBurst =
        ScenarioOp.AllocationBurst(chooseClass(), random.nextInt(8, 65))

    // Observes a random value and reserves an unknown local to keep local id space moving.
    private fun genLoad(state: BodyGenerationState): ScenarioOp.Observe {
        state.allocateUnknownLocal()
        return ScenarioOp.Observe(genScenarioValue(state))
    }

    // Stores a random value into a random local/global location.
    private fun genStore(state: BodyGenerationState): ScenarioOp.Store =
        ScenarioOp.Store(genScenarioLocation(state), genScenarioValue(state))

    // Clears a local/global/slot location with an explicit GC-lifecycle operation.
    private fun genClear(state: BodyGenerationState): ScenarioOp.Clear =
        ScenarioOp.Clear(genScenarioLocation(state))

    // Emits a compact mutation batch so barrier-heavy topologies can reuse the same IR primitive.
    private fun genStoreBatch(state: BodyGenerationState): ScenarioOp.StoreBatch =
        ScenarioOp.StoreBatch(
            List(random.nextInt(2, 6)) {
                ScenarioOp.Store(genScenarioLocation(state), genScenarioValue(state))
            }
        )

    // Repeats explicit GC collection across a small epoch window.
    private fun genGcEpoch(): ScenarioOp.GcEpoch =
        ScenarioOp.GcEpoch(
            count = random.nextInt(1, 5),
            yieldBetween = random.nextBoolean(),
        )

    // Calls a random function and reserves an unknown local for the backend's call result conventions.
    private fun genCall(state: BodyGenerationState): ScenarioOp.CallFunction {
        state.allocateUnknownLocal()
        return ScenarioOp.CallFunction(chooseFunction(), genScenarioArgs(state))
    }

    // Picks a global whose field shape is useful for CFFI payload generation.
    private fun chooseForeignGlobalOrNull(predicate: (ScenarioField) -> Boolean): Int? =
        generatedGlobals.indices.filter { globalId ->
            predicate(generatedGlobals[globalId].field)
        }.randomOrNullCompat(random)

    // Prefers payloads that are actual objects or object-like fields so callbacks stress object reachability.
    private fun genForeignObjectValue(state: BodyGenerationState): ScenarioValue {
        val directObjectLocal = state.chooseObjectLocalOrNull(random)
        val objectLocalField = state.chooseObjectLocalWithFieldOrNull(random) { field -> field.isForeignObjectLike() }
        val objectGlobal = chooseForeignGlobalOrNull { field -> field.isForeignObjectLike() }
        return when (random.nextInt(4)) {
            0 -> directObjectLocal?.let { ScenarioValue.LocalRef(it) }
            1 -> objectLocalField?.let { (localId, fieldId) -> ScenarioValue.LocalRef(localId, ScenarioPath(listOf(fieldId))) }
            2 -> objectGlobal?.let { globalId -> ScenarioValue.GlobalRef(globalId) }
            else -> null
        } ?: directObjectLocal?.let { ScenarioValue.LocalRef(it) }
            ?: objectLocalField?.let { (localId, fieldId) -> ScenarioValue.LocalRef(localId, ScenarioPath(listOf(fieldId))) }
            ?: objectGlobal?.let { globalId -> ScenarioValue.GlobalRef(globalId) }
            ?: genScenarioValue(state)
    }

    // Builds primitive/default/null payload candidates for CFFI handle paths.
    private fun genForeignScalarValue(state: BodyGenerationState): ScenarioValue {
        val scalarObjectField = state.chooseObjectLocalWithFieldOrNull(random) { field -> field.isForeignScalarLike() }
        val scalarGlobal = chooseForeignGlobalOrNull { field -> field.isForeignScalarLike() }
        return when (random.nextInt(4)) {
            0 -> scalarObjectField?.let { (localId, fieldId) -> ScenarioValue.LocalRef(localId, ScenarioPath(listOf(fieldId))) }
            1 -> scalarGlobal?.let { globalId -> ScenarioValue.GlobalRef(globalId) }
            2 -> ScenarioValue.DefaultValue
            else -> ScenarioValue.NullValue
        } ?: genScenarioValue(state)
    }

    // Selects a payload compatible with the modeled foreign reference strength.
    private fun genForeignRoundTripValue(state: BodyGenerationState, referenceKind: ScenarioForeignReferenceKind): ScenarioValue = when (referenceKind) {
        ScenarioForeignReferenceKind.Weak -> genForeignObjectValue(state)
        ScenarioForeignReferenceKind.Strong ->
            if (random.nextDouble() < 0.7) genForeignObjectValue(state) else genForeignScalarValue(state)
        ScenarioForeignReferenceKind.Handle ->
            when (random.nextInt(5)) {
                0 -> genForeignObjectValue(state)
                1 -> genForeignScalarValue(state)
                2 -> ScenarioValue.DefaultValue
                3 -> ScenarioValue.NullValue
                else -> genScenarioValue(state)
            }
    }

    // Generates one CFFI operation: payload, reference kind, C interaction shape, and repetition/depth.
    private fun genForeignRoundTrip(state: BodyGenerationState): ScenarioOp.ForeignRoundTrip {
        val referenceKind = distributions.foreignReferenceKind.next(random)
        val pattern = distributions.foreignInteractionPattern.next(random)
        val repetitions = if (pattern == ScenarioForeignInteractionPattern.Callback) 1 else distributions.foreignRepetitions.next(random)
        return ScenarioOp.ForeignRoundTrip(
            value = genForeignRoundTripValue(state, referenceKind),
            referenceKind = referenceKind,
            pattern = pattern,
            repetitions = repetitions,
        )
    }

    // Spawns a generated function with random arguments to add worker/concurrency pressure.
    private fun genSpawnThread(state: BodyGenerationState): ScenarioOp.SpawnFunction =
        ScenarioOp.SpawnFunction(chooseFunction(), genScenarioArgs(state))

    // Spawns an inline worker body and waits briefly for worker-local roots to disappear on exit.
    private fun genSpawnJoin(state: BodyGenerationState): ScenarioOp.Spawn =
        ScenarioOp.Spawn(
            body = genNestedScenarioBody(state, maxSize = 4),
            join = true,
        )

    // Spawns a worker that returns a value through a future, which the caller receives as a new local.
    // The worker body allocates an object and returns it; the result escapes into the caller's local
    // space, becoming a new root that subsequent GC must trace.
    private fun genSpawnWithResult(state: BodyGenerationState): ScenarioOp.SpawnWithResult {
        val payloadClassId = chooseClass()
        // caller scope: allocate local to receive worker result (advances caller nextLocalId)
        val callerResultLocalId = state.allocateLocal(fieldCount = 0)
        // worker body: fork state, force CreateObject first, then random statements
        val workerBodyState = state.fork()
        val payloadLocalId = workerBodyState.allocateLocal(
            fieldCount = classFieldCount(payloadClassId),
            classId = payloadClassId,
        )
        val body = buildList {
            add(ScenarioOp.CreateObject(payloadLocalId, payloadClassId))
            addAll(genScenarioStatements(
                state = workerBodyState,
                targetSize = random.nextInt(1, 4),
                allowStructuredStatements = false,
                allowTerminalStatements = false,
            ))
        }
        return ScenarioOp.SpawnWithResult(
            localId = callerResultLocalId,
            returnValue = ScenarioValue.LocalRef(payloadLocalId),
            body = body,
        )
    }

    // CAS is meaningful only for a shared strong global root: the Kotlin backend lowers that slot
    // to AtomicReference and can therefore preserve actual compare-and-set semantics.
    private fun genCompareAndSet(state: BodyGenerationState): ScenarioOp =
        chooseStrongSharedGlobalOrNull()?.let { globalId ->
            ScenarioOp.CompareAndSet(
                location = globalLocation(globalId),
                expectedValue = genScenarioValue(state),
                newValue = genScenarioValue(state),
            )
        } ?: genStore(state)

    // Wraps a small nested body in a block; nested locals do not leak into the outer generation state.
    private fun genBlock(state: BodyGenerationState): ScenarioOp.Block =
        ScenarioOp.Block(genNestedScenarioBody(state, maxSize = 5))

    // Creates a root whose local lifetime is explicitly scoped to the nested body.
    private fun genScopedRoot(state: BodyGenerationState): ScenarioOp.ScopedRoot {
        val localId = state.nextScopedLocalId()
        val nestedState = state.forkWithScopedLocal(localId)
        return ScenarioOp.ScopedRoot(
            localId = localId,
            value = genScenarioValue(state),
            body = genScenarioStatements(
                state = nestedState,
                targetSize = random.nextInt(1, 5),
                allowStructuredStatements = false,
                allowTerminalStatements = false,
            ),
        )
    }

    // Emits a conditional with independently generated small then/else bodies.
    private fun genIf(state: BodyGenerationState): ScenarioOp.If =
        ScenarioOp.If(
            condition = genScenarioValue(state),
            thenBody = genNestedScenarioBody(state, maxSize = 4),
            elseBody = genNestedScenarioBody(state, maxSize = 4),
        )

    // Emits a try/finally where finally always perturbs the heap and requests a GC.
    private fun genTryFinally(state: BodyGenerationState): ScenarioOp.TryFinally =
        ScenarioOp.TryFinally(
            body = genNestedScenarioBody(state, maxSize = 4),
            finallyBody = listOf(
                ScenarioOp.PerformGc(),
                ScenarioOp.AllocationBurst(chooseClass(), random.nextInt(4, 17)),
            ),
        )

    // Generates a bounded nested body from a forked state to avoid invalidating outer local accounting.
    private fun genNestedScenarioBody(state: BodyGenerationState, maxSize: Int): List<ScenarioOp> {
        val nestedState = state.fork()
        val size = random.nextInt(1, maxSize.coerceAtLeast(1) + 1)
        return genScenarioStatements(
            state = nestedState,
            targetSize = size,
            allowStructuredStatements = false,
            allowTerminalStatements = false,
        )
    }

    // Main statement loop: mixes random statements with occasional feature-gated topology templates.
    private fun genScenarioStatements(
        state: BodyGenerationState,
        targetSize: Int,
        allowStructuredStatements: Boolean,
        allowTerminalStatements: Boolean,
    ): List<ScenarioOp> {
        val statements = mutableListOf<ScenarioOp>()

        while (statements.size < targetSize) {
            val remaining = targetSize - statements.size
            if (allowTerminalStatements && remaining <= 2 && random.nextDouble() < 0.18) {
                statements += genTerminalOp(state)
                break
            }
            if (allowStructuredStatements && remaining >= 4 && random.nextDouble() < 0.28) {
                val topologyStatements = genTopologyScenario(state, remaining)
                if (topologyStatements != null) {
                    statements += topologyStatements
                    continue
                }
            }
            statements += genScenarioStatement(state, allowStructuredStatements)
        }

        return statements
    }

    // Generates one ordinary statement after filtering out kinds unsupported by the active capabilities.
    private fun genScenarioStatement(state: BodyGenerationState, allowStructuredStatements: Boolean = true): ScenarioOp = when (genStatementKind()) {
        StatementKind.ALLOC -> genAlloc(state)
        StatementKind.ALLOCATION_BURST -> genAllocationBurst()
        StatementKind.LOAD -> genLoad(state)
        StatementKind.STORE -> genStore(state)
        StatementKind.CLEAR ->
            if (ScenarioFeature.EXPLICIT_CLEAR_OP in features) genClear(state) else genStore(state)
        StatementKind.STORE_BATCH ->
            if (ScenarioFeature.STORE_BATCH_OP in features) genStoreBatch(state) else genStore(state)
        StatementKind.CALL -> genCall(state)
        StatementKind.FOREIGN_ROUNDTRIP ->
            if (ScenarioFeature.CFFI_CALLBACK_ROUNDTRIP in features) genForeignRoundTrip(state) else genLoad(state)
        StatementKind.SPAWN_THREAD -> genSpawnThread(state)
        StatementKind.SPAWN_JOIN ->
            if (ScenarioFeature.JOINED_SPAWN_OP in features && allowStructuredStatements) genSpawnJoin(state) else genSpawnThread(state)
        StatementKind.SPAWN_WITH_RESULT ->
            if (ScenarioFeature.SPAWN_WITH_RESULT_OP in features && allowStructuredStatements) genSpawnWithResult(state) else genSpawnThread(state)
        StatementKind.BLOCK -> if (allowStructuredStatements) genBlock(state) else genAlloc(state)
        StatementKind.SCOPED_ROOT ->
            if (ScenarioFeature.SCOPED_ROOT_OP in features && allowStructuredStatements) genScopedRoot(state) else genAlloc(state)
        StatementKind.IF -> if (allowStructuredStatements) genIf(state) else genLoad(state)
        StatementKind.TRY_FINALLY -> if (allowStructuredStatements) genTryFinally(state) else ScenarioOp.PerformGc()
        StatementKind.PERFORM_GC -> ScenarioOp.PerformGc()
        StatementKind.GC_EPOCH ->
            if (ScenarioFeature.GC_EPOCH_OP in features) genGcEpoch() else ScenarioOp.PerformGc()
        StatementKind.COMPARE_AND_SET ->
            if (ScenarioFeature.COMPARE_AND_SET_OP in features) genCompareAndSet(state) else genStore(state)
    }

    private fun genStatementKind(): StatementKind =
        generateSequence { distributions.statement.next(random) }
            .first { it in supportedStatementKinds }

    // Generates random argument expressions for object constructors and function calls.
    private fun genScenarioArgs(state: BodyGenerationState): List<ScenarioValue> =
        List(distributions.numParameters.next(random)) { genScenarioValue(state) }

    // Generates a value reference. Priority order keeps invalid stress to a small fraction:
    //   1. valid readable local (real object local or function parameter)
    //   2. valid global (single-slot, empty path)
    //   3. small invalid stress (spec §5.1) when a readable local exists, to keep some stress input
    // When readableLocals is empty (body early before any CreateObject, or function body whose
    // parameters were not added to readableLocals), fall back to a valid global instead of an invalid id.
    private fun genScenarioValue(state: BodyGenerationState): ScenarioValue = when (distributions.access.next(random)) {
        AccessKind.LOCAL -> {
            val localId = state.chooseReadableLocalOrNull(random)
            if (localId == null) {
                ScenarioValue.GlobalRef(chooseGlobal(), ScenarioPath(emptyList()))
            } else if (random.nextDouble() < 0.95) {
                ScenarioValue.LocalRef(localId, genFieldPathFor(state, localId))
            } else {
                ScenarioValue.LocalRef(chooseLocal(), genPath())
            }
        }
        AccessKind.GLOBAL -> ScenarioValue.GlobalRef(chooseGlobal(), ScenarioPath(emptyList()))
    }

    // Generates a write target. Globals are single-slot, so their path is empty.
    // For LOCAL writes, preferFieldStore controls whether we target a field or the root slot itself:
    // - preferFieldStore=true: write a real field of a known object local (or fall back to a stress path);
    // - preferFieldStore=false: write the root slot directly (empty path), preserving root publish/clear coverage.
    // When no mutable local is available (body early, or function body with only immutable parameters),
    // fall back to a valid Global location instead of an invalid local id, so store/clear always lands on
    // a real slot that translators can resolve.
    private fun genScenarioLocation(state: BodyGenerationState): ScenarioLocation = when (distributions.access.next(random)) {
        AccessKind.LOCAL -> {
            val mutableLocalId = state.chooseMutableLocalOrNull(random)
            if (mutableLocalId == null) {
                ScenarioLocation.Global(chooseGlobal(), ScenarioPath(emptyList()))
            } else {
                val preferFieldStore = random.nextDouble() < 0.55
                val fieldfulLocalId = state.chooseFieldfulMutableLocalOrNull(random)
                val localId = if (preferFieldStore) fieldfulLocalId ?: mutableLocalId else mutableLocalId
                val path = if (preferFieldStore) genFieldPathFor(state, localId) else ScenarioPath(emptyList())
                ScenarioLocation.Local(localId, path)
            }
        }
        AccessKind.GLOBAL -> ScenarioLocation.Global(chooseGlobal(), ScenarioPath(emptyList()))
    }

    // Picks a path for a value/location reference.
    // - known object local + fields > 0: real single-segment field path.
    // - known object local + fields == 0: empty path, i.e. reference to the object root itself.
    // - function parameter local (in readableLocals but classIdOf returns null, since parameters
    //   are not declared via allocateLocal and have no classId): empty path, references the
    //   parameter root. Legal and meaningful for translators.
    // - invalid id from chooseLocal() stress fallback (only reached via genScenarioValue's 5%
    //   invalid-stress branch, which fires when a readable local already exists): genPath(),
    //   kept as controlled invalid input per spec §5.1.
    //
    // Note: allocateUnknownLocal() no longer adds to readableLocals, so genLoad/genCall reserved
    // locals are never picked by genScenarioValue/genScenarioLocation and never reach this helper.
    // When readableLocals/mutableLocals is empty (body early before any CreateObject, or function
    // body with only immutable parameters), genScenarioValue/genScenarioLocation fall back to a
    // valid global instead of calling chooseLocal(), so genFieldPathFor is not invoked on invalid ids.
    private fun genFieldPathFor(state: BodyGenerationState, localId: Int): ScenarioPath {
        val classId = state.classIdOf(localId)
        return when {
            classId != null -> {
                val fieldIds = generatedClasses[classId].fields.indices.toList()
                if (fieldIds.isEmpty()) ScenarioPath(emptyList())
                else ScenarioPath(listOf(fieldIds.random(random)))
            }
            state.isKnownLocal(localId) -> ScenarioPath(emptyList())
            else -> genPath()
        }
    }

    // Generates an arbitrary path; translators/backend validation decide how nonexistent fields behave.
    fun genPath(): ScenarioPath = ScenarioPath(List(distributions.pathLength.next(random)) {
        random.nextInt(0, Int.MAX_VALUE)
    })

    // Helper paths/locations used by topology templates that need a simple first-field edge.
    private fun genFieldPath(): ScenarioPath = ScenarioPath(listOf(0))
    private fun fieldPath(fieldId: Int): ScenarioPath = ScenarioPath(listOf(fieldId))
    private fun localLocation(localId: Int, path: ScenarioPath = ScenarioPath(emptyList())) = ScenarioLocation.Local(localId, path)
    private fun globalLocation(globalId: Int, path: ScenarioPath = ScenarioPath(emptyList())) = ScenarioLocation.Global(globalId, path)
    private fun singletonLocation(singletonId: Int, path: ScenarioPath = ScenarioPath(emptyList())) = ScenarioLocation.Singleton(singletonId, path)
    private fun allocateCheckpointId(): Int = nextCheckpointId++

    // Tries a weighted primary topology and then enabled fallbacks until one fits the remaining budget/state.
    private fun genTopologyScenario(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        topologyAttemptOrder()
            .take(MAX_TOPOLOGY_ATTEMPTS)
            .forEach { topologyKind ->
                topologyAttempts.increment(topologyKind)
                val generated = genTopologyScenario(topologyKind, state, remaining)
                if (generated != null) {
                    topologyHits.increment(topologyKind)
                    return generated
                }
            }
        return null
    }

    // Lists only topology templates whose feature gates are active for the current generation profile.
    private fun enabledScenarioTopologyKinds(): List<ScenarioTopologyKind> =
        ScenarioTopologyKind.entries.filter { it.requiredFeature() in features && capabilities.supports(it) }

    // Gives the weighted family/topology distribution the first chance, then shuffles enabled stress templates as fallbacks.
    private fun topologyAttemptOrder(): List<ScenarioTopologyKind> {
        val enabled = enabledScenarioTopologyKinds()
        if (enabled.isEmpty()) return emptyList()
        val stressEnabled = enabled.filter { it.family != ScenarioTopologyFamily.ORACLE }
        val selectionPool = stressEnabled.ifEmpty { enabled }
        val enabledFamilies = selectionPool.map { it.family }.toSet()
        val primaryFamily =
            if (enabledFamilies == setOf(ScenarioTopologyFamily.ORACLE)) {
                ScenarioTopologyFamily.ORACLE
            } else {
                generateSequence { distributions.topologyFamily.next(random) }
                    .first { it in enabledFamilies }
            }
        val primary = generateSequence { distributions.topologyKindByFamily.getValue(primaryFamily).next(random) }
            .first { it in selectionPool }
        return listOf(primary) + (selectionPool - primary).shuffled(random)
    }

    // Converts enabled topology kinds back to feature ids for capability-repair decisions.
    private fun enabledTopologyFeatures(): Set<ScenarioFeature> =
        ScenarioTopologyKind.entries.map { it.requiredFeature() }.filter { it in features }.toSet()

    // True when generation must guarantee structural support for at least one topology.
    private fun hasAnyEnabledTopology(): Boolean = enabledTopologyFeatures().isNotEmpty()

    // Determines whether at least one generated class must contain an object-array field.
    private fun needsArrayFieldClass(): Boolean =
        ScenarioFeature.RICH_FIELDS in features ||
            ScenarioFeature.TOPOLOGY_ARRAY_SLOT_GRAPH in features ||
            ScenarioFeature.TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF in features ||
            ScenarioFeature.TOPOLOGY_MULTI_ROOT_STAGGERED_CLEAR in features ||
            ScenarioFeature.TOPOLOGY_CONCURRENT_ARRAY_SLOT_HANDOFF in features ||
            ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE in features ||
            ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_RESTORE_BARRIER in features ||
            ScenarioFeature.TOPOLOGY_MIXED_FIELD_ARRAY_MUTATION_BARRIER in features ||
            ScenarioFeature.TOPOLOGY_WEAK_ARRAY_SLOT in features

    // Determines whether at least one generated class must have several strong-reference slots.
    private fun needsMultiStrongRefFieldClass(): Boolean =
        ScenarioFeature.TOPOLOGY_LARGE_OBJECT_MULTI_FIELD_REWRITE in features

    // Topology templates generally need at least one field edge they can control.
    private fun needsStrongRefFieldClass(): Boolean =
        hasAnyEnabledTopology()

    // Determines whether any enabled topology needs a shared global, regardless of field strength.
    private fun needsSharedGlobal(): Boolean =
        enabledTopologyFeatures().any {
            it in setOf(
                ScenarioFeature.TOPOLOGY_GLOBAL_REATTACH,
                ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN,
                ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN_WITH_ALLOCATION_BURST,
                ScenarioFeature.TOPOLOGY_CONCURRENT_ROOT_MIGRATION,
            )
        }

    // Determines whether any enabled topology needs a shared strong global root for stable handoff/liveness.
    private fun needsStrongSharedGlobal(): Boolean =
        enabledTopologyFeatures().any {
            it in setOf(
                ScenarioFeature.ORACLE_SINGLE_STRONG_SLOT,
                ScenarioFeature.ORACLE_REACHABILITY_CONSISTENCY,
                ScenarioFeature.ORACLE_ROOT_MIGRATION_CAPSULE,
                ScenarioFeature.TOPOLOGY_REACHABILITY_CONSISTENCY,
                ScenarioFeature.TOPOLOGY_ROOT_MIGRATION,
                ScenarioFeature.TOPOLOGY_DELETE_EDGE_THEN_GC,
                ScenarioFeature.TOPOLOGY_WEAK_REF_LIFECYCLE,
                ScenarioFeature.TOPOLOGY_CONCURRENT_PUBLISH_CLEAR_GC,
                ScenarioFeature.TOPOLOGY_WORKER_ALLOC_PUBLISH,
                ScenarioFeature.TOPOLOGY_MULTI_STAGE_ROOT_HANDOFF,
                ScenarioFeature.TOPOLOGY_PING_PONG_ROOT_TRANSFER,
                ScenarioFeature.TOPOLOGY_CONCURRENT_DUPLICATE_HANDOFF,
                ScenarioFeature.TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF,
                ScenarioFeature.TOPOLOGY_STALE_OWNER_MUTATION_AFTER_HANDOFF,
                ScenarioFeature.TOPOLOGY_THREAD_LOCAL_SHARED_HANDOFF,
                ScenarioFeature.TOPOLOGY_WORKER_CAPTURE_ROOT,
                ScenarioFeature.TOPOLOGY_MULTI_ROOT_STAGGERED_CLEAR,
                ScenarioFeature.TOPOLOGY_CONCURRENT_ARRAY_SLOT_HANDOFF,
                ScenarioFeature.TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR,
                ScenarioFeature.TOPOLOGY_TRY_FINALLY_ROOT_CLEAR,
                ScenarioFeature.TOPOLOGY_RETURN_ESCAPE_WORKER_PUBLISH,
                ScenarioFeature.TOPOLOGY_THREAD_LOCAL_CLEAR_ON_WORKER_EXIT,
                ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE,
                ScenarioFeature.TOPOLOGY_WORKER_PUBLISH_MAIN_CLEAR_BARRIER,
                ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_RESTORE_BARRIER,
                ScenarioFeature.TOPOLOGY_MIXED_FIELD_ARRAY_MUTATION_BARRIER,
                ScenarioFeature.TOPOLOGY_LARGE_OBJECT_MULTI_FIELD_REWRITE,
                ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN_WITH_ALLOCATION_BURST,
                ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_MULTI_PHASE_SEQUENCE,
                ScenarioFeature.TOPOLOGY_SHARED_NODE_RECONNECT_BETWEEN_OWNERS,
                ScenarioFeature.TOPOLOGY_CYCLE_BREAK_AND_REROOT,
                ScenarioFeature.TOPOLOGY_WEAK_ROOT_HANDOFF,
                ScenarioFeature.TOPOLOGY_WEAK_ARRAY_SLOT,
                ScenarioFeature.TOPOLOGY_WEAK_THREAD_LOCAL_ROOT,
                ScenarioFeature.TOPOLOGY_WEAK_STRONG_GLOBAL_ALTERNATING,
                ScenarioFeature.TOPOLOGY_WEAK_LATE_STRONG_RESCUE,
                ScenarioFeature.TOPOLOGY_WEAK_MULTI_EPOCH_OBSERVE,
                ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH,
                ScenarioFeature.TOPOLOGY_WORKER_RESULT_ESCAPE,
                ScenarioFeature.TOPOLOGY_WORKER_RESULT_THEN_CLEAR_GC,
                ScenarioFeature.TOPOLOGY_NESTED_WORKER_ROOT_HANDOFF,
                ScenarioFeature.TOPOLOGY_CAS_ROOT_CONTENTION,
                ScenarioFeature.TOPOLOGY_CFFI_CALLBACK_AFTER_GC,
                ScenarioFeature.TOPOLOGY_CFFI_IDENTITY_HANDOFF,
            )
        }

    // Weak lifecycle stress needs a weak global slot in addition to the strong publishing root.
    private fun needsWeakGlobal(): Boolean =
        ScenarioFeature.TOPOLOGY_WEAK_REF_LIFECYCLE in features ||
            ScenarioFeature.TOPOLOGY_WEAK_ROOT_HANDOFF in features ||
            ScenarioFeature.TOPOLOGY_WEAK_ARRAY_SLOT in features ||
            ScenarioFeature.TOPOLOGY_WEAK_THREAD_LOCAL_ROOT in features ||
            ScenarioFeature.TOPOLOGY_WEAK_STRONG_GLOBAL_ALTERNATING in features ||
            ScenarioFeature.TOPOLOGY_WEAK_LATE_STRONG_RESCUE in features ||
            ScenarioFeature.TOPOLOGY_WEAK_MULTI_EPOCH_OBSERVE in features

    // Thread-local handoff stress needs a deterministic thread-local strong slot.
    private fun needsThreadLocalStrongGlobal(): Boolean =
        ScenarioFeature.TOPOLOGY_THREAD_LOCAL_SHARED_HANDOFF in features ||
            ScenarioFeature.TOPOLOGY_THREAD_LOCAL_CLEAR_ON_WORKER_EXIT in features ||
            ScenarioFeature.TOPOLOGY_WEAK_THREAD_LOCAL_ROOT in features

    // Finalizer stress publishes from cleanup code into a shared strong marker root.
    private fun needsFinalizerClass(): Boolean =
        ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH in features

    // Computes the minimum number of globals needed so mandatory root slots can be generated up front.
    private fun minimumGlobalDefinitions(): Int {
        val distinctRequiredSlots = listOf(
            needsStrongSharedGlobal(),
            needsWeakGlobal(),
            needsThreadLocalStrongGlobal(),
        ).count { it }
        return maxOf(
            if (needsSharedGlobal()) 1 else 0,
            distinctRequiredSlots +
                (if (needsInterfacePolymorphism()) 1 else 0) +
                (if (needsSealedHierarchy()) 1 else 0),
        )
    }

    private fun needsStructuralExercise(): Boolean =
        needsInterfacePolymorphism() || needsSealedHierarchy() || needsSingletonObjectRoot() || needsInnerClassOuterCapture()

    private fun needsInterfacePolymorphism(): Boolean =
        ScenarioFeature.INTERFACE_POLYMORPHISM in features &&
            capabilities.core.supports(ScenarioDefinitionKind.INTERFACE) &&
            capabilities.core.supports(ScenarioOpKind.INTERFACE_DISPATCH) &&
            capabilities.core.supports(ScenarioFieldKind.TYPED_STRONG_REF)

    private fun shouldEmitSecondBatchStructuralFeature(feature: ScenarioFeature, percent: Int): Boolean =
        feature in features && (forceSecondBatchStructuralFeatures || random.nextInt(100) < percent)

    private fun needsSealedHierarchy(): Boolean =
        emitSealedHierarchy &&
            capabilities.core.supports(ScenarioOpKind.SEALED_DISPATCH) &&
            capabilities.core.supports(ScenarioFieldKind.TYPED_STRONG_REF)

    private fun needsSingletonObjectRoot(): Boolean =
        emitSingletonObjectRoot &&
            capabilities.core.supports(ScenarioDefinitionKind.SINGLETON_OBJECT) &&
            capabilities.core.supports(ScenarioOpKind.SINGLETON_ACCESS)

    private fun needsInnerClassOuterCapture(): Boolean =
        emitInnerClassOuterCapture &&
            capabilities.core.supports(ScenarioOpKind.CREATE_INNER_OBJECT) &&
            capabilities.core.supports(ScenarioOpKind.OUTER_DISPATCH)

    private fun genStructuralExercise(): List<ScenarioOp> = buildList {
        if (needsInterfacePolymorphism()) addAll(genInterfaceExercise())
        if (needsSealedHierarchy()) addAll(genSealedHierarchyExercise())
        if (needsSingletonObjectRoot()) addAll(genSingletonObjectExercise())
        if (needsInnerClassOuterCapture()) addAll(genInnerClassExercise())
    }

    private fun genInterfaceExercise(): List<ScenarioOp> = listOf(
        ScenarioOp.CreateObject(0, 0, declaredType = ScenarioType.InterfaceRef(0)),
        ScenarioOp.Store(globalLocation(interfaceGlobalId()), ScenarioValue.LocalRef(0)),
        ScenarioOp.CreateObject(1, 1, declaredType = ScenarioType.InterfaceRef(0)),
        ScenarioOp.Store(localLocation(0, fieldPath(1)), ScenarioValue.LocalRef(1)),
        ScenarioOp.InterfaceDispatch(2, ScenarioValue.LocalRef(0), 0),
        ScenarioOp.InterfaceDispatch(3, ScenarioValue.GlobalRef(interfaceGlobalId()), 0),
        ScenarioOp.InterfaceDispatch(4, ScenarioValue.LocalRef(0, fieldPath(1)), 0),
    )

    private fun genSealedHierarchyExercise(): List<ScenarioOp> = listOf(
        ScenarioOp.CreateObject(5, 0),
        ScenarioOp.CreateObject(6, 8, listOf(ScenarioValue.LocalRef(5)), declaredType = ScenarioType.ClassRef(7)),
        ScenarioOp.Store(globalLocation(sealedGlobalId()), ScenarioValue.LocalRef(6)),
        ScenarioOp.SealedDispatch(7, ScenarioValue.GlobalRef(sealedGlobalId()), 7),
        ScenarioOp.CreateObject(8, 9, listOf(ScenarioValue.LocalRef(5)), declaredType = ScenarioType.ClassRef(7)),
        ScenarioOp.Store(globalLocation(sealedGlobalId()), ScenarioValue.LocalRef(8)),
        ScenarioOp.SealedDispatch(9, ScenarioValue.GlobalRef(sealedGlobalId()), 7),
    )

    private fun genSingletonObjectExercise(): List<ScenarioOp> = listOf(
        ScenarioOp.CreateObject(10, 0),
        ScenarioOp.Store(singletonLocation(0, fieldPath(0)), ScenarioValue.LocalRef(10)),
        ScenarioOp.SingletonAccess(11, 0, 0),
        ScenarioOp.Observe(ScenarioValue.SingletonRef(0, fieldPath(0))),
    )

    private fun genInnerClassExercise(): List<ScenarioOp> = listOf(
        ScenarioOp.CreateObject(12, 0),
        ScenarioOp.CreateObject(13, 10, listOf(ScenarioValue.LocalRef(12))),
        ScenarioOp.CreateInnerObject(14, ScenarioValue.LocalRef(13), 11, declaredType = ScenarioType.ClassRef(11)),
        ScenarioOp.OuterDispatch(15, ScenarioValue.LocalRef(14), 11),
    )

    private fun interfaceGlobalId(): Int = 0

    private fun sealedGlobalId(): Int = if (needsInterfacePolymorphism()) 1 else 0

    // Dispatches the selected topology kind to the concrete template builder.
    private fun genTopologyScenario(
        topologyKind: ScenarioTopologyKind,
        state: BodyGenerationState,
        remaining: Int,
    ): List<ScenarioOp>? = when (topologyKind) {
            ScenarioTopologyKind.SINGLE_STRONG_SLOT_CAPSULE -> genSingleStrongSlotCapsuleTopology(state, remaining)
            ScenarioTopologyKind.REACHABILITY_CONSISTENCY -> genReachabilityConsistencyTopology(state, remaining)
            ScenarioTopologyKind.REACHABILITY_CONSISTENCY_CAPSULE -> genReachabilityConsistencyCapsuleTopology(state, remaining)
            ScenarioTopologyKind.WEAK_DEAD_CAPSULE -> genWeakDeadCapsuleTopology(state, remaining)
            ScenarioTopologyKind.CYCLE -> genCycleTopology(state, remaining)
            ScenarioTopologyKind.SHARED_NODE -> genSharedNodeTopology(state, remaining)
            ScenarioTopologyKind.GLOBAL_REATTACH -> genGlobalReattachTopology(state, remaining)
            ScenarioTopologyKind.OLD_ROOT_CHURN -> genOldRootChurnTopology(state, remaining)
            ScenarioTopologyKind.ROOT_MIGRATION -> genRootMigrationTopology(state, remaining)
            ScenarioTopologyKind.ROOT_MIGRATION_CAPSULE -> genRootMigrationCapsuleTopology(state, remaining)
            ScenarioTopologyKind.DELETE_EDGE_THEN_GC -> genDeleteEdgeThenGcTopology(state, remaining)
            ScenarioTopologyKind.CONCURRENT_ROOT_MIGRATION -> genConcurrentRootMigrationTopology(state, remaining)
            ScenarioTopologyKind.WEAK_REF_LIFECYCLE -> genWeakRefLifecycleTopology(state, remaining)
            ScenarioTopologyKind.CONCURRENT_PUBLISH_CLEAR_GC -> genConcurrentPublishClearGcTopology(state, remaining)
            ScenarioTopologyKind.ARRAY_SLOT_GRAPH -> genArraySlotGraphTopology(state, remaining)
            ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE -> genGraphMutationSequenceTopology(state, remaining)
            ScenarioTopologyKind.FUNCTION_RETURN_ESCAPE -> genFunctionReturnEscapeTopology(state, remaining)
            ScenarioTopologyKind.WORKER_ALLOC_PUBLISH -> genWorkerAllocPublishTopology(state, remaining)
            ScenarioTopologyKind.MULTI_STAGE_ROOT_HANDOFF -> genMultiStageRootHandoffTopology(state, remaining)
            ScenarioTopologyKind.PING_PONG_ROOT_TRANSFER -> genPingPongRootTransferTopology(state, remaining)
            ScenarioTopologyKind.CONCURRENT_DUPLICATE_HANDOFF -> genConcurrentDuplicateHandoffTopology(state, remaining)
            ScenarioTopologyKind.LOCAL_GLOBAL_ARRAY_HANDOFF -> genLocalGlobalArrayHandoffTopology(state, remaining)
            ScenarioTopologyKind.STALE_OWNER_MUTATION_AFTER_HANDOFF -> genStaleOwnerMutationAfterHandoffTopology(state, remaining)
            ScenarioTopologyKind.THREAD_LOCAL_SHARED_HANDOFF -> genThreadLocalSharedHandoffTopology(state, remaining)
            ScenarioTopologyKind.WORKER_CAPTURE_ROOT -> genWorkerCaptureRootTopology(state, remaining)
            ScenarioTopologyKind.MULTI_ROOT_STAGGERED_CLEAR -> genMultiRootStaggeredClearTopology(state, remaining)
            ScenarioTopologyKind.CONCURRENT_ARRAY_SLOT_HANDOFF -> genConcurrentArraySlotHandoffTopology(state, remaining)
            ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR -> genRootRepublishAfterClearTopology(state, remaining)
            ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR -> genTryFinallyRootClearTopology(state, remaining)
            ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH -> genReturnEscapeWorkerPublishTopology(state, remaining)
            ScenarioTopologyKind.THREAD_LOCAL_CLEAR_ON_WORKER_EXIT -> genThreadLocalClearOnWorkerExitTopology(state, remaining)
            ScenarioTopologyKind.ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE -> genArraySlotClearWithLateRestoreTopology(state, remaining)
            ScenarioTopologyKind.WORKER_PUBLISH_MAIN_CLEAR_BARRIER -> genWorkerPublishMainClearBarrierTopology(state, remaining)
            ScenarioTopologyKind.ARRAY_SLOT_CLEAR_RESTORE_BARRIER -> genArraySlotClearRestoreBarrierTopology(state, remaining)
            ScenarioTopologyKind.MIXED_FIELD_ARRAY_MUTATION_BARRIER -> genMixedFieldArrayMutationBarrierTopology(state, remaining)
            ScenarioTopologyKind.LARGE_OBJECT_MULTI_FIELD_REWRITE -> genLargeObjectMultiFieldRewriteTopology(state, remaining)
            ScenarioTopologyKind.OLD_ROOT_CHURN_WITH_ALLOCATION_BURST -> genOldRootChurnWithAllocationBurstTopology(state, remaining)
            ScenarioTopologyKind.GRAPH_MUTATION_MULTI_PHASE_SEQUENCE -> genGraphMutationMultiPhaseSequenceTopology(state, remaining)
            ScenarioTopologyKind.SHARED_NODE_RECONNECT_BETWEEN_OWNERS -> genSharedNodeReconnectBetweenOwnersTopology(state, remaining)
            ScenarioTopologyKind.CYCLE_BREAK_AND_REROOT -> genCycleBreakAndRerootTopology(state, remaining)
            ScenarioTopologyKind.WEAK_ROOT_HANDOFF -> genWeakRootHandoffTopology(state, remaining)
            ScenarioTopologyKind.WEAK_ARRAY_SLOT -> genWeakArraySlotTopology(state, remaining)
            ScenarioTopologyKind.WEAK_THREAD_LOCAL_ROOT -> genWeakThreadLocalRootTopology(state, remaining)
            ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING -> genWeakStrongGlobalAlternatingTopology(state, remaining)
            ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE -> genWeakLateStrongRescueTopology(state, remaining)
            ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE -> genWeakMultiEpochObserveTopology(state, remaining)
            ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH -> genFinalizerGlobalPublishTopology(state, remaining)
            ScenarioTopologyKind.WORKER_RESULT_ESCAPE -> genWorkerResultEscapeTopology(state, remaining)
            ScenarioTopologyKind.WORKER_RESULT_THEN_CLEAR_GC -> genWorkerResultThenClearGcTopology(state, remaining)
            ScenarioTopologyKind.NESTED_WORKER_ROOT_HANDOFF -> genNestedWorkerRootHandoffTopology(state, remaining)
            ScenarioTopologyKind.CAS_ROOT_CONTENTION -> genCasRootContentionTopology(state, remaining)
            ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC -> genCffiCallbackAfterGcTopology(state, remaining)
            ScenarioTopologyKind.CFFI_IDENTITY_HANDOFF -> genCffiIdentityHandoffTopology(state, remaining)
        }

    // Publishes an object through a strong global, performs GC, then touches it through a C callback.
    private fun genCffiCallbackAfterGcTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 5) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.ForeignRoundTrip(
                value = ScenarioValue.GlobalRef(globalId),
                referenceKind = ScenarioForeignReferenceKind.Strong,
                pattern = ScenarioForeignInteractionPattern.Callback,
                repetitions = 1,
            ),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Sends a fresh local through foreign identity before publishing it to a strong global and collecting.
    private fun genCffiIdentityHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 5) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.ForeignRoundTrip(
                value = ScenarioValue.LocalRef(payloadLocalId),
                referenceKind = ScenarioForeignReferenceKind.Handle,
                pattern = ScenarioForeignInteractionPattern.Identity,
                repetitions = 1,
            ),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Oracle capsule: a payload is alive through exactly one strong slot, then must die after that slot is cleared.
    private fun genSingleStrongSlotCapsuleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val observationId = allocateObservationId()

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val payloadPath = fieldPath(ownerFieldId)

        return listOf(
            ScenarioOp.Block(
                listOf(
                    ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.Store(localLocation(ownerLocalId, payloadPath), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
                    ScenarioOp.CreateReachabilityObservation(
                        observationId = observationId,
                        value = ScenarioValue.GlobalRef(globalId, payloadPath),
                        kind = ScenarioReachabilityObservationKind.Weak,
                    ),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                expectation = ScenarioReachabilityExpectation.Alive,
                label = "single-strong-slot.alive-after-publish",
            ),
            ScenarioOp.Clear(globalLocation(globalId, payloadPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                expectation = ScenarioReachabilityExpectation.Dead,
                label = "single-strong-slot.dead-after-clear",
            ),
        )
    }

    // Stress template: publish a payload through an owner/global path, observe it, clear it, and observe again.
    private fun genReachabilityConsistencyTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val payloadPath = genPath()

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, payloadPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, payloadPath)),
            ScenarioOp.Clear(globalLocation(globalId, payloadPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, payloadPath)),
        )
    }

    // Oracle capsule version of reachability consistency with explicit alive/dead weak observations.
    private fun genReachabilityConsistencyCapsuleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val observationId = allocateObservationId()

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val payloadPath = fieldPath(ownerFieldId)

        return listOf(
            ScenarioOp.Block(
                listOf(
                    ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.Store(localLocation(ownerLocalId, payloadPath), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
                    ScenarioOp.CreateReachabilityObservation(
                        observationId = observationId,
                        value = ScenarioValue.GlobalRef(globalId, payloadPath),
                        kind = ScenarioReachabilityObservationKind.Weak,
                    ),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                expectation = ScenarioReachabilityExpectation.Alive,
                label = "reachability-consistency.alive-after-publish",
            ),
            ScenarioOp.Clear(globalLocation(globalId, payloadPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                expectation = ScenarioReachabilityExpectation.Dead,
                label = "reachability-consistency.dead-after-clear",
            ),
        )
    }

    // Oracle capsule: create a payload inside a block, keep only a weak observation, then require it to die.
    private fun genWeakDeadCapsuleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 3) return null
        val payloadClassId = chooseClass()
        val observationId = allocateObservationId()
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.Block(
                listOf(
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.CreateReachabilityObservation(
                        observationId = observationId,
                        value = ScenarioValue.LocalRef(payloadLocalId),
                        kind = ScenarioReachabilityObservationKind.Weak,
                    ),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                expectation = ScenarioReachabilityExpectation.Dead,
                label = "weak-dead-capsule.dead-after-first-gc",
            ),
        )
    }

    // Creates two objects with mutual references to stress cycle handling.
    private fun genCycleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 3) return null
        val leftClassId = chooseClassWithFieldsOrNull() ?: return null
        val rightClassId = chooseClassWithFieldsOrNull() ?: return null

        val leftLocalId = state.allocateLocal(classFieldCount(leftClassId))
        val rightLocalId = state.allocateLocal(classFieldCount(rightClassId))

        return listOf(
            ScenarioOp.CreateObject(leftLocalId, leftClassId),
            ScenarioOp.CreateObject(rightLocalId, rightClassId),
            ScenarioOp.Store(localLocation(leftLocalId, genFieldPath()), ScenarioValue.LocalRef(rightLocalId)),
            ScenarioOp.Store(localLocation(rightLocalId, genFieldPath()), ScenarioValue.LocalRef(leftLocalId)),
        )
    }

    // Creates one shared payload referenced by two different owners.
    private fun genSharedNodeTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 5) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val secondOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val sharedClassId = chooseClass()

        val sharedLocalId = state.allocateLocal(classFieldCount(sharedClassId))
        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val secondOwnerLocalId = state.allocateLocal(classFieldCount(secondOwnerClassId))

        return listOf(
            ScenarioOp.CreateObject(sharedLocalId, sharedClassId),
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(secondOwnerLocalId, secondOwnerClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, genFieldPath()), ScenarioValue.LocalRef(sharedLocalId)),
            ScenarioOp.Store(localLocation(secondOwnerLocalId, genFieldPath()), ScenarioValue.LocalRef(sharedLocalId)),
        )
    }

    // Moves an object reachable through a global path into a new owner, stressing path-based reattachment.
    private fun genGlobalReattachTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val sourceOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val targetOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseGlobal()

        val sourceOwnerLocalId = state.allocateLocal(classFieldCount(sourceOwnerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val targetOwnerLocalId = state.allocateLocal(classFieldCount(targetOwnerClassId))

        return listOf(
            ScenarioOp.CreateObject(sourceOwnerLocalId, sourceOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(targetOwnerLocalId, targetOwnerClassId),
            ScenarioOp.Store(localLocation(sourceOwnerLocalId, genFieldPath()), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(sourceOwnerLocalId)),
            ScenarioOp.Store(localLocation(targetOwnerLocalId, genFieldPath()), ScenarioValue.GlobalRef(globalId, genFieldPath())),
        )
    }

    // Repeatedly replaces a global-rooted field to churn old references and write barriers.
    private fun genOldRootChurnTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val rootOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val replacementClassId = chooseClass()
        val sharedGlobalId = chooseSharedGlobalOrNull() ?: return null

        val rootOwnerLocalId = state.allocateLocal(classFieldCount(rootOwnerClassId))
        val firstPayloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val secondPayloadLocalId = state.allocateLocal(classFieldCount(replacementClassId))

        return listOf(
            ScenarioOp.CreateObject(rootOwnerLocalId, rootOwnerClassId),
            ScenarioOp.Store(globalLocation(sharedGlobalId), ScenarioValue.LocalRef(rootOwnerLocalId)),
            ScenarioOp.CreateObject(firstPayloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(sharedGlobalId, genFieldPath()), ScenarioValue.LocalRef(firstPayloadLocalId)),
            ScenarioOp.CreateObject(secondPayloadLocalId, replacementClassId),
            ScenarioOp.Store(globalLocation(sharedGlobalId, genFieldPath()), ScenarioValue.LocalRef(secondPayloadLocalId)),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(sharedGlobalId, genFieldPath())),
        )
    }

    // Migrates a payload from source owner/global root to target owner, then clears old roots before GC.
    private fun genRootMigrationTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 10) return null
        val sourceOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val targetOwnerClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val sourceOwnerLocalId = state.allocateLocal(classFieldCount(sourceOwnerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val targetOwnerLocalId = state.allocateLocal(classFieldCount(targetOwnerClassId))
        val sourcePath = genPath()
        val targetPath = genPath()

        return listOf(
            ScenarioOp.CreateObject(sourceOwnerLocalId, sourceOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(targetOwnerLocalId, targetOwnerClassId),
            ScenarioOp.Store(localLocation(sourceOwnerLocalId, sourcePath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(sourceOwnerLocalId)),
            ScenarioOp.Store(localLocation(targetOwnerLocalId, targetPath), ScenarioValue.GlobalRef(globalId, sourcePath)),
            ScenarioOp.Clear(localLocation(sourceOwnerLocalId, sourcePath)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(targetOwnerLocalId, targetPath)),
        )
    }

    // Oracle capsule for root migration: target path must keep the payload alive after source roots are cleared.
    private fun genRootMigrationCapsuleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 11) return null
        val (sourceOwnerClassId, sourceFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (targetOwnerClassId, targetFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val observationId = allocateObservationId()

        val sourceOwnerLocalId = state.allocateLocal(classFieldCount(sourceOwnerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val targetOwnerLocalId = state.allocateLocal(classFieldCount(targetOwnerClassId))
        val sourcePath = fieldPath(sourceFieldId)
        val targetPath = fieldPath(targetFieldId)

        return listOf(
            ScenarioOp.CreateObject(sourceOwnerLocalId, sourceOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(targetOwnerLocalId, targetOwnerClassId),
            ScenarioOp.Store(localLocation(sourceOwnerLocalId, sourcePath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(sourceOwnerLocalId)),
            ScenarioOp.Store(localLocation(targetOwnerLocalId, targetPath), ScenarioValue.GlobalRef(globalId, sourcePath)),
            ScenarioOp.Clear(localLocation(sourceOwnerLocalId, sourcePath)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.CreateReachabilityObservation(
                observationId = observationId,
                value = ScenarioValue.LocalRef(targetOwnerLocalId, targetPath),
                kind = ScenarioReachabilityObservationKind.Weak,
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.CheckReachabilityObservation(
                observationId = observationId,
                ScenarioReachabilityExpectation.Alive,
                "root-migration.target-alive-after-gc",
            ),
            ScenarioOp.Observe(ScenarioValue.LocalRef(targetOwnerLocalId, targetPath)),
        )
    }

    // Deletes a global-rooted edge before GC to stress clearing and post-GC path observation.
    private fun genDeleteEdgeThenGcTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseGlobal()

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val edgePath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.Store(globalLocation(globalId, edgePath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Clear(localLocation(payloadLocalId)),
            ScenarioOp.Clear(globalLocation(globalId, edgePath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, edgePath)),
        )
    }

    // Worker copies a global-rooted payload into a sink while also clearing the original global path.
    private fun genConcurrentRootMigrationTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val sinkClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val sinkLocalId = state.allocateLocal(classFieldCount(sinkClassId))

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(sinkLocalId, sinkClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, genFieldPath()), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(sinkLocalId, genFieldPath()), ScenarioValue.GlobalRef(globalId, genFieldPath())),
                    ScenarioOp.Clear(globalLocation(globalId, genFieldPath())),
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(sinkLocalId, genFieldPath())),
                )
            ),
        )
    }

    // Publishes a payload, creates a weak global alias, drops the strong global, then observes the weak slot.
    private fun genWeakRefLifecycleTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 4) return null
        val payloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val observationId = allocateObservationId()

        return listOf(
            ScenarioOp.Block(
                listOf(
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.CreateReachabilityObservation(
                        observationId = observationId,
                        value = ScenarioValue.GlobalRef(strongGlobalId),
                        kind = ScenarioReachabilityObservationKind.Weak,
                    ),
                    ScenarioOp.Store(
                        globalLocation(weakGlobalId),
                        ScenarioValue.GlobalRef(strongGlobalId),
                        referenceKind = ScenarioStoreReferenceKind.Weak,
                    ),
                    ScenarioOp.Clear(globalLocation(strongGlobalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Moves a strong root between owners while a weak global aliases the current target.
    private fun genWeakRootHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 11) return null
        val (sourceClassId, sourceFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (targetClassId, targetFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null

        val sourceLocalId = state.allocateLocal(classFieldCount(sourceClassId), sourceClassId)
        val targetLocalId = state.allocateLocal(classFieldCount(targetClassId), targetClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val sourcePath = fieldPath(sourceFieldId)
        val targetPath = fieldPath(targetFieldId)

        return listOf(
            ScenarioOp.CreateObject(sourceLocalId, sourceClassId),
            ScenarioOp.CreateObject(targetLocalId, targetClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(sourceLocalId, sourcePath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(sourceLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId, sourcePath), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.Store(localLocation(targetLocalId, targetPath), ScenarioValue.GlobalRef(strongGlobalId, sourcePath)),
            ScenarioOp.Clear(localLocation(sourceLocalId, sourcePath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.Observe(ScenarioValue.LocalRef(targetLocalId, targetPath)),
        )
    }

    // Keeps a weak global beside a strong ObjectArray slot, then clears the array edge around GC.
    private fun genWeakArraySlotTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 10) return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null

        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))

        return listOf(
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(arrayOwnerLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId, arraySlotPath), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.Clear(localLocation(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Publishes a weak alias while the strong root temporarily lives in thread-local storage.
    private fun genWeakThreadLocalRootTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8) return null
        val payloadClassId = chooseClass()
        val threadLocalGlobalId = chooseThreadLocalStrongGlobalOrNull() ?: return null
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null
        val workerState = state.fork()
        val payloadLocalId = workerState.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(threadLocalGlobalId), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(threadLocalGlobalId), referenceKind = ScenarioStoreReferenceKind.Weak),
                    ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.GlobalRef(threadLocalGlobalId)),
                    ScenarioOp.Clear(globalLocation(threadLocalGlobalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(strongGlobalId)),
            ScenarioOp.Clear(globalLocation(strongGlobalId)),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Alternates strong and weak global slots around publish/clear cycles.
    private fun genWeakStrongGlobalAlternatingTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 13) return null
        val firstPayloadClassId = chooseClass()
        val secondPayloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null

        val firstPayloadLocalId = state.allocateLocal(classFieldCount(firstPayloadClassId), firstPayloadClassId)
        val secondPayloadLocalId = state.allocateLocal(classFieldCount(secondPayloadClassId), secondPayloadClassId)

        return listOf(
            ScenarioOp.CreateObject(firstPayloadLocalId, firstPayloadClassId),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(firstPayloadLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.Clear(globalLocation(strongGlobalId)),
            ScenarioOp.AllocationBurst(firstPayloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.CreateObject(secondPayloadLocalId, secondPayloadClassId),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(secondPayloadLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Clears the strong global, then attempts a late strong rescue from the weak slot before observing both roots.
    private fun genWeakLateStrongRescueTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 12) return null
        val payloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.PerformGc(),
            ScenarioOp.Clear(globalLocation(strongGlobalId)),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(strongGlobalId)),
            ScenarioOp.Clear(globalLocation(strongGlobalId)),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Repeatedly observes a weak global across several GC epochs before and after clearing the strong root.
    private fun genWeakMultiEpochObserveTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 12) return null
        val payloadClassId = chooseClass()
        val strongGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val weakGlobalId = chooseWeakGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(strongGlobalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(weakGlobalId), ScenarioValue.GlobalRef(strongGlobalId), referenceKind = ScenarioStoreReferenceKind.Weak),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
            ScenarioOp.Clear(globalLocation(strongGlobalId)),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(weakGlobalId)),
        )
    }

    // Races global publication/clearing with allocation bursts and GC across a worker and the main body.
    private fun genConcurrentPublishClearGcTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(localLocation(payloadLocalId)),
        )
    }

    // Builds object-array edges plus a back edge to stress array-slot graph traversal.
    private fun genArraySlotGraphTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val payloadClassId = chooseClassWithFieldsOrNull() ?: return null

        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val firstSlotPath = ScenarioPath(listOf(arrayFieldId, 0))
        val secondSlotPath = ScenarioPath(listOf(arrayFieldId, 1))

        return listOf(
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(arrayOwnerLocalId, firstSlotPath), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Store(localLocation(payloadLocalId, genFieldPath()), ScenarioValue.LocalRef(arrayOwnerLocalId)),
                    ScenarioOp.Store(localLocation(arrayOwnerLocalId, secondSlotPath), ScenarioValue.LocalRef(payloadLocalId, genFieldPath())),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(arrayOwnerLocalId, firstSlotPath)),
        )
    }

    // Mutates an owner field through two payloads with GC points between replacement and clearing.
    private fun genGraphMutationSequenceTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 12) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val firstPayloadClassId = chooseClass()
        val secondPayloadClassId = chooseClass()
        val globalId = chooseSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val firstPayloadLocalId = state.allocateLocal(classFieldCount(firstPayloadClassId))
        val secondPayloadLocalId = state.allocateLocal(classFieldCount(secondPayloadClassId))
        val ownerFieldPath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(firstPayloadLocalId, firstPayloadClassId),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(ownerLocalId, ownerFieldPath), ScenarioValue.LocalRef(firstPayloadLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.CreateObject(secondPayloadLocalId, secondPayloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerFieldPath), ScenarioValue.LocalRef(secondPayloadLocalId)),
            ScenarioOp.Clear(localLocation(firstPayloadLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Clear(localLocation(ownerLocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
        )
    }

    // Uses the special escaping-return function to make a returned object escape through global and owner paths.
    private fun genFunctionReturnEscapeTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7 || ScenarioFeature.TOPOLOGY_FUNCTION_RETURN_ESCAPE !in features) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val returnedLocalId = state.allocateUnknownLocal()
        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val ownerFieldPath = genFieldPath()

        return listOf(
            ScenarioOp.CallFunction(0, emptyList()),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(returnedLocalId)),
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(ownerLocalId, ownerFieldPath)),
            ScenarioOp.Clear(globalLocation(globalId)),
        )
    }

    // Allocates and publishes an object from a worker, then observes it from the main body after GC.
    private fun genWorkerAllocPublishTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 5) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val workerState = state.fork()
        val workerPayloadLocalId = workerState.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.CreateObject(workerPayloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(workerPayloadLocalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
        )
    }

    // Transfers a payload through multiple owners and workers, clearing previous owners between GC points.
    private fun genMultiStageRootHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 14) return null
        val ownerAClassId = chooseClassWithFieldsOrNull() ?: return null
        val ownerBClassId = chooseClassWithFieldsOrNull() ?: return null
        val ownerCClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerALocalId = state.allocateLocal(classFieldCount(ownerAClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val ownerBLocalId = state.allocateLocal(classFieldCount(ownerBClassId))
        val ownerCLocalId = state.allocateLocal(classFieldCount(ownerCClassId))
        val ownerFieldPath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(ownerALocalId, ownerAClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(ownerBLocalId, ownerBClassId),
            ScenarioOp.CreateObject(ownerCLocalId, ownerCClassId),
            ScenarioOp.Store(localLocation(ownerALocalId, ownerFieldPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerALocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(ownerBLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerBLocalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(ownerBLocalId, ownerFieldPath)),
                )
            ),
            ScenarioOp.Clear(localLocation(ownerALocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(ownerCLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerCLocalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(ownerCLocalId, ownerFieldPath)),
                )
            ),
            ScenarioOp.Clear(localLocation(ownerBLocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Observe(ScenarioValue.LocalRef(ownerCLocalId, ownerFieldPath)),
        )
    }

    // Moves a payload back and forth between two owners via a strong global root.
    private fun genPingPongRootTransferTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 14) return null
        val ownerAClassId = chooseClassWithFieldsOrNull() ?: return null
        val ownerBClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerFieldPath = genFieldPath()

        val ownerALocalId = state.allocateLocal(classFieldCount(ownerAClassId))
        val ownerBLocalId = state.allocateLocal(classFieldCount(ownerBClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.CreateObject(ownerALocalId, ownerAClassId),
            ScenarioOp.CreateObject(ownerBLocalId, ownerBClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerALocalId, ownerFieldPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerALocalId)),
            ScenarioOp.Store(localLocation(ownerBLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Clear(localLocation(ownerALocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerBLocalId)),
            ScenarioOp.Store(localLocation(ownerALocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Clear(localLocation(ownerBLocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Observe(ScenarioValue.LocalRef(ownerALocalId, ownerFieldPath)),
        )
    }

    // Duplicates a global-rooted payload into two worker sinks while clearing the global in one branch.
    private fun genConcurrentDuplicateHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 11) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val sinkAClassId = chooseClassWithFieldsOrNull() ?: return null
        val sinkBClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerFieldPath = genFieldPath()

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val sinkALocalId = state.allocateLocal(classFieldCount(sinkAClassId))
        val sinkBLocalId = state.allocateLocal(classFieldCount(sinkBClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(sinkALocalId, sinkAClassId),
            ScenarioOp.CreateObject(sinkBLocalId, sinkBClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerFieldPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(sinkALocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(sinkALocalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(sinkALocalId, ownerFieldPath)),
                )
            ),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(sinkBLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(sinkBLocalId, ownerFieldPath)),
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.Clear(localLocation(ownerLocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(sinkALocalId, ownerFieldPath)),
        )
    }

    // Hands a payload from a local owner to a global path, then through an array slot into a sink.
    private fun genLocalGlobalArrayHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 13) return null
        val ownerClassId = chooseClassWithFieldsOrNull() ?: return null
        val sinkClassId = chooseClassWithFieldsOrNull() ?: return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerFieldPath = genFieldPath()
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId))
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId))
        val sinkLocalId = state.allocateLocal(classFieldCount(sinkClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(sinkLocalId, sinkClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerFieldPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Clear(localLocation(ownerLocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(sinkLocalId, ownerFieldPath), ScenarioValue.LocalRef(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.Clear(localLocation(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(sinkLocalId, ownerFieldPath)),
        )
    }

    // Mutates a payload after another owner has taken it over, stressing stale-owner and nested-edge handling.
    private fun genStaleOwnerMutationAfterHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 12) return null
        val ownerAClassId = chooseClassWithFieldsOrNull() ?: return null
        val ownerBClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadNestedClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerFieldPath = genFieldPath()

        val ownerALocalId = state.allocateLocal(classFieldCount(ownerAClassId))
        val ownerBLocalId = state.allocateLocal(classFieldCount(ownerBClassId))
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId))
        val nestedPayloadLocalId = state.allocateLocal(classFieldCount(payloadNestedClassId))

        return listOf(
            ScenarioOp.CreateObject(ownerALocalId, ownerAClassId),
            ScenarioOp.CreateObject(ownerBLocalId, ownerBClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(nestedPayloadLocalId, payloadNestedClassId),
            ScenarioOp.Store(localLocation(ownerALocalId, ownerFieldPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerALocalId)),
            ScenarioOp.Store(localLocation(ownerBLocalId, ownerFieldPath), ScenarioValue.GlobalRef(globalId, ownerFieldPath)),
            ScenarioOp.Store(localLocation(payloadLocalId, ownerFieldPath), ScenarioValue.LocalRef(nestedPayloadLocalId)),
            ScenarioOp.Clear(localLocation(ownerALocalId, ownerFieldPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(ownerBLocalId, ownerFieldPath)),
            ScenarioOp.Observe(ScenarioValue.LocalRef(payloadLocalId, ownerFieldPath)),
        )
    }

    // Moves worker-local roots through a thread-local slot into a shared root and back into thread-local storage.
    private fun genThreadLocalSharedHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val payloadClassId = chooseClass()
        val sharedGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val threadLocalGlobalId = chooseThreadLocalStrongGlobalOrNull() ?: return null
        val workerState = state.fork()
        val workerPayloadLocalId = workerState.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.CreateObject(workerPayloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(threadLocalGlobalId), ScenarioValue.LocalRef(workerPayloadLocalId)),
                    ScenarioOp.Store(globalLocation(sharedGlobalId), ScenarioValue.GlobalRef(threadLocalGlobalId)),
                    ScenarioOp.Clear(globalLocation(threadLocalGlobalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(sharedGlobalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(globalLocation(threadLocalGlobalId), ScenarioValue.GlobalRef(sharedGlobalId)),
                    ScenarioOp.Clear(globalLocation(sharedGlobalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(threadLocalGlobalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(sharedGlobalId)),
        )
    }

    // Captures a local payload in a worker while the publishing global is cleared in the main body.
    private fun genWorkerCaptureRootTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 7) return null
        val payloadClassId = chooseClass()
        val sinkClassId = chooseClassWithFieldsOrNull() ?: return null
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val sinkLocalId = state.allocateLocal(classFieldCount(sinkClassId), sinkClassId)
        val sinkPath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(sinkLocalId, sinkClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Store(localLocation(sinkLocalId, sinkPath), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(sinkLocalId, sinkPath)),
        )
    }

    // Keeps one payload reachable through field, array-slot, and global roots while clearing them in stages.
    private fun genMultiRootStaggeredClearTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 13) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val ownerPath = fieldPath(ownerFieldId)
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Clear(localLocation(ownerLocalId, ownerPath)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
                )
            ),
            ScenarioOp.Clear(localLocation(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(arrayOwnerLocalId, arraySlotPath)),
        )
    }

    // Uses an array slot as the primary handoff path between a shared root and a worker-local sink.
    private fun genConcurrentArraySlotHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 10) return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val sinkClassId = chooseClassWithFieldsOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val sinkLocalId = state.allocateLocal(classFieldCount(sinkClassId), sinkClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))
        val sinkPath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(sinkLocalId, sinkClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(arrayOwnerLocalId)),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(localLocation(sinkLocalId, sinkPath), ScenarioValue.GlobalRef(globalId, arraySlotPath)),
                    ScenarioOp.Clear(globalLocation(globalId, arraySlotPath)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(sinkLocalId, sinkPath)),
                )
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(sinkLocalId, sinkPath)),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, arraySlotPath)),
        )
    }

    // Clears a shared root and republishes a replacement from a worker while the main body keeps collecting.
    private fun genRootRepublishAfterClearTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8) return null
        val firstPayloadClassId = chooseClass()
        val replacementClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val firstPayloadLocalId = state.allocateLocal(classFieldCount(firstPayloadClassId), firstPayloadClassId)
        val workerState = state.fork()
        val replacementLocalId = workerState.allocateLocal(classFieldCount(replacementClassId), replacementClassId)

        return listOf(
            ScenarioOp.CreateObject(firstPayloadLocalId, firstPayloadClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(firstPayloadLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.AllocationBurst(firstPayloadClassId, random.nextInt(8, 33)),
                    ScenarioOp.CreateObject(replacementLocalId, replacementClassId),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(replacementLocalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.AllocationBurst(replacementClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
        )
    }

    // Publishes a rooted field and then clears both field and global roots from finally before another GC.
    private fun genTryFinallyRootClearTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val ownerPath = fieldPath(ownerFieldId)

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.TryFinally(
                body = listOf(
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerPath)),
                    ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(4, 17)),
                    ScenarioOp.PerformGc(),
                ),
                finallyBody = listOf(
                    ScenarioOp.Clear(localLocation(ownerLocalId, ownerPath)),
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.PerformGc(),
                ),
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.LocalRef(ownerLocalId, ownerPath)),
        )
    }

    // Publishes a value returned from the escaping helper through a worker before clearing the caller local.
    private fun genReturnEscapeWorkerPublishTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8 || ScenarioFeature.ESCAPING_RETURN_FUNCTION !in features) return null
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val returnedLocalId = state.allocateUnknownLocal()

        return listOf(
            ScenarioOp.CallFunction(0, emptyList()),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(returnedLocalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
                )
            ),
            ScenarioOp.Clear(localLocation(returnedLocalId)),
            ScenarioOp.AllocationBurst(chooseClass(), random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.PerformGc(),
        )
    }

    // Leaves a worker thread-local root live until worker exit while a shared root preserves the payload.
    private fun genThreadLocalClearOnWorkerExitTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val payloadClassId = chooseClass()
        val sharedGlobalId = chooseStrongSharedGlobalOrNull() ?: return null
        val threadLocalGlobalId = chooseThreadLocalStrongGlobalOrNull() ?: return null
        val workerState = state.fork()
        val workerPayloadLocalId = workerState.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.CreateObject(workerPayloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(threadLocalGlobalId), ScenarioValue.LocalRef(workerPayloadLocalId)),
                    ScenarioOp.Store(globalLocation(sharedGlobalId), ScenarioValue.GlobalRef(threadLocalGlobalId)),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Observe(ScenarioValue.GlobalRef(threadLocalGlobalId)),
                )
            ),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(sharedGlobalId)),
            ScenarioOp.Clear(globalLocation(sharedGlobalId)),
            ScenarioOp.PerformGc(),
        )
    }

    // Clears an array slot, collects, then restores it from a backup strong owner field.
    private fun genArraySlotClearWithLateRestoreTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 12) return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val (backupClassId, backupFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val backupLocalId = state.allocateLocal(classFieldCount(backupClassId), backupClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))
        val backupPath = fieldPath(backupFieldId)

        return listOf(
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(backupLocalId, backupClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(localLocation(backupLocalId, backupPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(arrayOwnerLocalId)),
            ScenarioOp.Clear(localLocation(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(backupLocalId, backupPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, arraySlotPath)),
            ScenarioOp.Clear(localLocation(backupLocalId, backupPath)),
        )
    }

    // Uses checkpoints to force GC after a worker-published root is visible and before the worker clears it.
    private fun genWorkerPublishMainClearBarrierTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 10) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val publishedCheckpointId = allocateCheckpointId()
        val mainGcDoneCheckpointId = allocateCheckpointId()
        val workerState = state.fork()
        val payloadLocalId = workerState.allocateLocal(classFieldCount(payloadClassId), payloadClassId)

        return listOf(
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
                    ScenarioOp.Signal(publishedCheckpointId),
                    ScenarioOp.Wait(mainGcDoneCheckpointId),
                    ScenarioOp.Yield,
                    ScenarioOp.Clear(globalLocation(globalId)),
                    ScenarioOp.PerformGc(),
                )
            ),
            ScenarioOp.Wait(publishedCheckpointId),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Signal(mainGcDoneCheckpointId),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
        )
    }

    // Clears an array edge, lets a worker collect in that window, then restores the edge from a backup slot.
    private fun genArraySlotClearRestoreBarrierTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 15) return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val (backupClassId, backupFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val backupLocalId = state.allocateLocal(classFieldCount(backupClassId), backupClassId)
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val slotClearedCheckpointId = allocateCheckpointId()
        val gcAfterClearCheckpointId = allocateCheckpointId()
        val arraySlotPath = ScenarioPath(listOf(arrayFieldId, 0))
        val backupPath = fieldPath(backupFieldId)

        return listOf(
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(backupLocalId, backupClassId),
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(localLocation(backupLocalId, backupPath), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(arrayOwnerLocalId)),
            ScenarioOp.Clear(localLocation(arrayOwnerLocalId, arraySlotPath)),
            ScenarioOp.Signal(slotClearedCheckpointId),
            ScenarioOp.Spawn(
                listOf(
                    ScenarioOp.Wait(slotClearedCheckpointId),
                    ScenarioOp.PerformGc(),
                    ScenarioOp.Signal(gcAfterClearCheckpointId),
                    ScenarioOp.Yield,
                )
            ),
            ScenarioOp.Wait(gcAfterClearCheckpointId),
            ScenarioOp.Store(localLocation(arrayOwnerLocalId, arraySlotPath), ScenarioValue.LocalRef(backupLocalId, backupPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, arraySlotPath)),
            ScenarioOp.Clear(localLocation(backupLocalId, backupPath)),
        )
    }

    // Mutates strong field and ObjectArray slot edges together to stress distinct write-barrier paths.
    private fun genMixedFieldArrayMutationBarrierTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 15) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (arrayOwnerClassId, arrayFieldId) = chooseClassWithArrayFieldOrNull() ?: return null
        val firstPayloadClassId = chooseClass()
        val secondPayloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val arrayOwnerLocalId = state.allocateLocal(classFieldCount(arrayOwnerClassId), arrayOwnerClassId)
        val firstPayloadLocalId = state.allocateLocal(classFieldCount(firstPayloadClassId), firstPayloadClassId)
        val secondPayloadLocalId = state.allocateLocal(classFieldCount(secondPayloadClassId), secondPayloadClassId)
        val ownerPath = fieldPath(ownerFieldId)
        val firstSlotPath = ScenarioPath(listOf(arrayFieldId, 0))
        val secondSlotPath = ScenarioPath(listOf(arrayFieldId, 1))

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(arrayOwnerLocalId, arrayOwnerClassId),
            ScenarioOp.CreateObject(firstPayloadLocalId, firstPayloadClassId),
            ScenarioOp.CreateObject(secondPayloadLocalId, secondPayloadClassId),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(firstPayloadLocalId)),
                    ScenarioOp.Store(localLocation(arrayOwnerLocalId, firstSlotPath), ScenarioValue.LocalRef(firstPayloadLocalId)),
                    ScenarioOp.Store(localLocation(arrayOwnerLocalId, secondSlotPath), ScenarioValue.LocalRef(ownerLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(arrayOwnerLocalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(secondPayloadLocalId)),
                    ScenarioOp.Store(localLocation(arrayOwnerLocalId, firstSlotPath), ScenarioValue.LocalRef(secondPayloadLocalId)),
                )
            ),
            ScenarioOp.AllocationBurst(secondPayloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, firstSlotPath)),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ScenarioPath(listOf(arrayFieldId, 1, ownerFieldId)))),
        )
    }

    // Rewrites several slots of one large owner around allocation pressure and GC.
    private fun genLargeObjectMultiFieldRewriteTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 18) return null
        val (ownerClassId, fieldIds) = chooseClassWithStrongRefFieldsOrNull(minFields = 4) ?: return null
        val payloadClassIds = List(4) { chooseClass() }
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val payloadLocalIds = payloadClassIds.map { classId -> state.allocateLocal(classFieldCount(classId), classId) }
        val paths = fieldIds.take(4).map(::fieldPath)

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalIds[0], payloadClassIds[0]),
            ScenarioOp.CreateObject(payloadLocalIds[1], payloadClassIds[1]),
            ScenarioOp.CreateObject(payloadLocalIds[2], payloadClassIds[2]),
            ScenarioOp.CreateObject(payloadLocalIds[3], payloadClassIds[3]),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(ownerLocalId, paths[0]), ScenarioValue.LocalRef(payloadLocalIds[0])),
                    ScenarioOp.Store(localLocation(ownerLocalId, paths[1]), ScenarioValue.LocalRef(payloadLocalIds[1])),
                    ScenarioOp.Store(localLocation(ownerLocalId, paths[2]), ScenarioValue.LocalRef(payloadLocalIds[2])),
                    ScenarioOp.Store(localLocation(ownerLocalId, paths[3]), ScenarioValue.LocalRef(payloadLocalIds[3])),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(ownerLocalId, paths[0]), ScenarioValue.LocalRef(payloadLocalIds[2])),
            ScenarioOp.Store(localLocation(ownerLocalId, paths[1]), ScenarioValue.LocalRef(payloadLocalIds[3])),
            ScenarioOp.Clear(localLocation(ownerLocalId, paths[2])),
            ScenarioOp.Store(localLocation(ownerLocalId, paths[3]), ScenarioValue.LocalRef(payloadLocalIds[0])),
            ScenarioOp.AllocationBurst(payloadClassIds[0], random.nextInt(16, 65)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, paths[0])),
        )
    }

    // Repeatedly rewrites a shared-rooted field while allocation bursts force GC-visible dirty graph churn.
    private fun genOldRootChurnWithAllocationBurstTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 16) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val payloadClassIds = List(3) { chooseClass() }
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val payloadLocalIds = payloadClassIds.map { classId -> state.allocateLocal(classFieldCount(classId), classId) }
        val ownerPath = fieldPath(ownerFieldId)

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(payloadLocalIds[0], payloadClassIds[0]),
            ScenarioOp.CreateObject(payloadLocalIds[1], payloadClassIds[1]),
            ScenarioOp.CreateObject(payloadLocalIds[2], payloadClassIds[2]),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
            ScenarioOp.Store(globalLocation(globalId, ownerPath), ScenarioValue.LocalRef(payloadLocalIds[0])),
            ScenarioOp.AllocationBurst(payloadClassIds[0], random.nextInt(16, 65)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(globalLocation(globalId, ownerPath), ScenarioValue.LocalRef(payloadLocalIds[1])),
            ScenarioOp.AllocationBurst(payloadClassIds[1], random.nextInt(16, 65)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(globalLocation(globalId, ownerPath), ScenarioValue.LocalRef(payloadLocalIds[2])),
            ScenarioOp.AllocationBurst(payloadClassIds[2], random.nextInt(16, 65)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerPath)),
            ScenarioOp.Clear(globalLocation(globalId, ownerPath)),
        )
    }

    // Runs build, clear, reconnect, and observe phases to stress ordered graph mutation barriers.
    private fun genGraphMutationMultiPhaseSequenceTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 18) return null
        val (ownerClassId, ownerFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (backupClassId, backupFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val firstPayloadClassId = chooseClassWithFieldsOrNull() ?: return null
        val secondPayloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerLocalId = state.allocateLocal(classFieldCount(ownerClassId), ownerClassId)
        val backupLocalId = state.allocateLocal(classFieldCount(backupClassId), backupClassId)
        val firstPayloadLocalId = state.allocateLocal(classFieldCount(firstPayloadClassId), firstPayloadClassId)
        val secondPayloadLocalId = state.allocateLocal(classFieldCount(secondPayloadClassId), secondPayloadClassId)
        val ownerPath = fieldPath(ownerFieldId)
        val backupPath = fieldPath(backupFieldId)
        val nestedPath = genFieldPath()

        return listOf(
            ScenarioOp.CreateObject(ownerLocalId, ownerClassId),
            ScenarioOp.CreateObject(backupLocalId, backupClassId),
            ScenarioOp.CreateObject(firstPayloadLocalId, firstPayloadClassId),
            ScenarioOp.CreateObject(secondPayloadLocalId, secondPayloadClassId),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(firstPayloadLocalId)),
                    ScenarioOp.Store(localLocation(firstPayloadLocalId, nestedPath), ScenarioValue.LocalRef(secondPayloadLocalId)),
                    ScenarioOp.Store(localLocation(backupLocalId, backupPath), ScenarioValue.LocalRef(firstPayloadLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerLocalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Clear(localLocation(ownerLocalId, ownerPath)),
            ScenarioOp.AllocationBurst(secondPayloadClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(ownerLocalId, ownerPath), ScenarioValue.LocalRef(backupLocalId, backupPath)),
            ScenarioOp.Clear(localLocation(firstPayloadLocalId, nestedPath)),
            ScenarioOp.Store(localLocation(firstPayloadLocalId, nestedPath), ScenarioValue.LocalRef(secondPayloadLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerPath)),
            ScenarioOp.Clear(localLocation(backupLocalId, backupPath)),
        )
    }

    // Reconnects one shared node between multiple owners, repeatedly changing which owner exposes it.
    private fun genSharedNodeReconnectBetweenOwnersTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 16) return null
        val (ownerAClassId, ownerAFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (ownerBClassId, ownerBFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (ownerCClassId, ownerCFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val sharedClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val ownerALocalId = state.allocateLocal(classFieldCount(ownerAClassId), ownerAClassId)
        val ownerBLocalId = state.allocateLocal(classFieldCount(ownerBClassId), ownerBClassId)
        val ownerCLocalId = state.allocateLocal(classFieldCount(ownerCClassId), ownerCClassId)
        val sharedLocalId = state.allocateLocal(classFieldCount(sharedClassId), sharedClassId)
        val ownerAPath = fieldPath(ownerAFieldId)
        val ownerBPath = fieldPath(ownerBFieldId)
        val ownerCPath = fieldPath(ownerCFieldId)

        return listOf(
            ScenarioOp.CreateObject(ownerALocalId, ownerAClassId),
            ScenarioOp.CreateObject(ownerBLocalId, ownerBClassId),
            ScenarioOp.CreateObject(ownerCLocalId, ownerCClassId),
            ScenarioOp.CreateObject(sharedLocalId, sharedClassId),
            ScenarioOp.Store(localLocation(ownerALocalId, ownerAPath), ScenarioValue.LocalRef(sharedLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerALocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(ownerBLocalId, ownerBPath), ScenarioValue.GlobalRef(globalId, ownerAPath)),
            ScenarioOp.Clear(localLocation(ownerALocalId, ownerAPath)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerBLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(ownerCLocalId, ownerCPath), ScenarioValue.GlobalRef(globalId, ownerBPath)),
            ScenarioOp.Clear(localLocation(ownerBLocalId, ownerBPath)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(ownerCLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, ownerCPath)),
        )
    }

    // Breaks a cycle edge, keeps the cycle member through a new root, then reconnects the edge before GC.
    private fun genCycleBreakAndRerootTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 15) return null
        val (leftClassId, leftFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (rightClassId, rightFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val (rerootClassId, rerootFieldId) = chooseClassWithStrongRefFieldOrNull() ?: return null
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null

        val leftLocalId = state.allocateLocal(classFieldCount(leftClassId), leftClassId)
        val rightLocalId = state.allocateLocal(classFieldCount(rightClassId), rightClassId)
        val rerootLocalId = state.allocateLocal(classFieldCount(rerootClassId), rerootClassId)
        val leftPath = fieldPath(leftFieldId)
        val rightPath = fieldPath(rightFieldId)
        val rerootPath = fieldPath(rerootFieldId)

        return listOf(
            ScenarioOp.CreateObject(leftLocalId, leftClassId),
            ScenarioOp.CreateObject(rightLocalId, rightClassId),
            ScenarioOp.CreateObject(rerootLocalId, rerootClassId),
            ScenarioOp.StoreBatch(
                listOf(
                    ScenarioOp.Store(localLocation(leftLocalId, leftPath), ScenarioValue.LocalRef(rightLocalId)),
                    ScenarioOp.Store(localLocation(rightLocalId, rightPath), ScenarioValue.LocalRef(leftLocalId)),
                    ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(leftLocalId)),
                )
            ),
            ScenarioOp.PerformGc(),
            ScenarioOp.Clear(localLocation(leftLocalId, leftPath)),
            ScenarioOp.Store(localLocation(rerootLocalId, rerootPath), ScenarioValue.LocalRef(rightLocalId)),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(rerootLocalId)),
            ScenarioOp.AllocationBurst(rightClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Store(localLocation(leftLocalId, leftPath), ScenarioValue.GlobalRef(globalId, rerootPath)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId, rerootPath)),
        )
    }

    // Drops a finalizable object and keeps collecting while its cleanup publishes a marker into a shared root.
    private fun genFinalizerGlobalPublishTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 9) return null
        val finalizerClassId = chooseFinalizerClassOrNull() ?: return null
        val markerClassId = chooseNonFinalizerClassOrNull() ?: return null
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val finalizableLocalId = state.allocateLocal(classFieldCount(finalizerClassId), finalizerClassId)

        return listOf(
            ScenarioOp.CreateObject(finalizableLocalId, finalizerClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(finalizableLocalId)),
            ScenarioOp.Clear(localLocation(finalizableLocalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.AllocationBurst(markerClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.AllocationBurst(markerClassId, random.nextInt(8, 33)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Worker creates an object and returns it via future; the result escapes into a caller local,
    // which becomes a new root that subsequent GC must trace. Stress template, no oracle.
    private fun genWorkerResultEscapeTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 6) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val callerResultLocalId = state.allocateLocal(fieldCount = 0)
        val workerBodyState = state.fork()
        val payloadLocalId = workerBodyState.allocateLocal(
            fieldCount = classFieldCount(payloadClassId),
            classId = payloadClassId,
        )

        val workerBody = listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(4, 17)),
            ScenarioOp.PerformGc(),
        )

        return listOf(
            ScenarioOp.SpawnWithResult(
                localId = callerResultLocalId,
                returnValue = ScenarioValue.LocalRef(payloadLocalId),
                body = workerBody,
            ),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(callerResultLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Worker returns an object, caller publishes it, GC, then clears and observes again. Stress template.
    private fun genWorkerResultThenClearGcTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 8) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val callerResultLocalId = state.allocateLocal(fieldCount = 0)
        val workerBodyState = state.fork()
        val payloadLocalId = workerBodyState.allocateLocal(
            fieldCount = classFieldCount(payloadClassId),
            classId = payloadClassId,
        )

        val workerBody = listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(4, 17)),
            ScenarioOp.PerformGc(),
        )

        return listOf(
            ScenarioOp.SpawnWithResult(
                localId = callerResultLocalId,
                returnValue = ScenarioValue.LocalRef(payloadLocalId),
                body = workerBody,
            ),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(callerResultLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.Clear(localLocation(callerResultLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Nested worker result chain: inner worker returns to outer worker, outer returns to main.
    // Tests multi-layer worker root merging.
    private fun genNestedWorkerRootHandoffTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 10) return null
        val payloadClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val outerResultLocalId = state.allocateLocal(fieldCount = 0)
        val outerWorkerState = state.fork()
        val outerPayloadLocalId = outerWorkerState.allocateLocal(fieldCount = 0)
        val innerWorkerState = outerWorkerState.fork()
        val innerPayloadLocalId = innerWorkerState.allocateLocal(
            fieldCount = classFieldCount(payloadClassId),
            classId = payloadClassId,
        )

        val innerBody = listOf(
            ScenarioOp.CreateObject(innerPayloadLocalId, payloadClassId),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(4, 17)),
            ScenarioOp.PerformGc(),
        )
        val outerBody = listOf(
            ScenarioOp.SpawnWithResult(
                localId = outerPayloadLocalId,
                returnValue = ScenarioValue.LocalRef(innerPayloadLocalId),
                body = innerBody,
            ),
            ScenarioOp.PerformGc(),
        )

        return listOf(
            ScenarioOp.SpawnWithResult(
                localId = outerResultLocalId,
                returnValue = ScenarioValue.LocalRef(outerPayloadLocalId),
                body = outerBody,
            ),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(outerResultLocalId)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
        )
    }

    // Multiple workers contend on a shared global root via compare-and-set, with GC interleaving.
    private fun genCasRootContentionTopology(state: BodyGenerationState, remaining: Int): List<ScenarioOp>? {
        if (remaining < 9) return null
        val payloadClassId = chooseClass()
        val replacementClassId = chooseClass()
        val globalId = chooseStrongSharedGlobalOrNull() ?: return null
        val payloadLocalId = state.allocateLocal(classFieldCount(payloadClassId), payloadClassId)
        val replacementLocalId = state.allocateLocal(classFieldCount(replacementClassId), replacementClassId)
        val workerBody = listOf(
            ScenarioOp.CompareAndSet(
                location = globalLocation(globalId),
                expectedValue = ScenarioValue.LocalRef(payloadLocalId),
                newValue = ScenarioValue.LocalRef(replacementLocalId),
            ),
            ScenarioOp.PerformGc(),
        )

        return listOf(
            ScenarioOp.CreateObject(payloadLocalId, payloadClassId),
            ScenarioOp.CreateObject(replacementLocalId, replacementClassId),
            ScenarioOp.Store(globalLocation(globalId), ScenarioValue.LocalRef(payloadLocalId)),
            ScenarioOp.Spawn(body = workerBody, join = false),
            ScenarioOp.Spawn(body = workerBody, join = true),
            ScenarioOp.AllocationBurst(payloadClassId, random.nextInt(4, 17)),
            ScenarioOp.PerformGc(),
            ScenarioOp.Observe(ScenarioValue.GlobalRef(globalId)),
            ScenarioOp.Clear(globalLocation(globalId)),
            ScenarioOp.PerformGc(),
        )
    }
}

private fun <K> MutableMap<K, Int>.increment(key: K) {
    this[key] = getOrDefault(key, 0) + 1
}
