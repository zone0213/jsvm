/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlincffi.resolveKotlinCInteropScenarioGeneratedSourceDir
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlincffi.runKotlinCInteropScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlincffi.backend.KotlinCInteropScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.requiredTestName
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.standaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInfo

class KotlinCInteropScenarioExecutionTest {
    @Test
    fun kotlinCInteropSmoke(testInfo: TestInfo) {
        val host = standaloneExecutionHost()
        val name = testInfo.requiredTestName()
        val output = KotlinCInteropScenarioBackend.lower()
        val generatedDir = host.resolveKotlinCInteropScenarioGeneratedSourceDir(name)
        output.save(generatedDir)
        host.runKotlinCInteropScenario(name, output, host.executionTimeout)
    }
}
