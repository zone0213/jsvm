/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.execution

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.arkts.resolveArkTsScenarioGeneratedSourceDir
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.arkts.runArkTsScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save
import org.junit.jupiter.api.condition.EnabledIfSystemProperty
import org.junit.jupiter.api.Test
import java.nio.file.Files
import kotlin.test.assertTrue
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

/**
 * P1 execution smoke (compile-only). Requires the locally-installed DevEco SDK es2abc; enabled
 * only when -Dgcfuzzing.arkts.runTarget=compile (default) and es2abc is resolvable. Device
 * execution is out of scope for P1.
 */
class ArkTsScenarioExecutionTest {
    @Test
    @EnabledIfSystemProperty(named = "gcfuzzing.arkts.runTarget", matches = "compile")
    fun compileOnlySmoke() {
        val host = StandaloneExecutionHost(
            nativeHomeDir = Files.createTempDirectory("gcfuzz-arkts-nativehome").toFile(),
            targetName = "",
            executionTimeout = 1.minutes,
            resultsRootDir = Files.createTempDirectory("gcfuzz-arkts-runs").toFile(),
            runId = null,
        )
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Global(ScenarioTargetLanguage.ArkTs, ScenarioField.StrongRef),
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.ArkTs,
                    listOf(ScenarioField.StrongRef, ScenarioField.IntValue),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(localId = 0, classId = 0),
                    ScenarioOp.Store(
                        location = org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation.Global(0),
                        value = org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue.LocalRef(0),
                    ),
                    ScenarioOp.AllocationBurst(classId = 0, count = 4),
                    ScenarioOp.PerformGc(),
                )
            )
        )
        val output = ArkTsScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
        val name = "compileOnlySmoke"
        val generatedSourceDir = host.resolveArkTsScenarioGeneratedSourceDir(name)
        output.save(generatedSourceDir)
        host.runArkTsScenario(name, output, host.executionTimeout)

        val compileLog = host.resolveArkTsScenarioGeneratedSourceDir(name).parentFile.resolve("compile.log")
        assertTrue(compileLog.isFile, "compile.log missing")
        assertTrue(compileLog.readText().contains("exitCode=0"), "es2abc did not succeed; see ${compileLog.absolutePath}")
        assertTrue(generatedSourceDir.parentFile.resolve("main.abc").isFile, "main.abc not produced")
    }
}
