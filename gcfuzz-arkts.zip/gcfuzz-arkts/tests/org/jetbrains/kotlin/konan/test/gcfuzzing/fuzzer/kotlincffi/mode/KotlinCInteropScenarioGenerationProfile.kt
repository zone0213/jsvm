/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlincffi.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationCapabilities
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationProfile

internal object KotlinCInteropScenarioGenerationProfile : ScenarioGenerationProfile {
    override val features: ScenarioFeatureSet = ScenarioFeatureSet.NONE
    override val capabilities: ScenarioGenerationCapabilities =
        ScenarioGenerationCapabilities.pureKotlin(features, enableCInterop = false)
}
