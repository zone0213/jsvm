/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlin

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessExecutionException
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessRunner
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.PureKotlinCInteropSupport
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.PureKotlinOutput
import java.io.File
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.test.fail

private fun buildPureKotlinCompilerArgs(
    sourceFile: File,
    nativeHomeDir: File,
    testTargetName: String,
    baseArgs: List<String>,
    gcArgs: List<String>,
    extraBinaryArgs: List<String>,
    outputFile: File,
    minidumpLocation: String,
): List<String> = buildList {
    add(sourceFile.absolutePath)
    add("-kotlin-home")
    add(nativeHomeDir.absolutePath)
    add("-target")
    add(testTargetName)
    addAll(baseArgs)
    if (System.getProperty("gcfuzzing.incrementalCompilation")?.toBoolean() == true) {
        val incrementalCacheDir = outputFile.parentFile.resolve("ic-cache")
        incrementalCacheDir.mkdirs()
        add("-Xenable-incremental-compilation")
        add("-Xic-cache-dir=${incrementalCacheDir.absolutePath}")
    }
    add("-Xbinary=minidumpLocation=$minidumpLocation")
    addAll(gcArgs)
    addAll(extraBinaryArgs)
    add("-produce")
    add("program")
    add("-output")
    add(outputFile.absolutePath)
}

private fun resolvePureKotlinGcArgs(): List<String> = when (System.getProperty("gcfuzzing.gc")?.lowercase()) {
    null, "", "cms" -> listOf(
        "-Xbinary=gc=cms",
        "-Xallocator=custom",
    )
    "cmc" -> buildList {
        add("-Xbinary=gc=cmc")
        add("-Xallocator=crt")
        add("-Xbinary=runtimeAssertionsMode=panic")
    }
    else -> error("Unknown gcfuzzing.gc: ${System.getProperty("gcfuzzing.gc")}. Supported values: cms, cmc")
}

private fun resolvePureKotlinExtraBinaryArgs(): List<String> =
    buildList {
        if (System.getProperty("gcfuzzing.parallelCompilation")?.toBoolean() == true) {
            add("-Xbinary=splitBCfile=2")
        }
        if (System.getProperty("gcfuzzing.asan")?.toBoolean() == true) {
            add("-Xbinary=sanitizer=address")
        }
    }

private fun resolvePureKotlinBuildArgs(baseArgs: List<String>): List<String> {
    val buildType = System.getProperty("gcfuzzing.buildType")
        ?.lowercase()
        ?.ifBlank { null }
        ?: "release"
    val filteredArgs = baseArgs.filterNot { it == "-opt" || it == "-g" }
    val buildTypeArgs = when (buildType) {
        "release" -> listOf("-opt")
        "debug" -> listOf("-g")
        else -> error("Unknown gcfuzzing.buildType: $buildType. Supported values: release, debug")
    }
    return filteredArgs + buildTypeArgs
}

private fun resolveConfiguredLibCrtPath(): String? =
    System.getProperty("gcfuzzing.libcrtPath")
        ?.trim()
        ?.takeIf { it.isNotEmpty() }

private fun isPureKotlinHostCmcRun(): Boolean =
    System.getProperty("gcfuzzing.gc")?.lowercase() == "cmc"

internal fun StandaloneExecutionHost.resolvePureKotlinScenarioBuildDir(testName: String): File = sessionBuildDir.resolve(testName)
internal fun StandaloneExecutionHost.resolvePureKotlinScenarioGeneratedSourceDir(testName: String): File =
    resolvePureKotlinScenarioBuildDir(testName).resolve("generated")

internal fun StandaloneExecutionHost.runPureKotlinScenario(
    testName: String,
    output: PureKotlinOutput,
    executionTimeout: Duration,
) {
    val baseDir = resolvePureKotlinScenarioBuildDir(testName)
    val generatedSourceDir = resolvePureKotlinScenarioGeneratedSourceDir(testName)
    if (output.cInterop != null) {
        runPureKotlinScenarioWithCInterop(
            testName = testName,
            output = output,
            cInterop = output.cInterop,
            executionTimeout = executionTimeout,
            baseDir = baseDir,
            generatedSourceDir = generatedSourceDir,
            nativeHomeDir = nativeHomeDir,
            defaultTargetName = targetName,
        )
        return
    }
    val executableFile = baseDir.resolve("app")
    val compilerArgs = buildPureKotlinCompilerArgs(
        sourceFile = generatedSourceDir.resolve(output.filename),
        nativeHomeDir = nativeHomeDir,
        testTargetName = targetName,
        baseArgs = resolvePureKotlinBuildArgs(output.args),
        gcArgs = resolvePureKotlinGcArgs(),
        extraBinaryArgs = resolvePureKotlinExtraBinaryArgs(),
        outputFile = executableFile,
        minidumpLocation = baseDir.absolutePath,
    )
    baseDir.mkdirs()
    val compilerExecutable = nativeHomeDir.resolve("bin/konanc").absolutePath
    runTool(
        executable = compilerExecutable,
        args = compilerArgs,
        logFile = baseDir.resolve("app.kexe.log"),
        timeout = 5.minutes,
        toolName = "konanc",
    )
    val producedExecutable = resolveProducedExecutableFile(executableFile)
    if (isPureKotlinHostCmcRun()) {
        runPureKotlinScenarioOnHostWithLibCrt(producedExecutable, executionTimeout)
    } else {
        maybeCodesign(producedExecutable)
        runTool(
            executable = producedExecutable.absolutePath,
            args = emptyList(),
            logFile = baseDir.resolve("run.log"),
            timeout = executionTimeout,
            toolName = "run",
        )
    }
}

private fun StandaloneExecutionHost.runPureKotlinScenarioWithCInterop(
    testName: String,
    output: PureKotlinOutput,
    cInterop: PureKotlinCInteropSupport,
    executionTimeout: Duration,
    baseDir: File,
    generatedSourceDir: File,
    nativeHomeDir: File,
    defaultTargetName: String,
) {
    val cinteropExecutable = nativeHomeDir.resolve("bin/cinterop").absolutePath
    val konancExecutable = nativeHomeDir.resolve("bin/konanc").absolutePath
    val cinteropOutputBase = baseDir.resolve("interop/bridge")
    cinteropOutputBase.parentFile.mkdirs()
    val cinteropLibrary = runTool(
        executable = cinteropExecutable,
        args = listOf(
            "-def", generatedSourceDir.resolve(cInterop.cinteropDefFileName).absolutePath,
            "-target", defaultTargetName,
            "-compiler-option", "-I${generatedSourceDir.absolutePath}",
            "-o", cinteropOutputBase.absolutePath,
        ),
        logFile = baseDir.resolve("cinterop.log"),
        timeout = 2.minutes,
        toolName = "cinterop",
    ).let {
        sequenceOf(
            cinteropOutputBase,
            cinteropOutputBase.resolveSibling(cinteropOutputBase.name + ".klib"),
        ).firstOrNull(File::exists) ?: fail("cinterop did not produce a klib under ${cinteropOutputBase.absolutePath}")
    }
    val objectFile = baseDir.resolve("bridge.o")
    runTool(
        executable = "/usr/bin/clang",
        args = listOf(
            "-c",
            generatedSourceDir.resolve(cInterop.cSourceFileName).absolutePath,
            "-o",
            objectFile.absolutePath,
        ),
        logFile = baseDir.resolve("clang.log"),
        timeout = 2.minutes,
        toolName = "clang",
    )
    val executableFile = baseDir.resolve("app")
    val compilerArgs = buildPureKotlinCompilerArgs(
        sourceFile = generatedSourceDir.resolve(output.filename),
        nativeHomeDir = nativeHomeDir,
        testTargetName = defaultTargetName,
        baseArgs = resolvePureKotlinBuildArgs(output.args) + listOf(
            "-library", cinteropLibrary.absolutePath,
            "-linker-option", objectFile.absolutePath,
        ),
        gcArgs = resolvePureKotlinGcArgs(),
        extraBinaryArgs = resolvePureKotlinExtraBinaryArgs(),
        outputFile = executableFile,
        minidumpLocation = baseDir.absolutePath,
    )
    runTool(
        executable = konancExecutable,
        args = compilerArgs,
        logFile = baseDir.resolve("konanc.log"),
        timeout = 5.minutes,
        toolName = "konanc",
    )
    val producedExecutable = resolveProducedExecutableFile(executableFile)
    maybeCodesign(producedExecutable)
    runTool(
        executable = producedExecutable.absolutePath,
        args = emptyList(),
        logFile = baseDir.resolve("run.log"),
        timeout = executionTimeout,
        toolName = "run",
    )
}

private fun resolveProducedExecutableFile(requestedOutputFile: File): File =
    sequenceOf(
        requestedOutputFile,
        requestedOutputFile.resolveSibling(requestedOutputFile.name + ".kexe"),
    ).firstOrNull(File::exists) ?: requestedOutputFile

private fun runTool(
    executable: String,
    args: List<String>,
    logFile: File,
    timeout: Duration,
    toolName: String,
): File {
    logFile.parentFile.mkdirs()
    val result = try {
        ProcessRunner.run(listOf(executable) + args, timeout)
    } catch (e: ProcessExecutionException) {
        val output = buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=${e.exitCode ?: -1}")
            appendLine("stdout:")
            appendLine(e.stdout)
            appendLine("stderr:")
            appendLine(e.stderr)
        }
        logFile.writeText(output)
        fail(output)
    }
    logFile.writeText(
        buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=0")
            appendLine("stdout:")
            appendLine(result.stdout)
            appendLine("stderr:")
            appendLine(result.stderr)
        }
    )
    return logFile
}

private fun runPureKotlinScenarioOnHostWithLibCrt(
    executableFile: File,
    executionTimeout: Duration,
) {
    val baseDir = executableFile.parentFile
    val configuredLibCrtPath = resolveConfiguredLibCrtPath()
    val stdOutLog = baseDir.resolve("run.stdout.log")
    val stdErrLog = baseDir.resolve("run.stderr.log")
    val exitCodeLog = baseDir.resolve("run.exitcode.txt")
    val command = listOf(executableFile.absolutePath)
    val environment = buildMap<String, String> {
        configuredLibCrtPath?.let {
            put("LIBCRT_PATH", it)
            put("DYLD_LIBRARY_PATH", File(it).absolutePath)
            put("DYLD_FALLBACK_LIBRARY_PATH", File(it).absolutePath)
        }
    }

    val runResult = runCatching {
        ProcessRunner.run(command, executionTimeout, executableFile.parentFile, environment)
    }

    val exitCode = runResult.fold(
        onSuccess = { 0 },
        onFailure = { (it as? ProcessExecutionException)?.exitCode }
    )
    val stdOut = runResult.getOrNull()?.stdout ?: (runResult.exceptionOrNull() as? ProcessExecutionException)?.stdout.orEmpty()
    val stdErr = runResult.getOrNull()?.stderr ?: (runResult.exceptionOrNull() as? ProcessExecutionException)?.stderr.orEmpty()
    stdOutLog.writeText(stdOut)
    stdErrLog.writeText(stdErr)
    exitCodeLog.writeText(exitCode?.toString().orEmpty())
    if (exitCode != 0) {
        fail(
            buildString {
                appendLine("Runtime failed for ${executableFile.absolutePath}")
                appendLine("exitCode=${exitCode ?: "TIMEOUT"}")
                appendLine("stdout:")
                appendLine(stdOut)
                appendLine("stderr:")
                appendLine(stdErr)
            }
        )
    }
}

private fun maybeCodesign(executableFile: File) {
    if (!System.getProperty("os.name").lowercase().contains("mac")) return
    runCatching {
        ProcessRunner.run(
            command = listOf("/usr/bin/codesign", "--force", "--sign", "-", executableFile.absolutePath),
            timeout = 1.minutes,
        )
    }
}
