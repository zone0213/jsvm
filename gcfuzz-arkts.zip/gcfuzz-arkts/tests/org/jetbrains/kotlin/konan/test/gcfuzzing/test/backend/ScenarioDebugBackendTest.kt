/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.debug.DebugScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.withExecutionModel
import org.junit.jupiter.api.Test
import kotlin.test.assertTrue

class ScenarioDebugBackendTest {
    @Test
    fun debugBackendRendersScenarioProgram() {
        val rendered = withExecutionModel("pure-kotlin") {
            DebugScenarioBackend.render(generateScenario(7u))
        }

        assertTrue(rendered.startsWith("program {"))
        assertTrue(rendered.contains("definitions {"))
        assertTrue(rendered.contains("main {"))
        assertTrue(
            listOf("alloc ", "store ", "call ", "spawn ", "spawnBody ", "block ", "if ", "try ", "gc ").any(rendered::contains),
            "Expected rendered scenario to contain at least one operation",
        )
    }
}
