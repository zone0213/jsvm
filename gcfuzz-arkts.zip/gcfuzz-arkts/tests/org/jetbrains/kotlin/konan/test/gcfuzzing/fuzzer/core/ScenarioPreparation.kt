/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core

internal class ScenarioPreparedProgram(
    val program: ScenarioProgram,
)

internal interface ScenarioPreparationProfile {
    val targetLanguage: ScenarioTargetLanguage
    val domain: ScenarioDomain
    val capabilities: ScenarioCapabilityProfile

    fun prepareStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind
    fun prepareForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind
}

internal object ScenarioPreparation {
    fun prepare(program: ScenarioProgram, profile: ScenarioPreparationProfile): ScenarioPreparedProgram =
        ScenarioPreparedProgram(
            program = ScenarioProgram(
                definitions = program.definitions.map { prepareDefinition(it, profile) },
                mainBody = prepareBody(program.mainBody, profile),
            )
        )

    private fun prepareDefinition(definition: ScenarioDefinition, profile: ScenarioPreparationProfile): ScenarioDefinition = when (definition) {
        is ScenarioDefinition.Class ->
            ScenarioDefinition.Class(
                profile.targetLanguage,
                definition.fields,
                prepareClassLifecycle(definition.lifecycle, profile),
                definition.interfaces,
                definition.dispatchFieldId,
                definition.kind,
                definition.superClassId,
                definition.sealedPayloadFieldId,
                definition.nestedInClassId,
                definition.outerCaptureFieldId,
            )
        is ScenarioDefinition.Interface -> ScenarioDefinition.Interface(profile.targetLanguage)
        is ScenarioDefinition.SingletonObject ->
            ScenarioDefinition.SingletonObject(profile.targetLanguage, definition.fields)
        is ScenarioDefinition.Function ->
            ScenarioDefinition.Function(
                profile.targetLanguage,
                definition.parameters,
                ScenarioBodyWithReturn(
                    body = prepareBody(definition.body.body, profile),
                    returnValue = prepareValue(definition.body.returnValue, profile),
                ),
                definition.returnType,
            )
        is ScenarioDefinition.Global ->
            ScenarioDefinition.Global(profile.targetLanguage, definition.field, definition.storage)
    }

    private fun prepareBody(body: ScenarioBody, profile: ScenarioPreparationProfile): ScenarioBody =
        ScenarioBody(body.statements.map { prepareOp(it, profile) })

    private fun prepareClassLifecycle(lifecycle: ScenarioClassLifecycle, profile: ScenarioPreparationProfile): ScenarioClassLifecycle = when (lifecycle) {
        ScenarioClassLifecycle.None -> ScenarioClassLifecycle.None
        is ScenarioClassLifecycle.Finalizer ->
            ScenarioClassLifecycle.Finalizer(prepareBody(lifecycle.body, profile))
    }

    private fun prepareOp(op: ScenarioOp, profile: ScenarioPreparationProfile): ScenarioOp = when (op) {
        is ScenarioOp.CreateObject ->
            ScenarioOp.CreateObject(
                localId = op.localId,
                classId = op.classId,
                args = op.args.map { prepareValue(it, profile) },
                domain = profile.domain,
                declaredType = op.declaredType,
            )
        is ScenarioOp.Store ->
            ScenarioOp.Store(
                location = prepareLocation(op.location, profile),
                value = prepareValue(op.value, profile),
                referenceKind = profile.prepareStoreReferenceKind(op.referenceKind),
            )
        is ScenarioOp.CompareAndSet ->
            ScenarioOp.CompareAndSet(
                location = prepareLocation(op.location, profile),
                expectedValue = prepareValue(op.expectedValue, profile),
                newValue = prepareValue(op.newValue, profile),
                domain = profile.domain,
            )
        is ScenarioOp.Clear ->
            ScenarioOp.Clear(prepareLocation(op.location, profile))
        is ScenarioOp.StoreBatch ->
            ScenarioOp.StoreBatch(
                op.stores.map {
                    ScenarioOp.Store(
                        location = prepareLocation(it.location, profile),
                        value = prepareValue(it.value, profile),
                        referenceKind = profile.prepareStoreReferenceKind(it.referenceKind),
                    )
                }
            )
        is ScenarioOp.Observe ->
            ScenarioOp.Observe(prepareValue(op.value, profile))
        is ScenarioOp.ForeignRoundTrip ->
            ScenarioOp.ForeignRoundTrip(
                value = prepareValue(op.value, profile),
                referenceKind = profile.prepareForeignReferenceKind(op.referenceKind),
                pattern = op.pattern,
                repetitions = op.repetitions,
            )
        is ScenarioOp.CreateReachabilityObservation ->
            ScenarioOp.CreateReachabilityObservation(
                observationId = op.observationId,
                value = prepareValue(op.value, profile),
                kind = op.kind,
            )
        is ScenarioOp.CheckReachabilityObservation ->
            ScenarioOp.CheckReachabilityObservation(
                observationId = op.observationId,
                expectation = op.expectation,
                label = op.label,
            )
        is ScenarioOp.CheckReachability ->
            ScenarioOp.CheckReachability(
                value = prepareValue(op.value, profile),
                expectation = op.expectation,
                label = op.label,
            )
        is ScenarioOp.PerformGc ->
            ScenarioOp.PerformGc(profile.domain)
        is ScenarioOp.GcEpoch ->
            ScenarioOp.GcEpoch(
                count = op.count,
                yieldBetween = op.yieldBetween,
                domain = profile.domain,
            )
        is ScenarioOp.Block ->
            ScenarioOp.Block(prepareBody(ScenarioBody(op.body), profile).statements)
        is ScenarioOp.ScopedRoot ->
            ScenarioOp.ScopedRoot(
                localId = op.localId,
                value = prepareValue(op.value, profile),
                body = prepareBody(ScenarioBody(op.body), profile).statements,
            )
        is ScenarioOp.If ->
            ScenarioOp.If(
                condition = prepareValue(op.condition, profile),
                thenBody = prepareBody(ScenarioBody(op.thenBody), profile).statements,
                elseBody = prepareBody(ScenarioBody(op.elseBody), profile).statements,
            )
        is ScenarioOp.TryFinally ->
            ScenarioOp.TryFinally(
                body = prepareBody(ScenarioBody(op.body), profile).statements,
                finallyBody = prepareBody(ScenarioBody(op.finallyBody), profile).statements,
            )
        is ScenarioOp.Return ->
            ScenarioOp.Return(prepareValue(op.value, profile))
        is ScenarioOp.Throw ->
            ScenarioOp.Throw(prepareValue(op.value, profile))
        is ScenarioOp.Spawn ->
            ScenarioOp.Spawn(
                body = prepareBody(ScenarioBody(op.body), profile).statements,
                join = op.join,
            )
        is ScenarioOp.SpawnWithResult ->
            ScenarioOp.SpawnWithResult(
                localId = op.localId,
                returnValue = prepareValue(op.returnValue, profile),
                body = prepareBody(ScenarioBody(op.body), profile).statements,
                domain = profile.domain,
            )
        is ScenarioOp.SpawnFunction ->
            ScenarioOp.SpawnFunction(
                functionId = op.functionId,
                args = op.args.map { prepareValue(it, profile) },
                domain = profile.domain,
            )
        is ScenarioOp.AllocationBurst ->
            ScenarioOp.AllocationBurst(
                classId = op.classId,
                count = op.count,
                domain = profile.domain,
            )
        is ScenarioOp.Signal ->
            op
        is ScenarioOp.Wait ->
            op
        ScenarioOp.Yield ->
            ScenarioOp.Yield
        is ScenarioOp.CallFunction ->
            ScenarioOp.CallFunction(
                functionId = op.functionId,
                args = op.args.map { prepareValue(it, profile) },
                domain = profile.domain,
            )
        is ScenarioOp.InterfaceDispatch ->
            ScenarioOp.InterfaceDispatch(
                localId = op.localId,
                receiver = prepareValue(op.receiver, profile),
                interfaceId = op.interfaceId,
                domain = profile.domain,
            )
        is ScenarioOp.SealedDispatch ->
            ScenarioOp.SealedDispatch(
                localId = op.localId,
                receiver = prepareValue(op.receiver, profile),
                sealedClassId = op.sealedClassId,
                domain = profile.domain,
            )
        is ScenarioOp.SingletonAccess ->
            ScenarioOp.SingletonAccess(
                localId = op.localId,
                singletonId = op.singletonId,
                fieldId = op.fieldId,
                domain = profile.domain,
            )
        is ScenarioOp.CreateInnerObject ->
            ScenarioOp.CreateInnerObject(
                localId = op.localId,
                outer = prepareValue(op.outer, profile),
                classId = op.classId,
                args = op.args.map { prepareValue(it, profile) },
                domain = profile.domain,
                declaredType = op.declaredType,
            )
        is ScenarioOp.OuterDispatch ->
            ScenarioOp.OuterDispatch(
                localId = op.localId,
                receiver = prepareValue(op.receiver, profile),
                classId = op.classId,
                domain = profile.domain,
            )
    }

    private fun prepareValue(value: ScenarioValue, profile: ScenarioPreparationProfile): ScenarioValue = when (value) {
        ScenarioValue.DefaultValue -> ScenarioValue.DefaultValue
        ScenarioValue.NullValue -> ScenarioValue.NullValue
        is ScenarioValue.LocalRef ->
            ScenarioValue.LocalRef(
                localId = value.localId,
                path = value.path,
                domain = profile.domain,
            )
        is ScenarioValue.GlobalRef ->
            ScenarioValue.GlobalRef(
                globalId = value.globalId,
                path = value.path,
                domain = profile.domain,
            )
        is ScenarioValue.SingletonRef ->
            ScenarioValue.SingletonRef(
                singletonId = value.singletonId,
                path = value.path,
                domain = profile.domain,
            )
    }

    private fun prepareLocation(location: ScenarioLocation, profile: ScenarioPreparationProfile): ScenarioLocation = when (location) {
        is ScenarioLocation.Local ->
            ScenarioLocation.Local(
                localId = location.localId,
                path = location.path,
                domain = profile.domain,
            )
        is ScenarioLocation.Global ->
            ScenarioLocation.Global(
                globalId = location.globalId,
                path = location.path,
                domain = profile.domain,
            )
        is ScenarioLocation.Singleton ->
            ScenarioLocation.Singleton(
                singletonId = location.singletonId,
                path = location.path,
                domain = profile.domain,
            )
    }
}
