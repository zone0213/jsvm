/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.profile

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind

/**
 * P1 ArkTS backend has no CFFI support. Reference kinds are accepted as-is (no foreign roundtrip
 * IR is generated because the CFFI feature is not enabled in [ArkTsScenarioGenerationProfile]).
 */
internal object ArkTsScenarioCffi {
    fun validateStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind = referenceKind

    fun validateForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind = referenceKind
}
