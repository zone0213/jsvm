/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.profile.ArkTsScenarioProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityValidator
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPreparation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.ArkTsConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.ArkTsOutput
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.ArkTsOutputMode
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.produceArkTs

/**
 * Lowers a [ScenarioProgram] to an [ArkTsOutput]. Steps mirror [PureKotlinScenarioBackend]:
 *   1. ScenarioPreparation.prepare with the ArkTS profile (rewrites targetLanguage/domain, normalizes
 *      store/foreign reference kinds).
 *   2. ScenarioCapabilityValidator.validate fail-fasts on IR the ArkTS backend cannot consume.
 *   3. produceArkTs translates the prepared IR to .ets (ETS mode) or .js (JavaScript mode) source.
 *
 * Output mode is chosen by the `gcfuzzing.arkts.outputMode` system property (`ets` default, `js`
 * for plain-JS output that runs under `es2abc --extension=js` + `ark_js_vm`).
 */
internal object ArkTsScenarioBackend {
    fun lower(program: ScenarioProgram, config: ScenarioBackendConfig = ScenarioBackendConfig.DEFAULT): ArkTsOutput {
        val prepared = ScenarioPreparation.prepare(program, ArkTsScenarioProfile)
        ScenarioCapabilityValidator.validate(prepared.program, ArkTsScenarioProfile.capabilities)
        val outputMode = when (System.getProperty("gcfuzzing.arkts.outputMode")?.lowercase()) {
            "js", "javascript" -> ArkTsOutputMode.JavaScript
            else -> ArkTsOutputMode.ETS
        }
        return prepared.program.produceArkTs(
            ArkTsConfig(
                moduleName = "main",
                maximumStackDepth = config.maximumStackDepth,
                mainLoopRepeatCount = config.mainLoopRepeatCount,
                softTimeoutMillis = config.softTimeout.inWholeMilliseconds,
                outputMode = outputMode,
            )
        )
    }
}
