/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ProgramId
import kotlin.random.Random

class SimpleFuzzer(seed: Int = 0) {
    private val random = Random(seed)

    @Synchronized
    fun nextStepId() = ProgramId.Initial(random.nextInt().toUInt())
}
