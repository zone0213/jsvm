/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core

internal enum class ScenarioOpKind {
    CREATE_OBJECT,
    STORE,
    CLEAR,
    COMPARE_AND_SET,
    STORE_BATCH,
    OBSERVE,
    FOREIGN_ROUNDTRIP,
    CREATE_REACHABILITY_OBSERVATION,
    CHECK_REACHABILITY_OBSERVATION,
    CHECK_REACHABILITY,
    PERFORM_GC,
    GC_EPOCH,
    BLOCK,
    SCOPED_ROOT,
    IF,
    TRY_FINALLY,
    RETURN,
    THROW,
    SPAWN,
    SPAWN_WITH_RESULT,
    SPAWN_FUNCTION,
    ALLOCATION_BURST,
    SIGNAL,
    WAIT,
    YIELD,
    CALL_FUNCTION,
    INTERFACE_DISPATCH,
    SEALED_DISPATCH,
    SINGLETON_ACCESS,
    CREATE_INNER_OBJECT,
    OUTER_DISPATCH,
}

internal enum class ScenarioFieldKind {
    STRONG_REF,
    TYPED_STRONG_REF,
    WEAK_REF,
    INT_VALUE,
    BOOLEAN_VALUE,
    OBJECT_ARRAY,
}

internal enum class ScenarioDefinitionKind {
    CLASS,
    INTERFACE,
    SINGLETON_OBJECT,
    FUNCTION,
    GLOBAL,
}

internal enum class ScenarioGlobalStorageKind {
    SHARED,
    THREAD_LOCAL,
}

internal enum class ScenarioClassLifecycleKind {
    NONE,
    FINALIZER,
}

internal class ScenarioCapabilityProfile(
    val targetLanguage: ScenarioTargetLanguage,
    val domain: ScenarioDomain,
    val supportedOps: Set<ScenarioOpKind>,
    val supportedFields: Set<ScenarioFieldKind>,
    val supportedDefinitions: Set<ScenarioDefinitionKind>,
    val supportedGlobalStorage: Set<ScenarioGlobalStorageKind>,
    val supportedClassLifecycles: Set<ScenarioClassLifecycleKind>,
    val supportedStoreReferenceKinds: Set<ScenarioStoreReferenceKind>,
    val supportedForeignReferenceKinds: Set<ScenarioForeignReferenceKind>,
) {
    fun supports(opKind: ScenarioOpKind): Boolean = opKind in supportedOps
    fun supports(fieldKind: ScenarioFieldKind): Boolean = fieldKind in supportedFields
    fun supports(definitionKind: ScenarioDefinitionKind): Boolean = definitionKind in supportedDefinitions
    fun supports(storageKind: ScenarioGlobalStorageKind): Boolean = storageKind in supportedGlobalStorage
    fun supports(lifecycleKind: ScenarioClassLifecycleKind): Boolean = lifecycleKind in supportedClassLifecycles

    fun withoutOps(vararg opKinds: ScenarioOpKind): ScenarioCapabilityProfile =
        ScenarioCapabilityProfile(
            targetLanguage = targetLanguage,
            domain = domain,
            supportedOps = supportedOps - opKinds.toSet(),
            supportedFields = supportedFields,
            supportedDefinitions = supportedDefinitions,
            supportedGlobalStorage = supportedGlobalStorage,
            supportedClassLifecycles = supportedClassLifecycles,
            supportedStoreReferenceKinds = supportedStoreReferenceKinds,
            supportedForeignReferenceKinds = supportedForeignReferenceKinds,
        )

    fun withoutFields(vararg fieldKinds: ScenarioFieldKind): ScenarioCapabilityProfile =
        ScenarioCapabilityProfile(
            targetLanguage = targetLanguage,
            domain = domain,
            supportedOps = supportedOps,
            supportedFields = supportedFields - fieldKinds.toSet(),
            supportedDefinitions = supportedDefinitions,
            supportedGlobalStorage = supportedGlobalStorage,
            supportedClassLifecycles = supportedClassLifecycles,
            supportedStoreReferenceKinds = supportedStoreReferenceKinds,
            supportedForeignReferenceKinds = supportedForeignReferenceKinds,
        )

    fun withoutDefinitions(vararg definitionKinds: ScenarioDefinitionKind): ScenarioCapabilityProfile =
        ScenarioCapabilityProfile(
            targetLanguage = targetLanguage,
            domain = domain,
            supportedOps = supportedOps,
            supportedFields = supportedFields,
            supportedDefinitions = supportedDefinitions - definitionKinds.toSet(),
            supportedGlobalStorage = supportedGlobalStorage,
            supportedClassLifecycles = supportedClassLifecycles,
            supportedStoreReferenceKinds = supportedStoreReferenceKinds,
            supportedForeignReferenceKinds = supportedForeignReferenceKinds,
        )

    fun withoutGlobalStorage(vararg storageKinds: ScenarioGlobalStorageKind): ScenarioCapabilityProfile =
        ScenarioCapabilityProfile(
            targetLanguage = targetLanguage,
            domain = domain,
            supportedOps = supportedOps,
            supportedFields = supportedFields,
            supportedDefinitions = supportedDefinitions,
            supportedGlobalStorage = supportedGlobalStorage - storageKinds.toSet(),
            supportedClassLifecycles = supportedClassLifecycles,
            supportedStoreReferenceKinds = supportedStoreReferenceKinds,
            supportedForeignReferenceKinds = supportedForeignReferenceKinds,
        )

    fun withoutClassLifecycles(vararg lifecycleKinds: ScenarioClassLifecycleKind): ScenarioCapabilityProfile =
        ScenarioCapabilityProfile(
            targetLanguage = targetLanguage,
            domain = domain,
            supportedOps = supportedOps,
            supportedFields = supportedFields,
            supportedDefinitions = supportedDefinitions,
            supportedGlobalStorage = supportedGlobalStorage,
            supportedClassLifecycles = supportedClassLifecycles - lifecycleKinds.toSet(),
            supportedStoreReferenceKinds = supportedStoreReferenceKinds,
            supportedForeignReferenceKinds = supportedForeignReferenceKinds,
        )

    companion object {
        fun pureKotlin(enableCInterop: Boolean): ScenarioCapabilityProfile {
            val ops = ScenarioOpKind.entries.toMutableSet()
            if (!enableCInterop) {
                ops -= ScenarioOpKind.FOREIGN_ROUNDTRIP
            }
            return ScenarioCapabilityProfile(
                targetLanguage = ScenarioTargetLanguage.Kotlin,
                domain = ScenarioDomain.Kotlin,
                supportedOps = ops,
                supportedFields = ScenarioFieldKind.entries.toSet(),
                supportedDefinitions = ScenarioDefinitionKind.entries.toSet(),
                supportedGlobalStorage = ScenarioGlobalStorageKind.entries.toSet(),
                supportedClassLifecycles = ScenarioClassLifecycleKind.entries.toSet(),
                supportedStoreReferenceKinds = ScenarioStoreReferenceKind.entries.toSet(),
                supportedForeignReferenceKinds =
                    if (enableCInterop) ScenarioForeignReferenceKind.entries.toSet() else emptySet(),
            )
        }
    }
}

internal val ScenarioOp.kind: ScenarioOpKind
    get() = when (this) {
        is ScenarioOp.CreateObject -> ScenarioOpKind.CREATE_OBJECT
        is ScenarioOp.Store -> ScenarioOpKind.STORE
        is ScenarioOp.Clear -> ScenarioOpKind.CLEAR
        is ScenarioOp.CompareAndSet -> ScenarioOpKind.COMPARE_AND_SET
        is ScenarioOp.StoreBatch -> ScenarioOpKind.STORE_BATCH
        is ScenarioOp.Observe -> ScenarioOpKind.OBSERVE
        is ScenarioOp.ForeignRoundTrip -> ScenarioOpKind.FOREIGN_ROUNDTRIP
        is ScenarioOp.CreateReachabilityObservation -> ScenarioOpKind.CREATE_REACHABILITY_OBSERVATION
        is ScenarioOp.CheckReachabilityObservation -> ScenarioOpKind.CHECK_REACHABILITY_OBSERVATION
        is ScenarioOp.CheckReachability -> ScenarioOpKind.CHECK_REACHABILITY
        is ScenarioOp.PerformGc -> ScenarioOpKind.PERFORM_GC
        is ScenarioOp.GcEpoch -> ScenarioOpKind.GC_EPOCH
        is ScenarioOp.Block -> ScenarioOpKind.BLOCK
        is ScenarioOp.ScopedRoot -> ScenarioOpKind.SCOPED_ROOT
        is ScenarioOp.If -> ScenarioOpKind.IF
        is ScenarioOp.TryFinally -> ScenarioOpKind.TRY_FINALLY
        is ScenarioOp.Return -> ScenarioOpKind.RETURN
        is ScenarioOp.Throw -> ScenarioOpKind.THROW
        is ScenarioOp.Spawn -> ScenarioOpKind.SPAWN
        is ScenarioOp.SpawnWithResult -> ScenarioOpKind.SPAWN_WITH_RESULT
        is ScenarioOp.SpawnFunction -> ScenarioOpKind.SPAWN_FUNCTION
        is ScenarioOp.AllocationBurst -> ScenarioOpKind.ALLOCATION_BURST
        is ScenarioOp.Signal -> ScenarioOpKind.SIGNAL
        is ScenarioOp.Wait -> ScenarioOpKind.WAIT
        ScenarioOp.Yield -> ScenarioOpKind.YIELD
        is ScenarioOp.CallFunction -> ScenarioOpKind.CALL_FUNCTION
        is ScenarioOp.InterfaceDispatch -> ScenarioOpKind.INTERFACE_DISPATCH
        is ScenarioOp.SealedDispatch -> ScenarioOpKind.SEALED_DISPATCH
        is ScenarioOp.SingletonAccess -> ScenarioOpKind.SINGLETON_ACCESS
        is ScenarioOp.CreateInnerObject -> ScenarioOpKind.CREATE_INNER_OBJECT
        is ScenarioOp.OuterDispatch -> ScenarioOpKind.OUTER_DISPATCH
    }

internal val ScenarioField.kind: ScenarioFieldKind
    get() = when (this) {
        ScenarioField.StrongRef -> ScenarioFieldKind.STRONG_REF
        is ScenarioField.TypedStrongRef -> ScenarioFieldKind.TYPED_STRONG_REF
        ScenarioField.WeakRef -> ScenarioFieldKind.WEAK_REF
        ScenarioField.IntValue -> ScenarioFieldKind.INT_VALUE
        ScenarioField.BooleanValue -> ScenarioFieldKind.BOOLEAN_VALUE
        is ScenarioField.ObjectArray -> ScenarioFieldKind.OBJECT_ARRAY
    }

internal val ScenarioGlobalStorage.kind: ScenarioGlobalStorageKind
    get() = when (this) {
        ScenarioGlobalStorage.Shared -> ScenarioGlobalStorageKind.SHARED
        ScenarioGlobalStorage.ThreadLocal -> ScenarioGlobalStorageKind.THREAD_LOCAL
    }

internal val ScenarioDefinition.kind: ScenarioDefinitionKind
    get() = when (this) {
        is ScenarioDefinition.Class -> ScenarioDefinitionKind.CLASS
        is ScenarioDefinition.Interface -> ScenarioDefinitionKind.INTERFACE
        is ScenarioDefinition.SingletonObject -> ScenarioDefinitionKind.SINGLETON_OBJECT
        is ScenarioDefinition.Function -> ScenarioDefinitionKind.FUNCTION
        is ScenarioDefinition.Global -> ScenarioDefinitionKind.GLOBAL
    }

internal val ScenarioClassLifecycle.kind: ScenarioClassLifecycleKind
    get() = when (this) {
        ScenarioClassLifecycle.None -> ScenarioClassLifecycleKind.NONE
        is ScenarioClassLifecycle.Finalizer -> ScenarioClassLifecycleKind.FINALIZER
    }
