/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationCapabilities
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationProfile

internal object PureKotlinScenarioGenerationProfile : ScenarioGenerationProfile {
    override val features: ScenarioFeatureSet = ScenarioFeatureSet.of(
        ScenarioFeature.RICH_FIELDS,
        ScenarioFeature.STRUCTURED_CONTROL_FLOW,
        ScenarioFeature.TERMINAL_STATEMENTS,
        ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
        ScenarioFeature.ESCAPING_RETURN_FUNCTION,
        ScenarioFeature.EXPLICIT_CLEAR_OP,
        ScenarioFeature.STORE_BATCH_OP,
        ScenarioFeature.GC_EPOCH_OP,
        ScenarioFeature.SCOPED_ROOT_OP,
        ScenarioFeature.JOINED_SPAWN_OP,
        ScenarioFeature.SPAWN_WITH_RESULT_OP,
        ScenarioFeature.COMPARE_AND_SET_OP,
        ScenarioFeature.INTERFACE_POLYMORPHISM,
        ScenarioFeature.SEALED_HIERARCHY,
        ScenarioFeature.SINGLETON_OBJECT_ROOT,
        ScenarioFeature.INNER_CLASS_OUTER_CAPTURE,
        ScenarioFeature.TOPOLOGY_CYCLE,
        ScenarioFeature.TOPOLOGY_SHARED_NODE,
        ScenarioFeature.TOPOLOGY_GLOBAL_REATTACH,
        ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN,
        ScenarioFeature.TOPOLOGY_REACHABILITY_CONSISTENCY,
        ScenarioFeature.TOPOLOGY_ROOT_MIGRATION,
        ScenarioFeature.TOPOLOGY_DELETE_EDGE_THEN_GC,
        ScenarioFeature.TOPOLOGY_CONCURRENT_ROOT_MIGRATION,
        ScenarioFeature.TOPOLOGY_WEAK_REF_LIFECYCLE,
        ScenarioFeature.TOPOLOGY_CONCURRENT_PUBLISH_CLEAR_GC,
        ScenarioFeature.TOPOLOGY_ARRAY_SLOT_GRAPH,
        ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_SEQUENCE,
        ScenarioFeature.TOPOLOGY_FUNCTION_RETURN_ESCAPE,
        ScenarioFeature.TOPOLOGY_WORKER_ALLOC_PUBLISH,
        ScenarioFeature.TOPOLOGY_MULTI_STAGE_ROOT_HANDOFF,
        ScenarioFeature.TOPOLOGY_PING_PONG_ROOT_TRANSFER,
        ScenarioFeature.TOPOLOGY_CONCURRENT_DUPLICATE_HANDOFF,
        ScenarioFeature.TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF,
        ScenarioFeature.TOPOLOGY_STALE_OWNER_MUTATION_AFTER_HANDOFF,
        ScenarioFeature.TOPOLOGY_THREAD_LOCAL_SHARED_HANDOFF,
        ScenarioFeature.TOPOLOGY_WORKER_CAPTURE_ROOT,
        ScenarioFeature.TOPOLOGY_MULTI_ROOT_STAGGERED_CLEAR,
        ScenarioFeature.TOPOLOGY_CONCURRENT_ARRAY_SLOT_HANDOFF,
        ScenarioFeature.TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR,
        ScenarioFeature.TOPOLOGY_TRY_FINALLY_ROOT_CLEAR,
        ScenarioFeature.TOPOLOGY_RETURN_ESCAPE_WORKER_PUBLISH,
        ScenarioFeature.TOPOLOGY_THREAD_LOCAL_CLEAR_ON_WORKER_EXIT,
        ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE,
        ScenarioFeature.TOPOLOGY_WORKER_PUBLISH_MAIN_CLEAR_BARRIER,
        ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_RESTORE_BARRIER,
        ScenarioFeature.TOPOLOGY_MIXED_FIELD_ARRAY_MUTATION_BARRIER,
        ScenarioFeature.TOPOLOGY_LARGE_OBJECT_MULTI_FIELD_REWRITE,
        ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN_WITH_ALLOCATION_BURST,
        ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_MULTI_PHASE_SEQUENCE,
        ScenarioFeature.TOPOLOGY_SHARED_NODE_RECONNECT_BETWEEN_OWNERS,
        ScenarioFeature.TOPOLOGY_CYCLE_BREAK_AND_REROOT,
        ScenarioFeature.TOPOLOGY_WEAK_ROOT_HANDOFF,
        ScenarioFeature.TOPOLOGY_WEAK_ARRAY_SLOT,
        ScenarioFeature.TOPOLOGY_WEAK_THREAD_LOCAL_ROOT,
        ScenarioFeature.TOPOLOGY_WEAK_STRONG_GLOBAL_ALTERNATING,
        ScenarioFeature.TOPOLOGY_WEAK_LATE_STRONG_RESCUE,
        ScenarioFeature.TOPOLOGY_WEAK_MULTI_EPOCH_OBSERVE,
        ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH,
        ScenarioFeature.TOPOLOGY_WORKER_RESULT_ESCAPE,
        ScenarioFeature.TOPOLOGY_WORKER_RESULT_THEN_CLEAR_GC,
        ScenarioFeature.TOPOLOGY_NESTED_WORKER_ROOT_HANDOFF,
        ScenarioFeature.TOPOLOGY_CAS_ROOT_CONTENTION,
    )
    override val capabilities: ScenarioGenerationCapabilities =
        ScenarioGenerationCapabilities.pureKotlin(features, enableCInterop = false)
}
