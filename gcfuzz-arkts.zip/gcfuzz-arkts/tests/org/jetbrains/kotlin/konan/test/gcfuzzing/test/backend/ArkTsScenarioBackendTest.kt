/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.junit.jupiter.api.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ArkTsScenarioBackendTest {
    @Test
    fun arkTsBackendLowersMinimalProgram() {
        val program = minimalScenario()
        val output = ArkTsScenarioBackend.lower(program)
        assertEquals("main.ets", output.filename)
        assertTrue("class Class0 implements ArkTsIndexAccess" in output.contents, "expected Class0")
        assertTrue("function main()" in output.contents, "expected main entrypoint")
        assertTrue("tryGc()" in output.contents, "expected tryGc pressure sink")
    }

    @Test
    fun arkTsBackendIsDeterministic() {
        val program = minimalScenario()
        val first = ArkTsScenarioBackend.lower(program)
        val second = ArkTsScenarioBackend.lower(program)
        assertEquals(first.contents, second.contents)
    }

    private fun minimalScenario(): ScenarioProgram = ScenarioProgram(
        definitions = listOf(
            ScenarioDefinition.Global(ScenarioTargetLanguage.ArkTs, ScenarioField.StrongRef),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.ArkTs,
                listOf(ScenarioField.StrongRef, ScenarioField.IntValue),
            ),
        ),
        mainBody = ScenarioBody(
            listOf(
                ScenarioOp.CreateObject(localId = 0, classId = 0),
                ScenarioOp.Store(
                    location = org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation.Global(0),
                    value = org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue.LocalRef(0),
                ),
                ScenarioOp.AllocationBurst(classId = 0, count = 4),
                ScenarioOp.Observe(
                    org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue.GlobalRef(0),
                ),
                ScenarioOp.PerformGc(),
            )
        )
    )
}
