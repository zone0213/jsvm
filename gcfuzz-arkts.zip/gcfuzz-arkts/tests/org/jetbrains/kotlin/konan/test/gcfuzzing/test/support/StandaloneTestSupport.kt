/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.support

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHostResolver
import org.junit.jupiter.api.TestInfo
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

internal fun standaloneExecutionHost(defaultExecutionTimeout: Duration = 1.minutes): StandaloneExecutionHost =
    StandaloneExecutionHostResolver.fromSystemProperties(defaultExecutionTimeout)

internal fun TestInfo.requiredTestName(): String = testMethod.orElseThrow().name
