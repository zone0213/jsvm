/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.profile

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinitionKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDomain
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFieldKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorageKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycleKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOpKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage

/**
 * P5 ArkTS capability profile. This is the supported matrix (not a fuzz strategy toggle).
 *
 * Supported:
 *   ops:      CreateObject, Store, Clear, Observe, PerformGc, AllocationBurst,
 *             CreateReachabilityObservation, CheckReachabilityObservation, CheckReachability
 *   fields:   StrongRef, TypedStrongRef, ObjectArray, IntValue, BooleanValue, WeakRef
 *   defs:     Class, Global, Function
 *   storage:  Shared (also Weak store reference kind for oracle topologies)
 *
 * Closed: thread-local globals, finalizer lifecycle, structured control flow, spawn (P4),
 *         terminal statements, foreign roundtrip.
 *
 * ORACLE CAVEAT (P5 best-effort): ArkTS has no force-GC API, so PerformGc only applies
 * allocation pressure (tryGc). ALIVE assertions stay deterministic; DEAD assertions may false-fire
 * when GC has not yet collected the unreachable object. assertReachability gates DEAD checks behind a
 * best-effort "GC happened" signal (FinalizationRegistry epoch counter) and retries pressure, but
 * cannot match the determinism of kotlin.native.runtime.GC.collect(). This is a deliberate
 * downgrade from the pure-kotlin sample, documented per the P5 scope choice.
 */
internal object ArkTsScenarioCapabilities {
    val core: ScenarioCapabilityProfile = ScenarioCapabilityProfile(
        targetLanguage = ScenarioTargetLanguage.ArkTs,
        domain = ScenarioDomain.ArkTs,
        supportedOps = setOf(
            ScenarioOpKind.CREATE_OBJECT,
            ScenarioOpKind.STORE,
            ScenarioOpKind.CLEAR,
            ScenarioOpKind.OBSERVE,
            ScenarioOpKind.PERFORM_GC,
            ScenarioOpKind.ALLOCATION_BURST,
            ScenarioOpKind.BLOCK,
            ScenarioOpKind.CREATE_REACHABILITY_OBSERVATION,
            ScenarioOpKind.CHECK_REACHABILITY_OBSERVATION,
            ScenarioOpKind.CHECK_REACHABILITY,
        ),
        supportedFields = setOf(
            ScenarioFieldKind.STRONG_REF,
            ScenarioFieldKind.TYPED_STRONG_REF,
            ScenarioFieldKind.OBJECT_ARRAY,
            ScenarioFieldKind.WEAK_REF,
            ScenarioFieldKind.INT_VALUE,
            ScenarioFieldKind.BOOLEAN_VALUE,
        ),
        supportedDefinitions = setOf(
            ScenarioDefinitionKind.CLASS,
            ScenarioDefinitionKind.GLOBAL,
            ScenarioDefinitionKind.FUNCTION,
        ),
        supportedGlobalStorage = setOf(ScenarioGlobalStorageKind.SHARED),
        supportedClassLifecycles = setOf(ScenarioClassLifecycleKind.NONE),
        supportedStoreReferenceKinds = setOf(ScenarioStoreReferenceKind.Strong, ScenarioStoreReferenceKind.Weak),
        supportedForeignReferenceKinds = emptySet(),
    )
}
