/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlincffi.backend.KotlinCInteropScenarioBackend
import org.junit.jupiter.api.Test
import kotlin.test.assertContains
import kotlin.test.assertTrue

class KotlinCInteropScenarioTranslationTest {
    @Test
    fun kotlinCInteropSmokeTranslationContainsStableRefAndBridgeFiles() {
        val output = KotlinCInteropScenarioBackend.lower()

        assertTrue("main.kt" in output.files)
        assertTrue("cinterop.def" in output.files)
        assertTrue("bridge.h" in output.files)
        assertTrue("bridge.c" in output.files)
        assertContains(output.files.getValue("main.kt"), "StableRef.create(payload)")
        assertContains(output.files.getValue("main.kt"), "bridge_run_callback(staticCFunction(::consumeStableRefFromC), stableRef.asCPointer())")
        assertContains(output.files.getValue("main.kt"), "GC.collect()")
        assertContains(output.files.getValue("bridge.h"), "typedef void (*gcfuzz_callback_t)(void* payload);")
        assertContains(output.files.getValue("bridge.c"), "callback(payload);")
        assertContains(output.files.getValue("cinterop.def"), "language = C")
        assertContains(output.files.getValue("cinterop.def"), "package = gcfuzz_kotlincffi_bridge")
    }
}
