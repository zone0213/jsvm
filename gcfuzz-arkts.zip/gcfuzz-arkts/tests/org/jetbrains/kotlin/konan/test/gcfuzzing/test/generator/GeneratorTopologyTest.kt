/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.generator

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycleKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinitionKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFieldKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignInteractionPattern
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOpKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationCapabilities
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioStructuralCoverageKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioTopologyKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenarioWithMetadata
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.withExecutionModel
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import java.nio.file.Files
import kotlin.test.assertTrue

class GeneratorTopologyTest {
    @Test
    fun generatorProducesInterfacePolymorphismAnchor() {
        val program = generateScenario(
            seed = 7u,
            features = ScenarioFeatureSet.of(ScenarioFeature.INTERFACE_POLYMORPHISM),
        )

        val interfaces = program.definitions.filterIsInstance<ScenarioDefinition.Interface>()
        val implementors = program.definitions.filterIsInstance<ScenarioDefinition.Class>()
            .filter { 0 in it.interfaces && it.dispatchFieldId != null }
        val typedGlobal = program.definitions.filterIsInstance<ScenarioDefinition.Global>()
            .any { it.field == ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0)) }

        assertTrue(interfaces.isNotEmpty(), "Expected an interface definition")
        assertTrue(implementors.size >= 2, "Expected multiple interface implementors")
        assertTrue(typedGlobal, "Expected an interface-typed global root")
        assertTrue(
            program.mainBody.statements.count { it is ScenarioOp.InterfaceDispatch } >= 3,
            "Expected dispatch through local, global, and field interface references",
        )
    }

    @Test
    fun generatorRecordsInterfacePolymorphismStructuralTelemetry() {
        val generated = generateScenarioWithMetadata(
            seed = 7u,
            features = ScenarioFeatureSet.of(ScenarioFeature.INTERFACE_POLYMORPHISM),
        )

        val dispatchCount = generated.program.mainBody.statements.count { it is ScenarioOp.InterfaceDispatch }
        assertTrue(dispatchCount >= 3, "Expected interface dispatch statements in generated IR")
        assertTrue(
            generated.telemetry.structuralHits[ScenarioStructuralCoverageKind.INTERFACE_POLYMORPHISM] == dispatchCount,
            "Expected interface polymorphism structural hit count to match generated dispatch count",
        )

        val telemetryFile = Files.createTempDirectory("gcfuzz-structural-telemetry").resolve("topology.json").toFile()
        generated.telemetry.save(telemetryFile, "I-interface")
        val telemetryText = telemetryFile.readText()
        assertTrue(""""structuralHits"""" in telemetryText, "Expected structural hits in telemetry JSON")
        assertTrue(""""INTERFACE_POLYMORPHISM": $dispatchCount""" in telemetryText)
    }

    @Test
    fun generatorProducesSecondBatchTypeSystemStructures() {
        val generated = generateScenarioWithMetadata(
            seed = 11u,
            features = ScenarioFeatureSet.of(
                ScenarioFeature.SEALED_HIERARCHY,
                ScenarioFeature.SINGLETON_OBJECT_ROOT,
                ScenarioFeature.INNER_CLASS_OUTER_CAPTURE,
            ),
        )
        val program = generated.program
        val classes = program.definitions.filterIsInstance<ScenarioDefinition.Class>()

        assertTrue(classes.any { it.kind == ScenarioClassKind.Sealed }, "Expected a sealed class")
        assertTrue(classes.count { it.superClassId != null && it.sealedPayloadFieldId != null } >= 2, "Expected sealed subclasses")
        assertTrue(program.definitions.any { it is ScenarioDefinition.SingletonObject }, "Expected a singleton object")
        assertTrue(classes.any { it.nestedInClassId != null && it.outerCaptureFieldId != null }, "Expected an inner class")
        assertTrue(program.mainBody.statements.any { it is ScenarioOp.SealedDispatch }, "Expected sealed dispatch")
        assertTrue(program.mainBody.statements.any { it is ScenarioOp.SingletonAccess }, "Expected singleton access")
        assertTrue(program.mainBody.statements.any { it is ScenarioOp.OuterDispatch }, "Expected outer capture dispatch")
        assertTrue(
            generated.telemetry.structuralHits[ScenarioStructuralCoverageKind.SEALED_HIERARCHY] == 2,
            "Expected sealed hierarchy structural hits",
        )
        assertTrue(
            generated.telemetry.structuralHits[ScenarioStructuralCoverageKind.SINGLETON_OBJECT_ROOT] == 1,
            "Expected singleton object structural hits",
        )
        assertTrue(
            generated.telemetry.structuralHits[ScenarioStructuralCoverageKind.INNER_CLASS_OUTER_CAPTURE] == 1,
            "Expected inner class structural hits",
        )
    }

    @Test
    fun generatorDisablesInterfacePolymorphismWhenCapabilityIsMissing() {
        val program = generateScenario(
            seed = 7u,
            features = ScenarioFeatureSet.of(ScenarioFeature.INTERFACE_POLYMORPHISM),
            capabilities = ScenarioGenerationCapabilities(
                core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = false)
                    .withoutDefinitions(ScenarioDefinitionKind.INTERFACE),
                supportedTopologies = emptySet(),
            ),
        )

        assertTrue(
            program.definitions.none { it is ScenarioDefinition.Interface },
            "Interface feature must not generate definitions unsupported by the active capability profile",
        )
    }

    @Test
    fun generatorRecordsTopologyTelemetry() {
        val generatedScenarios = withExecutionModel("pure-kotlin") {
            (0u..255u).map(::generateScenarioWithMetadata)
        }
        val totalAttempts = generatedScenarios.sumOf { generated ->
            generated.telemetry.topologyAttempts.values.sum()
        }
        val totalHits = generatedScenarios.sumOf { generated ->
            generated.telemetry.topologyHits.values.sum()
        }

        assertTrue(totalAttempts > 0, "Expected topology attempts to be recorded")
        assertTrue(totalHits > 0, "Expected topology hits to be recorded")
        generatedScenarios.forEach { generated ->
            generated.telemetry.topologyHits.forEach { (topology, hits) ->
                val attempts = generated.telemetry.topologyAttempts[topology] ?: 0
                assertTrue(hits <= attempts, "Expected hits <= attempts for $topology")
            }
        }
        assertTrue(
            generatedScenarios.all {
                ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH in it.telemetry.enabledTopologies
            },
            "Expected telemetry to expose enabled topology kinds"
        )

        val telemetryFile = Files.createTempDirectory("gcfuzz-telemetry").resolve("topology.json").toFile()
        generatedScenarios.first { it.telemetry.topologyHits.isNotEmpty() }.telemetry.save(telemetryFile, "I1")
        val telemetryText = telemetryFile.readText()
        assertTrue(""""caseId": "I1"""" in telemetryText, "Expected case id in telemetry JSON")
        assertTrue(""""enabledTopologyFamilies"""" in telemetryText, "Expected enabled topology families in telemetry JSON")
        assertTrue(""""topologyAttempts"""" in telemetryText, "Expected attempts in telemetry JSON")
        assertTrue(""""topologyHits"""" in telemetryText, "Expected hits in telemetry JSON")
        assertTrue(""""structuralHits"""" in telemetryText, "Expected structural hits in telemetry JSON")
    }

    @Test
    fun generatorFiltersUnsupportedTopologyCapabilities() {
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH,
        )
        val capabilities = ScenarioGenerationCapabilities(
            core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = false),
            supportedTopologies = emptySet(),
        )
        val generated = generateScenarioWithMetadata(0u, features, capabilities)

        assertTrue(
            ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH !in generated.telemetry.enabledTopologies,
            "Unsupported topology must not be exposed as enabled",
        )
    }

    @Test
    fun generatorFiltersTopologiesWhenRequiredCapabilitiesAreMissing() {
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH,
            ScenarioFeature.TOPOLOGY_WEAK_ROOT_HANDOFF,
            ScenarioFeature.TOPOLOGY_CFFI_CALLBACK_AFTER_GC,
        )
        val supportedTopologies = setOf(
            ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH,
            ScenarioTopologyKind.WEAK_ROOT_HANDOFF,
            ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC,
        )

        val noFinalizer = generateScenarioWithMetadata(
            seed = 0u,
            features = features,
            capabilities = ScenarioGenerationCapabilities(
                core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = true)
                    .withoutClassLifecycles(ScenarioClassLifecycleKind.FINALIZER),
                supportedTopologies = supportedTopologies,
            ),
        )
        val noWeak = generateScenarioWithMetadata(
            seed = 0u,
            features = features,
            capabilities = ScenarioGenerationCapabilities(
                core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = true)
                    .withoutFields(ScenarioFieldKind.WEAK_REF),
                supportedTopologies = supportedTopologies,
            ),
        )
        val noCffi = generateScenarioWithMetadata(
            seed = 0u,
            features = features,
            capabilities = ScenarioGenerationCapabilities(
                core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = true)
                    .withoutOps(ScenarioOpKind.FOREIGN_ROUNDTRIP),
                supportedTopologies = supportedTopologies,
            ),
        )

        assertTrue(
            ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH !in noFinalizer.telemetry.enabledTopologies,
            "Finalizer topology must be filtered when finalizer lifecycle is unsupported",
        )
        assertTrue(
            ScenarioTopologyKind.WEAK_ROOT_HANDOFF !in noWeak.telemetry.enabledTopologies,
            "Weak topology must be filtered when weak fields are unsupported",
        )
        assertTrue(
            ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC !in noCffi.telemetry.enabledTopologies,
            "CFFI topology must be filtered when ForeignRoundTrip is unsupported",
        )
    }

    @Test
    fun generatorFiltersUnsupportedOrdinaryOps() {
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.EXPLICIT_CLEAR_OP,
            ScenarioFeature.STORE_BATCH_OP,
            ScenarioFeature.CFFI_CALLBACK_ROUNDTRIP,
        )
        val capabilities = ScenarioGenerationCapabilities(
            core = ScenarioCapabilityProfile.pureKotlin(enableCInterop = false).withoutOps(
                ScenarioOpKind.CLEAR,
                ScenarioOpKind.STORE_BATCH,
                ScenarioOpKind.FOREIGN_ROUNDTRIP,
            ),
            supportedTopologies = emptySet(),
        )
        val programs = (0u..127u).map { seed -> generateScenario(seed, features, capabilities) }
        val statements = programs.flatMap { it.allStatements() }

        assertTrue(statements.none { it is ScenarioOp.Clear }, "Unsupported Clear op must not be generated")
        assertTrue(statements.none { it is ScenarioOp.StoreBatch }, "Unsupported StoreBatch op must not be generated")
        assertTrue(statements.none { it is ScenarioOp.ForeignRoundTrip }, "Unsupported ForeignRoundTrip op must not be generated")
    }

    @Test
    fun generatorProducesTargetedTopologies() {
        val programs = withExecutionModel("pure-kotlin") { (0u..1023u).map(::generateScenario) }

        assertTrue(programs.any(ScenarioProgram::containsCycleTopology), "Expected at least one generated cycle topology")
        assertTrue(programs.any(ScenarioProgram::containsSharedNodeTopology), "Expected at least one generated shared-node topology")
        assertTrue(programs.any(ScenarioProgram::containsGlobalReattachTopology), "Expected at least one generated global-reattach topology")
        assertTrue(programs.any(ScenarioProgram::containsOldRootChurnTopology), "Expected at least one generated old-root-churn topology")
        assertTrue(programs.any(ScenarioProgram::containsRootMigrationTopology), "Expected at least one generated root-migration topology")
        assertTrue(programs.any(ScenarioProgram::containsConcurrentRootMigrationTopology), "Expected at least one generated concurrent-root-migration topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakRefLifecycleTopology), "Expected at least one generated weak-ref lifecycle topology")
        assertTrue(programs.any(ScenarioProgram::containsConcurrentPublishClearGcTopology), "Expected at least one generated concurrent publish-clear-GC topology")
        assertTrue(programs.any(ScenarioProgram::containsArraySlotGraphTopology), "Expected at least one generated array-slot graph topology")
        assertTrue(programs.any(ScenarioProgram::containsGraphMutationSequenceTopology), "Expected at least one generated graph-mutation sequence topology")
        assertTrue(programs.any(ScenarioProgram::containsFunctionReturnEscapeTopology), "Expected at least one generated function-return escape topology")
        assertTrue(programs.any(ScenarioProgram::containsWorkerAllocPublishTopology), "Expected at least one generated worker allocation publish topology")
        assertTrue(programs.any(ScenarioProgram::containsMultiStageRootHandoffTopology), "Expected at least one generated multi-stage root-handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsPingPongRootTransferTopology), "Expected at least one generated ping-pong root-transfer topology")
        assertTrue(programs.any(ScenarioProgram::containsConcurrentDuplicateHandoffTopology), "Expected at least one generated concurrent duplicate-handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsLocalGlobalArrayHandoffTopology), "Expected at least one generated local-global-array handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsStaleOwnerMutationAfterHandoffTopology), "Expected at least one generated stale-owner-mutation-after-handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsThreadLocalSharedHandoffTopology), "Expected at least one generated thread-local/shared handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsWorkerCaptureRootTopology), "Expected at least one generated worker-capture root topology")
        assertTrue(programs.any(ScenarioProgram::containsMultiRootStaggeredClearTopology), "Expected at least one generated multi-root staggered-clear topology")
        assertTrue(programs.any(ScenarioProgram::containsConcurrentArraySlotHandoffTopology), "Expected at least one generated concurrent array-slot handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsRootRepublishAfterClearTopology), "Expected at least one generated root-republish-after-clear topology")
        assertTrue(programs.any(ScenarioProgram::containsTryFinallyRootClearTopology), "Expected at least one generated try-finally root-clear topology")
        assertTrue(programs.any(ScenarioProgram::containsReturnEscapeWorkerPublishTopology), "Expected at least one generated return-escape worker-publish topology")
        assertTrue(programs.any(ScenarioProgram::containsThreadLocalClearOnWorkerExitTopology), "Expected at least one generated thread-local clear-on-worker-exit topology")
        assertTrue(programs.any(ScenarioProgram::containsArraySlotClearWithLateRestoreTopology), "Expected at least one generated array-slot clear-with-late-restore topology")
        assertTrue(programs.any(ScenarioProgram::containsWorkerPublishMainClearBarrierTopology), "Expected at least one generated worker-publish main-clear barrier topology")
        assertTrue(programs.any(ScenarioProgram::containsArraySlotClearRestoreBarrierTopology), "Expected at least one generated array-slot clear-restore barrier topology")
        assertTrue(programs.any(ScenarioProgram::containsMixedFieldArrayMutationBarrierTopology), "Expected at least one generated mixed field-array mutation barrier topology")
        assertTrue(programs.any(ScenarioProgram::containsLargeObjectMultiFieldRewriteTopology), "Expected at least one generated large-object multi-field rewrite topology")
        assertTrue(programs.any(ScenarioProgram::containsOldRootChurnWithAllocationBurstTopology), "Expected at least one generated old-root churn with allocation-burst topology")
        assertTrue(programs.any(ScenarioProgram::containsGraphMutationMultiPhaseSequenceTopology), "Expected at least one generated graph-mutation multi-phase sequence topology")
        assertTrue(programs.any(ScenarioProgram::containsSharedNodeReconnectBetweenOwnersTopology), "Expected at least one generated shared-node reconnect-between-owners topology")
        assertTrue(programs.any(ScenarioProgram::containsCycleBreakAndRerootTopology), "Expected at least one generated cycle break-and-reroot topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakRootHandoffTopology), "Expected at least one generated weak root-handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakArraySlotTopology), "Expected at least one generated weak array-slot topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakThreadLocalRootTopology), "Expected at least one generated weak thread-local-root topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakStrongGlobalAlternatingTopology), "Expected at least one generated weak/strong global alternating topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakLateStrongRescueTopology), "Expected at least one generated weak late-strong-rescue topology")
        assertTrue(programs.any(ScenarioProgram::containsWeakMultiEpochObserveTopology), "Expected at least one generated weak multi-epoch observe topology")
        assertTrue(programs.any(ScenarioProgram::containsFinalizerGlobalPublishTopology), "Expected at least one generated finalizer global-publish topology")
        assertTrue(programs.any(ScenarioProgram::containsWorkerResultEscapeTopology), "Expected at least one generated worker-result-escape topology")
        assertTrue(programs.any(ScenarioProgram::containsWorkerResultThenClearGcTopology), "Expected at least one generated worker-result-then-clear-gc topology")
        assertTrue(programs.any(ScenarioProgram::containsNestedWorkerRootHandoffTopology), "Expected at least one generated nested-worker-root-handoff topology")
        assertTrue(programs.any(ScenarioProgram::containsCasRootContentionTopology), "Expected at least one generated cas-root-contention topology")
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun generatorProducesOracleCapsuleTopologiesWhenEnabled() {
        val oracleFeatures = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.ORACLE_SINGLE_STRONG_SLOT,
            ScenarioFeature.ORACLE_REACHABILITY_CONSISTENCY,
            ScenarioFeature.ORACLE_ROOT_MIGRATION_CAPSULE,
            ScenarioFeature.ORACLE_WEAK_DEAD_CAPSULE,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, oracleFeatures) }

        assertTrue(programs.any(ScenarioProgram::containsSingleStrongSlotCapsuleTopology), "Expected at least one generated single-strong-slot capsule")
        assertTrue(programs.any(ScenarioProgram::containsReachabilityConsistencyCapsuleTopology), "Expected at least one generated reachability-consistency capsule")
        assertTrue(programs.any(ScenarioProgram::containsWeakDeadCapsuleTopology), "Expected at least one generated weak-dead capsule topology")
        assertTrue(programs.any(ScenarioProgram::containsRootMigrationCapsuleTopology), "Expected at least one generated root-migration capsule")
    }

    @Test
    fun generatorProducesDeleteEdgeThenGcTopologyWhenEnabled() {
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.TOPOLOGY_DELETE_EDGE_THEN_GC,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, features) }

        assertTrue(programs.any(ScenarioProgram::containsDeleteEdgeThenGcTopology), "Expected at least one generated delete-edge-then-gc topology")
    }

    @Test
    fun generatorProducesCffiTopologiesWhenEnabled() {
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.CFFI_CALLBACK_ROUNDTRIP,
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.TOPOLOGY_CFFI_CALLBACK_AFTER_GC,
            ScenarioFeature.TOPOLOGY_CFFI_IDENTITY_HANDOFF,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, features) }

        assertTrue(programs.any(ScenarioProgram::containsCffiCallbackAfterGcTopology), "Expected at least one generated CFFI callback-after-GC topology")
        assertTrue(programs.any(ScenarioProgram::containsCffiIdentityHandoffTopology), "Expected at least one generated CFFI identity-handoff topology")
    }

    @Test
    fun generatorProducesAdvancedGcShapes() {
        val programs = withExecutionModel("pure-kotlin") { (0u..255u).map(::generateScenario) }

        assertTrue(programs.any(ScenarioProgram::containsThreadLocalGlobal), "Expected at least one thread-local global")
        assertTrue(programs.any(ScenarioProgram::containsPrimitiveOrArrayField), "Expected at least one primitive or array field")
        assertTrue(programs.any(ScenarioProgram::containsTerminalControlFlow), "Expected at least one throw or early-return statement")
        assertTrue(programs.any(ScenarioProgram::containsStructuredControlFlow), "Expected at least one block, if, or try-finally statement")
        assertTrue(programs.any(ScenarioProgram::containsAllocationBurst), "Expected at least one allocation-burst statement")
    }

    @Test
    fun generatorUsesEmptyPathForGlobalsInRandomStream() {
        // Minimal feature set: no TOPOLOGY_* features, so no topology injection pollutes the path statistics.
        // This isolates the random stream behavior of genScenarioValue / genScenarioLocation.
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.TERMINAL_STATEMENTS,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, features) }
        val statements = programs.flatMap { it.allStatements() }

        val globalValues = statements.mapNotNull { op ->
            (op as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef
        }
        assertTrue(globalValues.isNotEmpty(), "Expected at least one global value observation")
        assertTrue(
            globalValues.all { it.path.accessors.isEmpty() },
            "Random stream global value paths must be empty (single-slot), got non-empty: ${globalValues.count { it.path.accessors.isNotEmpty() }}/${globalValues.size}",
        )

        val globalLocations = statements.mapNotNull { op ->
            (op as? ScenarioOp.Store)?.location as? ScenarioLocation.Global
        }
        assertTrue(globalLocations.isNotEmpty(), "Expected at least one global store")
        assertTrue(
            globalLocations.all { it.path.accessors.isEmpty() },
            "Random stream global location paths must be empty (single-slot), got non-empty: ${globalLocations.count { it.path.accessors.isNotEmpty() }}/${globalLocations.size}",
        )
    }

    @Test
    fun generatorProducesRootAndFieldLocalStores() {
        val programs = withExecutionModel("pure-kotlin") { (0u..1023u).map(::generateScenario) }
        val localLocations = programs.flatMap { it.allStatements() }
            .mapNotNull { op -> (op as? ScenarioOp.Store)?.location as? ScenarioLocation.Local }

        assertTrue(localLocations.isNotEmpty(), "Expected at least one local store")
        val rootStores = localLocations.count { it.path.accessors.isEmpty() }
        val fieldStores = localLocations.count { it.path.accessors.isNotEmpty() }
        // preferFieldStore=false is 45%, so root stores (empty path) must be a meaningful fraction
        assertTrue(rootStores > 0, "Expected non-zero root stores via preferFieldStore=false path")
        // preferFieldStore=true is 55%, and genFieldPathFor falls back to genPath() only when localId is
        // chooseLocal() invalid stress; field stores with real field ids must dominate this branch
        assertTrue(fieldStores > 0, "Expected non-zero field stores via preferFieldStore=true path")
    }

    @Test
    fun generatorBoundedBodySizeForTopLevelBodies() {
        val programs = withExecutionModel("pure-kotlin") { (0u..1023u).map(::generateScenario) }
        val bodySizes = programs.flatMap { it.topLevelBodies() }.map { it.statements.size }.toList()

        assertTrue(bodySizes.isNotEmpty(), "Expected at least one top-level body")
        // bodySize distribution is 0.0->8, 0.7->16, 1.0->32; terminal statements may shorten by up to 2
        assertTrue(bodySizes.all { it in 1..32 }, "Top-level body size must stay in [1, 32], got out-of-range: ${bodySizes.filterNot { it in 1..32 }.toSet()}")
    }

    @Test
    fun generatorProducesGcOperationsWithExpectedDensity() {
        val programs = withExecutionModel("pure-kotlin") { (0u..1023u).map(::generateScenario) }
        val allStatements = programs.flatMap { it.allStatements() }
        val total = allStatements.size
        assertTrue(total > 0, "Expected at least one statement")

        val performGc = allStatements.count { it is ScenarioOp.PerformGc }
        val allocationBurst = allStatements.count { it is ScenarioOp.AllocationBurst }
        val gcEpoch = allStatements.count { it is ScenarioOp.GcEpoch }

        // PERFORM_GC weight 2, ALLOCATION_BURST weight 1, GC_EPOCH weight 1, total statement weight 29
        // Topology templates also inject PerformGc, so density may exceed pure statement weight ratio.
        val performGcRate = performGc.toDouble() / total
        assertTrue(performGcRate > 0.03, "Expected PERFORM_GC rate > 3%, got $performGcRate ($performGc/$total)")
        assertTrue(performGcRate < 0.20, "Expected PERFORM_GC rate < 20%, got $performGcRate ($performGc/$total)")

        // GC-class operations (PERFORM_GC + ALLOCATION_BURST + GC_EPOCH) should be a meaningful fraction
        val gcOpsRate = (performGc + allocationBurst + gcEpoch).toDouble() / total
        assertTrue(gcOpsRate > 0.05, "Expected GC-class op rate > 5%, got $gcOpsRate")
        assertTrue(gcOpsRate < 0.30, "Expected GC-class op rate < 30%, got $gcOpsRate")
    }

    @Test
    fun generatorLocalRefsPreferDeclarableIdsInRandomStream() {
        // Minimal feature set: no TOPOLOGY_* features, so no topology injection pollutes the statistics.
        // After allocateUnknownLocal() no longer adds to readableLocals, and genScenarioValue /
        // genScenarioLocation fall back to valid globals when readableLocals/mutableLocals is empty,
        // invalid local ids should come only from the 5% invalid-stress branch in genScenarioValue
        // (kept per spec §5.1), and only when a readable local already exists.
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.TERMINAL_STATEMENTS,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, features) }

        // Collect all value and location references across all statements (including StoreBatch
        // inner stores, Clear locations, CallFunction/SpawnFunction/CreateObject args, If condition,
        // ForeignRoundTrip/Reachability/Return/Throw/ScopedRoot values), not just Observe and Store.
        val allValues = programs.flatMap { it.allValueReferences() }
        val allLocations = programs.flatMap { it.allLocationReferences() }

        val localRefIds = allValues.mapNotNull { (it as? ScenarioValue.LocalRef)?.localId }
        val localLocationIds = allLocations.mapNotNull { (it as? ScenarioLocation.Local)?.localId }
        val allLocalIds = localRefIds + localLocationIds
        assertTrue(allLocalIds.isNotEmpty(), "Expected at least one local reference")

        val createObjectLocalIds = programs.flatMap { program ->
            program.allStatements().mapNotNull { op -> (op as? ScenarioOp.CreateObject)?.localId }
        }.toSet()

        // Declarable = CreateObject-declared localIds, or parameter localIds (typically < 32, since
        // numParameters distribution caps at 32). chooseLocal() returns random.nextInt(0, Int.MAX_VALUE),
        // so invalid ids are typically >> 1000 and never collide with declarable ids in practice.
        val declarableIds = allLocalIds.count { it in createObjectLocalIds || it < 32 }
        val invalidIds = allLocalIds.count { it > 1_000 }
        val declarableRate = declarableIds.toDouble() / allLocalIds.size
        val invalidRate = invalidIds.toDouble() / allLocalIds.size

        // Declarable ids should dominate: unknown locals no longer enter readableLocals, and
        // genScenarioLocation falls back to valid globals when mutableLocals is empty.
        assertTrue(
            declarableRate > 0.85,
            "Expected declarable local id rate > 85%, got $declarableRate ($declarableIds/${allLocalIds.size})",
        )
        // Invalid stress (chooseLocal fallback per spec §5.1) is now bounded to the 5% invalid-stress
        // branch in genScenarioValue, and only fires when a readable local already exists.
        assertTrue(
            invalidRate < 0.05,
            "Expected invalid local id rate < 5%, got $invalidRate ($invalidIds/${allLocalIds.size})",
        )
    }

    @Test
    fun generatorLocalFallbackToGlobalDoesNotSkewDistribution() {
        // When AccessKind.LOCAL is drawn but readableLocals/mutableLocals is empty, genScenarioValue /
        // genScenarioLocation fall back to a valid GlobalRef/Global instead of an invalid local id.
        // This is correct for validity, but could skew the actual local/global ratio away from the
        // configured 2:3 (LOCAL:GLOBAL = 40%:60%). Verify the fallback does not over-suppress local.
        val features = ScenarioFeatureSet.of(
            ScenarioFeature.STRUCTURED_CONTROL_FLOW,
            ScenarioFeature.RICH_FIELDS,
            ScenarioFeature.ADVANCED_GLOBAL_STORAGE,
            ScenarioFeature.TERMINAL_STATEMENTS,
        )
        val programs = (0u..255u).map { seed -> generateScenario(seed, features) }
        val allValues = programs.flatMap { it.allValueReferences() }
        val allLocations = programs.flatMap { it.allLocationReferences() }

        val localValueCount = allValues.count { it is ScenarioValue.LocalRef }
        val globalValueCount = allValues.count { it is ScenarioValue.GlobalRef }
        val localLocationCount = allLocations.count { it is ScenarioLocation.Local }
        val globalLocationCount = allLocations.count { it is ScenarioLocation.Global }

        val totalValues = allValues.size
        val totalLocations = allLocations.size
        assertTrue(totalValues > 0, "Expected at least one value reference")
        assertTrue(totalLocations > 0, "Expected at least one location reference")

        // Configured LOCAL:GLOBAL = 2:3, so baseline global ratio is 60%. LOCAL fallback to global
        // pushes the actual global ratio above 60%. Verify the skew is bounded (< 80%) so that
        // local scenarios (root publish/clear, field store, etc.) still occupy a meaningful fraction.
        val globalValueRate = globalValueCount.toDouble() / totalValues
        val globalLocationRate = globalLocationCount.toDouble() / totalLocations
        assertTrue(
            globalValueRate < 0.80,
            "Expected global value rate < 80% (fallback should not over-suppress local), got $globalValueRate ($globalValueCount/$totalValues)",
        )
        assertTrue(
            globalLocationRate < 0.80,
            "Expected global location rate < 80% (fallback should not over-suppress local), got $globalLocationRate ($globalLocationCount/$totalLocations)",
        )
        // Local should still be a meaningful fraction (> 15%) of references
        val localValueRate = localValueCount.toDouble() / totalValues
        val localLocationRate = localLocationCount.toDouble() / totalLocations
        assertTrue(
            localValueRate > 0.15,
            "Expected local value rate > 15%, got $localValueRate ($localValueCount/$totalValues)",
        )
        assertTrue(
            localLocationRate > 0.15,
            "Expected local location rate > 15%, got $localLocationRate ($localLocationCount/$totalLocations)",
        )
    }

    @Test
    fun generatorProvidesTopologyDefinitionMaterials() {
        val programs = withExecutionModel("pure-kotlin") { (0u..255u).map(::generateScenario) }

        assertTrue(
            programs.all(ScenarioProgram::containsStrongSharedGlobal),
            "Pure Kotlin topology generation should always have a shared strong global available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsWeakGlobal),
            "Pure Kotlin weak topology generation should always have a weak global available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsStrongRefField),
            "Pure Kotlin topology generation should always have a strong-reference field available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsArrayField),
            "Pure Kotlin array topology generation should always have an object-array field available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsThreadLocalStrongGlobal),
            "Pure Kotlin thread-local/shared topology generation should always have a thread-local strong global available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsFinalizerClass),
            "Pure Kotlin finalizer topology generation should always have a finalizer class available",
        )
        assertTrue(
            programs.all(ScenarioProgram::containsNonFinalizerClass),
            "Pure Kotlin finalizer topology generation should always have a non-finalizer marker class available",
        )
    }

    @Test
    fun generatorKeepsTerminalControlFlowInTopLevelBodies() {
        val programs = withExecutionModel("pure-kotlin") { (0u..1023u).map(::generateScenario) }

        assertTrue(
            programs.all(ScenarioProgram::containsNoTerminalControlFlowInNestedBodies),
            "Terminal statements must stay out of nested bodies that may translate to lambdas or worker blocks",
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun generatorKeepsReachabilityOracleSlotsOnStrongRefFields() {
        val programs = withExecutionModel("pure-kotlin") { (0u..255u).map(::generateScenario) }

        assertTrue(
            programs.all(ScenarioProgram::reachabilityOracleSlotsUseStrongRefFields),
            "Reachability oracles must only use strong-reference fields as payload slots",
        )
        assertTrue(
            programs.all(ScenarioProgram::rootMigrationOracleSlotsUseStrongRefFields),
            "Root-migration oracles must only use strong-reference fields for source and target slots",
        )
    }
}

private fun ScenarioBody.flattenedStatements(): List<ScenarioOp> =
    statements.flatMap { statement ->
        when (statement) {
            is ScenarioOp.StoreBatch -> statement.stores
            else -> listOf(statement)
        }
    }

private fun ScenarioProgram.containsCycleTopology(): Boolean = allBodies().any(ScenarioBody::containsCycleTopology)
private fun ScenarioProgram.containsSingleStrongSlotCapsuleTopology(): Boolean = allBodies().any(ScenarioBody::containsSingleStrongSlotCapsuleTopology)
private fun ScenarioProgram.containsReachabilityConsistencyTopology(): Boolean = allBodies().any(ScenarioBody::containsReachabilityConsistencyTopology)
private fun ScenarioProgram.containsReachabilityConsistencyCapsuleTopology(): Boolean = allBodies().any(ScenarioBody::containsReachabilityConsistencyCapsuleTopology)
private fun ScenarioProgram.containsWeakDeadCapsuleTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakDeadCapsuleTopology)
private fun ScenarioProgram.containsSharedNodeTopology(): Boolean = allBodies().any(ScenarioBody::containsSharedNodeTopology)
private fun ScenarioProgram.containsGlobalReattachTopology(): Boolean = allBodies().any(ScenarioBody::containsGlobalReattachTopology)
private fun ScenarioProgram.containsOldRootChurnTopology(): Boolean = allBodies().any(ScenarioBody::containsOldRootChurnTopology)
private fun ScenarioProgram.containsRootMigrationTopology(): Boolean = allBodies().any(ScenarioBody::containsRootMigrationTopology)
private fun ScenarioProgram.containsRootMigrationCapsuleTopology(): Boolean = allBodies().any(ScenarioBody::containsRootMigrationCapsuleTopology)
private fun ScenarioProgram.containsDeleteEdgeThenGcTopology(): Boolean = allBodies().any(ScenarioBody::containsDeleteEdgeThenGcTopology)
private fun ScenarioProgram.containsConcurrentRootMigrationTopology(): Boolean = allBodies().any(ScenarioBody::containsConcurrentRootMigrationTopology)
private fun ScenarioProgram.containsWeakRefLifecycleTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakRefLifecycleTopology)
private fun ScenarioProgram.containsConcurrentPublishClearGcTopology(): Boolean = allBodies().any(ScenarioBody::containsConcurrentPublishClearGcTopology)
private fun ScenarioProgram.containsArraySlotGraphTopology(): Boolean = allBodies().any(ScenarioBody::containsArraySlotGraphTopology)
private fun ScenarioProgram.containsGraphMutationSequenceTopology(): Boolean = allBodies().any(ScenarioBody::containsGraphMutationSequenceTopology)
private fun ScenarioProgram.containsFunctionReturnEscapeTopology(): Boolean = allBodies().any(ScenarioBody::containsFunctionReturnEscapeTopology)
private fun ScenarioProgram.containsWorkerAllocPublishTopology(): Boolean = allBodies().any(ScenarioBody::containsWorkerAllocPublishTopology)
private fun ScenarioProgram.containsMultiStageRootHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsMultiStageRootHandoffTopology)
private fun ScenarioProgram.containsPingPongRootTransferTopology(): Boolean = allBodies().any(ScenarioBody::containsPingPongRootTransferTopology)
private fun ScenarioProgram.containsConcurrentDuplicateHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsConcurrentDuplicateHandoffTopology)
private fun ScenarioProgram.containsLocalGlobalArrayHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsLocalGlobalArrayHandoffTopology)
private fun ScenarioProgram.containsStaleOwnerMutationAfterHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsStaleOwnerMutationAfterHandoffTopology)
private fun ScenarioProgram.containsThreadLocalSharedHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsThreadLocalSharedHandoffTopology)
private fun ScenarioProgram.containsWorkerCaptureRootTopology(): Boolean = allBodies().any(ScenarioBody::containsWorkerCaptureRootTopology)
private fun ScenarioProgram.containsMultiRootStaggeredClearTopology(): Boolean = allBodies().any(ScenarioBody::containsMultiRootStaggeredClearTopology)
private fun ScenarioProgram.containsConcurrentArraySlotHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsConcurrentArraySlotHandoffTopology)
private fun ScenarioProgram.containsRootRepublishAfterClearTopology(): Boolean = allBodies().any(ScenarioBody::containsRootRepublishAfterClearTopology)
private fun ScenarioProgram.containsTryFinallyRootClearTopology(): Boolean = allBodies().any(ScenarioBody::containsTryFinallyRootClearTopology)
private fun ScenarioProgram.containsReturnEscapeWorkerPublishTopology(): Boolean = allBodies().any(ScenarioBody::containsReturnEscapeWorkerPublishTopology)
private fun ScenarioProgram.containsThreadLocalClearOnWorkerExitTopology(): Boolean = allBodies().any(ScenarioBody::containsThreadLocalClearOnWorkerExitTopology)
private fun ScenarioProgram.containsArraySlotClearWithLateRestoreTopology(): Boolean = allBodies().any(ScenarioBody::containsArraySlotClearWithLateRestoreTopology)
private fun ScenarioProgram.containsWorkerPublishMainClearBarrierTopology(): Boolean = allBodies().any(ScenarioBody::containsWorkerPublishMainClearBarrierTopology)
private fun ScenarioProgram.containsArraySlotClearRestoreBarrierTopology(): Boolean = allBodies().any(ScenarioBody::containsArraySlotClearRestoreBarrierTopology)
private fun ScenarioProgram.containsMixedFieldArrayMutationBarrierTopology(): Boolean = allBodies().any(ScenarioBody::containsMixedFieldArrayMutationBarrierTopology)
private fun ScenarioProgram.containsLargeObjectMultiFieldRewriteTopology(): Boolean = allBodies().any(ScenarioBody::containsLargeObjectMultiFieldRewriteTopology)
private fun ScenarioProgram.containsOldRootChurnWithAllocationBurstTopology(): Boolean = allBodies().any(ScenarioBody::containsOldRootChurnWithAllocationBurstTopology)
private fun ScenarioProgram.containsGraphMutationMultiPhaseSequenceTopology(): Boolean = allBodies().any(ScenarioBody::containsGraphMutationMultiPhaseSequenceTopology)
private fun ScenarioProgram.containsSharedNodeReconnectBetweenOwnersTopology(): Boolean = allBodies().any(ScenarioBody::containsSharedNodeReconnectBetweenOwnersTopology)
private fun ScenarioProgram.containsCycleBreakAndRerootTopology(): Boolean = allBodies().any(ScenarioBody::containsCycleBreakAndRerootTopology)
private fun ScenarioProgram.containsWeakRootHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakRootHandoffTopology)
private fun ScenarioProgram.containsWeakArraySlotTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakArraySlotTopology)
private fun ScenarioProgram.containsWeakThreadLocalRootTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakThreadLocalRootTopology)
private fun ScenarioProgram.containsWeakStrongGlobalAlternatingTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakStrongGlobalAlternatingTopology)
private fun ScenarioProgram.containsWeakLateStrongRescueTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakLateStrongRescueTopology)
private fun ScenarioProgram.containsWeakMultiEpochObserveTopology(): Boolean = allBodies().any(ScenarioBody::containsWeakMultiEpochObserveTopology)
private fun ScenarioProgram.containsFinalizerGlobalPublishTopology(): Boolean = allBodies().any(ScenarioBody::containsFinalizerGlobalPublishTopology)
private fun ScenarioProgram.containsWorkerResultEscapeTopology(): Boolean = allBodies().any { body ->
    body.flattenedStatements().any { it is ScenarioOp.SpawnWithResult }
}
private fun ScenarioProgram.containsWorkerResultThenClearGcTopology(): Boolean = allBodies().any { body ->
    val flat = body.flattenedStatements()
    flat.any { it is ScenarioOp.SpawnWithResult } && flat.any { it is ScenarioOp.Clear }
}
private fun ScenarioProgram.containsNestedWorkerRootHandoffTopology(): Boolean = allBodies().any { body ->
    body.statements.any { op ->
        op is ScenarioOp.SpawnWithResult && op.body.any { it is ScenarioOp.SpawnWithResult }
    }
}
private fun ScenarioProgram.containsCasRootContentionTopology(): Boolean = allBodies().any { body ->
    body.flattenedStatements().any { it is ScenarioOp.CompareAndSet }
}
private fun ScenarioProgram.containsCffiCallbackAfterGcTopology(): Boolean = allBodies().any(ScenarioBody::containsCffiCallbackAfterGcTopology)
private fun ScenarioProgram.containsCffiIdentityHandoffTopology(): Boolean = allBodies().any(ScenarioBody::containsCffiIdentityHandoffTopology)
private fun ScenarioProgram.containsThreadLocalGlobal(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Global>().any { it.storage is ScenarioGlobalStorage.ThreadLocal }
private fun ScenarioProgram.containsStrongSharedGlobal(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Global>().any {
        it.storage is ScenarioGlobalStorage.Shared && it.field is ScenarioField.StrongRef
    }
private fun ScenarioProgram.containsThreadLocalStrongGlobal(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Global>().any {
        it.storage is ScenarioGlobalStorage.ThreadLocal && it.field is ScenarioField.StrongRef
    }
private fun ScenarioProgram.containsFinalizerClass(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Class>().any { it.lifecycle is ScenarioClassLifecycle.Finalizer }
private fun ScenarioProgram.containsNonFinalizerClass(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Class>().any { it.lifecycle is ScenarioClassLifecycle.None }
private fun ScenarioProgram.containsWeakGlobal(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Global>().any { it.field is ScenarioField.WeakRef }
private fun ScenarioProgram.containsStrongRefField(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Class>().any { definition ->
        definition.fields.any { field -> field is ScenarioField.StrongRef }
    }
private fun ScenarioProgram.containsArrayField(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Class>().any { definition ->
        definition.fields.any { field -> field is ScenarioField.ObjectArray }
    }
private fun ScenarioProgram.containsPrimitiveOrArrayField(): Boolean =
    definitions.filterIsInstance<ScenarioDefinition.Class>().any { definition ->
        definition.fields.any { field -> field is ScenarioField.IntValue || field is ScenarioField.BooleanValue || field is ScenarioField.ObjectArray }
    }
private fun ScenarioProgram.containsTerminalControlFlow(): Boolean =
    allBodies().any { body -> body.statements.any { it is ScenarioOp.Return || it is ScenarioOp.Throw } }
private fun ScenarioProgram.containsStructuredControlFlow(): Boolean =
    allBodies().any { body ->
        body.statements.any { it is ScenarioOp.Block || it is ScenarioOp.If || it is ScenarioOp.TryFinally }
    }
private fun ScenarioProgram.containsAllocationBurst(): Boolean =
    allBodies().any { body -> body.statements.any { it is ScenarioOp.AllocationBurst } }

private fun ScenarioProgram.containsNoTerminalControlFlowInNestedBodies(): Boolean =
    topLevelBodies().all { body -> body.containsNoTerminalControlFlowInNestedBodies() }

private fun ScenarioProgram.reachabilityOracleSlotsUseStrongRefFields(): Boolean =
    allBodies().all { body -> body.reachabilityOracleSlotsUseStrongRefFields(definitions) }

private fun ScenarioProgram.rootMigrationOracleSlotsUseStrongRefFields(): Boolean =
    allBodies().all { body -> body.rootMigrationOracleSlotsUseStrongRefFields(definitions) }

private fun ScenarioProgram.allBodies(): Sequence<ScenarioBody> = sequence {
    yieldAll(mainBody.allNestedBodies())
    definitions.filterIsInstance<ScenarioDefinition.Function>().forEach { yieldAll(it.body.body.allNestedBodies()) }
}

private fun ScenarioProgram.allStatements(): List<ScenarioOp> =
    allBodies().flatMap { body -> body.flattenedStatements().asSequence() }.toList()

// Collects every ScenarioValue referenced by any statement, including nested StoreBatch inner stores,
// CallFunction/SpawnFunction/CreateObject args, If conditions, ForeignRoundTrip/Reachability/Return/Throw/
// ScopedRoot values. Used by statistics tests so that local/global/invalid ratios are not biased by
// sampling only Observe.value and Store.location.
private fun ScenarioProgram.allValueReferences(): List<ScenarioValue> = allStatements().flatMap { op ->
    buildList {
        when (op) {
            is ScenarioOp.CreateObject -> addAll(op.args)
            is ScenarioOp.Store -> add(op.value)
            is ScenarioOp.StoreBatch -> addAll(op.stores.map { it.value })
            is ScenarioOp.Observe -> add(op.value)
            is ScenarioOp.CallFunction -> addAll(op.args)
            is ScenarioOp.SpawnFunction -> addAll(op.args)
            is ScenarioOp.SpawnWithResult -> add(op.returnValue)
            is ScenarioOp.CompareAndSet -> {
                add(op.expectedValue)
                add(op.newValue)
            }
            is ScenarioOp.If -> add(op.condition)
            is ScenarioOp.ForeignRoundTrip -> add(op.value)
            is ScenarioOp.CreateReachabilityObservation -> add(op.value)
            is ScenarioOp.CheckReachability -> add(op.value)
            is ScenarioOp.Return -> add(op.value)
            is ScenarioOp.Throw -> add(op.value)
            is ScenarioOp.ScopedRoot -> add(op.value)
            else -> {}
        }
    }
}

// Collects every ScenarioLocation referenced by Store, Clear, and inner StoreBatch stores.
private fun ScenarioProgram.allLocationReferences(): List<ScenarioLocation> = allStatements().flatMap { op ->
    buildList {
        when (op) {
            is ScenarioOp.Store -> add(op.location)
            is ScenarioOp.Clear -> add(op.location)
            is ScenarioOp.StoreBatch -> addAll(op.stores.map { it.location })
            is ScenarioOp.CompareAndSet -> add(op.location)
            else -> {}
        }
    }
}

private fun ScenarioProgram.topLevelBodies(): Sequence<ScenarioBody> = sequence {
    yield(mainBody)
    definitions.filterIsInstance<ScenarioDefinition.Function>().forEach { yield(it.body.body) }
}

private fun ScenarioPath.isSingleStrongFieldIn(
    definitions: List<ScenarioDefinition>,
    classId: Int,
): Boolean {
    if (accessors.size != 1) return false
    val fieldId = accessors.single()
    val klass = definitions.filterIsInstance<ScenarioDefinition.Class>().getOrNull(classId) ?: return false
    return klass.fields.getOrNull(fieldId) is ScenarioField.StrongRef
}

private fun ScenarioBody.allNestedBodies(): Sequence<ScenarioBody> = sequence {
    yield(this@allNestedBodies)
    statements.forEach { statement ->
        when (statement) {
            is ScenarioOp.Block -> yieldAll(ScenarioBody(statement.body).allNestedBodies())
            is ScenarioOp.If -> {
                yieldAll(ScenarioBody(statement.thenBody).allNestedBodies())
                yieldAll(ScenarioBody(statement.elseBody).allNestedBodies())
            }
            is ScenarioOp.TryFinally -> {
                yieldAll(ScenarioBody(statement.body).allNestedBodies())
                yieldAll(ScenarioBody(statement.finallyBody).allNestedBodies())
            }
            is ScenarioOp.Spawn -> yieldAll(ScenarioBody(statement.body).allNestedBodies())
            is ScenarioOp.SpawnWithResult -> yieldAll(ScenarioBody(statement.body).allNestedBodies())
            else -> {}
        }
    }
}

private fun ScenarioBody.containsNoTerminalControlFlowInNestedBodies(): Boolean =
    statements.all { statement ->
        when (statement) {
            is ScenarioOp.Block ->
                !ScenarioBody(statement.body).containsTerminalControlFlow() &&
                    ScenarioBody(statement.body).containsNoTerminalControlFlowInNestedBodies()
            is ScenarioOp.If ->
                !ScenarioBody(statement.thenBody).containsTerminalControlFlow() &&
                    ScenarioBody(statement.thenBody).containsNoTerminalControlFlowInNestedBodies() &&
                    !ScenarioBody(statement.elseBody).containsTerminalControlFlow() &&
                    ScenarioBody(statement.elseBody).containsNoTerminalControlFlowInNestedBodies()
            is ScenarioOp.TryFinally ->
                !ScenarioBody(statement.body).containsTerminalControlFlow() &&
                    ScenarioBody(statement.body).containsNoTerminalControlFlowInNestedBodies() &&
                    !ScenarioBody(statement.finallyBody).containsTerminalControlFlow() &&
                    ScenarioBody(statement.finallyBody).containsNoTerminalControlFlowInNestedBodies()
            is ScenarioOp.Spawn ->
                !ScenarioBody(statement.body).containsTerminalControlFlow() &&
                    ScenarioBody(statement.body).containsNoTerminalControlFlowInNestedBodies()
            is ScenarioOp.SpawnWithResult ->
                !ScenarioBody(statement.body).containsTerminalControlFlow() &&
                    ScenarioBody(statement.body).containsNoTerminalControlFlowInNestedBodies()
            else -> true
        }
    }

private fun ScenarioBody.reachabilityOracleSlotsUseStrongRefFields(definitions: List<ScenarioDefinition>): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).all { window ->
        val block = window.getOrNull(0) as? ScenarioOp.Block ?: return@all true
        if (block.body.size != 5) return@all true
        val createOwner = block.body.getOrNull(0) as? ScenarioOp.CreateObject ?: return@all true
        val attachPayload = block.body.getOrNull(2) as? ScenarioOp.Store ?: return@all true
        val createObservation = block.body.getOrNull(4) as? ScenarioOp.CreateReachabilityObservation ?: return@all true
        val clearPayload = window.getOrNull(3) as? ScenarioOp.Store ?: return@all true
        val attachLocation = attachPayload.location as? ScenarioLocation.Local ?: return@all true
        val observationValue = createObservation.value as? ScenarioValue.GlobalRef ?: return@all true
        val clearLocation = clearPayload.location as? ScenarioLocation.Global ?: return@all true
        if (!observationValue.path.sameAs(attachLocation.path) || !clearLocation.path.sameAs(attachLocation.path)) return@all true
        attachLocation.path.isSingleStrongFieldIn(definitions, createOwner.classId)
    }

private fun ScenarioBody.containsSingleStrongSlotCapsuleTopology(): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).any { window ->
        val block = window.getOrNull(0) as? ScenarioOp.Block ?: return@any false
        val attachPayload = block.body.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishRoot = block.body.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val createObservation = block.body.getOrNull(4) as? ScenarioOp.CreateReachabilityObservation ?: return@any false
        val aliveCheck = window.getOrNull(2) as? ScenarioOp.CheckReachabilityObservation ?: return@any false
        val clearPayload = window.getOrNull(3) ?: return false
        val deadCheck = window.getOrNull(5) as? ScenarioOp.CheckReachabilityObservation ?: return@any false

        val attachLocation = attachPayload.location as? ScenarioLocation.Local ?: return@any false
        val attachedPayload = attachPayload.value as? ScenarioValue.LocalRef ?: return@any false
        val rootLocation = publishRoot.location as? ScenarioLocation.Global ?: return@any false
        val publishedOwner = publishRoot.value as? ScenarioValue.LocalRef ?: return@any false
        val observationValue = createObservation.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearLocation = clearPayload.clearLocation() as? ScenarioLocation.Global ?: return@any false

        block.body.size == 5 &&
            block.body[0] is ScenarioOp.CreateObject &&
            block.body[1] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.PerformGc &&
            window[4] is ScenarioOp.PerformGc &&
            aliveCheck.label == "single-strong-slot.alive-after-publish" &&
            deadCheck.label == "single-strong-slot.dead-after-clear" &&
            attachLocation.path.isNonEmpty() &&
            attachedPayload.path.isEmpty() &&
            rootLocation.path.isEmpty() &&
            publishedOwner.path.isEmpty() &&
            observationValue.path.sameAs(attachLocation.path) &&
            clearLocation.path.sameAs(attachLocation.path) &&
            createObservation.kind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind.Weak &&
            aliveCheck.expectation == ScenarioReachabilityExpectation.Alive &&
            deadCheck.expectation == ScenarioReachabilityExpectation.Dead &&
            aliveCheck.observationId == createObservation.observationId &&
            deadCheck.observationId == createObservation.observationId &&
            attachLocation.localId == publishedOwner.localId &&
            rootLocation.globalId == observationValue.globalId &&
            rootLocation.globalId == clearLocation.globalId
    }

private fun ScenarioBody.rootMigrationOracleSlotsUseStrongRefFields(definitions: List<ScenarioDefinition>): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).all { window ->
        val createSourceOwner = window.getOrNull(0) as? ScenarioOp.CreateObject ?: return@all true
        val createTargetOwner = window.getOrNull(2) as? ScenarioOp.CreateObject ?: return@all true
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@all true
        val migrationStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@all true
        val createObservation = window.getOrNull(8) as? ScenarioOp.CreateReachabilityObservation ?: return@all true
        val sourceLocation = firstStore.location as? ScenarioLocation.Local ?: return@all true
        val targetLocation = migrationStore.location as? ScenarioLocation.Local ?: return@all true
        val observationValue = createObservation.value as? ScenarioValue.LocalRef ?: return@all true
        if (!observationValue.path.sameAs(targetLocation.path)) return@all true
        sourceLocation.path.isSingleStrongFieldIn(definitions, createSourceOwner.classId) &&
            targetLocation.path.isSingleStrongFieldIn(definitions, createTargetOwner.classId)
    }

private fun ScenarioBody.containsTerminalControlFlow(): Boolean =
    statements.any { statement ->
        when (statement) {
            is ScenarioOp.Return, is ScenarioOp.Throw -> true
            is ScenarioOp.Block -> ScenarioBody(statement.body).containsTerminalControlFlow()
            is ScenarioOp.If ->
                ScenarioBody(statement.thenBody).containsTerminalControlFlow() ||
                    ScenarioBody(statement.elseBody).containsTerminalControlFlow()
            is ScenarioOp.TryFinally ->
                ScenarioBody(statement.body).containsTerminalControlFlow() ||
                    ScenarioBody(statement.finallyBody).containsTerminalControlFlow()
            is ScenarioOp.Spawn -> ScenarioBody(statement.body).containsTerminalControlFlow()
            else -> false
        }
}

private fun ScenarioBody.containsMultiStageRootHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 14, step = 1).any { window ->
        val publishStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val firstSpawn = window.getOrNull(6) as? ScenarioOp.Spawn ?: return@any false
        val clearFirstOwner = window.getOrNull(7) ?: return false
        val secondSpawn = window.getOrNull(9) as? ScenarioOp.Spawn ?: return@any false
        val clearSecondOwner = window.getOrNull(10) ?: return false
        val trailingObserveFromGlobal = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingObserveFromOwner = (window.getOrNull(13) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            publishStore.matchesTopLevelOwnerPublish() &&
            firstSpawn.matchesHandoffSpawn() &&
            clearFirstOwner.clearsTopLevelOwnerField() &&
            window[8] is ScenarioOp.PerformGc &&
            secondSpawn.matchesHandoffSpawn() &&
            clearSecondOwner.clearsTopLevelOwnerField() &&
            window[11] is ScenarioOp.PerformGc &&
            trailingObserveFromGlobal.path.isNonEmpty() &&
            trailingObserveFromOwner.path.isNonEmpty()
    }

private fun ScenarioBody.containsPingPongRootTransferTopology(): Boolean =
    flattenedStatements().windowed(size = 14, step = 1).any { window ->
        val firstPublish = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val firstTake = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val clearFirstOwner = window.getOrNull(6) ?: return false
        val secondPublish = window.getOrNull(8) as? ScenarioOp.Store ?: return@any false
        val secondTake = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val clearSecondOwner = window.getOrNull(10) ?: return false
        val trailingGlobalObserve = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingOwnerObserve = (window.getOrNull(13) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            firstPublish.matchesTopLevelOwnerPublish() &&
            firstTake.matchesGlobalToOwnerFieldTake() &&
            clearFirstOwner.clearsTopLevelOwnerField() &&
            window[7] is ScenarioOp.PerformGc &&
            secondPublish.matchesTopLevelOwnerPublish() &&
            secondTake.matchesGlobalToOwnerFieldTake() &&
            clearSecondOwner.clearsTopLevelOwnerField() &&
            window[11] is ScenarioOp.PerformGc &&
            trailingGlobalObserve.path.isNonEmpty() &&
            trailingOwnerObserve.path.isNonEmpty()
    }

private fun ScenarioBody.containsConcurrentDuplicateHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 11, step = 1).any { window ->
        val publishStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val firstSpawn = window.getOrNull(6) as? ScenarioOp.Spawn ?: return@any false
        val secondSpawn = window.getOrNull(7) as? ScenarioOp.Spawn ?: return@any false
        val clearOwner = window.getOrNull(8) ?: return false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            publishStore.matchesTopLevelOwnerPublish() &&
            firstSpawn.matchesHandoffSpawn() &&
            secondSpawn.matchesDuplicateHandoffSpawn() &&
            clearOwner.clearsTopLevelOwnerField() &&
            window[9] is ScenarioOp.PerformGc &&
            window[10] is ScenarioOp.Observe
    }

private fun ScenarioBody.containsLocalGlobalArrayHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 13, step = 1).any { window ->
        val firstPublish = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val arrayTake = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val clearOwner = window.getOrNull(7) ?: return false
        val finalTake = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val clearArray = window.getOrNull(10) ?: return false
        val trailingObserve = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false
        val arrayTakeTo = arrayTake.location as? ScenarioLocation.Local ?: return@any false
        val finalTakeFrom = finalTake.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            firstPublish.matchesTopLevelOwnerPublish() &&
            arrayTake.matchesGlobalToOwnerFieldTake() &&
            arrayTakeTo.path.accessors.size == 2 &&
            clearOwner.clearsTopLevelOwnerField() &&
            window[8] is ScenarioOp.PerformGc &&
            finalTake.matchesOwnerFieldTake() &&
            finalTakeFrom.path.accessors.size == 2 &&
            clearArray.clearsTopLevelOwnerField() &&
            window[11] is ScenarioOp.PerformGc &&
            trailingObserve.path.isNonEmpty()
    }

private fun ScenarioBody.containsStaleOwnerMutationAfterHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val publishStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val handoffStore = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val staleMutation = window.getOrNull(7) as? ScenarioOp.Store ?: return@any false
        val clearOldOwner = window.getOrNull(8) ?: return false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            publishStore.matchesTopLevelOwnerPublish() &&
            handoffStore.matchesGlobalToOwnerFieldTake() &&
            staleMutation.matchesOwnerFieldMutation() &&
            clearOldOwner.clearsTopLevelOwnerField() &&
            window[9] is ScenarioOp.PerformGc &&
            window[10] is ScenarioOp.Observe &&
            window[11] is ScenarioOp.Observe
    }

private fun ScenarioBody.containsThreadLocalSharedHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val firstSpawn = window.getOrNull(0) as? ScenarioOp.Spawn ?: return@any false
        val observeShared = (window.getOrNull(3) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val secondSpawn = window.getOrNull(4) as? ScenarioOp.Spawn ?: return@any false
        val trailingObserve = (window.getOrNull(6) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        firstSpawn.body.size == 5 &&
            firstSpawn.body[0] is ScenarioOp.CreateObject &&
            (firstSpawn.body[1] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromLocal() == true &&
            (firstSpawn.body[2] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromGlobal() == true &&
            firstSpawn.body[3].clearsTopLevelGlobal() &&
            firstSpawn.body[4] is ScenarioOp.PerformGc &&
            window[1] is ScenarioOp.AllocationBurst &&
            window[2] is ScenarioOp.PerformGc &&
            observeShared.path.isEmpty() &&
            secondSpawn.body.size == 4 &&
            (secondSpawn.body[0] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromGlobal() == true &&
            secondSpawn.body[1].clearsTopLevelGlobal() &&
            secondSpawn.body[2] is ScenarioOp.PerformGc &&
            secondSpawn.body[3] is ScenarioOp.Observe &&
            window[5] is ScenarioOp.PerformGc &&
            trailingObserve.path.isEmpty()
    }

private fun ScenarioBody.containsWorkerCaptureRootTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val publishStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val spawn = window.getOrNull(3) as? ScenarioOp.Spawn ?: return@any false
        val clearGlobal = window.getOrNull(4) ?: return false
        val trailingObserve = (window.getOrNull(6) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            publishStore.matchesTopLevelOwnerPublish() &&
            spawn.body.size == 4 &&
            spawn.body[0] is ScenarioOp.PerformGc &&
            (spawn.body[1] as? ScenarioOp.Observe)?.value is ScenarioValue.LocalRef &&
            (spawn.body[2] as? ScenarioOp.Store)?.matchesLocalFieldStoreFromLocal() == true &&
            spawn.body[3] is ScenarioOp.PerformGc &&
            clearGlobal.clearsTopLevelGlobal() &&
            window[5] is ScenarioOp.PerformGc &&
            trailingObserve.path.isNonEmpty()
    }

private fun ScenarioBody.containsMultiRootStaggeredClearTopology(): Boolean =
    flattenedStatements().windowed(size = 13, step = 1).any { window ->
        val fieldStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val arrayStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val globalStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val spawn = window.getOrNull(6) as? ScenarioOp.Spawn ?: return@any false
        val clearArray = window.getOrNull(7) ?: return false
        val observeGlobal = (window.getOrNull(9) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearGlobal = window.getOrNull(10) ?: return false
        val trailingObserve = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            fieldStore.matchesLocalFieldStoreFromLocal() &&
            arrayStore.matchesLocalFieldStoreFromLocal() &&
            (arrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            globalStore.matchesTopLevelOwnerPublish() &&
            spawn.body.size == 3 &&
            spawn.body[0].clearsTopLevelOwnerField() &&
            spawn.body[1] is ScenarioOp.PerformGc &&
            spawn.body[2] is ScenarioOp.Observe &&
            clearArray.clearsTopLevelOwnerField() &&
            (clearArray.clearLocation() as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            window[8] is ScenarioOp.PerformGc &&
            observeGlobal.path.isEmpty() &&
            clearGlobal.clearsTopLevelGlobal() &&
            window[11] is ScenarioOp.PerformGc &&
            trailingObserve.path.accessors.size == 2
    }

private fun ScenarioBody.containsConcurrentArraySlotHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 10, step = 1).any { window ->
        val arrayStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val spawn = window.getOrNull(5) as? ScenarioOp.Spawn ?: return@any false
        val sinkObserve = (window.getOrNull(8) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false
        val arrayObserve = (window.getOrNull(9) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            arrayStore.matchesLocalFieldStoreFromLocal() &&
            (arrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            publishStore.matchesTopLevelOwnerPublish() &&
            spawn.body.size == 4 &&
            (spawn.body[0] as? ScenarioOp.Store)?.matchesGlobalToOwnerFieldTake() == true &&
            spawn.body[1].clearsGlobalPath() &&
            spawn.body[2] is ScenarioOp.PerformGc &&
            spawn.body[3] is ScenarioOp.Observe &&
            window[6] is ScenarioOp.AllocationBurst &&
            window[7] is ScenarioOp.PerformGc &&
            sinkObserve.path.isNonEmpty() &&
            arrayObserve.path.accessors.size == 2
    }

private fun ScenarioBody.containsRootRepublishAfterClearTopology(): Boolean =
    flattenedStatements().windowed(size = 8, step = 1).any { window ->
        val firstPublish = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val spawn = window.getOrNull(3) as? ScenarioOp.Spawn ?: return@any false
        val trailingObserve = (window.getOrNull(6) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingClear = window.getOrNull(7) ?: return false

        window[0] is ScenarioOp.CreateObject &&
            firstPublish.matchesTopLevelOwnerPublish() &&
            window[2] is ScenarioOp.PerformGc &&
            spawn.body.size == 5 &&
            spawn.body[0].clearsTopLevelGlobal() &&
            spawn.body[1] is ScenarioOp.AllocationBurst &&
            spawn.body[2] is ScenarioOp.CreateObject &&
            (spawn.body[3] as? ScenarioOp.Store)?.matchesTopLevelOwnerPublish() == true &&
            spawn.body[4] is ScenarioOp.PerformGc &&
            window[4] is ScenarioOp.AllocationBurst &&
            window[5] is ScenarioOp.PerformGc &&
            trailingObserve.path.isEmpty() &&
            trailingClear.clearsTopLevelGlobal()
    }

private fun ScenarioBody.containsTryFinallyRootClearTopology(): Boolean =
    flattenedStatements().windowed(size = 8, step = 1).any { window ->
        val fieldStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val tryFinally = window.getOrNull(4) as? ScenarioOp.TryFinally ?: return@any false
        val trailingObserve = (window.getOrNull(7) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            fieldStore.matchesLocalFieldStoreFromLocal() &&
            publishStore.matchesTopLevelOwnerPublish() &&
            tryFinally.body.size == 3 &&
            (tryFinally.body[0] as? ScenarioOp.Observe)?.value is ScenarioValue.GlobalRef &&
            tryFinally.body[1] is ScenarioOp.AllocationBurst &&
            tryFinally.body[2] is ScenarioOp.PerformGc &&
            tryFinally.finallyBody.size == 3 &&
            tryFinally.finallyBody[0].clearsTopLevelOwnerField() &&
            tryFinally.finallyBody[1].clearsTopLevelGlobal() &&
            tryFinally.finallyBody[2] is ScenarioOp.PerformGc &&
            window[5] is ScenarioOp.AllocationBurst &&
            window[6] is ScenarioOp.PerformGc &&
            trailingObserve.path.isNonEmpty()
    }

private fun ScenarioBody.containsReturnEscapeWorkerPublishTopology(): Boolean =
    flattenedStatements().windowed(size = 8, step = 1).any { window ->
        val call = window.getOrNull(0) as? ScenarioOp.CallFunction ?: return@any false
        val spawn = window.getOrNull(1) as? ScenarioOp.Spawn ?: return@any false
        val clearLocal = window.getOrNull(2) ?: return false
        val observeGlobal = (window.getOrNull(5) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearGlobal = window.getOrNull(6) ?: return false

        call.functionId == 0 &&
            call.args.isEmpty() &&
            spawn.body.size == 3 &&
            (spawn.body[0] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromLocal() == true &&
            spawn.body[1] is ScenarioOp.PerformGc &&
            spawn.body[2] is ScenarioOp.Observe &&
            clearLocal.clearLocation() is ScenarioLocation.Local &&
            window[3] is ScenarioOp.AllocationBurst &&
            window[4] is ScenarioOp.PerformGc &&
            observeGlobal.path.isEmpty() &&
            clearGlobal.clearsTopLevelGlobal() &&
            window[7] is ScenarioOp.PerformGc
    }

private fun ScenarioBody.containsThreadLocalClearOnWorkerExitTopology(): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).any { window ->
        val spawn = window.getOrNull(0) as? ScenarioOp.Spawn ?: return@any false
        val observeShared = (window.getOrNull(3) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearShared = window.getOrNull(4) ?: return false

        spawn.body.size == 5 &&
            spawn.body[0] is ScenarioOp.CreateObject &&
            (spawn.body[1] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromLocal() == true &&
            (spawn.body[2] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromGlobal() == true &&
            spawn.body[3] is ScenarioOp.PerformGc &&
            (spawn.body[4] as? ScenarioOp.Observe)?.value is ScenarioValue.GlobalRef &&
            window[1] is ScenarioOp.AllocationBurst &&
            window[2] is ScenarioOp.PerformGc &&
            observeShared.path.isEmpty() &&
            clearShared.clearsTopLevelGlobal() &&
            window[5] is ScenarioOp.PerformGc
    }

private fun ScenarioBody.containsArraySlotClearWithLateRestoreTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val arrayStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val backupStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val publishArrayOwner = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val clearArraySlot = window.getOrNull(6) ?: return false
        val restoreArraySlot = window.getOrNull(8) as? ScenarioOp.Store ?: return@any false
        val observeArraySlot = (window.getOrNull(10) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearBackup = window.getOrNull(11) ?: return false
        val restoreFrom = restoreArraySlot.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            arrayStore.matchesLocalFieldStoreFromLocal() &&
            (arrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            backupStore.matchesLocalFieldStoreFromLocal() &&
            publishArrayOwner.matchesTopLevelOwnerPublish() &&
            clearArraySlot.clearsTopLevelOwnerField() &&
            (clearArraySlot.clearLocation() as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            window[7] is ScenarioOp.PerformGc &&
            (restoreArraySlot.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            restoreFrom.path.isNonEmpty() &&
            window[9] is ScenarioOp.PerformGc &&
            observeArraySlot.path.accessors.size == 2 &&
            clearBackup.clearsTopLevelOwnerField()
    }

private fun ScenarioBody.containsWorkerPublishMainClearBarrierTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val spawn = window.getOrNull(0) as? ScenarioOp.Spawn ?: return@any false
        val waitPublished = window.getOrNull(1) as? ScenarioOp.Wait ?: return@any false
        val observeGlobal = (window.getOrNull(3) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val signalMainGcDone = window.getOrNull(4) as? ScenarioOp.Signal ?: return@any false
        val workerPublish = spawn.body.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val workerSignalPublished = spawn.body.getOrNull(2) as? ScenarioOp.Signal ?: return@any false
        val workerWaitMainGcDone = spawn.body.getOrNull(3) as? ScenarioOp.Wait ?: return@any false
        val workerClear = spawn.body.getOrNull(5) ?: return false

        spawn.body.size == 7 &&
            spawn.body[0] is ScenarioOp.CreateObject &&
            workerPublish.matchesGlobalTopLevelStoreFromLocal() &&
            workerSignalPublished.checkpointId == waitPublished.checkpointId &&
            workerWaitMainGcDone.checkpointId == signalMainGcDone.checkpointId &&
            spawn.body[4] is ScenarioOp.Yield &&
            workerClear.clearsTopLevelGlobal() &&
            spawn.body[6] is ScenarioOp.PerformGc &&
            window[2] is ScenarioOp.PerformGc &&
            observeGlobal.path.isEmpty() &&
            window[5] is ScenarioOp.AllocationBurst &&
            window[6] is ScenarioOp.PerformGc
    }

private fun ScenarioBody.containsArraySlotClearRestoreBarrierTopology(): Boolean =
    flattenedStatements().windowed(size = 14, step = 1).any { window ->
        val arrayStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val backupStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val publishArrayOwner = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val clearArraySlot = window.getOrNull(6) ?: return false
        val signalSlotCleared = window.getOrNull(7) as? ScenarioOp.Signal ?: return@any false
        val spawn = window.getOrNull(8) as? ScenarioOp.Spawn ?: return@any false
        val waitGcAfterClear = window.getOrNull(9) as? ScenarioOp.Wait ?: return@any false
        val restoreArraySlot = window.getOrNull(10) as? ScenarioOp.Store ?: return@any false
        val observeArraySlot = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearBackup = window.getOrNull(13) ?: return false
        val workerWaitSlotCleared = spawn.body.getOrNull(0) as? ScenarioOp.Wait ?: return@any false
        val workerSignalGcAfterClear = spawn.body.getOrNull(2) as? ScenarioOp.Signal ?: return@any false
        val restoreFrom = restoreArraySlot.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            arrayStore.matchesLocalFieldStoreFromLocal() &&
            (arrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            backupStore.matchesLocalFieldStoreFromLocal() &&
            publishArrayOwner.matchesTopLevelOwnerPublish() &&
            clearArraySlot.clearsTopLevelOwnerField() &&
            (clearArraySlot.clearLocation() as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            spawn.body.size == 4 &&
            workerWaitSlotCleared.checkpointId == signalSlotCleared.checkpointId &&
            spawn.body[1] is ScenarioOp.PerformGc &&
            workerSignalGcAfterClear.checkpointId == waitGcAfterClear.checkpointId &&
            spawn.body[3] is ScenarioOp.Yield &&
            (restoreArraySlot.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            restoreFrom.path.isNonEmpty() &&
            window[11] is ScenarioOp.PerformGc &&
            observeArraySlot.path.accessors.size == 2 &&
            clearBackup.clearsTopLevelOwnerField()
    }

private fun ScenarioBody.containsMixedFieldArrayMutationBarrierTopology(): Boolean =
    flattenedStatements().windowed(size = 15, step = 1).any { window ->
        val initialFieldStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val initialArrayStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val ownerArrayStore = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val publishArrayOwner = window.getOrNull(7) as? ScenarioOp.Store ?: return@any false
        val rewriteFieldStore = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val rewriteArrayStore = window.getOrNull(10) as? ScenarioOp.Store ?: return@any false
        val observeArraySlot = (window.getOrNull(13) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val observeNestedField = (window.getOrNull(14) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            initialFieldStore.matchesLocalFieldStoreFromLocal() &&
            initialArrayStore.matchesLocalFieldStoreFromLocal() &&
            (initialArrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            ownerArrayStore.matchesLocalFieldStoreFromLocal() &&
            (ownerArrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            publishArrayOwner.matchesTopLevelOwnerPublish() &&
            window[8] is ScenarioOp.PerformGc &&
            rewriteFieldStore.matchesLocalFieldStoreFromLocal() &&
            rewriteArrayStore.matchesLocalFieldStoreFromLocal() &&
            (rewriteArrayStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            window[11] is ScenarioOp.AllocationBurst &&
            window[12] is ScenarioOp.PerformGc &&
            observeArraySlot.path.accessors.size == 2 &&
            observeNestedField.path.accessors.size == 3
    }

private fun ScenarioBody.containsLargeObjectMultiFieldRewriteTopology(): Boolean =
    flattenedStatements().windowed(size = 18, step = 1).any { window ->
        val publishOwner = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val initialStores = window.drop(6).take(4).map { it as? ScenarioOp.Store ?: return@any false }
        val rewriteOps = window.drop(11).take(4)
        val observeRewrite = (window.getOrNull(17) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val initialPaths = initialStores.mapNotNull { (it.location as? ScenarioLocation.Local)?.path?.accessors?.singleOrNull() }
        val rewritePaths = rewriteOps.mapNotNull { op ->
            when (op) {
                is ScenarioOp.Store -> (op.location as? ScenarioLocation.Local)?.path?.accessors?.singleOrNull()
                else -> (op.clearLocation() as? ScenarioLocation.Local)?.path?.accessors?.singleOrNull()
            }
        }

        window.take(5).all { it is ScenarioOp.CreateObject } &&
            publishOwner.matchesTopLevelOwnerPublish() &&
            initialStores.all(ScenarioOp.Store::matchesLocalFieldStoreFromLocal) &&
            initialPaths.toSet().size == 4 &&
            window[10] is ScenarioOp.PerformGc &&
            rewritePaths.toSet().size == 4 &&
            rewritePaths.toSet() == initialPaths.toSet() &&
            rewriteOps.count { it.clearLocation() != null } == 1 &&
            rewriteOps.count { it is ScenarioOp.Store && it.value is ScenarioValue.LocalRef } == 3 &&
            window[15] is ScenarioOp.AllocationBurst &&
            window[16] is ScenarioOp.PerformGc &&
            observeRewrite.path.isNonEmpty()
    }

private fun ScenarioBody.containsOldRootChurnWithAllocationBurstTopology(): Boolean =
    flattenedStatements().windowed(size = 16, step = 1).any { window ->
        val publishOwner = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val firstStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val secondStore = window.getOrNull(8) as? ScenarioOp.Store ?: return@any false
        val thirdStore = window.getOrNull(11) as? ScenarioOp.Store ?: return@any false
        val observe = (window.getOrNull(14) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clear = window.getOrNull(15) ?: return false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            publishOwner.matchesTopLevelOwnerPublish() &&
            firstStore.matchesGlobalPathStoreFromLocal() &&
            secondStore.matchesGlobalPathStoreFromLocal() &&
            thirdStore.matchesGlobalPathStoreFromLocal() &&
            window[6] is ScenarioOp.AllocationBurst &&
            window[7] is ScenarioOp.PerformGc &&
            window[9] is ScenarioOp.AllocationBurst &&
            window[10] is ScenarioOp.PerformGc &&
            window[12] is ScenarioOp.AllocationBurst &&
            window[13] is ScenarioOp.PerformGc &&
            observe.path.isNonEmpty() &&
            clear.clearsGlobalPath()
    }

private fun ScenarioBody.containsGraphMutationMultiPhaseSequenceTopology(): Boolean =
    flattenedStatements().windowed(size = 18, step = 1).any { window ->
        val ownerStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val nestedStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val backupStore = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val publishOwner = window.getOrNull(7) as? ScenarioOp.Store ?: return@any false
        val clearOwner = window.getOrNull(9) ?: return false
        val reconnectOwner = window.getOrNull(12) as? ScenarioOp.Store ?: return@any false
        val clearNested = window.getOrNull(13) ?: return false
        val restoreNested = window.getOrNull(14) as? ScenarioOp.Store ?: return@any false
        val observe = (window.getOrNull(16) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearBackup = window.getOrNull(17) ?: return false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            ownerStore.matchesLocalFieldStoreFromLocal() &&
            nestedStore.matchesLocalFieldStoreFromLocal() &&
            backupStore.matchesLocalFieldStoreFromLocal() &&
            publishOwner.matchesTopLevelOwnerPublish() &&
            window[8] is ScenarioOp.PerformGc &&
            clearOwner.clearsTopLevelOwnerField() &&
            window[10] is ScenarioOp.AllocationBurst &&
            window[11] is ScenarioOp.PerformGc &&
            reconnectOwner.matchesOwnerFieldTake() &&
            clearNested.clearsTopLevelOwnerField() &&
            restoreNested.matchesLocalFieldStoreFromLocal() &&
            window[15] is ScenarioOp.PerformGc &&
            observe.path.isNonEmpty() &&
            clearBackup.clearsTopLevelOwnerField()
    }

private fun ScenarioBody.containsSharedNodeReconnectBetweenOwnersTopology(): Boolean =
    flattenedStatements().windowed(size = 16, step = 1).any { window ->
        val initialStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val publishA = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val connectB = window.getOrNull(7) as? ScenarioOp.Store ?: return@any false
        val clearA = window.getOrNull(8) ?: return false
        val publishB = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val connectC = window.getOrNull(11) as? ScenarioOp.Store ?: return@any false
        val clearB = window.getOrNull(12) ?: return false
        val publishC = window.getOrNull(13) as? ScenarioOp.Store ?: return@any false
        val observe = (window.getOrNull(15) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(4).all { it is ScenarioOp.CreateObject } &&
            initialStore.matchesLocalFieldStoreFromLocal() &&
            publishA.matchesTopLevelOwnerPublish() &&
            window[6] is ScenarioOp.PerformGc &&
            connectB.matchesGlobalToOwnerFieldTake() &&
            clearA.clearsTopLevelOwnerField() &&
            publishB.matchesTopLevelOwnerPublish() &&
            window[10] is ScenarioOp.PerformGc &&
            connectC.matchesGlobalToOwnerFieldTake() &&
            clearB.clearsTopLevelOwnerField() &&
            publishC.matchesTopLevelOwnerPublish() &&
            window[14] is ScenarioOp.PerformGc &&
            observe.path.isNonEmpty()
    }

private fun ScenarioBody.containsCycleBreakAndRerootTopology(): Boolean =
    flattenedStatements().windowed(size = 15, step = 1).any { window ->
        val leftToRight = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val rightToLeft = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val publishLeft = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val breakLeft = window.getOrNull(7) ?: return false
        val rerootRight = window.getOrNull(8) as? ScenarioOp.Store ?: return@any false
        val publishReroot = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val reconnectLeft = window.getOrNull(12) as? ScenarioOp.Store ?: return@any false
        val observe = (window.getOrNull(14) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            leftToRight.matchesLocalFieldStoreFromLocal() &&
            rightToLeft.matchesLocalFieldStoreFromLocal() &&
            publishLeft.matchesTopLevelOwnerPublish() &&
            window[6] is ScenarioOp.PerformGc &&
            breakLeft.clearsTopLevelOwnerField() &&
            rerootRight.matchesLocalFieldStoreFromLocal() &&
            publishReroot.matchesTopLevelOwnerPublish() &&
            window[10] is ScenarioOp.AllocationBurst &&
            window[11] is ScenarioOp.PerformGc &&
            reconnectLeft.matchesOwnerFieldTakeFromGlobal() &&
            window[13] is ScenarioOp.PerformGc &&
            observe.path.isNonEmpty()
    }

private fun ScenarioBody.containsFinalizerGlobalPublishTopology(): Boolean =
    flattenedStatements().windowed(size = 9, step = 1).any { window ->
        val createFinalizable = window.getOrNull(0) as? ScenarioOp.CreateObject ?: return@any false
        val publishStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val clearLocal = window.getOrNull(2) ?: return false
        val clearGlobal = window.getOrNull(3) ?: return false
        val trailingObserve = (window.getOrNull(8) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        publishStore.matchesTopLevelOwnerPublish() &&
            clearLocal.clearLocation() is ScenarioLocation.Local &&
            clearGlobal.clearsTopLevelGlobal() &&
            window[4] is ScenarioOp.AllocationBurst &&
            window[5] is ScenarioOp.PerformGc &&
            window[6] is ScenarioOp.AllocationBurst &&
            window[7] is ScenarioOp.PerformGc &&
            trailingObserve.path.isEmpty() &&
            (publishStore.value as? ScenarioValue.LocalRef)?.localId == createFinalizable.localId
    }

private fun ScenarioOp.Store.matchesTopLevelOwnerPublish(): Boolean {
    val location = location as? ScenarioLocation.Global ?: return false
    val value = value as? ScenarioValue.LocalRef ?: return false
    return location.path.isEmpty() && value.path.isEmpty()
}

private fun ScenarioOp.Store.matchesGlobalTopLevelStoreFromLocal(): Boolean {
    val location = location as? ScenarioLocation.Global ?: return false
    val value = value as? ScenarioValue.LocalRef ?: return false
    return location.path.isEmpty() && value.path.isEmpty()
}

private fun ScenarioOp.Store.matchesGlobalTopLevelStoreFromGlobal(): Boolean {
    val location = location as? ScenarioLocation.Global ?: return false
    val value = value as? ScenarioValue.GlobalRef ?: return false
    return location.path.isEmpty() && value.path.isEmpty()
}

private fun ScenarioOp.Store.matchesWeakGlobalStoreFromGlobal(): Boolean {
    val location = location as? ScenarioLocation.Global ?: return false
    value as? ScenarioValue.GlobalRef ?: return false
    return location.path.isEmpty() && referenceKind == ScenarioStoreReferenceKind.Weak
}

private fun ScenarioOp.Store.matchesGlobalPathStoreFromLocal(): Boolean {
    val location = location as? ScenarioLocation.Global ?: return false
    val value = value as? ScenarioValue.LocalRef ?: return false
    return location.path.isNonEmpty() && value.path.isEmpty()
}

private fun ScenarioOp.Store.matchesLocalFieldStoreFromLocal(): Boolean {
    val location = location as? ScenarioLocation.Local ?: return false
    val value = value as? ScenarioValue.LocalRef ?: return false
    return location.path.isNonEmpty() && value.path.isEmpty()
}

private fun ScenarioOp.clearLocation(): ScenarioLocation? = when (this) {
    is ScenarioOp.Clear -> location
    is ScenarioOp.Store -> location.takeIf { value is ScenarioValue.NullValue }
    else -> null
}

private fun ScenarioOp.clearsTopLevelOwnerField(): Boolean {
    val location = clearLocation() as? ScenarioLocation.Local ?: return false
    return location.path.isNonEmpty()
}

private fun ScenarioOp.clearsTopLevelGlobal(): Boolean {
    val location = clearLocation() as? ScenarioLocation.Global ?: return false
    return location.path.isEmpty()
}

private fun ScenarioOp.clearsGlobalPath(): Boolean {
    val location = clearLocation() as? ScenarioLocation.Global ?: return false
    return location.path.isNonEmpty()
}

private fun ScenarioOp.Store.matchesGlobalToOwnerFieldTake(): Boolean {
    val location = location as? ScenarioLocation.Local ?: return false
    val value = value as? ScenarioValue.GlobalRef ?: return false
    return location.path.isNonEmpty() && value.path.isNonEmpty()
}

private fun ScenarioOp.Store.matchesOwnerFieldTake(): Boolean {
    val location = location as? ScenarioLocation.Local ?: return false
    val value = value as? ScenarioValue.LocalRef ?: return false
    return location.path.isNonEmpty() && value.path.isNonEmpty()
}

private fun ScenarioOp.Store.matchesOwnerFieldTakeFromGlobal(): Boolean {
    val location = location as? ScenarioLocation.Local ?: return false
    val value = value as? ScenarioValue.GlobalRef ?: return false
    return location.path.isNonEmpty() && value.path.isNonEmpty()
}

private fun ScenarioOp.Store.matchesOwnerFieldMutation(): Boolean {
    val location = location as? ScenarioLocation.Local ?: return false
    return location.path.isNonEmpty() && value is ScenarioValue.LocalRef
}

private fun ScenarioOp.Spawn.matchesHandoffSpawn(): Boolean {
    if (body.size != 4) return false
    val takeStore = body[0] as? ScenarioOp.Store ?: return false
    val republishStore = body[1] as? ScenarioOp.Store ?: return false
    val observe = body[3] as? ScenarioOp.Observe ?: return false
    val takeTo = takeStore.location as? ScenarioLocation.Local ?: return false
    val takeFrom = takeStore.value as? ScenarioValue.GlobalRef ?: return false
    val observeValue = observe.value as? ScenarioValue.LocalRef ?: return false

    return takeTo.path.isNonEmpty() &&
        takeFrom.path.isNonEmpty() &&
        republishStore.matchesTopLevelOwnerPublish() &&
        body[2] is ScenarioOp.PerformGc &&
        observeValue.path.isNonEmpty()
}

private fun ScenarioOp.Spawn.matchesDuplicateHandoffSpawn(): Boolean {
    if (body.size != 4) return false
    val takeStore = body[0] as? ScenarioOp.Store ?: return false
    val observe = body[1] as? ScenarioOp.Observe ?: return false
    val clearStore = body[2] ?: return false
    val observeValue = observe.value as? ScenarioValue.LocalRef ?: return false
    return takeStore.matchesGlobalToOwnerFieldTake() &&
        observeValue.path.isNonEmpty() &&
        clearStore.clearLocation() is ScenarioLocation.Global &&
        body[3] is ScenarioOp.PerformGc
}

private fun ScenarioBody.containsCffiCallbackAfterGcTopology(): Boolean =
    flattenedStatements().windowed(size = 5, step = 1).any { window ->
        val publishStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val roundTrip = window.getOrNull(3) as? ScenarioOp.ForeignRoundTrip ?: return@any false
        val observe = window.getOrNull(4) as? ScenarioOp.Observe ?: return@any false

        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val roundTripValue = roundTrip.value as? ScenarioValue.GlobalRef ?: return@any false
        val observeValue = observe.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[2] is ScenarioOp.PerformGc &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            roundTripValue.path.isEmpty() &&
            observeValue.path.isEmpty() &&
            roundTrip.referenceKind == ScenarioForeignReferenceKind.Strong &&
            roundTrip.pattern == ScenarioForeignInteractionPattern.Callback &&
            roundTrip.repetitions == 1 &&
            publishStoreTo.globalId == roundTripValue.globalId &&
            publishStoreTo.globalId == observeValue.globalId
    }

private fun ScenarioBody.containsCffiIdentityHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 5, step = 1).any { window ->
        val create = window.getOrNull(0) as? ScenarioOp.CreateObject ?: return@any false
        val roundTrip = window.getOrNull(1) as? ScenarioOp.ForeignRoundTrip ?: return@any false
        val publishStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val observe = window.getOrNull(4) as? ScenarioOp.Observe ?: return@any false

        val roundTripValue = roundTrip.value as? ScenarioValue.LocalRef ?: return@any false
        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val observeValue = observe.value as? ScenarioValue.GlobalRef ?: return@any false

        window[3] is ScenarioOp.PerformGc &&
            roundTripValue.path.isEmpty() &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            observeValue.path.isEmpty() &&
            roundTrip.referenceKind == ScenarioForeignReferenceKind.Handle &&
            roundTrip.pattern == ScenarioForeignInteractionPattern.Identity &&
            roundTrip.repetitions == 1 &&
            create.localId == roundTripValue.localId &&
            create.localId == publishStoreFrom.localId &&
            publishStoreTo.globalId == observeValue.globalId
    }

private fun ScenarioBody.containsCycleTopology(): Boolean =
    flattenedStatements().windowed(size = 4, step = 1).any { window ->
        val firstStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val secondStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val secondStoreTo = secondStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val secondStoreFrom = secondStore.value as? ScenarioValue.LocalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            firstStoreTo.path.isNonEmpty() &&
            secondStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            secondStoreFrom.path.isEmpty() &&
            firstStoreTo.localId == secondStoreFrom.localId &&
            secondStoreTo.localId == firstStoreFrom.localId
    }

private fun ScenarioBody.containsSharedNodeTopology(): Boolean =
    flattenedStatements().windowed(size = 5, step = 1).any { window ->
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val secondStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val secondStoreTo = secondStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val secondStoreFrom = secondStore.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            firstStoreTo.path.isNonEmpty() &&
            secondStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            secondStoreFrom.path.isEmpty() &&
            firstStoreFrom.localId == secondStoreFrom.localId &&
            firstStoreTo.localId != secondStoreTo.localId
    }

private fun ScenarioBody.containsGlobalReattachTopology(): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).any { window ->
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val secondStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val thirdStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val secondStoreTo = secondStore.location as? ScenarioLocation.Global ?: return@any false
        val secondStoreFrom = secondStore.value as? ScenarioValue.LocalRef ?: return@any false
        val thirdStoreTo = thirdStore.location as? ScenarioLocation.Local ?: return@any false
        val thirdStoreFrom = thirdStore.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            firstStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            secondStoreTo.path.isEmpty() &&
            secondStoreFrom.path.isEmpty() &&
            thirdStoreTo.path.isNonEmpty() &&
            thirdStoreFrom.path.isNonEmpty() &&
            secondStoreTo.globalId == thirdStoreFrom.globalId &&
            secondStoreFrom.localId == firstStoreTo.localId
    }

private fun ScenarioBody.containsOldRootChurnTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val rootStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val firstPayloadStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val secondPayloadStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val trailingLoad = window.getOrNull(6) as? ScenarioOp.Observe ?: return@any false
        val rootStoreTo = rootStore.location as? ScenarioLocation.Global ?: return@any false
        val rootStoreFrom = rootStore.value as? ScenarioValue.LocalRef ?: return@any false
        val firstPayloadStoreTo = firstPayloadStore.location as? ScenarioLocation.Global ?: return@any false
        val firstPayloadStoreFrom = firstPayloadStore.value as? ScenarioValue.LocalRef ?: return@any false
        val secondPayloadStoreTo = secondPayloadStore.location as? ScenarioLocation.Global ?: return@any false
        val secondPayloadStoreFrom = secondPayloadStore.value as? ScenarioValue.LocalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[2] is ScenarioOp.CreateObject &&
            window[4] is ScenarioOp.CreateObject &&
            rootStoreTo.path.isEmpty() &&
            rootStoreFrom.path.isEmpty() &&
            firstPayloadStoreTo.path.isNonEmpty() &&
            firstPayloadStoreFrom.path.isEmpty() &&
            secondPayloadStoreTo.path.isNonEmpty() &&
            secondPayloadStoreFrom.path.isEmpty() &&
            trailingLoadFrom.path.isNonEmpty() &&
            rootStoreTo.globalId == firstPayloadStoreTo.globalId &&
            firstPayloadStoreTo.globalId == secondPayloadStoreTo.globalId &&
            secondPayloadStoreTo.globalId == trailingLoadFrom.globalId
    }

private fun ScenarioBody.containsReachabilityConsistencyTopology(): Boolean =
    flattenedStatements().windowed(size = 9, step = 1).any { window ->
        val createOwner = window.getOrNull(0) as? ScenarioOp.CreateObject ?: return@any false
        val createPayload = window.getOrNull(1) as? ScenarioOp.CreateObject ?: return@any false
        val attachPayload = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishRoot = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val firstLoad = window.getOrNull(5) as? ScenarioOp.Observe ?: return@any false
        val clearPayload = window.getOrNull(6) ?: return false
        val trailingLoad = window.getOrNull(8) as? ScenarioOp.Observe ?: return@any false

        val attachLocation = attachPayload.location as? ScenarioLocation.Local ?: return@any false
        val attachedPayload = attachPayload.value as? ScenarioValue.LocalRef ?: return@any false
        val rootLocation = publishRoot.location as? ScenarioLocation.Global ?: return@any false
        val publishedOwner = publishRoot.value as? ScenarioValue.LocalRef ?: return@any false
        val clearLocation = clearPayload.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val firstLoadFrom = firstLoad.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.GlobalRef ?: return@any false

            window[4] is ScenarioOp.PerformGc &&
            window[7] is ScenarioOp.PerformGc &&
            attachLocation.path.isNonEmpty() &&
            attachedPayload.path.isEmpty() &&
            rootLocation.path.isEmpty() &&
            publishedOwner.path.isEmpty() &&
            clearLocation.path.sameAs(attachLocation.path) &&
            firstLoadFrom.path.sameAs(attachLocation.path) &&
            trailingLoadFrom.path.sameAs(attachLocation.path) &&
            createOwner.localId == attachLocation.localId &&
            createPayload.localId == attachedPayload.localId &&
            attachLocation.localId == publishedOwner.localId &&
            rootLocation.globalId == firstLoadFrom.globalId &&
            rootLocation.globalId == clearLocation.globalId &&
            rootLocation.globalId == trailingLoadFrom.globalId
    }

private fun ScenarioBody.containsReachabilityConsistencyCapsuleTopology(): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).any { window ->
        val block = window.getOrNull(0) as? ScenarioOp.Block ?: return@any false
        val attachPayload = block.body.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishRoot = block.body.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val createObservation = block.body.getOrNull(4) as? ScenarioOp.CreateReachabilityObservation ?: return@any false
        val aliveCheck = window.getOrNull(2) as? ScenarioOp.CheckReachabilityObservation ?: return@any false
        val clearPayload = window.getOrNull(3) ?: return false
        val deadCheck = window.getOrNull(5) as? ScenarioOp.CheckReachabilityObservation ?: return@any false

        val attachLocation = attachPayload.location as? ScenarioLocation.Local ?: return@any false
        val attachedPayload = attachPayload.value as? ScenarioValue.LocalRef ?: return@any false
        val rootLocation = publishRoot.location as? ScenarioLocation.Global ?: return@any false
        val publishedOwner = publishRoot.value as? ScenarioValue.LocalRef ?: return@any false
        val observationValue = createObservation.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearLocation = clearPayload.clearLocation() as? ScenarioLocation.Global ?: return@any false

        block.body.size == 5 &&
            block.body[0] is ScenarioOp.CreateObject &&
            block.body[1] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.PerformGc &&
            window[4] is ScenarioOp.PerformGc &&
            attachLocation.path.isNonEmpty() &&
            attachedPayload.path.isEmpty() &&
            rootLocation.path.isEmpty() &&
            publishedOwner.path.isEmpty() &&
            observationValue.path.sameAs(attachLocation.path) &&
            clearLocation.path.sameAs(attachLocation.path) &&
            createObservation.kind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind.Weak &&
            aliveCheck.expectation == ScenarioReachabilityExpectation.Alive &&
            deadCheck.expectation == ScenarioReachabilityExpectation.Dead &&
            aliveCheck.observationId == createObservation.observationId &&
            deadCheck.observationId == createObservation.observationId &&
            attachLocation.localId == publishedOwner.localId &&
            rootLocation.globalId == observationValue.globalId &&
            rootLocation.globalId == clearLocation.globalId
    }

private fun ScenarioBody.containsWeakDeadCapsuleTopology(): Boolean =
    flattenedStatements().windowed(size = 3, step = 1).any { window ->
        val block = window.getOrNull(0) as? ScenarioOp.Block ?: return@any false
        val createObservation = block.body.getOrNull(1) as? ScenarioOp.CreateReachabilityObservation ?: return@any false
        val observationValue = createObservation.value as? ScenarioValue.LocalRef ?: return@any false
        val deadCheck = window.getOrNull(2) as? ScenarioOp.CheckReachabilityObservation ?: return@any false

        block.body.size == 2 &&
            block.body[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.PerformGc &&
            createObservation.kind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind.Weak &&
            observationValue.path.isEmpty() &&
            deadCheck.expectation == ScenarioReachabilityExpectation.Dead &&
            deadCheck.observationId == createObservation.observationId &&
            observationValue.localId == (block.body[0] as ScenarioOp.CreateObject).localId
    }

private fun ScenarioBody.containsRootMigrationTopology(): Boolean =
    flattenedStatements().windowed(size = 10, step = 1).any { window ->
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val migrationStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val clearSourceStoreTo = window.getOrNull(6)?.clearLocation() as? ScenarioLocation.Local ?: return@any false
        val clearGlobalStoreTo = window.getOrNull(7)?.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val trailingLoad = window.getOrNull(9) as? ScenarioOp.Observe ?: return@any false

        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val migrationStoreTo = migrationStore.location as? ScenarioLocation.Local ?: return@any false
        val migrationStoreFrom = migrationStore.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            window[8] is ScenarioOp.PerformGc &&
            firstStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            migrationStoreTo.path.isNonEmpty() &&
            migrationStoreFrom.path.isNonEmpty() &&
            trailingLoadFrom.path.sameAs(migrationStoreTo.path) &&
            publishStoreFrom.localId == firstStoreTo.localId &&
            publishStoreTo.globalId == migrationStoreFrom.globalId &&
            clearSourceStoreTo.localId == firstStoreTo.localId &&
            clearSourceStoreTo.path.sameAs(firstStoreTo.path) &&
            clearGlobalStoreTo.globalId == publishStoreTo.globalId &&
            clearGlobalStoreTo.path.isEmpty() &&
            trailingLoadFrom.localId == migrationStoreTo.localId
    }

private fun ScenarioBody.containsRootMigrationCapsuleTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val migrationStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val clearSourceStoreTo = window.getOrNull(6)?.clearLocation() as? ScenarioLocation.Local ?: return@any false
        val clearGlobalStoreTo = window.getOrNull(7)?.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val createObservation = window.getOrNull(8) as? ScenarioOp.CreateReachabilityObservation ?: return@any false
        val oracleCheck = window.getOrNull(10) as? ScenarioOp.CheckReachabilityObservation ?: return@any false
        val trailingLoad = window.getOrNull(11) as? ScenarioOp.Observe ?: return@any false

        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val migrationStoreTo = migrationStore.location as? ScenarioLocation.Local ?: return@any false
        val migrationStoreFrom = migrationStore.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.LocalRef ?: return@any false
        val observationValue = createObservation.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            window[9] is ScenarioOp.PerformGc &&
            oracleCheck.expectation == ScenarioReachabilityExpectation.Alive &&
            firstStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            migrationStoreTo.path.isNonEmpty() &&
            migrationStoreFrom.path.isNonEmpty() &&
            trailingLoadFrom.path.sameAs(migrationStoreTo.path) &&
            publishStoreFrom.localId == firstStoreTo.localId &&
            publishStoreTo.globalId == migrationStoreFrom.globalId &&
            clearSourceStoreTo.localId == firstStoreTo.localId &&
            clearSourceStoreTo.path.sameAs(firstStoreTo.path) &&
            clearGlobalStoreTo.globalId == publishStoreTo.globalId &&
            clearGlobalStoreTo.path.isEmpty() &&
            observationValue.localId == migrationStoreTo.localId &&
            observationValue.path.sameAs(migrationStoreTo.path) &&
            createObservation.kind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind.Weak &&
            oracleCheck.observationId == createObservation.observationId &&
            trailingLoadFrom.localId == migrationStoreTo.localId
    }

private fun ScenarioBody.containsDeleteEdgeThenGcTopology(): Boolean =
    flattenedStatements().windowed(size = 8, step = 1).any { window ->
        val rootStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val attachStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val clearPayloadStoreTo = window.getOrNull(4)?.clearLocation() as? ScenarioLocation.Local ?: return@any false
        val clearEdgeStoreTo = window.getOrNull(5)?.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val trailingLoad = window.getOrNull(7) as? ScenarioOp.Observe ?: return@any false

        val rootStoreTo = rootStore.location as? ScenarioLocation.Global ?: return@any false
        val rootStoreFrom = rootStore.value as? ScenarioValue.LocalRef ?: return@any false
        val attachStoreTo = attachStore.location as? ScenarioLocation.Global ?: return@any false
        val attachStoreFrom = attachStore.value as? ScenarioValue.LocalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            window[6] is ScenarioOp.PerformGc &&
            rootStoreTo.path.isEmpty() &&
            rootStoreFrom.path.isEmpty() &&
            attachStoreTo.path.isNonEmpty() &&
            attachStoreFrom.path.isEmpty() &&
            clearPayloadStoreTo.path.isEmpty() &&
            clearEdgeStoreTo.path.sameAs(attachStoreTo.path) &&
            trailingLoadFrom.path.sameAs(attachStoreTo.path) &&
            rootStoreTo.globalId == attachStoreTo.globalId &&
            attachStoreTo.globalId == clearEdgeStoreTo.globalId &&
            clearEdgeStoreTo.globalId == trailingLoadFrom.globalId
    }

private fun ScenarioBody.containsConcurrentRootMigrationTopology(): Boolean =
    flattenedStatements().windowed(size = 6, step = 1).any { window ->
        val firstStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val threadStatement = window.getOrNull(5) as? ScenarioOp.Spawn ?: return@any false
        val firstStoreTo = firstStore.location as? ScenarioLocation.Local ?: return@any false
        val firstStoreFrom = firstStore.value as? ScenarioValue.LocalRef ?: return@any false
        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false

        val workerStatements = threadStatement.body
        val workerStore = workerStatements.getOrNull(0) as? ScenarioOp.Store ?: return@any false
        val workerClearField = workerStatements.getOrNull(1) ?: return@any false
        val workerClearGlobal = workerStatements.getOrNull(2) ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            firstStoreTo.path.isNonEmpty() &&
            firstStoreFrom.path.isEmpty() &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            publishStoreFrom.localId == firstStoreTo.localId &&
            workerStore.location is ScenarioLocation.Local &&
            workerStore.value is ScenarioValue.GlobalRef &&
            workerClearField.clearsGlobalPath() &&
            workerClearGlobal.clearsTopLevelGlobal() &&
            workerStatements.any { it is ScenarioOp.PerformGc }
    }

private fun ScenarioBody.containsWeakRefLifecycleTopology(): Boolean =
    flattenedStatements().windowed(size = 3, step = 1).any { window ->
        val block = window.getOrNull(0) as? ScenarioOp.Block ?: return@any false
        val strongStore = block.body.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val createObservation = block.body.getOrNull(2) as? ScenarioOp.CreateReachabilityObservation ?: return@any false
        val weakStore = block.body.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val clearStrongTo = block.body.getOrNull(4)?.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val trailingLoad = window.getOrNull(2) as? ScenarioOp.Observe ?: return@any false

        val strongStoreTo = strongStore.location as? ScenarioLocation.Global ?: return@any false
        val strongStoreFrom = strongStore.value as? ScenarioValue.LocalRef ?: return@any false
        val observationValue = createObservation.value as? ScenarioValue.GlobalRef ?: return@any false
        val weakStoreTo = weakStore.location as? ScenarioLocation.Global ?: return@any false
        val weakStoreFrom = weakStore.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        block.body.size == 5 &&
            block.body[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.PerformGc &&
            strongStoreTo.path.isEmpty() &&
            strongStoreFrom.path.isEmpty() &&
            observationValue.path.isEmpty() &&
            createObservation.kind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind.Weak &&
            weakStoreTo.path.isEmpty() &&
            weakStoreFrom.path.isEmpty() &&
            weakStore.referenceKind == ScenarioStoreReferenceKind.Weak &&
            clearStrongTo.path.isEmpty() &&
            trailingLoadFrom.path.isEmpty() &&
            strongStoreTo.globalId == observationValue.globalId &&
            strongStoreTo.globalId == weakStoreFrom.globalId &&
            strongStoreTo.globalId == clearStrongTo.globalId &&
            weakStoreTo.globalId == trailingLoadFrom.globalId
    }

private fun ScenarioBody.containsWeakRootHandoffTopology(): Boolean =
    flattenedStatements().windowed(size = 11, step = 1).any { window ->
        val publishSource = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val weakStore = window.getOrNull(5) as? ScenarioOp.Store ?: return@any false
        val handoffStore = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val clearSource = window.getOrNull(7) ?: return false
        val observeWeak = (window.getOrNull(9) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val observeTarget = (window.getOrNull(10) as? ScenarioOp.Observe)?.value as? ScenarioValue.LocalRef ?: return@any false

        window.take(3).all { it is ScenarioOp.CreateObject } &&
            publishSource.matchesTopLevelOwnerPublish() &&
            weakStore.matchesWeakGlobalStoreFromGlobal() &&
            handoffStore.matchesGlobalToOwnerFieldTake() &&
            clearSource.clearsTopLevelOwnerField() &&
            window[8] is ScenarioOp.PerformGc &&
            observeWeak.path.isEmpty() &&
            observeTarget.path.isNonEmpty()
    }

private fun ScenarioBody.containsWeakArraySlotTopology(): Boolean =
    flattenedStatements().windowed(size = 10, step = 1).any { window ->
        val slotStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishArrayOwner = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val weakStore = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val firstObserveWeak = (window.getOrNull(6) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearSlot = window.getOrNull(7) ?: return false
        val secondObserveWeak = (window.getOrNull(9) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window.take(2).all { it is ScenarioOp.CreateObject } &&
            slotStore.matchesLocalFieldStoreFromLocal() &&
            (slotStore.location as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            publishArrayOwner.matchesTopLevelOwnerPublish() &&
            weakStore.matchesWeakGlobalStoreFromGlobal() &&
            (weakStore.value as? ScenarioValue.GlobalRef)?.path?.accessors?.size == 2 &&
            window[5] is ScenarioOp.PerformGc &&
            firstObserveWeak.path.isEmpty() &&
            clearSlot.clearsTopLevelOwnerField() &&
            (clearSlot.clearLocation() as? ScenarioLocation.Local)?.path?.accessors?.size == 2 &&
            window[8] is ScenarioOp.PerformGc &&
            secondObserveWeak.path.isEmpty()
    }

private fun ScenarioBody.containsWeakThreadLocalRootTopology(): Boolean =
    flattenedStatements().windowed(size = 8, step = 1).any { window ->
        val spawn = window.getOrNull(0) as? ScenarioOp.Spawn ?: return@any false
        val observeWeakBeforeClear = (window.getOrNull(2) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val observeStrong = (window.getOrNull(3) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearStrong = window.getOrNull(4) ?: return false
        val observeWeakAfterClear = (window.getOrNull(7) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        spawn.body.size == 5 &&
            spawn.body[0] is ScenarioOp.CreateObject &&
            (spawn.body[1] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromLocal() == true &&
            (spawn.body[2] as? ScenarioOp.Store)?.matchesWeakGlobalStoreFromGlobal() == true &&
            (spawn.body[3] as? ScenarioOp.Store)?.matchesGlobalTopLevelStoreFromGlobal() == true &&
            spawn.body[4].clearsTopLevelGlobal() &&
            window[1] is ScenarioOp.PerformGc &&
            observeWeakBeforeClear.path.isEmpty() &&
            observeStrong.path.isEmpty() &&
            clearStrong.clearsTopLevelGlobal() &&
            window[5] is ScenarioOp.AllocationBurst &&
            window[6] is ScenarioOp.PerformGc &&
            observeWeakAfterClear.path.isEmpty()
    }

private fun ScenarioBody.containsWeakStrongGlobalAlternatingTopology(): Boolean =
    flattenedStatements().windowed(size = 13, step = 1).any { window ->
        val firstStrongStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val firstWeakStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val firstObserveWeak = (window.getOrNull(4) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearStrong = window.getOrNull(5) ?: return false
        val secondStrongStore = window.getOrNull(9) as? ScenarioOp.Store ?: return@any false
        val secondWeakStore = window.getOrNull(10) as? ScenarioOp.Store ?: return@any false
        val secondObserveWeak = (window.getOrNull(12) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            firstStrongStore.matchesGlobalTopLevelStoreFromLocal() &&
            firstWeakStore.matchesWeakGlobalStoreFromGlobal() &&
            window[3] is ScenarioOp.PerformGc &&
            firstObserveWeak.path.isEmpty() &&
            clearStrong.clearsTopLevelGlobal() &&
            window[6] is ScenarioOp.AllocationBurst &&
            window[7] is ScenarioOp.PerformGc &&
            window[8] is ScenarioOp.CreateObject &&
            secondStrongStore.matchesGlobalTopLevelStoreFromLocal() &&
            secondWeakStore.matchesWeakGlobalStoreFromGlobal() &&
            window[11] is ScenarioOp.PerformGc &&
            secondObserveWeak.path.isEmpty()
    }

private fun ScenarioBody.containsWeakLateStrongRescueTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val strongStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val weakStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val clearStrong = window.getOrNull(4) ?: return false
        val rescueStore = window.getOrNull(7) as? ScenarioOp.Store ?: return@any false
        val observeStrong = (window.getOrNull(9) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearRescue = window.getOrNull(10) ?: return false
        val observeWeak = (window.getOrNull(11) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            strongStore.matchesGlobalTopLevelStoreFromLocal() &&
            weakStore.matchesWeakGlobalStoreFromGlobal() &&
            window[3] is ScenarioOp.PerformGc &&
            clearStrong.clearsTopLevelGlobal() &&
            window[5] is ScenarioOp.AllocationBurst &&
            window[6] is ScenarioOp.PerformGc &&
            rescueStore.matchesGlobalTopLevelStoreFromGlobal() &&
            window[8] is ScenarioOp.PerformGc &&
            observeStrong.path.isEmpty() &&
            clearRescue.clearsTopLevelGlobal() &&
            observeWeak.path.isEmpty()
    }

private fun ScenarioBody.containsWeakMultiEpochObserveTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val strongStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val weakStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val firstObserveWeak = (window.getOrNull(4) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val secondObserveWeak = (window.getOrNull(7) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false
        val clearStrong = window.getOrNull(8) ?: return false
        val thirdObserveWeak = (window.getOrNull(11) as? ScenarioOp.Observe)?.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            strongStore.matchesGlobalTopLevelStoreFromLocal() &&
            weakStore.matchesWeakGlobalStoreFromGlobal() &&
            window[3] is ScenarioOp.PerformGc &&
            firstObserveWeak.path.isEmpty() &&
            window[5] is ScenarioOp.AllocationBurst &&
            window[6] is ScenarioOp.PerformGc &&
            secondObserveWeak.path.isEmpty() &&
            clearStrong.clearsTopLevelGlobal() &&
            window[9] is ScenarioOp.AllocationBurst &&
            window[10] is ScenarioOp.PerformGc &&
            thirdObserveWeak.path.isEmpty()
    }

private fun ScenarioBody.containsConcurrentPublishClearGcTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val publishStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val threadStatement = window.getOrNull(2) as? ScenarioOp.Spawn ?: return@any false
        val mainLoad = window.getOrNull(5) as? ScenarioOp.Observe ?: return@any false
        val clearLocalTo = window.getOrNull(6)?.clearLocation() as? ScenarioLocation.Local ?: return@any false

        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val mainLoadFrom = mainLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        val workerStatements = threadStatement.body
        val workerLoad = workerStatements.getOrNull(0) as? ScenarioOp.Observe ?: return@any false
        val workerClearTo = workerStatements.getOrNull(1)?.clearLocation() as? ScenarioLocation.Global ?: return@any false
        val workerLoadFrom = workerLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[3] is ScenarioOp.AllocationBurst &&
            window[4] is ScenarioOp.PerformGc &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            mainLoadFrom.path.isEmpty() &&
            clearLocalTo.path.isEmpty() &&
            workerLoadFrom.path.isEmpty() &&
            workerClearTo.path.isEmpty() &&
            workerStatements.getOrNull(2) is ScenarioOp.AllocationBurst &&
            workerStatements.getOrNull(3) is ScenarioOp.PerformGc &&
            publishStoreTo.globalId == mainLoadFrom.globalId &&
            publishStoreTo.globalId == workerLoadFrom.globalId &&
            publishStoreTo.globalId == workerClearTo.globalId &&
            publishStoreFrom.localId == clearLocalTo.localId
    }

private fun ScenarioBody.containsArraySlotGraphTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val storeSlot = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val storeBackEdge = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val storeSecondSlot = window.getOrNull(4) as? ScenarioOp.Store ?: return@any false
        val trailingLoad = window.getOrNull(6) as? ScenarioOp.Observe ?: return@any false

        val storeSlotTo = storeSlot.location as? ScenarioLocation.Local ?: return@any false
        val storeSlotFrom = storeSlot.value as? ScenarioValue.LocalRef ?: return@any false
        val storeBackEdgeTo = storeBackEdge.location as? ScenarioLocation.Local ?: return@any false
        val storeBackEdgeFrom = storeBackEdge.value as? ScenarioValue.LocalRef ?: return@any false
        val storeSecondSlotTo = storeSecondSlot.location as? ScenarioLocation.Local ?: return@any false
        val storeSecondSlotFrom = storeSecondSlot.value as? ScenarioValue.LocalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.LocalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            window[5] is ScenarioOp.PerformGc &&
            storeSlotTo.path.accessors.size == 2 &&
            storeSlotFrom.path.isEmpty() &&
            storeBackEdgeTo.path.isNonEmpty() &&
            storeBackEdgeFrom.path.isEmpty() &&
            storeSecondSlotTo.path.accessors.size == 2 &&
            storeSecondSlotFrom.path.isNonEmpty() &&
            trailingLoadFrom.path.sameAs(storeSlotTo.path) &&
            storeSlotTo.localId == storeBackEdgeFrom.localId &&
            storeSlotTo.localId == storeSecondSlotTo.localId &&
            storeSlotTo.localId == trailingLoadFrom.localId &&
            storeSlotFrom.localId == storeBackEdgeTo.localId &&
            storeSlotFrom.localId == storeSecondSlotFrom.localId
    }

private fun ScenarioBody.containsGraphMutationSequenceTopology(): Boolean =
    flattenedStatements().windowed(size = 12, step = 1).any { window ->
        val initialStore = window.getOrNull(2) as? ScenarioOp.Store ?: return@any false
        val publishStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val replacementStore = window.getOrNull(6) as? ScenarioOp.Store ?: return@any false
        val clearFirstPayloadTo = window.getOrNull(7)?.clearLocation() as? ScenarioLocation.Local ?: return@any false
        val loadAfterReplacement = window.getOrNull(9) as? ScenarioOp.Observe ?: return@any false
        val clearOwnerFieldTo = window.getOrNull(10)?.clearLocation() as? ScenarioLocation.Local ?: return@any false

        val initialStoreTo = initialStore.location as? ScenarioLocation.Local ?: return@any false
        val initialStoreFrom = initialStore.value as? ScenarioValue.LocalRef ?: return@any false
        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val replacementStoreTo = replacementStore.location as? ScenarioLocation.Local ?: return@any false
        val replacementStoreFrom = replacementStore.value as? ScenarioValue.LocalRef ?: return@any false
        val loadAfterReplacementFrom = loadAfterReplacement.value as? ScenarioValue.GlobalRef ?: return@any false

        window[0] is ScenarioOp.CreateObject &&
            window[1] is ScenarioOp.CreateObject &&
            window[4] is ScenarioOp.PerformGc &&
            window[5] is ScenarioOp.CreateObject &&
            window[8] is ScenarioOp.PerformGc &&
            window[11] is ScenarioOp.PerformGc &&
            initialStoreTo.path.isNonEmpty() &&
            initialStoreFrom.path.isEmpty() &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            replacementStoreTo.path.sameAs(initialStoreTo.path) &&
            replacementStoreFrom.path.isEmpty() &&
            clearFirstPayloadTo.path.isEmpty() &&
            loadAfterReplacementFrom.path.sameAs(initialStoreTo.path) &&
            clearOwnerFieldTo.path.sameAs(initialStoreTo.path) &&
            publishStoreFrom.localId == initialStoreTo.localId &&
            replacementStoreTo.localId == initialStoreTo.localId &&
            clearOwnerFieldTo.localId == initialStoreTo.localId &&
            clearFirstPayloadTo.localId == initialStoreFrom.localId &&
            publishStoreTo.globalId == loadAfterReplacementFrom.globalId
    }

private fun ScenarioBody.containsFunctionReturnEscapeTopology(): Boolean =
    flattenedStatements().windowed(size = 7, step = 1).any { window ->
        val call = window.getOrNull(0) as? ScenarioOp.CallFunction ?: return@any false
        val publishStore = window.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val ownerStore = window.getOrNull(3) as? ScenarioOp.Store ?: return@any false
        val trailingLoad = window.getOrNull(5) as? ScenarioOp.Observe ?: return@any false
        val clearGlobalTo = window.getOrNull(6)?.clearLocation() as? ScenarioLocation.Global ?: return@any false

        val publishStoreTo = publishStore.location as? ScenarioLocation.Global ?: return@any false
        val publishStoreFrom = publishStore.value as? ScenarioValue.LocalRef ?: return@any false
        val ownerStoreTo = ownerStore.location as? ScenarioLocation.Local ?: return@any false
        val ownerStoreFrom = ownerStore.value as? ScenarioValue.GlobalRef ?: return@any false
        val trailingLoadFrom = trailingLoad.value as? ScenarioValue.LocalRef ?: return@any false

        call.functionId == 0 &&
            call.args.isEmpty() &&
            window[2] is ScenarioOp.CreateObject &&
            window[4] is ScenarioOp.PerformGc &&
            publishStoreTo.path.isEmpty() &&
            publishStoreFrom.path.isEmpty() &&
            ownerStoreTo.path.isNonEmpty() &&
            ownerStoreFrom.path.isEmpty() &&
            trailingLoadFrom.path.sameAs(ownerStoreTo.path) &&
            clearGlobalTo.path.isEmpty() &&
            publishStoreTo.globalId == ownerStoreFrom.globalId &&
            publishStoreTo.globalId == clearGlobalTo.globalId &&
            ownerStoreTo.localId == trailingLoadFrom.localId
    }

private fun ScenarioBody.containsWorkerAllocPublishTopology(): Boolean =
    flattenedStatements().windowed(size = 5, step = 1).any { window ->
        val threadStatement = window.getOrNull(0) as? ScenarioOp.Spawn ?: return@any false
        val mainLoad = window.getOrNull(3) as? ScenarioOp.Observe ?: return@any false
        val clearGlobalTo = window.getOrNull(4)?.clearLocation() as? ScenarioLocation.Global ?: return@any false

        val workerStatements = threadStatement.body
        val workerAlloc = workerStatements.getOrNull(0) as? ScenarioOp.CreateObject ?: return@any false
        val workerPublish = workerStatements.getOrNull(1) as? ScenarioOp.Store ?: return@any false
        val workerPublishTo = workerPublish.location as? ScenarioLocation.Global ?: return@any false
        val workerPublishFrom = workerPublish.value as? ScenarioValue.LocalRef ?: return@any false
        val mainLoadFrom = mainLoad.value as? ScenarioValue.GlobalRef ?: return@any false

        window[1] is ScenarioOp.AllocationBurst &&
            window[2] is ScenarioOp.PerformGc &&
            workerStatements.getOrNull(2) is ScenarioOp.PerformGc &&
            workerPublishTo.path.isEmpty() &&
            workerPublishFrom.path.isEmpty() &&
            mainLoadFrom.path.isEmpty() &&
            clearGlobalTo.path.isEmpty() &&
            workerPublishTo.globalId == mainLoadFrom.globalId &&
            workerPublishTo.globalId == clearGlobalTo.globalId &&
            workerAlloc.classId >= 0
    }

private fun ScenarioPath.isEmpty(): Boolean = accessors.isEmpty()
private fun ScenarioPath.isNonEmpty(): Boolean = accessors.isNotEmpty()
private fun ScenarioPath.sameAs(other: ScenarioPath): Boolean = accessors == other.accessors
