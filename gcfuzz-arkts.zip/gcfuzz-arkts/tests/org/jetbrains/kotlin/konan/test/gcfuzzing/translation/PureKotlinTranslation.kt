/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDomain
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioEntityId
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioParameter
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import java.io.File
import kotlin.time.Duration
import kotlin.time.TimeSource

class PureKotlinOutput(
    val files: Map<String, String>,
    val entryFileName: String,
    val args: List<String>,
    val cInterop: PureKotlinCInteropSupport? = null,
) {
    val filename: String
        get() = entryFileName

    val contents: String
        get() = files.getValue(entryFileName)
}

class PureKotlinConfig(
    val moduleName: String,
    val maximumStackDepth: Int,
    val mainLoopRepeatCount: Int,
    val maxThreadCount: Int,
    val softTimeout: Duration,
)

internal fun ScenarioProgram.producePureKotlin(config: PureKotlinConfig): PureKotlinOutput {
    val hasCInterop = containsCInterop()
    val context = PureKotlinScenarioTranslationContext(config, this, hasCInterop)
    context.translate()
    val entryFileName = "${config.moduleName}.kt"
    val files = linkedMapOf(entryFileName to context.contents.toString())
    val cInterop = if (hasCInterop) {
        val generated = generatePureKotlinCInteropFiles()
        files.putAll(generated.files)
        generated.support
    } else {
        null
    }
    return PureKotlinOutput(
        files = files,
        entryFileName = entryFileName,
        args = listOf(
            "-opt",
            "-entry", "main",
        ),
        cInterop = cInterop,
    )
}

fun PureKotlinOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}

private fun ScenarioProgram.containsCInterop(): Boolean =
    definitions.any { definition ->
        when (definition) {
            is ScenarioDefinition.Function -> definition.body.body.statements.containsCInterop()
            is ScenarioDefinition.Class,
            is ScenarioDefinition.Interface,
            is ScenarioDefinition.SingletonObject,
            is ScenarioDefinition.Global -> false
        }
    } || mainBody.statements.containsCInterop()

private fun List<ScenarioOp>.containsCInterop(): Boolean = any { op ->
    when (op) {
        is ScenarioOp.ForeignRoundTrip -> true
        is ScenarioOp.CreateReachabilityObservation -> false
        is ScenarioOp.CheckReachabilityObservation -> false
        is ScenarioOp.CheckReachability -> false
        is ScenarioOp.Clear -> false
        is ScenarioOp.StoreBatch -> false
        is ScenarioOp.GcEpoch -> false
        is ScenarioOp.Block -> op.body.containsCInterop()
        is ScenarioOp.ScopedRoot -> op.body.containsCInterop()
        is ScenarioOp.If -> op.thenBody.containsCInterop() || op.elseBody.containsCInterop()
        is ScenarioOp.TryFinally -> op.body.containsCInterop() || op.finallyBody.containsCInterop()
        is ScenarioOp.Spawn -> op.body.containsCInterop()
        is ScenarioOp.SpawnWithResult -> op.body.containsCInterop()
        is ScenarioOp.CompareAndSet -> false
        is ScenarioOp.Signal -> false
        is ScenarioOp.Wait -> false
        ScenarioOp.Yield -> false
        else -> false
    }
}


private class PureKotlinScenarioTranslationContext(
    private val config: PureKotlinConfig,
    private val scenarioProgram: ScenarioProgram,
    private val hasCInterop: Boolean,
    val contents: OutputFileBuilder = OutputFileBuilder(),
) {
    private val scopeResolver = ScenarioGlobalScopeResolver(scenarioProgram)
    private val observationIds = scenarioProgram.collectObservationIds()

    fun translate() {
        renderPrelude(contents, config, hasCInterop)
        scenarioProgram.definitions.forEachIndexed { index, definition ->
            when (definition) {
                is ScenarioDefinition.Function -> translateFunctionDefinition(index, definition)
                is ScenarioDefinition.Global -> translateGlobalDefinition(index, definition)
                is ScenarioDefinition.Class -> if (definition.nestedInClassId == null) translateClassDefinition(index, definition)
                is ScenarioDefinition.Interface -> translateInterfaceDefinition(index)
                is ScenarioDefinition.SingletonObject -> translateSingletonObjectDefinition(index, definition)
            }
        }
        translateObservationDeclarations()
        translateThreadLocalCleanup()
        translateMainFunction()
    }

    private fun translateField(field: ScenarioField, name: String, init: String, isPrivate: Boolean, atomic: Boolean) {
        val backingName = "${name}Impl"
        when (field) {
            is ScenarioField.StrongRef -> {
                if (atomic) {
                    contents.lineEnd("private val $backingName = AtomicReference<Any?>($init)")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName.load()")
                    contents.lineEnd("    set(value) { $backingName.store(value) }")
                } else {
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any? = $init")
                    }
                }
            }
            is ScenarioField.TypedStrongRef -> {
                val type = renderKotlinType(field.type)
                if (atomic) {
                    contents.lineEnd("private val ${backingName} = AtomicReference<Any?>(${init})")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var ${name}: ${type}")
                    }
                    contents.lineEnd("    get() = ${backingName}.load() as? ${type}")
                    contents.lineEnd("    set(value) { ${backingName}.store(value) }")
                } else {
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var ${name}: ${type} = ${init} as? ${type}")
                    }
                }
            }
            is ScenarioField.WeakRef -> {
                val asWeak = "?.let { WeakReference(it) }"
                if (atomic) {
                    contents.lineEnd("private val $backingName = AtomicReference<WeakReference<Any>?>($init$asWeak)")
                } else {
                    contents.lineEnd("private var $backingName: WeakReference<Any>? = $init$asWeak")
                }
                contents.lineEnd {
                    if (isPrivate) append("private ")
                    append("var ${name}: Any?")
                }
                if (atomic) {
                    contents.lineEnd("    get() = $backingName.load()?.value")
                    contents.lineEnd("    set(value) { $backingName.store(value$asWeak) }")
                } else {
                    contents.lineEnd("    get() = $backingName?.value")
                    contents.lineEnd("    set(value) { $backingName = value$asWeak }")
                }
            }
            is ScenarioField.IntValue -> {
                if (atomic) {
                    contents.lineEnd("private val $backingName = AtomicInt(anyToInt($init))")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName.load()")
                    contents.lineEnd("    set(value) { $backingName.store(anyToInt(value)) }")
                } else {
                    contents.lineEnd("private var $backingName: Int = anyToInt($init)")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName")
                    contents.lineEnd("    set(value) { $backingName = anyToInt(value) }")
                }
            }
            is ScenarioField.BooleanValue -> {
                if (atomic) {
                    contents.lineEnd("private val $backingName = AtomicBoolean(anyToBoolean($init))")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName.load()")
                    contents.lineEnd("    set(value) { $backingName.store(anyToBoolean(value)) }")
                } else {
                    contents.lineEnd("private var $backingName: Boolean = anyToBoolean($init)")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName")
                    contents.lineEnd("    set(value) { $backingName = anyToBoolean(value) }")
                }
            }
            is ScenarioField.ObjectArray -> {
                if (atomic) {
                    contents.lineEnd("private val $backingName = AtomicReference(anyToArrayBox($init, ${field.size}))")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName.load()")
                    contents.lineEnd("    set(value) { $backingName.store(anyToArrayBox(value, ${field.size})) }")
                } else {
                    contents.lineEnd("private var $backingName: KotlinArrayBox = anyToArrayBox($init, ${field.size})")
                    contents.lineEnd {
                        if (isPrivate) append("private ")
                        append("var $name: Any?")
                    }
                    contents.lineEnd("    get() = $backingName")
                    contents.lineEnd("    set(value) { $backingName = anyToArrayBox(value, ${field.size}) }")
                }
            }
        }
    }

    private fun translateGlobalDefinition(index: Int, definition: ScenarioDefinition.Global) {
        if (definition.storage is ScenarioGlobalStorage.ThreadLocal) {
            contents.lineEnd("@ThreadLocal")
        }
        translateField(
            field = definition.field,
            name = "g$index",
            init = "null",
            isPrivate = true,
            atomic = definition.storage is ScenarioGlobalStorage.Shared,
        )
    }

    private fun translateObservationDeclarations() {
        observationIds.forEach { observationId ->
            contents.lineEnd("private val o${observationId}Impl = AtomicReference<WeakReference<Any>?>(null)")
            contents.lineEnd("private var o${observationId}: WeakReference<Any>?")
            contents.lineEnd("    get() = o${observationId}Impl.load()")
            contents.lineEnd("    set(value) { o${observationId}Impl.store(value) }")
        }
    }

    private fun translateThreadLocalCleanup() {
        val threadLocals = scenarioProgram.definitions
            .filterIsInstance<ScenarioDefinition.Global>()
            .mapIndexedNotNull { index, definition ->
                if (definition.storage is ScenarioGlobalStorage.ThreadLocal) index to definition else null
            }
        contents.lineEnd()
        contents.line("private fun clearThreadLocalRoots()")
        contents.braces {
            threadLocals.forEach { (index, global) ->
                when (global.field) {
                    is ScenarioField.StrongRef, is ScenarioField.TypedStrongRef, is ScenarioField.WeakRef, is ScenarioField.ObjectArray -> contents.lineEnd("g$index = null")
                    is ScenarioField.IntValue -> contents.lineEnd("g$index = 0")
                    is ScenarioField.BooleanValue -> contents.lineEnd("g$index = false")
                }
            }
        }
    }

    private fun translateClassDefinition(index: Int, definition: ScenarioDefinition.Class) {
        translateClassDefinition(index, definition, nested = false)
        contents.lineEnd()
    }

    private fun translateClassDefinition(index: Int, definition: ScenarioDefinition.Class, nested: Boolean) {
        contents.line {
            if (definition.kind == ScenarioClassKind.Sealed) append("sealed ")
            if (nested) append("inner ")
            append("class Class$index")
            parens {
                if (definition.kind == ScenarioClassKind.Concrete) {
                    definition.fields.forEachIndexed { fieldIndex, _ ->
                        arg("f${fieldIndex}: Any?")
                    }
                }
            }
            val superClass = definition.superClassId?.let(scopeResolver::resolveClass)
            if (superClass != null) {
                append(" : ${scopeResolver.computeName(superClass)}()")
            } else {
                append(" : KotlinIndexAccess")
            }
            definition.interfaces.forEach { interfaceId ->
                scopeResolver.resolveInterface(interfaceId)?.let { append(", ${scopeResolver.computeName(it)}") }
            }
        }
        contents.braces {
            definition.fields.forEachIndexed { fieldIndex, field ->
                translateField(field, "f$fieldIndex", if (definition.kind == ScenarioClassKind.Sealed) "null" else "f$fieldIndex", false, atomic = true)
            }
            translateClassLifecycle(definition.lifecycle)
            contents.line("${if (definition.kind == ScenarioClassKind.Sealed) "override open" else "override"} fun loadKotlinField(index: Int): Any?")
            contents.braces {
                if (definition.fields.isEmpty()) {
                    contents.lineEnd("return null")
                } else {
                    contents.line("return when (index % ${definition.fields.size})")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, _ ->
                            contents.lineEnd("$fieldIndex -> f$fieldIndex")
                        }
                        contents.lineEnd("else -> null")
                    }
                }
            }
            contents.lineEnd()
            contents.line("${if (definition.kind == ScenarioClassKind.Sealed) "override open" else "override"} fun storeKotlinField(index: Int, value: Any?)")
            contents.braces {
                if (definition.fields.isNotEmpty()) {
                    contents.line("when (index % ${definition.fields.size})")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, field ->
                            val assignment = when (field) {
                                is ScenarioField.StrongRef, is ScenarioField.WeakRef -> "f$fieldIndex = value"
                                is ScenarioField.TypedStrongRef -> "f$fieldIndex = value as? ${renderKotlinType(field.type)}"
                                is ScenarioField.IntValue -> "f$fieldIndex = anyToInt(value)"
                                is ScenarioField.BooleanValue -> "f$fieldIndex = anyToBoolean(value)"
                                is ScenarioField.ObjectArray -> "f$fieldIndex = anyToArrayBox(value, ${field.size})"
                            }
                            contents.lineEnd("$fieldIndex -> $assignment")
                        }
                    }
                }
            }
            definition.dispatchFieldId?.takeIf { it in definition.fields.indices }?.let { fieldId ->
                contents.lineEnd("override fun dispatchPayload(): Any? = f${fieldId}")
            }
            if (definition.kind == ScenarioClassKind.Sealed) {
                contents.lineEnd("open fun sealedPayload(): Any? = null")
            }
            definition.sealedPayloadFieldId?.takeIf { it in definition.fields.indices }?.let { fieldId ->
                contents.lineEnd("override fun sealedPayload(): Any? = f${fieldId}")
            }
            definition.outerCaptureFieldId?.let { fieldId ->
                contents.lineEnd("fun outerPayload(): Any? = this@${scopeResolver.resolveClass(definition.nestedInClassId ?: -1)?.let(scopeResolver::computeSimpleName) ?: "Class0"}.loadKotlinField($fieldId)")
            }
            scopeResolver.nestedClassesOf(definition).forEach { nestedClass ->
                translateClassDefinition(scopeResolver.computeSimpleName(nestedClass).removePrefix("Class").toInt(), nestedClass, nested = true)
            }
        }
    }

    private fun translateInterfaceDefinition(index: Int) {
        contents.line("interface Interface$index")
        contents.braces {
            contents.lineEnd("fun dispatchPayload(): Any?")
        }
        contents.lineEnd()
    }

    private fun translateSingletonObjectDefinition(index: Int, definition: ScenarioDefinition.SingletonObject) {
        contents.line("object Object$index : KotlinIndexAccess")
        contents.braces {
            definition.fields.forEachIndexed { fieldIndex, field ->
                translateField(field, "f$fieldIndex", "null", false, atomic = true)
            }
            contents.line("override fun loadKotlinField(index: Int): Any?")
            contents.braces {
                if (definition.fields.isEmpty()) {
                    contents.lineEnd("return null")
                } else {
                    contents.line("return when (index % ${definition.fields.size})")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, _ ->
                            contents.lineEnd("$fieldIndex -> f$fieldIndex")
                        }
                        contents.lineEnd("else -> null")
                    }
                }
            }
            contents.lineEnd()
            contents.line("override fun storeKotlinField(index: Int, value: Any?)")
            contents.braces {
                if (definition.fields.isNotEmpty()) {
                    contents.line("when (index % ${definition.fields.size})")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, field ->
                            val assignment = when (field) {
                                is ScenarioField.StrongRef, is ScenarioField.WeakRef -> "f$fieldIndex = value"
                                is ScenarioField.TypedStrongRef -> "f$fieldIndex = value as? ${renderKotlinType(field.type)}"
                                is ScenarioField.IntValue -> "f$fieldIndex = anyToInt(value)"
                                is ScenarioField.BooleanValue -> "f$fieldIndex = anyToBoolean(value)"
                                is ScenarioField.ObjectArray -> "f$fieldIndex = anyToArrayBox(value, ${field.size})"
                            }
                            contents.lineEnd("$fieldIndex -> $assignment")
                        }
                    }
                }
            }
        }
        contents.lineEnd()
    }

    private fun translateClassLifecycle(lifecycle: ScenarioClassLifecycle) {
        when (lifecycle) {
            ScenarioClassLifecycle.None -> return
            is ScenarioClassLifecycle.Finalizer -> {
                contents.line("private val lifecycleCleaner = createCleaner(Unit)")
                contents.braces {
                    PureKotlinScenarioBodyTranslationContext(
                        ScenarioLocalScopeResolver(scopeResolver, emptyList()),
                        contents,
                    ).translateBody(lifecycle.body)
                }
            }
        }
    }

    private fun translateFunctionDefinition(index: Int, definition: ScenarioDefinition.Function) {
        contents.lineEnd()
        contents.line {
            append("fun fun$index")
            parens {
                arg("localsCount: Int")
                definition.parameters.forEachIndexed { parameterIndex, _: ScenarioParameter ->
                    arg("l$parameterIndex: Any?")
                }
            }
            append(": ${renderKotlinType(definition.returnType)}")
        }
        contents.braces {
            contents.line("try")
            contents.braces {
                bodyContext(definition.parameters) {
                    translateFunctionBody(definition.body)
                }
            }
            contents.line("catch (control: FuzzControlException)")
            contents.braces {
                contents.lineEnd("return control.payload as? ${renderKotlinType(definition.returnType)}")
            }
        }
    }

    private fun translateMainFunction() {
        contents.lineEnd()
        contents.line("private fun mainBodyImpl(localsCount: Int): Any?")
        contents.braces {
            contents.line("try")
            contents.braces {
                bodyContext(emptyList()) {
                    translateBody(scenarioProgram.mainBody)
                }
                contents.lineEnd("return null")
            }
            contents.line("catch (_: FuzzControlException)")
            contents.braces {
                contents.lineEnd("return null")
            }
        }
        contents.lineEnd()
        contents.line("fun main()")
        contents.braces {
            contents.line("repeat(${config.mainLoopRepeatCount})")
            contents.braces {
                contents.lineEnd("if (shouldTerminate()) return")
                bodyContext(emptyList()) {
                    contents.lineEnd("val localsCount = 0")
                    contents.lineEnd {
                        expressionContext {
                            translateFunctionCallExpressionImpl("mainBodyImpl", scenarioProgram.mainBody.estimateLocalsCount(), emptyList())
                        }
                    }
                }
            }
            contents.lineEnd("terminationRequest.store(true)")
            contents.lineEnd("performGC()")
        }
    }

    private inline fun bodyContext(initialScope: List<ScenarioParameter>, block: PureKotlinScenarioBodyTranslationContext.() -> Unit) =
        PureKotlinScenarioBodyTranslationContext(
            ScenarioLocalScopeResolver(scopeResolver, initialScope),
            contents,
        ).run(block)

    private fun renderKotlinType(type: ScenarioType): String = when (type) {
        ScenarioType.AnyRef -> "Any?"
        is ScenarioType.InterfaceRef -> scopeResolver.resolveInterface(type.interfaceId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
        is ScenarioType.ClassRef -> scopeResolver.resolveClass(type.classId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
        is ScenarioType.SingletonRef -> scopeResolver.resolveSingleton(type.singletonId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
    }
}

private class ScenarioDefinitionLocal(val id: ScenarioEntityId, val mutable: Boolean)

private class ScenarioGlobalScopeResolver(
    private val program: ScenarioProgram,
) {
    private val definitions = program.definitions

    private fun computeEntityId(definition: ScenarioDefinition): ScenarioEntityId {
        val index = definitions.indexOfFirst { it === definition }
        check(index != -1) { "Definition of $definition is not found" }
        return index
    }

    fun computeName(definition: ScenarioDefinition.Function): String = "fun${computeEntityId(definition)}"
    fun computeSimpleName(definition: ScenarioDefinition.Class): String = "Class${computeEntityId(definition)}"
    fun computeName(definition: ScenarioDefinition.Class): String {
        val simpleName = computeSimpleName(definition)
        val outer = definition.nestedInClassId?.let(::resolveClass)
        return if (outer == null) simpleName else "${computeName(outer)}.$simpleName"
    }
    fun computeName(definition: ScenarioDefinition.Global): String = "g${computeEntityId(definition)}"
    fun computeName(definition: ScenarioDefinition.Interface): String = "Interface${computeEntityId(definition)}"
    fun computeName(definition: ScenarioDefinition.SingletonObject): String = "Object${computeEntityId(definition)}"

    private fun isAvailable(definition: ScenarioDefinition): Boolean = definition.targetLanguage == ScenarioTargetLanguage.Kotlin

    fun resolveFunction(id: ScenarioEntityId): ScenarioDefinition.Function? =
        definitions.filterIsInstance<ScenarioDefinition.Function>().filter(::isAvailable).findEntity(id)

    fun resolveClass(id: ScenarioEntityId): ScenarioDefinition.Class? =
        definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).findEntity(id)

    fun resolveGlobal(id: ScenarioEntityId): ScenarioDefinition.Global? =
        definitions.filterIsInstance<ScenarioDefinition.Global>().filter(::isAvailable).findEntity(id)

    fun resolveInterface(id: ScenarioEntityId): ScenarioDefinition.Interface? =
        definitions.filterIsInstance<ScenarioDefinition.Interface>().filter(::isAvailable).findEntity(id)

    fun resolveSingleton(id: ScenarioEntityId): ScenarioDefinition.SingletonObject? =
        definitions.filterIsInstance<ScenarioDefinition.SingletonObject>().filter(::isAvailable).findEntity(id)

    fun nestedClassesOf(definition: ScenarioDefinition.Class): List<ScenarioDefinition.Class> {
        val classId = definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).indexOfFirst { it === definition }
        if (classId == -1) return emptyList()
        return definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).filter { it.nestedInClassId == classId }
    }

    fun sealedSubclassesOf(definition: ScenarioDefinition.Class): List<ScenarioDefinition.Class> {
        val classId = definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).indexOfFirst { it === definition }
        if (classId == -1) return emptyList()
        return definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).filter { it.superClassId == classId }
    }
}

private class ScenarioLocalScopeResolver(
    private val globalScopeResolver: ScenarioGlobalScopeResolver,
    initialScope: List<ScenarioParameter>,
) {
    private val locals = mutableListOf<ScenarioDefinitionLocal>().apply {
        initialScope.mapIndexedTo(this) { index, _ -> ScenarioDefinitionLocal(index, mutable = false) }
    }
    private var nextAutoLocalId: Int = locals.size
    private var nextSyntheticId: Int = 0

    fun computeName(definition: ScenarioDefinition.Function): String = globalScopeResolver.computeName(definition)
    fun computeName(definition: ScenarioDefinition.Class): String = globalScopeResolver.computeName(definition)
    fun computeSimpleName(definition: ScenarioDefinition.Class): String = globalScopeResolver.computeSimpleName(definition)
    fun computeName(definition: ScenarioDefinition.Global): String = globalScopeResolver.computeName(definition)
    fun computeName(definition: ScenarioDefinition.Interface): String = globalScopeResolver.computeName(definition)
    fun computeName(definition: ScenarioDefinition.SingletonObject): String = globalScopeResolver.computeName(definition)
    fun computeName(definition: ScenarioDefinitionLocal): String = "l${definition.id}"

    fun resolveFunction(id: ScenarioEntityId): ScenarioDefinition.Function? = globalScopeResolver.resolveFunction(id)
    fun resolveClass(id: ScenarioEntityId): ScenarioDefinition.Class? = globalScopeResolver.resolveClass(id)
    fun resolveGlobal(id: ScenarioEntityId): ScenarioDefinition.Global? = globalScopeResolver.resolveGlobal(id)
    fun resolveInterface(id: ScenarioEntityId): ScenarioDefinition.Interface? = globalScopeResolver.resolveInterface(id)
    fun resolveSingleton(id: ScenarioEntityId): ScenarioDefinition.SingletonObject? = globalScopeResolver.resolveSingleton(id)
    fun nestedClassesOf(definition: ScenarioDefinition.Class): List<ScenarioDefinition.Class> = globalScopeResolver.nestedClassesOf(definition)
    fun sealedSubclassesOf(definition: ScenarioDefinition.Class): List<ScenarioDefinition.Class> = globalScopeResolver.sealedSubclassesOf(definition)
    fun resolveLocal(id: ScenarioEntityId, onlyMutable: Boolean = false): ScenarioDefinitionLocal? =
        locals.filter { if (onlyMutable) it.mutable else true }.findEntity(id)

    fun declareSpecificLocal(id: ScenarioEntityId, mutable: Boolean = true, block: (String, Boolean) -> Unit) {
        val isNewDeclaration = locals.none { it.id == id }
        val local = ScenarioDefinitionLocal(id, mutable)
        block(computeName(local), isNewDeclaration)
        registerLocal(id, mutable)
    }

    fun allocateGeneratedLocal(block: (String) -> Unit) {
        val id = nextAutoLocalId++
        val local = ScenarioDefinitionLocal(id, mutable = true)
        block(computeName(local))
        locals.add(local)
    }

    fun allocateGeneratedLocalName(): String {
        val id = nextAutoLocalId++
        val local = ScenarioDefinitionLocal(id, mutable = true)
        locals.add(local)
        return computeName(local)
    }

    fun allocateSyntheticName(prefix: String): String = "${prefix}${nextSyntheticId++}"

    fun fork(): ScenarioLocalScopeResolver = ScenarioLocalScopeResolver(globalScopeResolver, locals.toMutableList(), nextAutoLocalId, nextSyntheticId)

    fun forkWithSpecificLocal(id: ScenarioEntityId, mutable: Boolean = true): ScenarioLocalScopeResolver =
        fork().also { it.registerLocal(id, mutable) }

    fun computeLocalName(id: ScenarioEntityId): String = computeName(ScenarioDefinitionLocal(id, mutable = true))

    private fun registerLocal(id: ScenarioEntityId, mutable: Boolean) {
        locals.removeAll { it.id == id }
        locals.add(ScenarioDefinitionLocal(id, mutable))
        nextAutoLocalId = maxOf(nextAutoLocalId, id + 1)
    }

    private constructor(
        globalScopeResolver: ScenarioGlobalScopeResolver,
        locals: MutableList<ScenarioDefinitionLocal>,
        nextAutoLocalId: Int,
        nextSyntheticId: Int,
    ) : this(globalScopeResolver, emptyList()) {
        this.locals.clear()
        this.locals.addAll(locals)
        this.nextAutoLocalId = nextAutoLocalId
        this.nextSyntheticId = nextSyntheticId
    }
}

private class PureKotlinScenarioBodyTranslationContext(
    private val scopeResolver: ScenarioLocalScopeResolver,
    private val contents: OutputFileBuilder,
) {
    private fun OutputFileBuilder.lineWithSpecificLocal(
        localId: ScenarioEntityId,
        type: String = "Any?",
        block: LineBuilder.() -> Unit,
    ) = lineEnd {
        scopeResolver.declareSpecificLocal(localId) { name, isNewDeclaration ->
            if (isNewDeclaration) {
                append("var $name: $type = ")
            } else {
                append("$name = ")
            }
            block()
        }
    }

    private fun OutputFileBuilder.lineWithGeneratedLocal(block: LineBuilder.() -> Unit) = lineEnd {
        scopeResolver.allocateGeneratedLocal { name ->
            append("var $name: Any? = ")
            block()
        }
    }

    fun translateBody(body: ScenarioBody) {
        var index = 0
        while (index < body.statements.size) {
            val statements = body.statements
            translateWeakDeadCapsuleSequence(statements, index)?.let {
                index += it
                continue
            }
            translateRootMigrationSequence(statements, index)?.let {
                index += it
                continue
            }
            translateReachabilityConsistencySequence(statements, index)?.let {
                index += it
                continue
            }
            val statement = statements[index]
            if (translateWeakRefLifecycleBlock(statement)) {
                index++
                continue
            }
            when (statement) {
                is ScenarioOp.CreateObject -> translateCreateObject(statement)
                is ScenarioOp.AllocationBurst -> translateAllocationBurst(statement)
                is ScenarioOp.Observe -> translateObserve(statement)
                is ScenarioOp.ForeignRoundTrip -> translateForeignRoundTrip(statement)
                is ScenarioOp.CreateReachabilityObservation -> translateCreateReachabilityObservation(statement)
                is ScenarioOp.CheckReachabilityObservation -> translateCheckReachabilityObservation(statement)
                is ScenarioOp.CheckReachability -> translateCheckReachability(statement)
                is ScenarioOp.Store -> translateStore(statement)
                is ScenarioOp.Clear -> translateClear(statement)
                is ScenarioOp.StoreBatch -> translateStoreBatch(statement)
                is ScenarioOp.CallFunction -> translateCallFunction(statement)
                is ScenarioOp.InterfaceDispatch -> translateInterfaceDispatch(statement)
                is ScenarioOp.SealedDispatch -> translateSealedDispatch(statement)
                is ScenarioOp.SingletonAccess -> translateSingletonAccess(statement)
                is ScenarioOp.CreateInnerObject -> translateCreateInnerObject(statement)
                is ScenarioOp.OuterDispatch -> translateOuterDispatch(statement)
                is ScenarioOp.SpawnFunction -> translateSpawnFunction(statement)
                is ScenarioOp.Spawn -> translateSpawnBody(statement)
                is ScenarioOp.SpawnWithResult -> translateSpawnWithResult(statement)
                is ScenarioOp.CompareAndSet -> translateCompareAndSet(statement)
                is ScenarioOp.Block -> translateBlock(statement)
                is ScenarioOp.ScopedRoot -> translateScopedRoot(statement)
                is ScenarioOp.If -> translateIf(statement)
                is ScenarioOp.TryFinally -> translateTryFinally(statement)
                is ScenarioOp.PerformGc -> translatePerformGc()
                is ScenarioOp.GcEpoch -> translateGcEpoch(statement)
                is ScenarioOp.Signal -> translateSignal(statement)
                is ScenarioOp.Wait -> translateWait(statement)
                ScenarioOp.Yield -> translateYield()
                is ScenarioOp.Return -> translateReturn(statement.value)
                is ScenarioOp.Throw -> translateThrow(statement.value)
            }
            index++
        }
    }

    private fun translateWeakDeadCapsuleSequence(statements: List<ScenarioOp>, startIndex: Int): Int? {
        val block = statements.getOrNull(startIndex) as? ScenarioOp.Block ?: return null
        val gc = statements.getOrNull(startIndex + 1) as? ScenarioOp.PerformGc ?: return null
        val deadCheck = statements.getOrNull(startIndex + 2) as? ScenarioOp.CheckReachabilityObservation ?: return null
        if (gc.domain != ScenarioDomain.Kotlin) return null
        val blockStatements = block.body
        if (blockStatements.size != 2) return null
        val createPayload = blockStatements[0] as? ScenarioOp.CreateObject ?: return null
        val createObservation = blockStatements[1] as? ScenarioOp.CreateReachabilityObservation ?: return null
        val observationValue = createObservation.value as? ScenarioValue.LocalRef ?: return null

        if (createObservation.kind != ScenarioReachabilityObservationKind.Weak) return null
        if (observationValue.localId != createPayload.localId || observationValue.path.accessors.isNotEmpty()) return null
        if (deadCheck.observationId != createObservation.observationId || deadCheck.expectation != ScenarioReachabilityExpectation.Dead) return null

        val probeName = scopeResolver.allocateSyntheticName("_weakDeadProbe")
        contents.lineEnd {
            append("val $probeName = prepareWeakDeadObservationProbe(")
            append("{ ")
            expressionContext {
                translateConstructorCallExpression(createPayload.classId, createPayload.args)
            }
            append(" }, ")
            append("{ value -> createReachabilityObservation(value, ReachabilityObservationKind.WEAK) }")
            append(")")
        }
        contents.lineEnd("o${createObservation.observationId} = $probeName.observation")
        translatePerformGc()
        contents.lineEnd("assertReachability(${renderKotlinStringLiteral(deadCheck.label)}, ReachabilityExpectation.DEAD, $probeName.loadObserved())")
        return 3
    }

    private fun translateReachabilityConsistencySequence(statements: List<ScenarioOp>, startIndex: Int): Int? {
        val block = statements.getOrNull(startIndex) as? ScenarioOp.Block ?: return null
        val firstGc = statements.getOrNull(startIndex + 1) as? ScenarioOp.PerformGc ?: return null
        val aliveCheck = statements.getOrNull(startIndex + 2) as? ScenarioOp.CheckReachabilityObservation ?: return null
        val clearPayload = statements.getOrNull(startIndex + 3) as? ScenarioOp.Store ?: return null
        val secondGc = statements.getOrNull(startIndex + 4) as? ScenarioOp.PerformGc ?: return null
        val deadCheck = statements.getOrNull(startIndex + 5) as? ScenarioOp.CheckReachabilityObservation ?: return null
        val trailingObserve = statements.getOrNull(startIndex + 6) as? ScenarioOp.Observe
        if (firstGc.domain != ScenarioDomain.Kotlin || secondGc.domain != ScenarioDomain.Kotlin) return null
        val blockStatements = block.body
        if (blockStatements.size != 5) return null
        val createOwner = blockStatements[0] as? ScenarioOp.CreateObject ?: return null
        val createPayload = blockStatements[1] as? ScenarioOp.CreateObject ?: return null
        val attachPayload = blockStatements[2] as? ScenarioOp.Store ?: return null
        val publishRoot = blockStatements[3] as? ScenarioOp.Store ?: return null
        val createObservation = blockStatements[4] as? ScenarioOp.CreateReachabilityObservation ?: return null

        val attachLocation = (attachPayload.location as? ScenarioLocation.Local)?.takeIf { it.path.accessors.isNotEmpty() } ?: return null
        val attachedPayload = attachPayload.value as? ScenarioValue.LocalRef ?: return null
        val rootLocation = (publishRoot.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return null
        val publishedOwner = publishRoot.value as? ScenarioValue.LocalRef ?: return null
        val observationValue = createObservation.value as? ScenarioValue.GlobalRef ?: return null
        val clearLocation = (clearPayload.location as? ScenarioLocation.Global)?.takeIf { it.path.samePathAs(attachLocation.path) } ?: return null

        if (attachPayload.referenceKind != org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Strong) return null
        if (createObservation.kind != ScenarioReachabilityObservationKind.Weak) return null
        if (aliveCheck.observationId != createObservation.observationId || aliveCheck.expectation != ScenarioReachabilityExpectation.Alive) return null
        if (deadCheck.observationId != createObservation.observationId || deadCheck.expectation != ScenarioReachabilityExpectation.Dead) return null
        if (clearPayload.value != ScenarioValue.NullValue) return null
        if (attachLocation.localId != createOwner.localId) return null
        if (attachedPayload.localId != createPayload.localId || attachedPayload.path.accessors.isNotEmpty()) return null
        if (publishedOwner.localId != createOwner.localId || publishedOwner.path.accessors.isNotEmpty()) return null
        if (observationValue.globalId != rootLocation.globalId || !observationValue.path.samePathAs(attachLocation.path)) return null
        if (clearLocation.globalId != rootLocation.globalId) return null
        if (trailingObserve != null && !trailingObserve.value.isGlobalRef(rootLocation.globalId, attachLocation.path)) return null

        val rootName = scopeResolver.globalName(rootLocation.globalId) ?: return null
        val probeName = scopeResolver.allocateSyntheticName("_reachabilityProbe")
        contents.lineEnd {
            append("val $probeName = prepareReachabilityConsistencyProbe(")
            append("{ ")
            expressionContext {
                translateConstructorCallExpression(createOwner.classId, createOwner.args)
            }
            append(" }, ")
            append("{ ")
            expressionContext {
                translateConstructorCallExpression(createPayload.classId, createPayload.args)
            }
            append(" }, ")
            append("{ owner, payload -> ")
            append("owner")
            attachLocation.path.accessors.dropLast(1).forEach { append("?.loadField($it)") }
            val terminalAccessor = attachLocation.path.accessors.last()
            append("?.storeField($terminalAccessor, payload) }, ")
            append("{ owner -> $rootName = owner }, ")
            append("{ owner -> createReachabilityObservation(")
            append("owner")
            observationValue.path.accessors.forEach { append("?.loadField($it)") }
            append(", ReachabilityObservationKind.WEAK) }, ")
            append("{ owner -> ")
            append("owner")
            attachLocation.path.accessors.dropLast(1).forEach { append("?.loadField($it)") }
            append("?.storeField($terminalAccessor, null) }, ")
            append("{ owner -> ")
            append("owner")
            observationValue.path.accessors.forEach { append("?.loadField($it)") }
            append(" }")
            append(")")
        }
        contents.lineEnd("o${createObservation.observationId} = $probeName.observation")
        translatePerformGc()
        contents.lineEnd("assertReachability(${renderKotlinStringLiteral(aliveCheck.label)}, ReachabilityExpectation.ALIVE, $probeName.loadObserved())")
        contents.lineEnd("$probeName.clearPayload()")
        translatePerformGc()
        contents.lineEnd("assertReachability(${renderKotlinStringLiteral(deadCheck.label)}, ReachabilityExpectation.DEAD, $probeName.loadObserved())")
        if (trailingObserve != null) {
            contents.lineEnd("val ${scopeResolver.allocateSyntheticName("_observeTmp")}: Any? = $probeName.readPayload()")
            return 7
        }
        return 6
    }

    private fun translateRootMigrationSequence(statements: List<ScenarioOp>, startIndex: Int): Int? {
        val createSourceOwner = statements.getOrNull(startIndex) as? ScenarioOp.CreateObject ?: return null
        val createPayload = statements.getOrNull(startIndex + 1) as? ScenarioOp.CreateObject ?: return null
        val createTargetOwner = statements.getOrNull(startIndex + 2) as? ScenarioOp.CreateObject ?: return null
        val attachSource = statements.getOrNull(startIndex + 3) as? ScenarioOp.Store ?: return null
        val publishRoot = statements.getOrNull(startIndex + 4) as? ScenarioOp.Store ?: return null
        val migrateTarget = statements.getOrNull(startIndex + 5) as? ScenarioOp.Store ?: return null
        val clearSource = statements.getOrNull(startIndex + 6) as? ScenarioOp.Store ?: return null
        val clearRoot = statements.getOrNull(startIndex + 7) as? ScenarioOp.Store ?: return null
        val createObservation = statements.getOrNull(startIndex + 8) as? ScenarioOp.CreateReachabilityObservation ?: return null
        val gc = statements.getOrNull(startIndex + 9) as? ScenarioOp.PerformGc ?: return null
        val aliveCheck = statements.getOrNull(startIndex + 10) as? ScenarioOp.CheckReachabilityObservation ?: return null
        val trailingObserve = statements.getOrNull(startIndex + 11) as? ScenarioOp.Observe

        val attachLocation = (attachSource.location as? ScenarioLocation.Local)?.takeIf { it.path.accessors.isNotEmpty() } ?: return null
        val attachedPayload = attachSource.value as? ScenarioValue.LocalRef ?: return null
        val rootLocation = (publishRoot.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return null
        val publishedOwner = publishRoot.value as? ScenarioValue.LocalRef ?: return null
        val migrateLocation = (migrateTarget.location as? ScenarioLocation.Local)?.takeIf { it.path.accessors.isNotEmpty() } ?: return null
        val migratedValue = migrateTarget.value as? ScenarioValue.GlobalRef ?: return null
        val clearSourceLocation = (clearSource.location as? ScenarioLocation.Local)?.takeIf { it.path.samePathAs(attachLocation.path) } ?: return null
        val clearRootLocation = (clearRoot.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return null
        val observationValue = createObservation.value as? ScenarioValue.LocalRef ?: return null

        if (gc.domain != ScenarioDomain.Kotlin) return null
        if (attachSource.referenceKind != org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Strong) return null
        if (createObservation.kind != ScenarioReachabilityObservationKind.Weak) return null
        if (aliveCheck.observationId != createObservation.observationId || aliveCheck.expectation != ScenarioReachabilityExpectation.Alive) return null
        if (clearSource.value != ScenarioValue.NullValue || clearRoot.value != ScenarioValue.NullValue) return null
        if (attachLocation.localId != createSourceOwner.localId) return null
        if (attachedPayload.localId != createPayload.localId || attachedPayload.path.accessors.isNotEmpty()) return null
        if (publishedOwner.localId != createSourceOwner.localId || publishedOwner.path.accessors.isNotEmpty()) return null
        if (migrateLocation.localId != createTargetOwner.localId) return null
        if (migratedValue.globalId != rootLocation.globalId || !migratedValue.path.samePathAs(attachLocation.path)) return null
        if (clearSourceLocation.localId != createSourceOwner.localId) return null
        if (clearRootLocation.globalId != rootLocation.globalId) return null
        if (observationValue.localId != createTargetOwner.localId || !observationValue.path.samePathAs(migrateLocation.path)) return null
        if (trailingObserve != null && !trailingObserve.value.isLocalRef(createTargetOwner.localId, migrateLocation.path)) return null

        val targetAccessPrefix = migrateLocation.path.accessors.dropLast(1)
        val targetTerminalAccessor = migrateLocation.path.accessors.last()
        val sourceTerminalAccessor = attachLocation.path.accessors.last()
        val rootName = scopeResolver.globalName(rootLocation.globalId) ?: return null
        val probeName = scopeResolver.allocateSyntheticName("_rootMigrationProbe")
        contents.lineEnd {
            append("val $probeName = prepareRootMigrationProbe(")
            append("{ ")
            expressionContext { translateConstructorCallExpression(createSourceOwner.classId, createSourceOwner.args) }
            append(" }, ")
            append("{ ")
            expressionContext { translateConstructorCallExpression(createPayload.classId, createPayload.args) }
            append(" }, ")
            append("{ ")
            expressionContext { translateConstructorCallExpression(createTargetOwner.classId, createTargetOwner.args) }
            append(" }, ")
            append("{ owner, payload -> owner")
            attachLocation.path.accessors.dropLast(1).forEach { append("?.loadField($it)") }
            append("?.storeField($sourceTerminalAccessor, payload) }, ")
            append("{ owner -> $rootName = owner }, ")
            append("{ target, owner -> target")
            targetAccessPrefix.forEach { append("?.loadField($it)") }
            append("?.storeField($targetTerminalAccessor, owner")
            migratedValue.path.accessors.forEach { append("?.loadField($it)") }
            append(") }, ")
            append("{ owner -> owner")
            attachLocation.path.accessors.dropLast(1).forEach { append("?.loadField($it)") }
            append("?.storeField($sourceTerminalAccessor, null) }, ")
            append("{ $rootName = null }, ")
            append("{ target -> createReachabilityObservation(target")
            observationValue.path.accessors.forEach { append("?.loadField($it)") }
            append(", ReachabilityObservationKind.WEAK) }, ")
            append("{ target -> target")
            observationValue.path.accessors.forEach { append("?.loadField($it)") }
            append(" }")
            append(")")
        }
        contents.lineEnd("o${createObservation.observationId} = $probeName.observation")
        translatePerformGc()
        contents.lineEnd("assertReachability(${renderKotlinStringLiteral(aliveCheck.label)}, ReachabilityExpectation.ALIVE, $probeName.loadObserved())")
        if (trailingObserve != null) {
            contents.lineEnd("val ${scopeResolver.allocateSyntheticName("_observeTmp")}: Any? = $probeName.readPayload()")
            return 12
        }
        return 11
    }

    private fun translateWeakRefLifecycleBlock(statement: ScenarioOp): Boolean {
        val block = statement as? ScenarioOp.Block ?: return false
        val statements = block.body
        if (statements.size != 5) return false
        val create = statements[0] as? ScenarioOp.CreateObject ?: return false
        val publishStrong = statements[1] as? ScenarioOp.Store ?: return false
        val createObservation = statements[2] as? ScenarioOp.CreateReachabilityObservation ?: return false
        val publishWeak = statements[3] as? ScenarioOp.Store ?: return false
        val clearStrong = statements[4] as? ScenarioOp.Store ?: return false

        val strongGlobal = (publishStrong.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return false
        val weakGlobal = (publishWeak.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return false
        val clearedStrongGlobal = (clearStrong.location as? ScenarioLocation.Global)?.takeIf { it.path.accessors.isEmpty() } ?: return false
        val publishedLocal = publishStrong.value as? ScenarioValue.LocalRef ?: return false
        val weakSource = publishWeak.value as? ScenarioValue.GlobalRef ?: return false
        val observationSource = createObservation.value as? ScenarioValue.GlobalRef ?: return false

        if (publishStrong.referenceKind != org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Strong) return false
        if (publishWeak.referenceKind != org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Weak) return false
        if (createObservation.kind != ScenarioReachabilityObservationKind.Weak) return false
        if (clearStrong.value != ScenarioValue.NullValue) return false
        if (create.localId != publishedLocal.localId || publishedLocal.path.accessors.isNotEmpty()) return false
        if (strongGlobal.globalId != observationSource.globalId || observationSource.path.accessors.isNotEmpty()) return false
        if (strongGlobal.globalId != weakSource.globalId || weakSource.path.accessors.isNotEmpty()) return false
        if (strongGlobal.globalId != clearedStrongGlobal.globalId) return false

        val strongGlobalName = scopeResolver.globalName(strongGlobal.globalId) ?: return false
        val weakGlobalName = scopeResolver.globalName(weakGlobal.globalId) ?: return false
        contents.lineEnd {
            append("prepareWeakReachabilityProbe(")
            append("{ ")
            expressionContext {
                translateConstructorCallExpression(create.classId, create.args)
            }
            append(" }, ")
            append("{ value -> $strongGlobalName = value }, ")
            append("{ value -> o${createObservation.observationId} = createReachabilityObservation(value, ReachabilityObservationKind.WEAK) }, ")
            append("{ value -> $weakGlobalName = value }")
            append(")")
        }
        return true
    }

    fun translateFunctionBody(body: ScenarioBodyWithReturn) {
        translateBody(body.body)
        if (!body.body.endsWithTerminalStatement()) {
            translateReturn(body.returnValue)
        }
    }

    private fun translateCreateObject(statement: ScenarioOp.CreateObject) {
        contents.lineWithSpecificLocal(statement.localId, renderKotlinType(statement.declaredType)) {
            expressionContext {
                translateConstructorCallExpression(statement.classId, statement.args)
            }
            if (statement.declaredType != ScenarioType.AnyRef) {
                append(" as? ${renderKotlinType(statement.declaredType)}")
            }
        }
    }

    private fun translateInterfaceDispatch(statement: ScenarioOp.InterfaceDispatch) {
        val interfaceDefinition = scopeResolver.resolveInterface(statement.interfaceId) ?: return
        contents.lineWithSpecificLocal(statement.localId) {
            append("(")
            expressionContext { translateValue(statement.receiver) }
            append(" as? ${scopeResolver.computeName(interfaceDefinition)})?.dispatchPayload()")
        }
    }

    private fun translateSealedDispatch(statement: ScenarioOp.SealedDispatch) {
        val sealedDefinition = scopeResolver.resolveClass(statement.sealedClassId) ?: return
        val subclasses = scopeResolver.sealedSubclassesOf(sealedDefinition)
        if (subclasses.isEmpty()) return
        contents.lineWithSpecificLocal(statement.localId) {
            append("when (val sealedReceiver = ")
            expressionContext { translateValue(statement.receiver) }
            append(" as? ${scopeResolver.computeName(sealedDefinition)}) { ")
            subclasses.forEach { subclass ->
                append("is ${scopeResolver.computeName(subclass)} -> sealedReceiver.sealedPayload(); ")
            }
            append("else -> null }")
        }
    }

    private fun translateSingletonAccess(statement: ScenarioOp.SingletonAccess) {
        val singletonDefinition = scopeResolver.resolveSingleton(statement.singletonId) ?: return
        contents.lineWithSpecificLocal(statement.localId) {
            append("${scopeResolver.computeName(singletonDefinition)}.loadKotlinField(${statement.fieldId})")
        }
    }

    private fun translateCreateInnerObject(statement: ScenarioOp.CreateInnerObject) {
        val definition = scopeResolver.resolveClass(statement.classId) ?: return
        val outerDefinition = definition.nestedInClassId?.let(scopeResolver::resolveClass) ?: return
        contents.lineWithSpecificLocal(statement.localId, renderKotlinType(statement.declaredType)) {
            append("(")
            expressionContext { translateValue(statement.outer) }
            append(" as? ${scopeResolver.computeName(outerDefinition)})?.${scopeResolver.computeSimpleName(definition)}")
            parens {
                definition.fields.forEachIndexed { index, _ ->
                    arg { expressionContext { translateValue(statement.args.getOrNull(index) ?: ScenarioValue.DefaultValue) } }
                }
            }
            if (statement.declaredType != ScenarioType.AnyRef) {
                append(" as? ${renderKotlinType(statement.declaredType)}")
            }
        }
    }

    private fun translateOuterDispatch(statement: ScenarioOp.OuterDispatch) {
        val definition = scopeResolver.resolveClass(statement.classId) ?: return
        contents.lineWithSpecificLocal(statement.localId) {
            append("(")
            expressionContext { translateValue(statement.receiver) }
            append(" as? ${scopeResolver.computeName(definition)})?.outerPayload()")
        }
    }

    private fun translateAllocationBurst(statement: ScenarioOp.AllocationBurst) {
        contents.line("repeat(${statement.count.coerceAtLeast(1)})")
        contents.braces {
            contents.lineEnd {
                expressionContext {
                    translateConstructorCallExpression(statement.classId, emptyList())
                }
            }
        }
    }

    private fun translateObserve(statement: ScenarioOp.Observe) {
        contents.lineWithGeneratedLocal {
            expressionContext {
                translateValue(statement.value)
            }
        }
    }

    private fun translateCreateReachabilityObservation(statement: ScenarioOp.CreateReachabilityObservation) {
        contents.lineEnd {
            append("o${statement.observationId} = ")
            append("createReachabilityObservation(")
            expressionContext {
                translateValue(statement.value)
            }
            append(", ReachabilityObservationKind.")
            append(statement.kind.toRuntimeEnumName())
            append(")")
        }
    }

    private fun translateCheckReachabilityObservation(statement: ScenarioOp.CheckReachabilityObservation) {
        contents.lineEnd {
            append("assertReachability(")
            append(renderKotlinStringLiteral(statement.label))
            append(", ReachabilityExpectation.")
            append(statement.expectation.toRuntimeEnumName())
            append(", loadReachabilityObservation(o${statement.observationId}))")
        }
    }

    private fun translateCheckReachability(statement: ScenarioOp.CheckReachability) {
        contents.lineEnd {
            append("assertReachability(")
            append(renderKotlinStringLiteral(statement.label))
            append(", ReachabilityExpectation.")
            append(statement.expectation.toRuntimeEnumName())
            append(", ")
            expressionContext {
                translateValue(statement.value)
            }
            append(")")
        }
    }

    private fun translateForeignRoundTrip(statement: ScenarioOp.ForeignRoundTrip) {
        contents.lineEnd {
            append("performForeignRoundTrip(")
            expressionContext {
                translateValue(statement.value)
            }
            append(", ${translatePureKotlinForeignReferenceKind(statement.referenceKind)}")
            append(", ${translatePureKotlinForeignInteractionPattern(statement.pattern)}")
            append(", ${statement.repetitions.coerceAtLeast(1)}")
            append(")")
        }
    }

    private fun translateStore(statement: ScenarioOp.Store) {
        when (val location = statement.location) {
            is ScenarioLocation.Global -> {
                val definition = scopeResolver.resolveGlobal(location.globalId) ?: return
                translateStoreWithPath(scopeResolver.computeName(definition), location.path, statement.value, definition.field)
            }
            is ScenarioLocation.Singleton -> {
                val definition = scopeResolver.resolveSingleton(location.singletonId) ?: return
                translateStoreWithPath(scopeResolver.computeName(definition), location.path, statement.value)
            }
            is ScenarioLocation.Local -> {
                val definition = scopeResolver.resolveLocal(location.localId, onlyMutable = location.path.accessors.isEmpty()) ?: return
                translateStoreWithPath(scopeResolver.computeName(definition), location.path, statement.value)
            }
        }
    }

    private fun translateClear(statement: ScenarioOp.Clear) {
        translateStore(
            ScenarioOp.Store(
                location = statement.location,
                value = ScenarioValue.NullValue,
            )
        )
    }

    private fun translateStoreBatch(statement: ScenarioOp.StoreBatch) {
        statement.stores.forEach(::translateStore)
    }

    private fun translateStoreWithPath(name: String, path: ScenarioPath, from: ScenarioValue, rootField: ScenarioField? = null) {
        val loadAccessors = path.accessors.dropLast(1)
        val storeAccessor = path.accessors.lastOrNull()
        if (storeAccessor != null) {
            contents.lineEnd {
                expressionContext {
                    functionCall {
                        name {
                            append(name)
                            loadAccessors.forEach {
                                append("?.loadField($it)")
                            }
                            append("?.storeField")
                        }
                        arg(storeAccessor.asString)
                        arg {
                            translateValue(from)
                        }
                    }
                }
            }
        } else {
            check(loadAccessors.isEmpty())
            contents.lineEnd {
                append(name)
                append(" = ")
                expressionContext {
                    translateValue(from)
                }
                if (rootField is ScenarioField.TypedStrongRef) {
                    append(" as? ${renderKotlinType(rootField.type)}")
                }
            }
        }
    }

    private fun translateCallFunction(statement: ScenarioOp.CallFunction) {
        contents.lineWithGeneratedLocal {
            expressionContext {
                translateFunctionCallExpression(statement.functionId, statement.args)
            }
        }
    }

    private fun translateSpawnFunction(statement: ScenarioOp.SpawnFunction) {
        contents.line("spawnThread")
        contents.braces {
            contents.lineEnd("val localsCount = 0")
            contents.lineEnd {
                expressionContext {
                    translateFunctionCallExpression(statement.functionId, statement.args)
                }
            }
        }
    }

    private fun translateSpawnBody(statement: ScenarioOp.Spawn) {
        contents.line(if (statement.join) "spawnThreadAndJoin" else "spawnThread")
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.body))
        }
    }

    private fun translateSpawnWithResult(statement: ScenarioOp.SpawnWithResult) {
        scopeResolver.declareSpecificLocal(statement.localId, mutable = true) { name, isNewDeclaration ->
            if (isNewDeclaration) {
                contents.lineEnd {
                    append("var $name: Any? = spawnThreadWithResult")
                    contents.braces {
                        val bodyContext = PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents)
                        bodyContext.translateBody(ScenarioBody(statement.body))
                        contents.lineEnd {
                            expressionContext { translateValue(statement.returnValue) }
                        }
                    }
                }
            }
        }
    }

    private fun translateCompareAndSet(statement: ScenarioOp.CompareAndSet) {
        val location = statement.location as? ScenarioLocation.Global ?: return
        if (location.path.accessors.isNotEmpty()) return
        val definition = scopeResolver.resolveGlobal(location.globalId) ?: return
        if (definition.storage !is ScenarioGlobalStorage.Shared || definition.field !is ScenarioField.StrongRef) return
        val backingName = "${scopeResolver.computeName(definition)}Impl"
        contents.lineEnd {
            append("$backingName.compareAndSet(")
            expressionContext { translateValue(statement.expectedValue) }
            append(", ")
            expressionContext { translateValue(statement.newValue) }
            append(")")
        }
    }

    private fun translateBlock(statement: ScenarioOp.Block) {
        contents.line("run")
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.body))
        }
    }

    private fun translateScopedRoot(statement: ScenarioOp.ScopedRoot) {
        val childScope = scopeResolver.forkWithSpecificLocal(statement.localId)
        contents.line("run")
        contents.braces {
            contents.lineEnd {
                append("var ${childScope.computeLocalName(statement.localId)}: Any? = ")
                expressionContext {
                    translateValue(statement.value)
                }
            }
            PureKotlinScenarioBodyTranslationContext(childScope, contents).translateBody(ScenarioBody(statement.body))
        }
    }

    private fun translateIf(statement: ScenarioOp.If) {
        contents.line {
            append("if (anyToBoolean(")
            expressionContext {
                translateValue(statement.condition)
            }
            append("))")
        }
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.thenBody))
        }
        contents.line("else")
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.elseBody))
        }
    }

    private fun translateTryFinally(statement: ScenarioOp.TryFinally) {
        contents.line("try")
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.body))
        }
        contents.line("finally")
        contents.braces {
            PureKotlinScenarioBodyTranslationContext(scopeResolver.fork(), contents).translateBody(ScenarioBody(statement.finallyBody))
        }
    }

    private fun translatePerformGc() {
        contents.lineEnd("performGC()")
    }

    private fun translateGcEpoch(statement: ScenarioOp.GcEpoch) {
        contents.line("repeat(${statement.count.coerceAtLeast(1)})")
        contents.braces {
            translatePerformGc()
            if (statement.yieldBetween) {
                translateYield()
            }
        }
    }

    private fun translateSignal(statement: ScenarioOp.Signal) {
        contents.lineEnd("signalCheckpoint(${statement.checkpointId})")
    }

    private fun translateWait(statement: ScenarioOp.Wait) {
        contents.lineEnd("waitCheckpoint(${statement.checkpointId})")
    }

    private fun translateYield() {
        contents.lineEnd("yieldCheckpoint()")
    }

    private fun translateReturn(value: ScenarioValue) {
        contents.lineEnd {
            append("return ")
            expressionContext {
                translateValue(value)
            }
        }
    }

    private fun translateThrow(value: ScenarioValue) {
        contents.lineEnd {
            append("throw FuzzControlException(")
            expressionContext {
                translateValue(value)
            }
            append(")")
        }
    }

    private fun ScenarioLocalScopeResolver.globalName(id: ScenarioEntityId): String? =
        resolveGlobal(id)?.let(::computeName)

    private fun renderKotlinType(type: ScenarioType): String = when (type) {
        ScenarioType.AnyRef -> "Any?"
        is ScenarioType.InterfaceRef -> scopeResolver.resolveInterface(type.interfaceId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
        is ScenarioType.ClassRef -> scopeResolver.resolveClass(type.classId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
        is ScenarioType.SingletonRef -> scopeResolver.resolveSingleton(type.singletonId)?.let(scopeResolver::computeName)?.plus("?") ?: "Any?"
    }

    inline fun <R> LineBuilder.expressionContext(block: PureKotlinScenarioExpressionTranslationContext.() -> R): R =
        PureKotlinScenarioExpressionTranslationContext(scopeResolver, this).run(block)
}

private class PureKotlinScenarioExpressionTranslationContext(
    private val scopeResolver: ScenarioLocalScopeResolver,
    private val contents: LineBuilder,
) {
    fun translateValue(value: ScenarioValue) {
        when (value) {
            ScenarioValue.DefaultValue, ScenarioValue.NullValue -> contents.append("null")
            is ScenarioValue.GlobalRef -> {
                val definition = scopeResolver.resolveGlobal(value.globalId)
                if (definition == null) {
                    contents.append("null")
                } else {
                    contents.append(scopeResolver.computeName(definition))
                    value.path.accessors.forEach {
                        contents.append("?.loadField($it)")
                    }
                }
            }
            is ScenarioValue.LocalRef -> {
                val definition = scopeResolver.resolveLocal(value.localId)
                if (definition == null) {
                    contents.append("null")
                } else {
                    contents.append(scopeResolver.computeName(definition))
                    value.path.accessors.forEach {
                        contents.append("?.loadField($it)")
                    }
                }
            }
            is ScenarioValue.SingletonRef -> {
                val definition = scopeResolver.resolveSingleton(value.singletonId)
                if (definition == null) {
                    contents.append("null")
                } else {
                    contents.append(scopeResolver.computeName(definition))
                    value.path.accessors.forEach {
                        contents.append("?.loadField($it)")
                    }
                }
            }
        }
    }

    fun translateConstructorCallExpression(classId: ScenarioEntityId, args: List<ScenarioValue>) {
        val clazz = scopeResolver.resolveClass(classId)
        if (clazz == null || clazz.kind == ScenarioClassKind.Sealed || clazz.nestedInClassId != null) {
            translateValue(ScenarioValue.DefaultValue)
            return
        }
        contents.functionCall {
            name("alloc")
            arg {
                append("{ ")
                contents.functionCall {
                    name(scopeResolver.computeName(clazz))
                    clazz.fields.forEachIndexed { index, _ ->
                        arg {
                            translateValue(args.getOrNull(index) ?: ScenarioValue.DefaultValue)
                        }
                    }
                }
                append(" }")
            }
        }
    }

    fun translateFunctionCallExpressionImpl(functionName: String, functionLocalsCount: Int, args: List<ScenarioValue>) {
        contents.functionCall {
            name("call")
            arg("localsCount")
            arg(functionLocalsCount.toString())
            arg {
                append("{ ")
                append(functionName)
                parens {
                    arg("it")
                    args.forEach {
                        arg {
                            translateValue(it)
                        }
                    }
                }
                append(" }")
            }
        }
    }

    fun translateFunctionCallExpression(functionId: ScenarioEntityId, args: List<ScenarioValue>) {
        val function = scopeResolver.resolveFunction(functionId)
        if (function == null) {
            translateValue(ScenarioValue.DefaultValue)
            return
        }
        translateFunctionCallExpressionImpl(
            scopeResolver.computeName(function),
            function.estimateLocalsCount(),
            function.parameters.mapIndexed { index, _ -> args.getOrNull(index) ?: ScenarioValue.DefaultValue },
        )
    }
}

private fun ScenarioBody.estimateLocalsCount(): Int =
    statements.sumOf {
        when (it) {
            is ScenarioOp.CreateObject -> 1
            is ScenarioOp.Observe -> 1
            is ScenarioOp.ForeignRoundTrip -> 0
            is ScenarioOp.CreateReachabilityObservation -> 0
            is ScenarioOp.CheckReachabilityObservation -> 0
            is ScenarioOp.CheckReachability -> 0
            is ScenarioOp.CallFunction -> 1
            is ScenarioOp.InterfaceDispatch -> 1
            is ScenarioOp.SealedDispatch -> 1
            is ScenarioOp.SingletonAccess -> 1
            is ScenarioOp.CreateInnerObject -> 1
            is ScenarioOp.OuterDispatch -> 1
            is ScenarioOp.AllocationBurst -> 0
            is ScenarioOp.Clear -> 0
            is ScenarioOp.StoreBatch -> 0
            is ScenarioOp.GcEpoch -> 0
            is ScenarioOp.Store -> 0
            is ScenarioOp.SpawnFunction -> 0
            is ScenarioOp.Spawn -> 0
            is ScenarioOp.SpawnWithResult -> 1 + ScenarioBody(it.body).estimateLocalsCount()
            is ScenarioOp.CompareAndSet -> 0
            is ScenarioOp.Signal -> 0
            is ScenarioOp.Wait -> 0
            ScenarioOp.Yield -> 0
            is ScenarioOp.Block -> ScenarioBody(it.body).estimateLocalsCount()
            is ScenarioOp.ScopedRoot -> 1 + ScenarioBody(it.body).estimateLocalsCount()
            is ScenarioOp.If -> maxOf(ScenarioBody(it.thenBody).estimateLocalsCount(), ScenarioBody(it.elseBody).estimateLocalsCount())
            is ScenarioOp.TryFinally -> ScenarioBody(it.body).estimateLocalsCount() + ScenarioBody(it.finallyBody).estimateLocalsCount()
            is ScenarioOp.PerformGc -> 0
            is ScenarioOp.Return -> 0
            is ScenarioOp.Throw -> 0
        }
    }

private fun ScenarioBody.endsWithTerminalStatement(): Boolean = when (val last = statements.lastOrNull()) {
    is ScenarioOp.Return, is ScenarioOp.Throw -> true
    is ScenarioOp.Block -> ScenarioBody(last.body).endsWithTerminalStatement()
    is ScenarioOp.ScopedRoot -> ScenarioBody(last.body).endsWithTerminalStatement()
    is ScenarioOp.If -> ScenarioBody(last.thenBody).endsWithTerminalStatement() && ScenarioBody(last.elseBody).endsWithTerminalStatement()
    is ScenarioOp.TryFinally -> ScenarioBody(last.body).endsWithTerminalStatement() || ScenarioBody(last.finallyBody).endsWithTerminalStatement()
    else -> false
}

private fun ScenarioDefinition.Function.estimateLocalsCount(): Int = parameters.size + body.body.estimateLocalsCount()

private fun ScenarioPath.samePathAs(other: ScenarioPath): Boolean =
    accessors == other.accessors

private fun ScenarioValue.isGlobalRef(globalId: Int, path: ScenarioPath): Boolean =
    this is ScenarioValue.GlobalRef && this.globalId == globalId && this.path.samePathAs(path)

private fun ScenarioValue.isLocalRef(localId: Int, path: ScenarioPath): Boolean =
    this is ScenarioValue.LocalRef && this.localId == localId && this.path.samePathAs(path)

private fun renderPrelude(contents: OutputFileBuilder, config: PureKotlinConfig, hasCInterop: Boolean) {
    contents.apply {
        raw(
            """
        |@file:OptIn(
        |    kotlin.concurrent.atomics.ExperimentalAtomicApi::class,
        |    kotlin.native.runtime.NativeRuntimeApi::class,
        |    kotlin.experimental.ExperimentalNativeApi::class${if (hasCInterop) ",\n        |    kotlinx.cinterop.ExperimentalForeignApi::class" else ""}
        |)
        |
        |import kotlin.concurrent.atomics.AtomicBoolean
        |import kotlin.concurrent.atomics.AtomicArray
        |import kotlin.concurrent.atomics.AtomicInt
        |import kotlin.concurrent.atomics.AtomicReference
        |import kotlin.native.concurrent.ThreadLocal
        |import kotlin.native.concurrent.Worker
        |import kotlin.native.ref.createCleaner
        |import kotlin.native.ref.WeakReference
        |import kotlin.time.TimeSource
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_callback" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_callback_repeated" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_identity" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_callback_wrapped" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_callback_then_identity" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_callback_nested" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_boxed_callback" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_box_identity" else ""}
        |${if (hasCInterop) "import gcfuzz_purekotlin_bridge.bridge_run_boxed_callback_repeated" else ""}
        |${if (hasCInterop) "import kotlinx.cinterop.COpaquePointer" else ""}
        |${if (hasCInterop) "import kotlinx.cinterop.StableRef" else ""}
        |${if (hasCInterop) "import kotlinx.cinterop.asStableRef" else ""}
        |${if (hasCInterop) "import kotlinx.cinterop.staticCFunction" else ""}
        |
        |private class FuzzControlException(val payload: Any?) : RuntimeException()
        |private enum class ReachabilityExpectation { ALIVE, DEAD }
        |${if (hasCInterop) "private enum class ForeignReferenceKind { HANDLE, STRONG, WEAK }" else ""}
        |${if (hasCInterop) "private enum class ForeignInteractionPattern { CALLBACK, REPEATED_CALLBACK, IDENTITY, WRAPPED_CALLBACK, CALLBACK_THEN_IDENTITY, NESTED_CALLBACK, BOXED_CALLBACK, BOXED_IDENTITY, BOXED_REPEATED_CALLBACK }" else ""}
        |
        |interface KotlinIndexAccess {
        |   fun loadKotlinField(index: Int): Any?
        |   fun storeKotlinField(index: Int, value: Any?)
        |}
        |
        |class KotlinArrayBox(size: Int, seed: Any?) : KotlinIndexAccess {
        |    private val values = AtomicArray<Any?>(size.coerceAtLeast(1)) { index -> if (index == 0) seed else null }
        |
        |    override fun loadKotlinField(index: Int): Any? = values.loadAt(index.mod(values.size))
        |
        |    override fun storeKotlinField(index: Int, value: Any?) {
        |        values.storeAt(index.mod(values.size), value)
        |    }
        |}
        |
        |private fun anyToInt(value: Any?): Int = when (value) {
        |    is Int -> value
        |    is Boolean -> if (value) 1 else 0
        |    else -> 0
        |}
        |
        |private fun anyToBoolean(value: Any?): Boolean = when (value) {
        |    is Boolean -> value
        |    is Int -> value != 0
        |    else -> false
        |}
        |
        |private fun anyToArrayBox(value: Any?, size: Int): KotlinArrayBox = when (value) {
        |    is KotlinArrayBox -> value
        |    else -> KotlinArrayBox(size, value)
        |}
        |
        |private fun Any.loadField(index: Int) = when (this) {
        |    is KotlinIndexAccess -> loadKotlinField(index)
        |    else -> null
        |}
        |
        |private fun Any.storeField(index: Int, value: Any?) = when (this) {
        |    is KotlinIndexAccess -> storeKotlinField(index, value)
        |    else -> Unit
        |}
        |
        |object WorkerTerminationProcessor {
        |    private val processor = Worker.start()
        |
        |    fun terminateCurrent() {
        |        val future = Worker.current.requestTermination()
        |        processor.executeAfter(0L) { future.result }
        |    }
        |}
        |
        |private val allowedThreadsCount = AtomicInt(${config.maxThreadCount})
        |private val terminationRequest = AtomicBoolean(false)
        |private val checkpoints = AtomicArray<Int>(64) { 0 }
        |private val startTime = TimeSource.Monotonic.markNow()
        |
        |private fun shouldTerminate(): Boolean {
        |    if (terminationRequest.load()) return true
        |    if (startTime.elapsedNow().inWholeMilliseconds <= ${config.softTimeout.inWholeMilliseconds}L) return false
        |    terminationRequest.store(true)
        |    return true
        |}
        |
        |private fun tryRegisterThread(): Boolean {
        |    while (true) {
        |        val current = allowedThreadsCount.load()
        |        if (current <= 0) return false
        |        if (allowedThreadsCount.compareAndSet(current, current - 1)) return true
        |    }
        |}
        |
        |private fun unregisterThread() {
        |    while (true) {
        |        val current = allowedThreadsCount.load()
        |        if (allowedThreadsCount.compareAndSet(current, current + 1)) return
        |    }
        |}
        |
        |private fun checkpointIndex(id: Int): Int = id.mod(checkpoints.size)
        |
        |private fun signalCheckpoint(id: Int) {
        |    checkpoints.storeAt(checkpointIndex(id), 1)
        |}
        |
        |private fun waitCheckpoint(id: Int) {
        |    repeat(4096) {
        |        if (checkpoints.loadAt(checkpointIndex(id)) != 0) return
        |        if (shouldTerminate()) return
        |        Worker.current.processQueue()
        |    }
        |}
        |
        |private fun yieldCheckpoint() {
        |    Worker.current.processQueue()
        |}
        |
        |private fun spawnThread(block: () -> Unit) {
        |   if (!tryRegisterThread()) return
        |   Worker.start().executeAfter(0L) {
        |       try {
        |           if (shouldTerminate()) return@executeAfter
        |           block()
        |       } catch (_: FuzzControlException) {
        |       } finally {
        |           clearThreadLocalRoots()
        |           unregisterThread()
        |           WorkerTerminationProcessor.terminateCurrent()
        |       }
        |   }
        |}
        |
        |private fun spawnThreadAndJoin(block: () -> Unit) {
        |   if (!tryRegisterThread()) return
        |   val completed = AtomicBoolean(false)
        |   Worker.start().executeAfter(0L) {
        |       try {
        |           if (shouldTerminate()) return@executeAfter
        |           block()
        |       } catch (_: FuzzControlException) {
        |       } finally {
        |           clearThreadLocalRoots()
        |           completed.store(true)
        |           unregisterThread()
        |           WorkerTerminationProcessor.terminateCurrent()
        |       }
        |   }
        |   repeat(4096) {
        |       if (completed.load() || shouldTerminate()) return
        |       Worker.current.processQueue()
        |   }
        |}
        |
        |private fun spawnThreadWithResult(block: () -> Any?): Any? {
        |   if (!tryRegisterThread()) return null
        |   val result = AtomicReference<Any?>(null)
        |   val completed = AtomicBoolean(false)
        |   Worker.start().executeAfter(0L) {
        |       try {
        |           if (shouldTerminate()) return@executeAfter
        |           result.store(block())
        |       } catch (_: FuzzControlException) {
        |       } finally {
        |           clearThreadLocalRoots()
        |           completed.store(true)
        |           unregisterThread()
        |           WorkerTerminationProcessor.terminateCurrent()
        |       }
        |   }
        |   repeat(4096) {
        |       if (completed.load()) return result.load()
        |       if (shouldTerminate()) return null
        |       Worker.current.processQueue()
        |   }
        |   return if (completed.load()) result.load() else null
        |}
        |
        |private inline fun call(localsCount: Int, blockLocalsCount: Int, block: (Int) -> Any?): Any? {
        |    if (shouldTerminate()) return null
        |    val nextLocalsCount = localsCount + blockLocalsCount
        |    if (nextLocalsCount > ${config.maximumStackDepth}) {
        |        return null
        |    }
        |    return block(nextLocalsCount)
        |}
        |
        |private enum class ReachabilityObservationKind { WEAK }
        |
        |fun performGC() {
        |    kotlin.native.runtime.GC.collect()
        |}
        |
        |private fun createReachabilityObservation(value: Any?, kind: ReachabilityObservationKind): WeakReference<Any>? =
        |    when (kind) {
        |        ReachabilityObservationKind.WEAK -> value?.let { WeakReference(it) }
        |    }
        |
        |private fun loadReachabilityObservation(observation: WeakReference<Any>?): Any? = observation?.value
        |
|private fun prepareWeakReachabilityProbe(
|    factory: () -> Any?,
|    publishStrong: (Any?) -> Unit,
|    publishObservation: (Any?) -> Unit,
|    publishWeak: (Any?) -> Unit,
|) {
|    val payload = factory()
|    publishStrong(payload)
|    publishObservation(payload)
|    publishWeak(payload)
|    publishStrong(null)
|}
|
|private class WeakDeadObservationProbe(
|    val observation: WeakReference<Any>?,
|) {
|    fun loadObserved(): Any? = loadReachabilityObservation(observation)
|}
|
|private fun prepareWeakDeadObservationProbe(
|    factory: () -> Any?,
|    createObservation: (Any?) -> WeakReference<Any>?,
|): WeakDeadObservationProbe {
|    val payload = factory()
|    val observation = createObservation(payload)
|    return WeakDeadObservationProbe(observation)
|}
|
|private class ReachabilityConsistencyProbe(
|    val observation: WeakReference<Any>?,
|    private val clearPayloadImpl: () -> Unit,
|    private val readPayloadImpl: () -> Any?,
|) {
        |    fun loadObserved(): Any? = loadReachabilityObservation(observation)
        |    fun clearPayload() {
        |        clearPayloadImpl()
        |    }
        |    fun readPayload(): Any? = readPayloadImpl()
        |}
        |
        |private fun prepareReachabilityConsistencyProbe(
        |    ownerFactory: () -> Any?,
        |    payloadFactory: () -> Any?,
        |    attachPayload: (Any?, Any?) -> Unit,
        |    publishRoot: (Any?) -> Unit,
        |    createObservation: (Any?) -> WeakReference<Any>?,
        |    clearPayload: (Any?) -> Unit,
        |    readPayload: (Any?) -> Any?,
        |): ReachabilityConsistencyProbe {
        |    val owner = ownerFactory()
        |    val payload = payloadFactory()
        |    attachPayload(owner, payload)
        |    publishRoot(owner)
        |    val observation = createObservation(owner)
        |    return ReachabilityConsistencyProbe(
        |        observation = observation,
        |        clearPayloadImpl = { clearPayload(owner) },
        |        readPayloadImpl = { readPayload(owner) },
        |    )
        |}
        |
        |private class RootMigrationProbe(
        |    val observation: WeakReference<Any>?,
        |    private val readPayloadImpl: () -> Any?,
        |) {
        |    fun loadObserved(): Any? = loadReachabilityObservation(observation)
        |    fun readPayload(): Any? = readPayloadImpl()
        |}
        |
        |private fun prepareRootMigrationProbe(
        |    sourceOwnerFactory: () -> Any?,
        |    payloadFactory: () -> Any?,
        |    targetOwnerFactory: () -> Any?,
        |    attachSourcePayload: (Any?, Any?) -> Unit,
        |    publishRoot: (Any?) -> Unit,
        |    migratePayloadToTarget: (Any?, Any?) -> Unit,
        |    clearSourcePayload: (Any?) -> Unit,
        |    clearRoot: () -> Unit,
        |    createObservation: (Any?) -> WeakReference<Any>?,
        |    readPayload: (Any?) -> Any?,
        |): RootMigrationProbe {
        |    val sourceOwner = sourceOwnerFactory()
        |    val payload = payloadFactory()
        |    val targetOwner = targetOwnerFactory()
        |    attachSourcePayload(sourceOwner, payload)
        |    publishRoot(sourceOwner)
        |    migratePayloadToTarget(targetOwner, sourceOwner)
        |    clearSourcePayload(sourceOwner)
        |    clearRoot()
        |    val observation = createObservation(targetOwner)
        |    return RootMigrationProbe(
        |        observation = observation,
        |        readPayloadImpl = { readPayload(targetOwner) },
        |    )
        |}
        |
        |private fun assertReachability(label: String, expectation: ReachabilityExpectation, value: Any?) {
        |    when (expectation) {
        |        ReachabilityExpectation.ALIVE ->
        |            if (value == null) throw IllegalStateException("Reachability oracle failed [${'$'}label]: expected alive after GC")
        |        ReachabilityExpectation.DEAD ->
        |            if (value != null) throw IllegalStateException("Reachability oracle failed [${'$'}label]: expected dead after GC")
        |    }
        |}
        |
        |${renderPureKotlinCInteropPrelude(hasCInterop)}
        |
        |private inline fun alloc(block: () -> Any?): Any? {
        |    if (shouldTerminate()) return null
        |    return block()
        |}
        |
        |
        """.trimMargin()
    )
}
}

private fun ScenarioReachabilityExpectation.toRuntimeEnumName(): String = when (this) {
    ScenarioReachabilityExpectation.Alive -> "ALIVE"
    ScenarioReachabilityExpectation.Dead -> "DEAD"
}

private fun ScenarioReachabilityObservationKind.toRuntimeEnumName(): String = when (this) {
    ScenarioReachabilityObservationKind.Weak -> "WEAK"
}

private fun ScenarioProgram.collectObservationIds(): List<Int> =
    buildSet {
        fun collectFromBody(body: ScenarioBody) {
            body.statements.forEach { op ->
                when (op) {
                    is ScenarioOp.CreateReachabilityObservation -> add(op.observationId)
                    is ScenarioOp.CheckReachabilityObservation -> add(op.observationId)
                    is ScenarioOp.Block -> collectFromBody(ScenarioBody(op.body))
                    is ScenarioOp.If -> {
                        collectFromBody(ScenarioBody(op.thenBody))
                        collectFromBody(ScenarioBody(op.elseBody))
                    }
                    is ScenarioOp.TryFinally -> {
                        collectFromBody(ScenarioBody(op.body))
                        collectFromBody(ScenarioBody(op.finallyBody))
                    }
                    is ScenarioOp.Spawn -> collectFromBody(ScenarioBody(op.body))
                    is ScenarioOp.SpawnWithResult -> collectFromBody(ScenarioBody(op.body))
                    else -> Unit
                }
            }
        }

        collectFromBody(mainBody)
        definitions.filterIsInstance<ScenarioDefinition.Function>().forEach { collectFromBody(it.body.body) }
    }.toList().sorted()

private fun renderKotlinStringLiteral(value: String): String =
    buildString {
        append('"')
        value.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(ch)
            }
        }
        append('"')
    }
