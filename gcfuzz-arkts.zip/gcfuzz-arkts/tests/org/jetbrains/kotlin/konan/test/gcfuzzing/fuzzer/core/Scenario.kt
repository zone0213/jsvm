/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core

internal class ScenarioProgram(
    val definitions: List<ScenarioDefinition>,
    val mainBody: ScenarioBody,
)

internal typealias ScenarioEntityId = Int
internal typealias ScenarioObservationId = Int

internal sealed interface ScenarioTargetLanguage {
    data object Kotlin : ScenarioTargetLanguage
    data object ObjC : ScenarioTargetLanguage
    data object Java : ScenarioTargetLanguage
    data object ArkTs : ScenarioTargetLanguage
}

internal sealed interface ScenarioGlobalStorage {
    data object Shared : ScenarioGlobalStorage
    data object ThreadLocal : ScenarioGlobalStorage
}

internal sealed interface ScenarioField {
    data object StrongRef : ScenarioField
    data class TypedStrongRef(val type: ScenarioType) : ScenarioField
    data object WeakRef : ScenarioField
    data object IntValue : ScenarioField
    data object BooleanValue : ScenarioField
    data class ObjectArray(val size: Int) : ScenarioField
}

/** A language-neutral declared reference type. */
internal sealed interface ScenarioType {
    data object AnyRef : ScenarioType
    data class InterfaceRef(val interfaceId: ScenarioEntityId) : ScenarioType
    data class ClassRef(val classId: ScenarioEntityId) : ScenarioType
    data class SingletonRef(val singletonId: ScenarioEntityId) : ScenarioType
}

internal enum class ScenarioClassKind {
    Concrete,
    Sealed,
}

internal sealed interface ScenarioClassLifecycle {
    data object None : ScenarioClassLifecycle
    class Finalizer(val body: ScenarioBody) : ScenarioClassLifecycle
}

internal data object ScenarioParameter

internal class ScenarioPath(val accessors: List<ScenarioEntityId>)

internal sealed interface ScenarioDefinition {
    val targetLanguage: ScenarioTargetLanguage

    class Class(
        override val targetLanguage: ScenarioTargetLanguage,
        val fields: List<ScenarioField>,
        val lifecycle: ScenarioClassLifecycle = ScenarioClassLifecycle.None,
        val interfaces: List<ScenarioEntityId> = emptyList(),
        val dispatchFieldId: ScenarioEntityId? = null,
        val kind: ScenarioClassKind = ScenarioClassKind.Concrete,
        val superClassId: ScenarioEntityId? = null,
        val sealedPayloadFieldId: ScenarioEntityId? = null,
        val nestedInClassId: ScenarioEntityId? = null,
        val outerCaptureFieldId: ScenarioEntityId? = null,
    ) : ScenarioDefinition

    class Interface(
        override val targetLanguage: ScenarioTargetLanguage,
    ) : ScenarioDefinition

    class SingletonObject(
        override val targetLanguage: ScenarioTargetLanguage,
        val fields: List<ScenarioField>,
    ) : ScenarioDefinition

    class Function(
        override val targetLanguage: ScenarioTargetLanguage,
        val parameters: List<ScenarioParameter>,
        val body: ScenarioBodyWithReturn,
        val returnType: ScenarioType = ScenarioType.AnyRef,
    ) : ScenarioDefinition

    class Global(
        override val targetLanguage: ScenarioTargetLanguage,
        val field: ScenarioField,
        val storage: ScenarioGlobalStorage = ScenarioGlobalStorage.Shared,
    ) : ScenarioDefinition
}

internal class ScenarioBody(
    val statements: List<ScenarioOp>,
)

internal class ScenarioBodyWithReturn(
    val body: ScenarioBody,
    val returnValue: ScenarioValue,
)

internal enum class ScenarioDomain {
    Kotlin,
    ObjC,
    Java,
    Native,
    ArkTs,
}

internal enum class ScenarioStoreReferenceKind {
    Strong,
    Weak,
}

internal enum class ScenarioForeignReferenceKind {
    Handle,
    Strong,
    Weak,
}

internal enum class ScenarioForeignInteractionPattern {
    Callback,
    RepeatedCallback,
    Identity,
    WrappedCallback,
    CallbackThenIdentity,
    NestedCallback,
    BoxedCallback,
    BoxedIdentity,
    BoxedRepeatedCallback,
}

internal enum class ScenarioReachabilityExpectation {
    Alive,
    Dead,
}

internal enum class ScenarioReachabilityObservationKind {
    Weak,
}

internal sealed interface ScenarioValue {
    data object DefaultValue : ScenarioValue
    data object NullValue : ScenarioValue
    data class LocalRef(
        val localId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioValue
    data class GlobalRef(
        val globalId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioValue
    data class SingletonRef(
        val singletonId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioValue
}

internal sealed interface ScenarioLocation {
    data class Local(
        val localId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioLocation
    data class Global(
        val globalId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioLocation
    data class Singleton(
        val singletonId: Int,
        val path: ScenarioPath = ScenarioPath(emptyList()),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioLocation
}

internal sealed interface ScenarioOp {
    data class CreateObject(
        val localId: Int,
        val classId: Int,
        val args: List<ScenarioValue> = emptyList(),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
        val declaredType: ScenarioType = ScenarioType.AnyRef,
    ) : ScenarioOp
    data class Store(
        val location: ScenarioLocation,
        val value: ScenarioValue,
        val referenceKind: ScenarioStoreReferenceKind = ScenarioStoreReferenceKind.Strong,
    ) : ScenarioOp
    data class CompareAndSet(
        val location: ScenarioLocation,
        val expectedValue: ScenarioValue,
        val newValue: ScenarioValue,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class Clear(val location: ScenarioLocation) : ScenarioOp
    data class StoreBatch(val stores: List<Store>) : ScenarioOp
    data class Observe(val value: ScenarioValue) : ScenarioOp
    data class ForeignRoundTrip(
        val value: ScenarioValue,
        val referenceKind: ScenarioForeignReferenceKind = ScenarioForeignReferenceKind.Handle,
        val pattern: ScenarioForeignInteractionPattern = ScenarioForeignInteractionPattern.Callback,
        val repetitions: Int = 1,
    ) : ScenarioOp
    data class CreateReachabilityObservation(
        val observationId: ScenarioObservationId,
        val value: ScenarioValue,
        val kind: ScenarioReachabilityObservationKind = ScenarioReachabilityObservationKind.Weak,
    ) : ScenarioOp
    data class CheckReachabilityObservation(
        val observationId: ScenarioObservationId,
        val expectation: ScenarioReachabilityExpectation,
        val label: String,
    ) : ScenarioOp
    data class CheckReachability(
        val value: ScenarioValue,
        val expectation: ScenarioReachabilityExpectation,
        val label: String,
    ) : ScenarioOp
    data class PerformGc(val domain: ScenarioDomain? = ScenarioDomain.Kotlin) : ScenarioOp
    data class GcEpoch(
        val count: Int,
        val yieldBetween: Boolean = true,
        val domain: ScenarioDomain? = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class Block(val body: List<ScenarioOp>) : ScenarioOp
    data class ScopedRoot(
        val localId: Int,
        val value: ScenarioValue,
        val body: List<ScenarioOp>,
    ) : ScenarioOp
    data class If(
        val condition: ScenarioValue,
        val thenBody: List<ScenarioOp>,
        val elseBody: List<ScenarioOp>,
    ) : ScenarioOp
    data class TryFinally(
        val body: List<ScenarioOp>,
        val finallyBody: List<ScenarioOp>,
    ) : ScenarioOp
    data class Return(val value: ScenarioValue) : ScenarioOp
    data class Throw(val value: ScenarioValue) : ScenarioOp
    data class Spawn(
        val body: List<ScenarioOp>,
        val join: Boolean = false,
    ) : ScenarioOp
    data class SpawnWithResult(
        val localId: Int,
        val returnValue: ScenarioValue,
        val body: List<ScenarioOp>,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class SpawnFunction(
        val functionId: Int,
        val args: List<ScenarioValue>,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class AllocationBurst(
        val classId: Int,
        val count: Int,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class Signal(val checkpointId: Int) : ScenarioOp
    data class Wait(val checkpointId: Int) : ScenarioOp
    data object Yield : ScenarioOp
    data class CallFunction(
        val functionId: Int,
        val args: List<ScenarioValue>,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class InterfaceDispatch(
        val localId: Int,
        val receiver: ScenarioValue,
        val interfaceId: ScenarioEntityId,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class SealedDispatch(
        val localId: Int,
        val receiver: ScenarioValue,
        val sealedClassId: ScenarioEntityId,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class SingletonAccess(
        val localId: Int,
        val singletonId: ScenarioEntityId,
        val fieldId: ScenarioEntityId,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
    data class CreateInnerObject(
        val localId: Int,
        val outer: ScenarioValue,
        val classId: ScenarioEntityId,
        val args: List<ScenarioValue> = emptyList(),
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
        val declaredType: ScenarioType = ScenarioType.AnyRef,
    ) : ScenarioOp
    data class OuterDispatch(
        val localId: Int,
        val receiver: ScenarioValue,
        val classId: ScenarioEntityId,
        val domain: ScenarioDomain = ScenarioDomain.Kotlin,
    ) : ScenarioOp
}
