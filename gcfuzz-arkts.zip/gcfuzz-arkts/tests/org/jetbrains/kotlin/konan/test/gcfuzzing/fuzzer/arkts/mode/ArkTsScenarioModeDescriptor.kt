/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.arkts.resolveArkTsScenarioGeneratedSourceDir
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.arkts.runArkTsScenario
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ProgramId
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenarioWithMetadata
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioModeDescriptor
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save

internal object ArkTsScenarioModeDescriptor : ScenarioModeDescriptor {
    override val aliases: Set<String> = setOf("arkts", "ark-ts", "ark")
    override val generationProfile = ArkTsScenarioGenerationProfile

    override fun execute(
        host: StandaloneExecutionHost,
        id: ProgramId,
        config: ScenarioBackendConfig,
    ) {
        val name = id.toString()
        val generatedSourceDir = host.resolveArkTsScenarioGeneratedSourceDir(name)
        val generated = generateScenarioWithMetadata(id.seed(), generationProfile.features)
        val output = ArkTsScenarioBackend.lower(generated.program, config)
        output.save(generatedSourceDir)
        generated.telemetry.save(generatedSourceDir.parentFile.resolve("topology.json"), name)
        host.runArkTsScenario(name, output, host.executionTimeout)
    }
}

private fun ProgramId.seed(): UInt = when (this) {
    is ProgramId.Initial -> seed
}
