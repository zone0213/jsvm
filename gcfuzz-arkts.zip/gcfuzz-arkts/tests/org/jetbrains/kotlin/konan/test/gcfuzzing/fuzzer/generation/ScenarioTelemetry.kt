/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycleKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFieldKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorageKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOpKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import java.io.File

internal class GeneratedScenario(
    val program: ScenarioProgram,
    val telemetry: ScenarioTelemetry,
)

internal class ScenarioTelemetry(
    val enabledFeatures: Set<ScenarioFeature>,
    val enabledTopologies: Set<ScenarioTopologyKind>,
    val topologyAttempts: Map<ScenarioTopologyKind, Int>,
    val topologyHits: Map<ScenarioTopologyKind, Int>,
    val structuralHits: Map<ScenarioStructuralCoverageKind, Int> = emptyMap(),
) {
    fun save(file: File, caseId: String) {
        file.parentFile.mkdirs()
        file.writeText(toJson(caseId))
    }

    private fun toJson(caseId: String): String {
        fun String.escapeJson(): String = buildString {
            for (character in this@escapeJson) {
                when (character) {
                    '\\' -> append("\\\\")
                    '"' -> append("\\\"")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    else -> append(character)
                }
            }
        }

        fun names(values: Iterable<Enum<*>>): String =
            values
                .map { it.name }
                .sorted()
                .joinToString(",\n") { """    "${it.escapeJson()}"""" }

        fun topologyCounts(values: Map<ScenarioTopologyKind, Int>): String =
            values
                .toSortedMap(compareBy { it.name })
                .entries
                .joinToString(",\n") { (topology, count) -> """    "${topology.name.escapeJson()}": $count""" }

        fun structuralCounts(values: Map<ScenarioStructuralCoverageKind, Int>): String =
            values
                .toSortedMap(compareBy { it.name })
                .entries
                .joinToString(",\n") { (kind, count) -> """    "${kind.name.escapeJson()}": $count""" }

        return """
            |{
            |  "caseId": "${caseId.escapeJson()}",
            |  "enabledFeatures": [
            |${names(enabledFeatures)}
            |  ],
            |  "enabledTopologies": [
            |${names(enabledTopologies)}
            |  ],
            |  "enabledTopologyFamilies": [
            |${names(enabledTopologies.map { it.family }.toSet())}
            |  ],
            |  "topologyAttempts": {
            |${topologyCounts(topologyAttempts)}
            |  },
            |  "topologyHits": {
            |${topologyCounts(topologyHits)}
            |  },
            |  "structuralHits": {
            |${structuralCounts(structuralHits)}
            |  }
            |}
        """.trimMargin()
    }
}

internal enum class ScenarioStructuralCoverageKind {
    INTERFACE_POLYMORPHISM,
    SEALED_HIERARCHY,
    SINGLETON_OBJECT_ROOT,
    INNER_CLASS_OUTER_CAPTURE,
}

internal fun collectStructuralHits(program: ScenarioProgram): Map<ScenarioStructuralCoverageKind, Int> {
    val interfaceIds = program.definitions
        .filterIsInstance<ScenarioDefinition.Interface>()
        .indices
        .toSet()
    val implementorCounts = program.definitions
        .filterIsInstance<ScenarioDefinition.Class>()
        .flatMap { it.interfaces }
        .groupingBy { it }
        .eachCount()
    val typedSlotInterfaceIds = program.definitions.flatMap { definition ->
        when (definition) {
            is ScenarioDefinition.Class -> definition.fields.mapNotNull { it.interfaceRefId() }
            is ScenarioDefinition.Global -> listOfNotNull(definition.field.interfaceRefId())
            is ScenarioDefinition.Function -> listOfNotNull(definition.returnType.interfaceRefId())
            is ScenarioDefinition.Interface,
            is ScenarioDefinition.SingletonObject -> emptyList()
        }
    }.toSet()
    val dispatchCounts = countInterfaceDispatchOps(program)
    val interfaceDispatchHits = interfaceIds.sumOf { interfaceId ->
        if (
            (implementorCounts[interfaceId] ?: 0) >= 2 &&
            interfaceId in typedSlotInterfaceIds
        ) {
            dispatchCounts[interfaceId] ?: 0
        } else {
            0
        }
    }

    return buildMap {
        if (interfaceDispatchHits > 0) {
            put(ScenarioStructuralCoverageKind.INTERFACE_POLYMORPHISM, interfaceDispatchHits)
        }
        countSealedDispatchOps(program).takeIf { it > 0 }?.let {
            put(ScenarioStructuralCoverageKind.SEALED_HIERARCHY, it)
        }
        countSingletonAccessOps(program).takeIf { it > 0 }?.let {
            put(ScenarioStructuralCoverageKind.SINGLETON_OBJECT_ROOT, it)
        }
        countOuterDispatchOps(program).takeIf { it > 0 }?.let {
            put(ScenarioStructuralCoverageKind.INNER_CLASS_OUTER_CAPTURE, it)
        }
    }
}

private fun ScenarioField.interfaceRefId(): Int? =
    (this as? ScenarioField.TypedStrongRef)
        ?.type
        ?.interfaceRefId()

private fun ScenarioType.interfaceRefId(): Int? =
    (this as? ScenarioType.InterfaceRef)?.interfaceId

private fun countInterfaceDispatchOps(program: ScenarioProgram): Map<Int, Int> =
    mergeCounts(
        program.definitions.map { definition ->
            when (definition) {
                is ScenarioDefinition.Class -> countInterfaceDispatchOps(definition.lifecycleBodyStatements())
                is ScenarioDefinition.Function -> countInterfaceDispatchOps(definition.body.body.statements)
                is ScenarioDefinition.Global,
                is ScenarioDefinition.Interface,
                is ScenarioDefinition.SingletonObject -> emptyMap()
            }
        } + countInterfaceDispatchOps(program.mainBody.statements)
    )

private fun ScenarioDefinition.Class.lifecycleBodyStatements(): List<ScenarioOp> =
    when (val lifecycle = lifecycle) {
        is ScenarioClassLifecycle.Finalizer -> lifecycle.body.statements
        ScenarioClassLifecycle.None -> emptyList()
    }

private fun countInterfaceDispatchOps(statements: List<ScenarioOp>): Map<Int, Int> =
    mergeCounts(statements.map { statement ->
        when (statement) {
            is ScenarioOp.InterfaceDispatch -> mapOf(statement.interfaceId to 1)
            is ScenarioOp.Block -> countInterfaceDispatchOps(statement.body)
            is ScenarioOp.ScopedRoot -> countInterfaceDispatchOps(statement.body)
            is ScenarioOp.If -> mergeCounts(
                listOf(
                    countInterfaceDispatchOps(statement.thenBody),
                    countInterfaceDispatchOps(statement.elseBody),
                )
            )
            is ScenarioOp.TryFinally -> mergeCounts(
                listOf(
                    countInterfaceDispatchOps(statement.body),
                    countInterfaceDispatchOps(statement.finallyBody),
                )
            )
            is ScenarioOp.Spawn -> countInterfaceDispatchOps(statement.body)
            is ScenarioOp.SpawnWithResult -> countInterfaceDispatchOps(statement.body)
            is ScenarioOp.StoreBatch,
            is ScenarioOp.SealedDispatch,
            is ScenarioOp.SingletonAccess,
            is ScenarioOp.CreateInnerObject,
            is ScenarioOp.OuterDispatch,
            is ScenarioOp.CreateObject,
            is ScenarioOp.Store,
            is ScenarioOp.CompareAndSet,
            is ScenarioOp.Clear,
            is ScenarioOp.Observe,
            is ScenarioOp.ForeignRoundTrip,
            is ScenarioOp.CreateReachabilityObservation,
            is ScenarioOp.CheckReachabilityObservation,
            is ScenarioOp.CheckReachability,
            is ScenarioOp.PerformGc,
            is ScenarioOp.GcEpoch,
            is ScenarioOp.Return,
            is ScenarioOp.Throw,
            is ScenarioOp.SpawnFunction,
            is ScenarioOp.AllocationBurst,
            is ScenarioOp.Signal,
            is ScenarioOp.Wait,
            ScenarioOp.Yield,
            is ScenarioOp.CallFunction -> emptyMap()
        }
    })

private fun countSealedDispatchOps(program: ScenarioProgram): Int =
    countOps(program) { it is ScenarioOp.SealedDispatch }

private fun countSingletonAccessOps(program: ScenarioProgram): Int =
    countOps(program) { it is ScenarioOp.SingletonAccess }

private fun countOuterDispatchOps(program: ScenarioProgram): Int =
    countOps(program) { it is ScenarioOp.OuterDispatch }

private fun countOps(program: ScenarioProgram, predicate: (ScenarioOp) -> Boolean): Int =
    program.definitions.sumOf { definition ->
        when (definition) {
            is ScenarioDefinition.Class -> countOps(definition.lifecycleBodyStatements(), predicate)
            is ScenarioDefinition.Function -> countOps(definition.body.body.statements, predicate)
            is ScenarioDefinition.Global,
            is ScenarioDefinition.Interface,
            is ScenarioDefinition.SingletonObject -> 0
        }
    } + countOps(program.mainBody.statements, predicate)

private fun countOps(statements: List<ScenarioOp>, predicate: (ScenarioOp) -> Boolean): Int =
    statements.sumOf { statement ->
        (if (predicate(statement)) 1 else 0) +
            when (statement) {
                is ScenarioOp.Block -> countOps(statement.body, predicate)
                is ScenarioOp.ScopedRoot -> countOps(statement.body, predicate)
                is ScenarioOp.If -> countOps(statement.thenBody, predicate) + countOps(statement.elseBody, predicate)
                is ScenarioOp.TryFinally -> countOps(statement.body, predicate) + countOps(statement.finallyBody, predicate)
                is ScenarioOp.Spawn -> countOps(statement.body, predicate)
                is ScenarioOp.SpawnWithResult -> countOps(statement.body, predicate)
                is ScenarioOp.StoreBatch,
                is ScenarioOp.CreateObject,
                is ScenarioOp.Store,
                is ScenarioOp.CompareAndSet,
                is ScenarioOp.Clear,
                is ScenarioOp.Observe,
                is ScenarioOp.ForeignRoundTrip,
                is ScenarioOp.CreateReachabilityObservation,
                is ScenarioOp.CheckReachabilityObservation,
                is ScenarioOp.CheckReachability,
                is ScenarioOp.PerformGc,
                is ScenarioOp.GcEpoch,
                is ScenarioOp.Return,
                is ScenarioOp.Throw,
                is ScenarioOp.SpawnFunction,
                is ScenarioOp.AllocationBurst,
                is ScenarioOp.Signal,
                is ScenarioOp.Wait,
                ScenarioOp.Yield,
                is ScenarioOp.CallFunction,
                is ScenarioOp.InterfaceDispatch,
                is ScenarioOp.SealedDispatch,
                is ScenarioOp.SingletonAccess,
                is ScenarioOp.CreateInnerObject,
                is ScenarioOp.OuterDispatch -> 0
            }
    }

private fun mergeCounts(counts: Iterable<Map<Int, Int>>): Map<Int, Int> =
    counts
        .flatMap { it.entries }
        .groupingBy { it.key }
        .fold(0) { total, entry -> total + entry.value }

internal enum class ScenarioTopologyKind {
    SINGLE_STRONG_SLOT_CAPSULE,
    REACHABILITY_CONSISTENCY,
    REACHABILITY_CONSISTENCY_CAPSULE,
    WEAK_DEAD_CAPSULE,
    CYCLE,
    SHARED_NODE,
    GLOBAL_REATTACH,
    OLD_ROOT_CHURN,
    ROOT_MIGRATION,
    ROOT_MIGRATION_CAPSULE,
    DELETE_EDGE_THEN_GC,
    CONCURRENT_ROOT_MIGRATION,
    WEAK_REF_LIFECYCLE,
    CONCURRENT_PUBLISH_CLEAR_GC,
    ARRAY_SLOT_GRAPH,
    GRAPH_MUTATION_SEQUENCE,
    FUNCTION_RETURN_ESCAPE,
    WORKER_ALLOC_PUBLISH,
    MULTI_STAGE_ROOT_HANDOFF,
    PING_PONG_ROOT_TRANSFER,
    CONCURRENT_DUPLICATE_HANDOFF,
    LOCAL_GLOBAL_ARRAY_HANDOFF,
    STALE_OWNER_MUTATION_AFTER_HANDOFF,
    THREAD_LOCAL_SHARED_HANDOFF,
    WORKER_CAPTURE_ROOT,
    MULTI_ROOT_STAGGERED_CLEAR,
    CONCURRENT_ARRAY_SLOT_HANDOFF,
    ROOT_REPUBLISH_AFTER_CLEAR,
    TRY_FINALLY_ROOT_CLEAR,
    RETURN_ESCAPE_WORKER_PUBLISH,
    THREAD_LOCAL_CLEAR_ON_WORKER_EXIT,
    ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE,
    WORKER_PUBLISH_MAIN_CLEAR_BARRIER,
    ARRAY_SLOT_CLEAR_RESTORE_BARRIER,
    MIXED_FIELD_ARRAY_MUTATION_BARRIER,
    LARGE_OBJECT_MULTI_FIELD_REWRITE,
    OLD_ROOT_CHURN_WITH_ALLOCATION_BURST,
    GRAPH_MUTATION_MULTI_PHASE_SEQUENCE,
    SHARED_NODE_RECONNECT_BETWEEN_OWNERS,
    CYCLE_BREAK_AND_REROOT,
    WEAK_ROOT_HANDOFF,
    WEAK_ARRAY_SLOT,
    WEAK_THREAD_LOCAL_ROOT,
    WEAK_STRONG_GLOBAL_ALTERNATING,
    WEAK_LATE_STRONG_RESCUE,
    WEAK_MULTI_EPOCH_OBSERVE,
    FINALIZER_GLOBAL_PUBLISH,
    WORKER_RESULT_ESCAPE,
    WORKER_RESULT_THEN_CLEAR_GC,
    NESTED_WORKER_ROOT_HANDOFF,
    CAS_ROOT_CONTENTION,
    CFFI_CALLBACK_AFTER_GC,
    CFFI_IDENTITY_HANDOFF,
}

internal enum class ScenarioTopologyFamily {
    ORACLE,
    BASIC_GRAPH,
    ROOT_LIFECYCLE,
    DIRTY_GRAPH_BARRIER,
    WEAK_REFERENCE,
    FINALIZATION,
    CFFI,
}

internal val ScenarioTopologyKind.family: ScenarioTopologyFamily
    get() = when (this) {
        ScenarioTopologyKind.SINGLE_STRONG_SLOT_CAPSULE,
        ScenarioTopologyKind.REACHABILITY_CONSISTENCY,
        ScenarioTopologyKind.REACHABILITY_CONSISTENCY_CAPSULE,
        ScenarioTopologyKind.WEAK_DEAD_CAPSULE,
        ScenarioTopologyKind.ROOT_MIGRATION_CAPSULE -> ScenarioTopologyFamily.ORACLE

        ScenarioTopologyKind.CYCLE,
        ScenarioTopologyKind.SHARED_NODE,
        ScenarioTopologyKind.GLOBAL_REATTACH,
        ScenarioTopologyKind.OLD_ROOT_CHURN,
        ScenarioTopologyKind.ROOT_MIGRATION,
        ScenarioTopologyKind.DELETE_EDGE_THEN_GC,
        ScenarioTopologyKind.ARRAY_SLOT_GRAPH,
        ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE -> ScenarioTopologyFamily.BASIC_GRAPH

        ScenarioTopologyKind.CONCURRENT_ROOT_MIGRATION,
        ScenarioTopologyKind.CONCURRENT_PUBLISH_CLEAR_GC,
        ScenarioTopologyKind.FUNCTION_RETURN_ESCAPE,
        ScenarioTopologyKind.WORKER_ALLOC_PUBLISH,
        ScenarioTopologyKind.MULTI_STAGE_ROOT_HANDOFF,
        ScenarioTopologyKind.PING_PONG_ROOT_TRANSFER,
        ScenarioTopologyKind.CONCURRENT_DUPLICATE_HANDOFF,
        ScenarioTopologyKind.LOCAL_GLOBAL_ARRAY_HANDOFF,
        ScenarioTopologyKind.STALE_OWNER_MUTATION_AFTER_HANDOFF,
        ScenarioTopologyKind.THREAD_LOCAL_SHARED_HANDOFF,
        ScenarioTopologyKind.WORKER_CAPTURE_ROOT,
        ScenarioTopologyKind.MULTI_ROOT_STAGGERED_CLEAR,
        ScenarioTopologyKind.CONCURRENT_ARRAY_SLOT_HANDOFF,
        ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR,
        ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR,
        ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH,
        ScenarioTopologyKind.THREAD_LOCAL_CLEAR_ON_WORKER_EXIT,
        ScenarioTopologyKind.ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE,
        ScenarioTopologyKind.WORKER_PUBLISH_MAIN_CLEAR_BARRIER,
        ScenarioTopologyKind.ARRAY_SLOT_CLEAR_RESTORE_BARRIER,
        ScenarioTopologyKind.WORKER_RESULT_ESCAPE,
        ScenarioTopologyKind.WORKER_RESULT_THEN_CLEAR_GC,
        ScenarioTopologyKind.NESTED_WORKER_ROOT_HANDOFF,
        ScenarioTopologyKind.CAS_ROOT_CONTENTION -> ScenarioTopologyFamily.ROOT_LIFECYCLE

        ScenarioTopologyKind.MIXED_FIELD_ARRAY_MUTATION_BARRIER,
        ScenarioTopologyKind.LARGE_OBJECT_MULTI_FIELD_REWRITE,
        ScenarioTopologyKind.OLD_ROOT_CHURN_WITH_ALLOCATION_BURST,
        ScenarioTopologyKind.GRAPH_MUTATION_MULTI_PHASE_SEQUENCE,
        ScenarioTopologyKind.SHARED_NODE_RECONNECT_BETWEEN_OWNERS,
        ScenarioTopologyKind.CYCLE_BREAK_AND_REROOT -> ScenarioTopologyFamily.DIRTY_GRAPH_BARRIER

        ScenarioTopologyKind.WEAK_REF_LIFECYCLE,
        ScenarioTopologyKind.WEAK_ROOT_HANDOFF,
        ScenarioTopologyKind.WEAK_ARRAY_SLOT,
        ScenarioTopologyKind.WEAK_THREAD_LOCAL_ROOT,
        ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING,
        ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE,
        ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE -> ScenarioTopologyFamily.WEAK_REFERENCE

        ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH -> ScenarioTopologyFamily.FINALIZATION

        ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC,
        ScenarioTopologyKind.CFFI_IDENTITY_HANDOFF -> ScenarioTopologyFamily.CFFI
    }

// Maps each targeted topology to the feature gate that allows it to be emitted.
internal fun ScenarioTopologyKind.requiredFeature(): ScenarioFeature = when (this) {
    ScenarioTopologyKind.SINGLE_STRONG_SLOT_CAPSULE -> ScenarioFeature.ORACLE_SINGLE_STRONG_SLOT
    ScenarioTopologyKind.REACHABILITY_CONSISTENCY -> ScenarioFeature.TOPOLOGY_REACHABILITY_CONSISTENCY
    ScenarioTopologyKind.REACHABILITY_CONSISTENCY_CAPSULE -> ScenarioFeature.ORACLE_REACHABILITY_CONSISTENCY
    ScenarioTopologyKind.WEAK_DEAD_CAPSULE -> ScenarioFeature.ORACLE_WEAK_DEAD_CAPSULE
    ScenarioTopologyKind.CYCLE -> ScenarioFeature.TOPOLOGY_CYCLE
    ScenarioTopologyKind.SHARED_NODE -> ScenarioFeature.TOPOLOGY_SHARED_NODE
    ScenarioTopologyKind.GLOBAL_REATTACH -> ScenarioFeature.TOPOLOGY_GLOBAL_REATTACH
    ScenarioTopologyKind.OLD_ROOT_CHURN -> ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN
    ScenarioTopologyKind.ROOT_MIGRATION -> ScenarioFeature.TOPOLOGY_ROOT_MIGRATION
    ScenarioTopologyKind.ROOT_MIGRATION_CAPSULE -> ScenarioFeature.ORACLE_ROOT_MIGRATION_CAPSULE
    ScenarioTopologyKind.DELETE_EDGE_THEN_GC -> ScenarioFeature.TOPOLOGY_DELETE_EDGE_THEN_GC
    ScenarioTopologyKind.CONCURRENT_ROOT_MIGRATION -> ScenarioFeature.TOPOLOGY_CONCURRENT_ROOT_MIGRATION
    ScenarioTopologyKind.WEAK_REF_LIFECYCLE -> ScenarioFeature.TOPOLOGY_WEAK_REF_LIFECYCLE
    ScenarioTopologyKind.CONCURRENT_PUBLISH_CLEAR_GC -> ScenarioFeature.TOPOLOGY_CONCURRENT_PUBLISH_CLEAR_GC
    ScenarioTopologyKind.ARRAY_SLOT_GRAPH -> ScenarioFeature.TOPOLOGY_ARRAY_SLOT_GRAPH
    ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE -> ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_SEQUENCE
    ScenarioTopologyKind.FUNCTION_RETURN_ESCAPE -> ScenarioFeature.TOPOLOGY_FUNCTION_RETURN_ESCAPE
    ScenarioTopologyKind.WORKER_ALLOC_PUBLISH -> ScenarioFeature.TOPOLOGY_WORKER_ALLOC_PUBLISH
    ScenarioTopologyKind.MULTI_STAGE_ROOT_HANDOFF -> ScenarioFeature.TOPOLOGY_MULTI_STAGE_ROOT_HANDOFF
    ScenarioTopologyKind.PING_PONG_ROOT_TRANSFER -> ScenarioFeature.TOPOLOGY_PING_PONG_ROOT_TRANSFER
    ScenarioTopologyKind.CONCURRENT_DUPLICATE_HANDOFF -> ScenarioFeature.TOPOLOGY_CONCURRENT_DUPLICATE_HANDOFF
    ScenarioTopologyKind.LOCAL_GLOBAL_ARRAY_HANDOFF -> ScenarioFeature.TOPOLOGY_LOCAL_GLOBAL_ARRAY_HANDOFF
    ScenarioTopologyKind.STALE_OWNER_MUTATION_AFTER_HANDOFF -> ScenarioFeature.TOPOLOGY_STALE_OWNER_MUTATION_AFTER_HANDOFF
    ScenarioTopologyKind.THREAD_LOCAL_SHARED_HANDOFF -> ScenarioFeature.TOPOLOGY_THREAD_LOCAL_SHARED_HANDOFF
    ScenarioTopologyKind.WORKER_CAPTURE_ROOT -> ScenarioFeature.TOPOLOGY_WORKER_CAPTURE_ROOT
    ScenarioTopologyKind.MULTI_ROOT_STAGGERED_CLEAR -> ScenarioFeature.TOPOLOGY_MULTI_ROOT_STAGGERED_CLEAR
    ScenarioTopologyKind.CONCURRENT_ARRAY_SLOT_HANDOFF -> ScenarioFeature.TOPOLOGY_CONCURRENT_ARRAY_SLOT_HANDOFF
    ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR -> ScenarioFeature.TOPOLOGY_ROOT_REPUBLISH_AFTER_CLEAR
    ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR -> ScenarioFeature.TOPOLOGY_TRY_FINALLY_ROOT_CLEAR
    ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH -> ScenarioFeature.TOPOLOGY_RETURN_ESCAPE_WORKER_PUBLISH
    ScenarioTopologyKind.THREAD_LOCAL_CLEAR_ON_WORKER_EXIT -> ScenarioFeature.TOPOLOGY_THREAD_LOCAL_CLEAR_ON_WORKER_EXIT
    ScenarioTopologyKind.ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE -> ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE
    ScenarioTopologyKind.WORKER_PUBLISH_MAIN_CLEAR_BARRIER -> ScenarioFeature.TOPOLOGY_WORKER_PUBLISH_MAIN_CLEAR_BARRIER
    ScenarioTopologyKind.ARRAY_SLOT_CLEAR_RESTORE_BARRIER -> ScenarioFeature.TOPOLOGY_ARRAY_SLOT_CLEAR_RESTORE_BARRIER
    ScenarioTopologyKind.MIXED_FIELD_ARRAY_MUTATION_BARRIER -> ScenarioFeature.TOPOLOGY_MIXED_FIELD_ARRAY_MUTATION_BARRIER
    ScenarioTopologyKind.LARGE_OBJECT_MULTI_FIELD_REWRITE -> ScenarioFeature.TOPOLOGY_LARGE_OBJECT_MULTI_FIELD_REWRITE
    ScenarioTopologyKind.OLD_ROOT_CHURN_WITH_ALLOCATION_BURST -> ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN_WITH_ALLOCATION_BURST
    ScenarioTopologyKind.GRAPH_MUTATION_MULTI_PHASE_SEQUENCE -> ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_MULTI_PHASE_SEQUENCE
    ScenarioTopologyKind.SHARED_NODE_RECONNECT_BETWEEN_OWNERS -> ScenarioFeature.TOPOLOGY_SHARED_NODE_RECONNECT_BETWEEN_OWNERS
    ScenarioTopologyKind.CYCLE_BREAK_AND_REROOT -> ScenarioFeature.TOPOLOGY_CYCLE_BREAK_AND_REROOT
    ScenarioTopologyKind.WEAK_ROOT_HANDOFF -> ScenarioFeature.TOPOLOGY_WEAK_ROOT_HANDOFF
    ScenarioTopologyKind.WEAK_ARRAY_SLOT -> ScenarioFeature.TOPOLOGY_WEAK_ARRAY_SLOT
    ScenarioTopologyKind.WEAK_THREAD_LOCAL_ROOT -> ScenarioFeature.TOPOLOGY_WEAK_THREAD_LOCAL_ROOT
    ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING -> ScenarioFeature.TOPOLOGY_WEAK_STRONG_GLOBAL_ALTERNATING
    ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE -> ScenarioFeature.TOPOLOGY_WEAK_LATE_STRONG_RESCUE
    ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE -> ScenarioFeature.TOPOLOGY_WEAK_MULTI_EPOCH_OBSERVE
    ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH -> ScenarioFeature.TOPOLOGY_FINALIZER_GLOBAL_PUBLISH
    ScenarioTopologyKind.WORKER_RESULT_ESCAPE -> ScenarioFeature.TOPOLOGY_WORKER_RESULT_ESCAPE
    ScenarioTopologyKind.WORKER_RESULT_THEN_CLEAR_GC -> ScenarioFeature.TOPOLOGY_WORKER_RESULT_THEN_CLEAR_GC
    ScenarioTopologyKind.NESTED_WORKER_ROOT_HANDOFF -> ScenarioFeature.TOPOLOGY_NESTED_WORKER_ROOT_HANDOFF
    ScenarioTopologyKind.CAS_ROOT_CONTENTION -> ScenarioFeature.TOPOLOGY_CAS_ROOT_CONTENTION
    ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC -> ScenarioFeature.TOPOLOGY_CFFI_CALLBACK_AFTER_GC
    ScenarioTopologyKind.CFFI_IDENTITY_HANDOFF -> ScenarioFeature.TOPOLOGY_CFFI_IDENTITY_HANDOFF
}

internal class ScenarioTopologyRequirements(
    val ops: Set<ScenarioOpKind> = emptySet(),
    val fields: Set<ScenarioFieldKind> = emptySet(),
    val globalStorage: Set<ScenarioGlobalStorageKind> = emptySet(),
    val classLifecycles: Set<ScenarioClassLifecycleKind> = emptySet(),
)

internal fun ScenarioTopologyKind.requiredCapabilities(): ScenarioTopologyRequirements = when (this) {
    ScenarioTopologyKind.SINGLE_STRONG_SLOT_CAPSULE,
    ScenarioTopologyKind.REACHABILITY_CONSISTENCY,
    ScenarioTopologyKind.REACHABILITY_CONSISTENCY_CAPSULE,
    ScenarioTopologyKind.ROOT_MIGRATION_CAPSULE ->
        oracleStrongSlotRequirements()

    ScenarioTopologyKind.WEAK_DEAD_CAPSULE ->
        oracleStrongSlotRequirements(
            fields = setOf(ScenarioFieldKind.STRONG_REF, ScenarioFieldKind.WEAK_REF),
        )

    ScenarioTopologyKind.CYCLE,
    ScenarioTopologyKind.SHARED_NODE,
    ScenarioTopologyKind.GLOBAL_REATTACH,
    ScenarioTopologyKind.OLD_ROOT_CHURN,
    ScenarioTopologyKind.ROOT_MIGRATION,
    ScenarioTopologyKind.DELETE_EDGE_THEN_GC,
    ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE ->
        graphRequirements()

    ScenarioTopologyKind.ARRAY_SLOT_GRAPH ->
        graphRequirements(fields = setOf(ScenarioFieldKind.STRONG_REF, ScenarioFieldKind.OBJECT_ARRAY))

    ScenarioTopologyKind.CONCURRENT_ROOT_MIGRATION,
    ScenarioTopologyKind.CONCURRENT_PUBLISH_CLEAR_GC,
    ScenarioTopologyKind.WORKER_ALLOC_PUBLISH,
    ScenarioTopologyKind.MULTI_STAGE_ROOT_HANDOFF,
    ScenarioTopologyKind.PING_PONG_ROOT_TRANSFER,
    ScenarioTopologyKind.CONCURRENT_DUPLICATE_HANDOFF,
    ScenarioTopologyKind.STALE_OWNER_MUTATION_AFTER_HANDOFF,
    ScenarioTopologyKind.WORKER_CAPTURE_ROOT,
    ScenarioTopologyKind.MULTI_ROOT_STAGGERED_CLEAR,
    ScenarioTopologyKind.ROOT_REPUBLISH_AFTER_CLEAR,
    ScenarioTopologyKind.RETURN_ESCAPE_WORKER_PUBLISH ->
        concurrentRootRequirements()

    ScenarioTopologyKind.FUNCTION_RETURN_ESCAPE ->
        graphRequirements(ops = graphOps() + ScenarioOpKind.CALL_FUNCTION)

    ScenarioTopologyKind.TRY_FINALLY_ROOT_CLEAR ->
        graphRequirements(ops = graphOps() + ScenarioOpKind.TRY_FINALLY + ScenarioOpKind.ALLOCATION_BURST)

    ScenarioTopologyKind.LOCAL_GLOBAL_ARRAY_HANDOFF,
    ScenarioTopologyKind.CONCURRENT_ARRAY_SLOT_HANDOFF,
    ScenarioTopologyKind.ARRAY_SLOT_CLEAR_WITH_LATE_RESTORE,
    ScenarioTopologyKind.ARRAY_SLOT_CLEAR_RESTORE_BARRIER ->
        concurrentRootRequirements(fields = setOf(ScenarioFieldKind.STRONG_REF, ScenarioFieldKind.OBJECT_ARRAY))

    ScenarioTopologyKind.THREAD_LOCAL_SHARED_HANDOFF,
    ScenarioTopologyKind.THREAD_LOCAL_CLEAR_ON_WORKER_EXIT ->
        concurrentRootRequirements(globalStorage = setOf(ScenarioGlobalStorageKind.SHARED, ScenarioGlobalStorageKind.THREAD_LOCAL))

    ScenarioTopologyKind.WORKER_PUBLISH_MAIN_CLEAR_BARRIER ->
        concurrentRootRequirements(ops = concurrentRootOps() + ScenarioOpKind.SIGNAL + ScenarioOpKind.WAIT + ScenarioOpKind.YIELD)

    ScenarioTopologyKind.MIXED_FIELD_ARRAY_MUTATION_BARRIER,
    ScenarioTopologyKind.LARGE_OBJECT_MULTI_FIELD_REWRITE,
    ScenarioTopologyKind.GRAPH_MUTATION_MULTI_PHASE_SEQUENCE,
    ScenarioTopologyKind.SHARED_NODE_RECONNECT_BETWEEN_OWNERS,
    ScenarioTopologyKind.CYCLE_BREAK_AND_REROOT ->
        graphRequirements(ops = graphOps() + ScenarioOpKind.STORE_BATCH + ScenarioOpKind.ALLOCATION_BURST)

    ScenarioTopologyKind.OLD_ROOT_CHURN_WITH_ALLOCATION_BURST ->
        graphRequirements(ops = graphOps() + ScenarioOpKind.ALLOCATION_BURST)

    ScenarioTopologyKind.WEAK_REF_LIFECYCLE,
    ScenarioTopologyKind.WEAK_ROOT_HANDOFF,
    ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING,
    ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE,
    ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE ->
        weakRequirements()

    ScenarioTopologyKind.WEAK_ARRAY_SLOT ->
        weakRequirements(fields = setOf(ScenarioFieldKind.STRONG_REF, ScenarioFieldKind.WEAK_REF, ScenarioFieldKind.OBJECT_ARRAY))

    ScenarioTopologyKind.WEAK_THREAD_LOCAL_ROOT ->
        weakRequirements(globalStorage = setOf(ScenarioGlobalStorageKind.SHARED, ScenarioGlobalStorageKind.THREAD_LOCAL))

    ScenarioTopologyKind.FINALIZER_GLOBAL_PUBLISH ->
        graphRequirements(
            ops = graphOps() + ScenarioOpKind.ALLOCATION_BURST,
            classLifecycles = setOf(ScenarioClassLifecycleKind.NONE, ScenarioClassLifecycleKind.FINALIZER),
        )

    ScenarioTopologyKind.WORKER_RESULT_ESCAPE ->
        concurrentRootRequirements(ops = concurrentRootOps() + ScenarioOpKind.SPAWN_WITH_RESULT)

    ScenarioTopologyKind.WORKER_RESULT_THEN_CLEAR_GC ->
        concurrentRootRequirements(ops = concurrentRootOps() + ScenarioOpKind.SPAWN_WITH_RESULT + ScenarioOpKind.CLEAR)

    ScenarioTopologyKind.NESTED_WORKER_ROOT_HANDOFF ->
        concurrentRootRequirements(ops = concurrentRootOps() + ScenarioOpKind.SPAWN_WITH_RESULT)

    ScenarioTopologyKind.CAS_ROOT_CONTENTION ->
        concurrentRootRequirements(ops = concurrentRootOps() + ScenarioOpKind.COMPARE_AND_SET)

    ScenarioTopologyKind.CFFI_CALLBACK_AFTER_GC,
    ScenarioTopologyKind.CFFI_IDENTITY_HANDOFF ->
        graphRequirements(ops = graphOps() + ScenarioOpKind.FOREIGN_ROUNDTRIP)
}

internal fun ScenarioTopologyRequirements.isSupportedBy(capabilities: ScenarioCapabilityProfile): Boolean =
    ops.all(capabilities::supports) &&
        fields.all(capabilities::supports) &&
        globalStorage.all(capabilities::supports) &&
        classLifecycles.all(capabilities::supports)

private fun graphOps(): Set<ScenarioOpKind> = setOf(
    ScenarioOpKind.CREATE_OBJECT,
    ScenarioOpKind.STORE,
    ScenarioOpKind.CLEAR,
    ScenarioOpKind.OBSERVE,
    ScenarioOpKind.PERFORM_GC,
)

private fun concurrentRootOps(): Set<ScenarioOpKind> =
    graphOps() + ScenarioOpKind.SPAWN + ScenarioOpKind.ALLOCATION_BURST

private fun graphRequirements(
    ops: Set<ScenarioOpKind> = graphOps(),
    fields: Set<ScenarioFieldKind> = setOf(ScenarioFieldKind.STRONG_REF),
    globalStorage: Set<ScenarioGlobalStorageKind> = setOf(ScenarioGlobalStorageKind.SHARED),
    classLifecycles: Set<ScenarioClassLifecycleKind> = setOf(ScenarioClassLifecycleKind.NONE),
): ScenarioTopologyRequirements =
    ScenarioTopologyRequirements(ops, fields, globalStorage, classLifecycles)

private fun concurrentRootRequirements(
    ops: Set<ScenarioOpKind> = concurrentRootOps(),
    fields: Set<ScenarioFieldKind> = setOf(ScenarioFieldKind.STRONG_REF),
    globalStorage: Set<ScenarioGlobalStorageKind> = setOf(ScenarioGlobalStorageKind.SHARED),
): ScenarioTopologyRequirements =
    graphRequirements(ops, fields, globalStorage)

private fun oracleStrongSlotRequirements(
    fields: Set<ScenarioFieldKind> = setOf(ScenarioFieldKind.STRONG_REF),
): ScenarioTopologyRequirements =
    graphRequirements(
        ops = graphOps() + ScenarioOpKind.CREATE_REACHABILITY_OBSERVATION + ScenarioOpKind.CHECK_REACHABILITY_OBSERVATION,
        fields = fields,
    )

private fun weakRequirements(
    ops: Set<ScenarioOpKind> = graphOps() + ScenarioOpKind.ALLOCATION_BURST,
    fields: Set<ScenarioFieldKind> = setOf(ScenarioFieldKind.STRONG_REF, ScenarioFieldKind.WEAK_REF),
    globalStorage: Set<ScenarioGlobalStorageKind> = setOf(ScenarioGlobalStorageKind.SHARED),
): ScenarioTopologyRequirements =
    graphRequirements(ops, fields, globalStorage)
