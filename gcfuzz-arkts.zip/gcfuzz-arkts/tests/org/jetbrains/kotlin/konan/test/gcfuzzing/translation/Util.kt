/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioEntityId

internal fun OutputFileBuilder.braces(block: () -> Unit) {
    lineEnd("{")
    indent(block)
    lineEnd("}")
}

internal fun LineBuilder.parens(block: ArgumentListBuilder.() -> Unit) {
    append("(")
    ArgumentListBuilder(this).block()
    append(")")
}

internal fun LineBuilder.functionCall(block: FunctionCallBuilder.() -> Unit) {
    FunctionCallBuilder(this).apply(block).finish()
}

internal val Int.asString: String
    get() = toString()

internal fun <T> List<T>.findEntity(id: ScenarioEntityId): T? = getOrNull(id)

internal class ArgumentListBuilder(
    private val contents: LineBuilder,
) {
    private var first = true

    fun arg(value: String) {
        separator()
        contents.append(value)
    }

    fun arg(block: LineBuilder.() -> Unit) {
        separator()
        contents.block()
    }

    private fun separator() {
        if (first) {
            first = false
        } else {
            contents.append(", ")
        }
    }
}

internal class FunctionCallBuilder(
    private val contents: LineBuilder,
) {
    private var hasName = false
    private var hasArgs = false
    private var firstArg = true

    fun name(value: String) {
        check(!hasName) { "Function call name is already defined" }
        contents.append(value)
        hasName = true
    }

    fun name(block: LineBuilder.() -> Unit) {
        check(!hasName) { "Function call name is already defined" }
        contents.block()
        hasName = true
    }

    fun arg(value: String) {
        openArgs()
        separator()
        contents.append(value)
    }

    fun arg(block: LineBuilder.() -> Unit) {
        openArgs()
        separator()
        contents.block()
    }

    fun finish() {
        check(hasName) { "Function call name is missing" }
        if (!hasArgs) {
            contents.append("()")
        } else {
            contents.append(")")
        }
    }

    private fun openArgs() {
        check(hasName) { "Function call name must be emitted before arguments" }
        if (!hasArgs) {
            contents.append("(")
            hasArgs = true
        }
    }

    private fun separator() {
        if (firstArg) {
            firstArg = false
        } else {
            contents.append(", ")
        }
    }
}
