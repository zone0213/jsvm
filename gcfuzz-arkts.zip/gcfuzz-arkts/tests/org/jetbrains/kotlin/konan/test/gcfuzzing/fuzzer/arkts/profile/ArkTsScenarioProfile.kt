/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.profile

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDomain
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPreparationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage

/**
 * P1 ArkTS preparation profile.
 *
 * Preparation rewrites targetLanguage/domain to ArkTs and validates reference kinds. Because P1
 * enables no weak/foreign features, store reference kind is normalized to Strong (weak, if it ever
 * appears, is rejected by [capabilities] at the capability validator stage).
 */
internal object ArkTsScenarioProfile : ScenarioPreparationProfile {
    override val targetLanguage: ScenarioTargetLanguage = ScenarioTargetLanguage.ArkTs
    override val domain: ScenarioDomain = ScenarioDomain.ArkTs
    override val capabilities: ScenarioCapabilityProfile = ArkTsScenarioCapabilities.core

    override fun prepareStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind =
        ArkTsScenarioCffi.validateStoreReferenceKind(referenceKind)

    override fun prepareForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind =
        ArkTsScenarioCffi.validateForeignReferenceKind(referenceKind)
}
