/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPreparation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityValidator
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.profile.PureKotlinCInteropScenarioProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.profile.PureKotlinScenarioProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.PureKotlinConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.PureKotlinOutput
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.producePureKotlin

internal object PureKotlinScenarioBackend {
    fun lower(program: ScenarioProgram, config: ScenarioBackendConfig = ScenarioBackendConfig.DEFAULT): PureKotlinOutput {
        val profile = if (config.enableCInterop) PureKotlinCInteropScenarioProfile else PureKotlinScenarioProfile
        val prepared = ScenarioPreparation.prepare(
            program,
            profile,
        )
        ScenarioCapabilityValidator.validate(prepared.program, profile.capabilities)
        return prepared.program.producePureKotlin(
            PureKotlinConfig(
                moduleName = "main",
                maximumStackDepth = config.maximumStackDepth,
                mainLoopRepeatCount = config.mainLoopRepeatCount,
                maxThreadCount = config.maxThreadCount,
                softTimeout = config.softTimeout,
            )
        )
    }
}
