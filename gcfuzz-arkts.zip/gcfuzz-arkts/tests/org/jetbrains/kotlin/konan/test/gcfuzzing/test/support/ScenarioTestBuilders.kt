/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.support

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue

internal fun localValue(localId: Int, vararg path: Int): ScenarioValue.LocalRef =
    ScenarioValue.LocalRef(localId, ScenarioPath(path.toList()))

internal fun globalValue(globalId: Int, vararg path: Int): ScenarioValue.GlobalRef =
    ScenarioValue.GlobalRef(globalId, ScenarioPath(path.toList()))

internal fun localLocation(localId: Int, vararg path: Int): ScenarioLocation.Local =
    ScenarioLocation.Local(localId, ScenarioPath(path.toList()))

internal fun globalLocation(globalId: Int, vararg path: Int): ScenarioLocation.Global =
    ScenarioLocation.Global(globalId, ScenarioPath(path.toList()))
