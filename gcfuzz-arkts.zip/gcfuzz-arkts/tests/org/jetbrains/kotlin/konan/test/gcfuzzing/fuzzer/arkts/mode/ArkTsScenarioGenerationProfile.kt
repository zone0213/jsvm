/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.profile.ArkTsScenarioCapabilities
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationCapabilities
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioGenerationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.ScenarioTopologyKind

/**
 * P5 ArkTS generation profile. RICH_FIELDS + the pure-object-graph BASIC_GRAPH topologies +
 * the single-threaded WEAK_REFERENCE topologies + the WEAK_DEAD_CAPSULE oracle topology
 * (best-effort oracle, no force-GC).
 *
 * Enabled topologies emit only CreateObject/Store/Clear/Observe/PerformGc/AllocationBurst/
 * Block/CreateReachabilityObservation/CheckReachabilityObservation — no Spawn, no terminal
 * statements. WEAK_DEAD_CAPSULE is the lightest oracle capsule: a payload created inside a Block
 * with only a WeakRef observation, then required to die after GC. It needs no strong-ref field
 * and no shared strong global, so it fits the ArkTS capability matrix cleanly.
 *
 * DEAD reachability assertions are best-effort (see ArkTsScenarioCapabilities caveat): without
 * force-GC, the oracle cannot deterministically confirm death; ALIVE is deterministic. The
 * CreateReachabilityObservation translation calls registerObservation so the FinalizationRegistry
 * actually tracks the target — gcEpoch bumps when/if the object is collected, giving the DEAD
 * branch a "GC has plausibly run" signal (still not a hard assertion).
 */
internal object ArkTsScenarioGenerationProfile : ScenarioGenerationProfile {
    override val features: ScenarioFeatureSet = ScenarioFeatureSet.of(
        ScenarioFeature.RICH_FIELDS,
        ScenarioFeature.TOPOLOGY_CYCLE,
        ScenarioFeature.TOPOLOGY_SHARED_NODE,
        ScenarioFeature.TOPOLOGY_GLOBAL_REATTACH,
        ScenarioFeature.TOPOLOGY_OLD_ROOT_CHURN,
        ScenarioFeature.TOPOLOGY_ROOT_MIGRATION,
        ScenarioFeature.TOPOLOGY_DELETE_EDGE_THEN_GC,
        ScenarioFeature.TOPOLOGY_GRAPH_MUTATION_SEQUENCE,
        ScenarioFeature.TOPOLOGY_WEAK_REF_LIFECYCLE,
        ScenarioFeature.TOPOLOGY_WEAK_STRONG_GLOBAL_ALTERNATING,
        ScenarioFeature.TOPOLOGY_WEAK_LATE_STRONG_RESCUE,
        ScenarioFeature.TOPOLOGY_WEAK_MULTI_EPOCH_OBSERVE,
        ScenarioFeature.ORACLE_WEAK_DEAD_CAPSULE,
    )
    override val capabilities: ScenarioGenerationCapabilities =
        ScenarioGenerationCapabilities(
            core = ArkTsScenarioCapabilities.core,
            supportedTopologies = setOf(
                ScenarioTopologyKind.CYCLE,
                ScenarioTopologyKind.SHARED_NODE,
                ScenarioTopologyKind.GLOBAL_REATTACH,
                ScenarioTopologyKind.OLD_ROOT_CHURN,
                ScenarioTopologyKind.ROOT_MIGRATION,
                ScenarioTopologyKind.DELETE_EDGE_THEN_GC,
                ScenarioTopologyKind.GRAPH_MUTATION_SEQUENCE,
                ScenarioTopologyKind.WEAK_REF_LIFECYCLE,
                ScenarioTopologyKind.WEAK_STRONG_GLOBAL_ALTERNATING,
                ScenarioTopologyKind.WEAK_LATE_STRONG_RESCUE,
                ScenarioTopologyKind.WEAK_MULTI_EPOCH_OBSERVE,
                ScenarioTopologyKind.WEAK_DEAD_CAPSULE,
            ),
        )
}
