/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core

internal object ScenarioCapabilityValidator {
    fun validate(program: ScenarioProgram, capabilities: ScenarioCapabilityProfile) {
        val errors = mutableListOf<String>()
        program.definitions.forEachIndexed { index, definition ->
            validateDefinition(index, definition, capabilities, errors)
        }
        validateBody("main", program.mainBody.statements, capabilities, errors)
        if (errors.isNotEmpty()) {
            error("Scenario program is not supported by ${capabilities.targetLanguage}: ${errors.joinToString("; ")}")
        }
    }

    private fun validateDefinition(
        index: Int,
        definition: ScenarioDefinition,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        if (definition.targetLanguage != capabilities.targetLanguage) {
            errors += "definition[$index] targets ${definition.targetLanguage}, expected ${capabilities.targetLanguage}"
        }
        if (!capabilities.supports(definition.kind)) {
            errors += "definition[$index] uses unsupported definition ${definition.kind}"
        }
        when (definition) {
            is ScenarioDefinition.Class -> {
                definition.fields.forEachIndexed { fieldIndex, field ->
                    if (!capabilities.supports(field.kind)) {
                        errors += "class[$index].field[$fieldIndex] uses unsupported field ${field.kind}"
                    }
                }
                if (!capabilities.supports(definition.lifecycle.kind)) {
                    errors += "class[$index] uses unsupported lifecycle ${definition.lifecycle.kind}"
                }
                if (definition.lifecycle is ScenarioClassLifecycle.Finalizer) {
                    validateBody("class[$index].finalizer", definition.lifecycle.body.statements, capabilities, errors)
                }
            }
            is ScenarioDefinition.Interface -> Unit
            is ScenarioDefinition.SingletonObject -> {
                definition.fields.forEachIndexed { fieldIndex, field ->
                    if (!capabilities.supports(field.kind)) {
                        errors += "singleton[$index].field[$fieldIndex] uses unsupported field ${field.kind}"
                    }
                }
            }
            is ScenarioDefinition.Function ->
                validateBody("function[$index]", definition.body.body.statements, capabilities, errors)
            is ScenarioDefinition.Global -> {
                if (!capabilities.supports(definition.field.kind)) {
                    errors += "global[$index] uses unsupported field ${definition.field.kind}"
                }
                if (!capabilities.supports(definition.storage.kind)) {
                    errors += "global[$index] uses unsupported storage ${definition.storage.kind}"
                }
            }
        }
    }

    private fun validateBody(
        label: String,
        body: List<ScenarioOp>,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        body.forEachIndexed { index, op ->
            validateOp("$label.op[$index]", op, capabilities, errors)
        }
    }

    private fun validateOp(
        label: String,
        op: ScenarioOp,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        if (!capabilities.supports(op.kind)) {
            errors += "$label uses unsupported op ${op.kind}"
        }
        when (op) {
            is ScenarioOp.CreateObject -> validateDomain(label, op.domain, capabilities, errors)
            is ScenarioOp.InterfaceDispatch -> {
                validateValue(label, op.receiver, capabilities, errors)
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.SealedDispatch -> {
                validateValue(label, op.receiver, capabilities, errors)
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.SingletonAccess -> validateDomain(label, op.domain, capabilities, errors)
            is ScenarioOp.CreateInnerObject -> {
                validateValue(label, op.outer, capabilities, errors)
                op.args.forEach { validateValue(label, it, capabilities, errors) }
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.OuterDispatch -> {
                validateValue(label, op.receiver, capabilities, errors)
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.Store -> validateStore(label, op, capabilities, errors)
            is ScenarioOp.Clear -> validateLocation(label, op.location, capabilities, errors)
            is ScenarioOp.CompareAndSet -> {
                validateLocation(label, op.location, capabilities, errors)
                validateValue(label, op.expectedValue, capabilities, errors)
                validateValue(label, op.newValue, capabilities, errors)
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.StoreBatch -> op.stores.forEachIndexed { index, store ->
                validateStore("$label.store[$index]", store, capabilities, errors)
            }
            is ScenarioOp.Observe -> validateValue(label, op.value, capabilities, errors)
            is ScenarioOp.ForeignRoundTrip -> {
                validateValue(label, op.value, capabilities, errors)
                if (op.referenceKind !in capabilities.supportedForeignReferenceKinds) {
                    errors += "$label uses unsupported foreign reference kind ${op.referenceKind}"
                }
            }
            is ScenarioOp.CreateReachabilityObservation -> validateValue(label, op.value, capabilities, errors)
            is ScenarioOp.CheckReachabilityObservation -> Unit
            is ScenarioOp.CheckReachability -> validateValue(label, op.value, capabilities, errors)
            is ScenarioOp.PerformGc -> validateNullableDomain(label, op.domain, capabilities, errors)
            is ScenarioOp.GcEpoch -> validateNullableDomain(label, op.domain, capabilities, errors)
            is ScenarioOp.Block -> validateBody(label, op.body, capabilities, errors)
            is ScenarioOp.ScopedRoot -> {
                validateValue(label, op.value, capabilities, errors)
                validateBody(label, op.body, capabilities, errors)
            }
            is ScenarioOp.If -> {
                validateValue(label, op.condition, capabilities, errors)
                validateBody("$label.then", op.thenBody, capabilities, errors)
                validateBody("$label.else", op.elseBody, capabilities, errors)
            }
            is ScenarioOp.TryFinally -> {
                validateBody("$label.body", op.body, capabilities, errors)
                validateBody("$label.finally", op.finallyBody, capabilities, errors)
            }
            is ScenarioOp.Return -> validateValue(label, op.value, capabilities, errors)
            is ScenarioOp.Throw -> validateValue(label, op.value, capabilities, errors)
            is ScenarioOp.Spawn -> validateBody(label, op.body, capabilities, errors)
            is ScenarioOp.SpawnWithResult -> {
                validateValue(label, op.returnValue, capabilities, errors)
                validateBody(label, op.body, capabilities, errors)
                validateDomain(label, op.domain, capabilities, errors)
            }
            is ScenarioOp.SpawnFunction -> {
                validateDomain(label, op.domain, capabilities, errors)
                op.args.forEach { validateValue(label, it, capabilities, errors) }
            }
            is ScenarioOp.AllocationBurst -> validateDomain(label, op.domain, capabilities, errors)
            is ScenarioOp.Signal -> Unit
            is ScenarioOp.Wait -> Unit
            ScenarioOp.Yield -> Unit
            is ScenarioOp.CallFunction -> {
                validateDomain(label, op.domain, capabilities, errors)
                op.args.forEach { validateValue(label, it, capabilities, errors) }
            }
        }
    }

    private fun validateStore(
        label: String,
        store: ScenarioOp.Store,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        validateLocation(label, store.location, capabilities, errors)
        validateValue(label, store.value, capabilities, errors)
        if (store.referenceKind !in capabilities.supportedStoreReferenceKinds) {
            errors += "$label uses unsupported store reference kind ${store.referenceKind}"
        }
    }

    private fun validateValue(
        label: String,
        value: ScenarioValue,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        when (value) {
            ScenarioValue.DefaultValue,
            ScenarioValue.NullValue -> Unit
            is ScenarioValue.LocalRef -> validateDomain(label, value.domain, capabilities, errors)
            is ScenarioValue.GlobalRef -> validateDomain(label, value.domain, capabilities, errors)
            is ScenarioValue.SingletonRef -> validateDomain(label, value.domain, capabilities, errors)
        }
    }

    private fun validateLocation(
        label: String,
        location: ScenarioLocation,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        when (location) {
            is ScenarioLocation.Local -> validateDomain(label, location.domain, capabilities, errors)
            is ScenarioLocation.Global -> validateDomain(label, location.domain, capabilities, errors)
            is ScenarioLocation.Singleton -> validateDomain(label, location.domain, capabilities, errors)
        }
    }

    private fun validateNullableDomain(
        label: String,
        domain: ScenarioDomain?,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        if (domain != null) {
            validateDomain(label, domain, capabilities, errors)
        }
    }

    private fun validateDomain(
        label: String,
        domain: ScenarioDomain,
        capabilities: ScenarioCapabilityProfile,
        errors: MutableList<String>,
    ) {
        if (domain != capabilities.domain) {
            errors += "$label uses domain $domain, expected ${capabilities.domain}"
        }
    }
}
