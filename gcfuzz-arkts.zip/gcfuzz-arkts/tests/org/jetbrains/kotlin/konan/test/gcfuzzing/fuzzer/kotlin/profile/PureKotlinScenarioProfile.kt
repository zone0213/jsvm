/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.profile

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDomain
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPreparationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage

internal object PureKotlinScenarioProfile : ScenarioPreparationProfile {
    override val targetLanguage: ScenarioTargetLanguage = ScenarioTargetLanguage.Kotlin
    override val domain: ScenarioDomain = ScenarioDomain.Kotlin
    override val capabilities: ScenarioCapabilityProfile = ScenarioCapabilityProfile.pureKotlin(enableCInterop = false)

    override fun prepareStoreReferenceKind(referenceKind: ScenarioStoreReferenceKind): ScenarioStoreReferenceKind =
        PureKotlinScenarioCffi.validateStoreReferenceKind(referenceKind)

    override fun prepareForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): ScenarioForeignReferenceKind =
        PureKotlinScenarioCffi.validateForeignReferenceKind(referenceKind)
}
