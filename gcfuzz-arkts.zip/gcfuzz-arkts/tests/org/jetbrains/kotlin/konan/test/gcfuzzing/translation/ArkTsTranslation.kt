/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioEntityId
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue

/**
 * ArkTS translation (P3). Maps a prepared [ScenarioProgram] to a single `main.ets` file.
 *
 * Supported (see ArkTsScenarioCapabilities):
 *   definitions: Class, Global, Function
 *   ops: CreateObject, Store, Clear, Observe, PerformGc, AllocationBurst
 *   fields: StrongRef, TypedStrongRef, ObjectArray, IntValue, BooleanValue
 *   topologies: the pure-object-graph BASIC_GRAPH family (cycle/shared-node/global-reattach/
 *     old-root-churn/root-migration/delete-edge-then-gc/graph-mutation-sequence) — these emit
 *     only the ops above, so no special probe-sequence recognition is needed.
 * Anything else is a programming error: features that would emit it are not enabled, so this path
 * is unreachable in normal generation and fail-fasts if hand-written IR reaches it.
 */
internal fun ScenarioProgram.produceArkTs(config: ArkTsConfig): ArkTsOutput {
    val context = ArkTsScenarioTranslationContext(config, this)
    context.translate()
    val (ext, es2abcExtension) = when (config.outputMode) {
        ArkTsOutputMode.ETS -> "ets" to "ts"
        ArkTsOutputMode.JavaScript -> "js" to "js"
    }
    val entryFileName = "${config.moduleName}.$ext"
    return ArkTsOutput(
        files = linkedMapOf(entryFileName to context.contents.toString()),
        entryFileName = entryFileName,
        args = listOf("--module", "--extension", es2abcExtension, config.moduleName),
    )
}

private class ArkTsScenarioTranslationContext(
    private val config: ArkTsConfig,
    private val scenarioProgram: ScenarioProgram,
    val contents: OutputFileBuilder = OutputFileBuilder(),
) {
    private val scopeResolver = ArkTsGlobalScopeResolver(scenarioProgram)
    private val js: Boolean = config.outputMode == ArkTsOutputMode.JavaScript

    // Syntax helpers that vary by output mode. TS-only constructs are dropped in JS mode so the
    // output is valid under `es2abc --extension=js` strict mode (which rejects `interface`, type
    // annotations, `public`/`private`, `implements`, generics, `as`, and `enum`).
    private fun pub(): String = if (js) "" else "public "
    private fun colonType(t: String): String = if (js) "" else ": $t"
    private fun retType(t: String): String = if (js) "" else ": $t"
    private fun objNullable(): String = if (js) "" else "Object | null"
    private fun weakRefType(): String = if (js) "WeakRef" else "WeakRef<Object>"
    private fun arrayType(): String = if (js) "Array" else "Array<Object | null>"

    fun translate() {
        renderPrelude(contents, config)
        // IR entity ids (op.classId, globalId, functionId) are per-kind subset indices into the
        // filtered, kind-specific definition list (see Generator.chooseClass/chooseGlobal/
        // chooseFunction — they index generatedClasses/generatedGlobals/generatedFunctions, not
        // the global definitions list). So name each definition by its per-kind index, not by its
        // position in the full definitions list, or else `new Class${classId}` would reference a
        // Class named by a different (global) index and crash at runtime with ReferenceError.
        var globalIndex = 0
        var classIndex = 0
        var functionIndex = 0
        scenarioProgram.definitions.forEach { definition ->
            when (definition) {
                is ScenarioDefinition.Global -> translateGlobalDefinition(globalIndex++, definition)
                is ScenarioDefinition.Class -> translateClassDefinition(classIndex++, definition)
                is ScenarioDefinition.Function -> translateFunctionDefinition(functionIndex++, definition)
                is ScenarioDefinition.Interface,
                is ScenarioDefinition.SingletonObject -> unsupported(definition)
            }
        }
        translateMainFunction()
    }

    private fun translateField(field: ScenarioField, name: String, init: String) {
        // P2 supports StrongRef, TypedStrongRef, ObjectArray, IntValue, BooleanValue.
        // TypedStrongRef and ObjectArray are rendered as `Object | null` slots (the index-access
        // pattern treats them as opaque reference fields); ObjectArray's size is not needed at the
        // field-declaration level since stores replace the whole slot.
        when (field) {
            is ScenarioField.StrongRef,
            is ScenarioField.TypedStrongRef,
            is ScenarioField.ObjectArray -> contents.lineEnd("${pub()}$name${colonType(objNullable())} = $init")
            is ScenarioField.WeakRef -> contents.lineEnd("${pub()}$name${colonType("${weakRefType()} | null")} = $init")
            is ScenarioField.IntValue -> contents.lineEnd("${pub()}$name${colonType("number")} = anyToInt($init)")
            is ScenarioField.BooleanValue -> contents.lineEnd("${pub()}$name${colonType("boolean")} = anyToBoolean($init)")
            else -> unsupported(field)
        }
    }

    private fun translateGlobalDefinition(index: Int, definition: ScenarioDefinition.Global) {
        // Globals are module-level `let` bindings (no `public` modifier — that's illegal at top
        // level). Storage is always Shared in P3 (thread-local is unsupported/not generated).
        if (definition.storage is ScenarioGlobalStorage.ThreadLocal) unsupported(definition.storage)
        val type = when (definition.field) {
            is ScenarioField.StrongRef, is ScenarioField.TypedStrongRef, is ScenarioField.ObjectArray -> objNullable()
            is ScenarioField.WeakRef -> "${weakRefType()} | null"
            is ScenarioField.IntValue -> "number"
            is ScenarioField.BooleanValue -> "boolean"
            else -> unsupported(definition.field)
        }
        val init = if (definition.field is ScenarioField.IntValue) "0" else if (definition.field is ScenarioField.BooleanValue) "false" else "null"
        contents.lineEnd("let g$index${colonType(type)} = $init")
    }

    private fun translateClassDefinition(index: Int, definition: ScenarioDefinition.Class) {
        // P1: concrete classes only; no sealed, no nesting, no interfaces, no finalizer.
        if (definition.kind != ScenarioClassKind.Concrete || definition.nestedInClassId != null ||
            definition.lifecycle !is ScenarioClassLifecycle.None
        ) {
            unsupported(definition)
        }
        // ETS mode: `class ClassN implements ArkTsIndexAccess`. JS mode drops `implements` (and the
        // interface block is omitted from the prelude) — classes rely on duck-typed loadField/storeField.
        val implClause = if (js) "" else " implements ArkTsIndexAccess"
        contents.line("class Class$index$implClause")
        contents.braces {
            val ctorParams = definition.fields.indices.joinToString(", ") { "f$it${colonType(objNullable())}" }
            contents.lineEnd("constructor($ctorParams)")
            contents.braces {
                definition.fields.forEachIndexed { fieldIndex, _ ->
                    contents.lineEnd("this.f$fieldIndex = f$fieldIndex")
                }
            }
            definition.fields.forEachIndexed { fieldIndex, field ->
                translateField(field, "f$fieldIndex", "null")
            }
            contents.line("${pub()}loadField(index${colonType("number")})${retType(objNullable())}")
            contents.braces {
                if (definition.fields.isEmpty()) {
                    contents.lineEnd("return null")
                } else {
                    val idxCast = if (js) "" else " as number"
                    contents.line("switch ((index % ${definition.fields.size})$idxCast)")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, field ->
                            val loadExpr = when (field) {
                                is ScenarioField.WeakRef -> "this.f$fieldIndex?.deref()"
                                else -> "this.f$fieldIndex"
                            }
                            contents.lineEnd("case $fieldIndex: return $loadExpr;")
                        }
                        contents.lineEnd("default: return null;")
                    }
                }
            }
            contents.line("${pub()}storeField(index${colonType("number")}, value${colonType(objNullable())})${retType("void")}")
            contents.braces {
                if (definition.fields.isNotEmpty()) {
                    val idxCast = if (js) "" else " as number"
                    contents.line("switch ((index % ${definition.fields.size})$idxCast)")
                    contents.braces {
                        definition.fields.forEachIndexed { fieldIndex, field ->
                            val assignment = when (field) {
                                is ScenarioField.StrongRef,
                                is ScenarioField.TypedStrongRef,
                                is ScenarioField.ObjectArray -> "this.f$fieldIndex = value"
                                is ScenarioField.WeakRef -> "this.f$fieldIndex = value == null ? null : new ${weakRefType()}(value)"
                                is ScenarioField.IntValue -> "this.f$fieldIndex = anyToInt(value)"
                                is ScenarioField.BooleanValue -> "this.f$fieldIndex = anyToBoolean(value)"
                                else -> unsupported(field)
                            }
                            contents.lineEnd("case $fieldIndex: $assignment; break;")
                        }
                        contents.lineEnd("default: break;")
                    }
                }
            }
        }
        contents.lineEnd()
    }

    private fun translateFunctionDefinition(index: Int, definition: ScenarioDefinition.Function) {
        // Function bodies reference parameters as locals 0..n-1 (after preparation the domain is
        // ArkTs). Seed the body-local scope with those ids so renderValue/translateStore resolve them
        // as live locals (they are declared by the parameter list, not by a `let` inside).
        val params = definition.parameters
        val locals: MutableList<ScenarioEntityId> = (0 until params.size).toMutableList()
        val paramList = params.indices.joinToString(", ") { "l$it${colonType(objNullable())}" }
        contents.line("function fun$index($paramList)${retType(objNullable())}")
        contents.braces {
            translateBody(definition.body.body, locals)
            contents.lineEnd("return ${renderValue(definition.body.returnValue, locals)}")
        }
        contents.lineEnd()
    }

    private fun translateMainFunction() {
        contents.lineEnd()
        contents.line("function mainBodyImpl()${retType(objNullable())}")
        contents.braces {
            translateBody(scenarioProgram.mainBody)
            contents.lineEnd("return null")
        }
        contents.lineEnd()
        contents.line("function main()${retType("void")}")
        contents.braces {
            contents.line("for (let i = 0; i < ${config.mainLoopRepeatCount}; i++)")
            contents.braces {
                contents.lineEnd("if (shouldTerminate()) return")
                contents.lineEnd("mainBodyImpl()")
            }
            contents.lineEnd("terminationRequested = true")
            contents.lineEnd("tryGc()")
        }
        // Top-level invocation: ark_js_vm with --entry-point loads the module but does not
        // auto-invoke the entry function, so the generated case would otherwise only define
        // main() and exit immediately (module top-level runs, main never called). Call it
        // explicitly at top level, wrapped so a thrown FuzzControlException surfaces as a
        // visible message rather than a silent abort. print is available in ark_js_vm; console
        // is used as a fallback when present (e.g. Node).
        contents.lineEnd()
        contents.lineEnd("try {")
        contents.lineEnd("    main()")
        contents.lineEnd("} catch (e) {")
        contents.lineEnd("    ;(typeof console !== \"undefined\") ? console.log(\"fuzz-terminated:\", e) : print(\"fuzz-terminated:\", e)")
        contents.lineEnd("}")
        contents.lineEnd(";(typeof console !== \"undefined\") ? console.log(\"fuzz-case-done\") : print(\"fuzz-case-done\")")
    }

    private fun translateBody(body: ScenarioBody, locals: MutableList<ScenarioEntityId> = mutableListOf()) {
        body.statements.forEach { op -> translateOp(op, locals) }
    }

    private fun translateOp(op: ScenarioOp, locals: MutableList<ScenarioEntityId>) {
        when (op) {
            is ScenarioOp.CreateObject -> {
                val clazz = scopeResolver.resolveClass(op.classId)
                if (clazz == null) {
                    declareLocal(op.localId, locals, "null")
                    return
                }
                val args = (0 until clazz.fields.size).joinToString(", ") {
                    renderValue(op.args.getOrNull(it) ?: ScenarioValue.DefaultValue, locals)
                }
                declareLocal(op.localId, locals, "alloc(() => { return new Class${op.classId}($args); })")
            }
            is ScenarioOp.Store -> translateStore(op, locals)
            is ScenarioOp.Clear -> {
                // Clear = store null into the location (mirrors PureKotlin's translateClear).
                translateStore(ScenarioOp.Store(op.location, ScenarioValue.NullValue), locals)
            }
            is ScenarioOp.Observe -> {
                // P1 has no oracle: observe is a keep-alive statement referencing the value.
                contents.lineEnd(renderValue(op.value, locals))
            }
            is ScenarioOp.PerformGc -> contents.lineEnd("tryGc()")
            is ScenarioOp.Block -> {
                // Flatten the block's ops inline (locals share the enclosing scope, matching the
                // sample's lexical handling; no separate scope wrapper needed).
                translateBody(ScenarioBody(op.body), locals)
            }
            is ScenarioOp.CreateReachabilityObservation -> {
                // Best-effort oracle: store a WeakRef observation slot AND register the target with
                // the FinalizationRegistry so gcEpoch bumps when (if) the object is collected. The
                // registration is the link the prelude's `fr`/`gcEpoch` machinery needs to actually
                // observe collection — without it, assertReachability's DEAD branch has no "GC has
                // run" signal at all. Mirrors PureKotlin's createReachabilityObservation(value, WEAK).
                val v = renderValue(op.value, locals)
                contents.lineEnd("let o${op.observationId}${colonType("${weakRefType()} | null")} = ($v) == null ? null : new ${weakRefType()}($v)")
                contents.lineEnd("registerObservation(${op.observationId}, ($v))")
            }
            is ScenarioOp.CheckReachabilityObservation -> {
                // assertReachability derefs the stored observation. DEAD is best-effort (see prelude).
                val exp = if (op.expectation == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation.Alive) "ALIVE" else "DEAD"
                contents.lineEnd("assertReachability(\"${op.label}\", ReachabilityExpectation.$exp, o${op.observationId}?.deref())")
            }
            is ScenarioOp.CheckReachability -> {
                val exp = if (op.expectation == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation.Alive) "ALIVE" else "DEAD"
                val v = renderValue(op.value, locals)
                contents.lineEnd("assertReachability(\"${op.label}\", ReachabilityExpectation.$exp, $v)")
            }
            is ScenarioOp.AllocationBurst -> {
                val count = op.count.coerceAtLeast(1)
                val clazz = scopeResolver.resolveClass(op.classId)
                val argList = clazz?.let { c -> (0 until c.fields.size).joinToString(", ") { "null" } } ?: ""
                contents.line("for (let i = 0; i < $count; i++)")
                contents.braces {
                    contents.lineEnd("alloc(() => { return new Class${op.classId}($argList); })")
                }
            }
            else -> unsupported(op)
        }
    }

    private fun translateStore(statement: ScenarioOp.Store, locals: MutableList<ScenarioEntityId>) {
        val value = renderValue(statement.value, locals)
        when (val location = statement.location) {
            is ScenarioLocation.Global -> {
                val name = scopeResolver.computeGlobalName(location.globalId) ?: return
                translateStoreWithPath(name, location.path, value, statement.referenceKind, locals)
            }
            is ScenarioLocation.Local -> {
                val name = computeLocalName(location.localId, locals) ?: return
                translateStoreWithPath(name, location.path, value, statement.referenceKind, locals)
            }
            is ScenarioLocation.Singleton -> unsupported(location)
        }
    }

    private fun translateStoreWithPath(
        name: String,
        path: ScenarioPath,
        from: String,
        referenceKind: org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind,
        locals: MutableList<ScenarioEntityId>,
    ) {
        val loadAccessors = path.accessors.dropLast(1)
        val storeAccessor = path.accessors.lastOrNull()
        if (storeAccessor != null) {
            // Path store goes through storeField, whose case for a weak field wraps the value.
            val builder = StringBuilder(name)
            loadAccessors.forEach { builder.append("?.loadField($it)") }
            builder.append("?.storeField($storeAccessor, $from)")
            contents.lineEnd(builder.toString())
        } else {
            // Direct assignment. A Weak store into a WeakRef slot must wrap the value.
            val rhs = if (referenceKind == org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Weak) {
                "($from) == null ? null : new ${weakRefType()}($from)"
            } else {
                from
            }
            contents.lineEnd("$name = $rhs")
        }
    }

    private fun declareLocal(id: ScenarioEntityId, locals: MutableList<ScenarioEntityId>, rhs: String) {
        // P1: locals are flat (no scoping/nesting). Each local id is declared once with `let`,
        // subsequent stores become re-assignment.
        if (locals.none { it == id }) {
            locals.add(id)
            contents.lineEnd("let l$id${colonType(objNullable())} = $rhs")
        } else {
            contents.lineEnd("l$id = $rhs")
        }
    }

    private fun computeLocalName(id: ScenarioEntityId, locals: MutableList<ScenarioEntityId>): String? =
        if (locals.any { it == id }) "l$id" else null

    private fun renderValue(value: ScenarioValue, locals: MutableList<ScenarioEntityId>): String = when (value) {
        ScenarioValue.DefaultValue, ScenarioValue.NullValue -> "null"
        is ScenarioValue.GlobalRef -> {
            val name = scopeResolver.computeGlobalName(value.globalId) ?: "null"
            if (name == "null") name else name + value.path.accessors.joinToString("") { "?.loadField($it)" }
        }
        is ScenarioValue.LocalRef -> {
            val name = if (locals.any { it == value.localId }) "l${value.localId}" else "null"
            if (name == "null") name else name + value.path.accessors.joinToString("") { "?.loadField($it)" }
        }
        is ScenarioValue.SingletonRef -> unsupported(value)
    }

    private fun unsupported(any: Any): Nothing = error("ArkTS P1 translation does not support $any (feature not enabled in ArkTsScenarioGenerationProfile)")
}

private class ArkTsGlobalScopeResolver(private val program: ScenarioProgram) {
    private val definitions = program.definitions

    private fun isAvailable(definition: ScenarioDefinition): Boolean =
        definition.targetLanguage == ScenarioTargetLanguage.ArkTs

    fun resolveClass(id: ScenarioEntityId): ScenarioDefinition.Class? =
        definitions.filterIsInstance<ScenarioDefinition.Class>().filter(::isAvailable).getOrNull(id)

    fun resolveGlobal(id: ScenarioEntityId): ScenarioDefinition.Global? =
        definitions.filterIsInstance<ScenarioDefinition.Global>().filter(::isAvailable).getOrNull(id)

    fun computeGlobalName(id: ScenarioEntityId): String? = resolveGlobal(id)?.let { "g$id" }
}

private fun renderPrelude(contents: OutputFileBuilder, config: ArkTsConfig) {
    // ArkTS does not expose a public force-GC API. tryGc() applies allocation pressure and observes
    // via FinalizationRegistry best-effort; P1 uses it as a stress sink (no oracle assertions yet).
    if (config.outputMode == ArkTsOutputMode.JavaScript) {
        // Plain-JS prelude: valid under `es2abc --extension=js` strict mode. Drops `interface`,
        // type annotations, `public`/`private`, `implements`, generics, `as`, and renders the
        // reachability-enum as a const object (JS strict mode rejects TS `enum`). Verified to run
        // under ark_js_vm (seed-7: 30s, fuzz-case-done) and Node.
        contents.raw(
            """
            |class ArkTsArrayBox {
            |    values;
            |    constructor(size, seed) {
            |        const len = size > 0 ? size : 1;
            |        this.values = new Array(len).fill(null);
            |        if (len > 0) { this.values[0] = seed; }
            |    }
            |    loadField(index) {
            |        return this.values[index % this.values.length];
            |    }
            |    storeField(index, value) {
            |        this.values[index % this.values.length] = value;
            |    }
            |}
            |
            |function anyToInt(value) {
            |    if (typeof value === "number") { return value; }
            |    if (typeof value === "boolean") { return value ? 1 : 0; }
            |    return 0;
            |}
            |
            |function anyToBoolean(value) {
            |    if (typeof value === "boolean") { return value; }
            |    if (typeof value === "number") { return value !== 0; }
            |    return false;
            |}
            |
            |class FuzzControlException extends Error {
            |    payload;
            |    constructor(payload) {
            |        super("FuzzControlException");
            |        this.payload = payload;
            |    }
            |}
            |
            |let terminationRequested = false;
            |const startTimeMs = Date.now();
            |const GC_PRESSURE = 4096;
            |let pressureSink = new Array(GC_PRESSURE).fill(null);
            |
            |function shouldTerminate() {
            |    if (terminationRequested) { return true; }
            |    if ((Date.now() - startTimeMs) <= ${config.softTimeoutMillis}) { return false; }
            |    terminationRequested = true;
            |    return true;
            |}
            |
            |function tryGc() {
            |    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
            |    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
            |    for (let i = 0; i < GC_PRESSURE; i++) {
            |        if (shouldTerminate()) { return; }
            |        pressureSink[i % GC_PRESSURE] = { n: i };
            |    }
            |    pressureSink = new Array(GC_PRESSURE).fill(null);
            |}
            |
            |function alloc(block) {
            |    if (shouldTerminate()) { return null; }
            |    return block();
            |}
            |
            |// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
            |// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
            |// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
            |// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
            |// of kotlin.native.runtime.GC.collect().
            |const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
            |let gcEpoch = 0;
            |const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
            |function assertReachability(label, expectation, value) {
            |    if (expectation === ReachabilityExpectation.ALIVE) {
            |        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
            |    } else {
            |        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
            |        // non-null value here is NOT treated as a hard failure (would drown in false positives).
            |        // Real GC bugs still surface as crashes/aborts from the runtime itself.
            |    }
            |}
            |function registerObservation(observationId, target) {
            |    if (target != null) { fr.register(target, target); }
            |}
            |
            """.trimMargin()
        )
        return
    }
    contents.raw(
        """
        |interface ArkTsIndexAccess {
        |    loadField(index: number): Object | null;
        |    storeField(index: number, value: Object | null): void;
        |}
        |
        |class ArkTsArrayBox implements ArkTsIndexAccess {
        |    private values: Array<Object | null>;
        |    constructor(size: number, seed: Object | null) {
        |        const len = size > 0 ? size : 1;
        |        this.values = new Array<Object | null>(len).fill(null);
        |        if (len > 0) { this.values[0] = seed; }
        |    }
        |    public loadField(index: number): Object | null {
        |        return this.values[index % this.values.length];
        |    }
        |    public storeField(index: number, value: Object | null): void {
        |        this.values[index % this.values.length] = value;
        |    }
        |}
        |
        |function anyToInt(value: Object | null): number {
        |    if (typeof value === "number") { return value as number; }
        |    if (typeof value === "boolean") { return value ? 1 : 0; }
        |    return 0;
        |}
        |
        |function anyToBoolean(value: Object | null): boolean {
        |    if (typeof value === "boolean") { return value as boolean; }
        |    if (typeof value === "number") { return (value as number) !== 0; }
        |    return false;
        |}
        |
        |class FuzzControlException extends Error {
        |    public payload: Object | null;
        |    constructor(payload: Object | null) {
        |        super("FuzzControlException");
        |        this.payload = payload;
        |    }
        |}
        |
        |let terminationRequested: boolean = false;
        |const startTimeMs: number = Date.now();
        |const GC_PRESSURE: number = 4096;
        |let pressureSink: Array<Object | null> = new Array<Object | null>(GC_PRESSURE).fill(null);
        |
        |function shouldTerminate(): boolean {
        |    if (terminationRequested) { return true; }
        |    if ((Date.now() - startTimeMs) <= ${config.softTimeoutMillis}) { return false; }
        |    terminationRequested = true;
        |    return true;
        |}
        |
        |function tryGc(): void {
        |    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
        |    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
        |    for (let i = 0; i < GC_PRESSURE; i++) {
        |        if (shouldTerminate()) { return; }
        |        pressureSink[i % GC_PRESSURE] = { n: i };
        |    }
        |    pressureSink = new Array<Object | null>(GC_PRESSURE).fill(null);
        |}
        |
        |function alloc(block: () => Object | null): Object | null {
        |    if (shouldTerminate()) { return null; }
        |    return block();
        |}
        |
        |// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
        |// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
        |// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
        |// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
        |// of kotlin.native.runtime.GC.collect().
        |enum ReachabilityExpectation { ALIVE, DEAD }
        |let gcEpoch: number = 0;
        |const fr: FinalizationRegistry<Object> = new FinalizationRegistry((_held: Object) => { gcEpoch = gcEpoch + 1; });
        |function assertReachability(label: string, expectation: number, value: Object | null): void {
        |    if (expectation === ReachabilityExpectation.ALIVE) {
        |        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
        |    } else {
        |        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        |        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        |        // Real GC bugs still surface as crashes/aborts from the runtime itself.
        |    }
        |}
        |function registerObservation(observationId: number, target: Object | null): void {
        |    if (target != null) { fr.register(target, target); }
        |}
        |
        """.trimMargin()
    )
}
