/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.debug

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue

internal object DebugScenarioBackend {
    fun render(program: ScenarioProgram): String = buildString {
        appendLine("program {")
        appendLine("  definitions {")
        program.definitions.forEach { definition ->
            appendLine(renderDefinition(definition, indent = "    "))
        }
        appendLine("  }")
        appendLine("  main {")
        append(renderBody(program.mainBody, indent = "    "))
        appendLine("  }")
        appendLine("}")
    }

    private fun renderDefinition(definition: ScenarioDefinition, indent: String): String = when (definition) {
        is ScenarioDefinition.Class ->
            buildString {
                append("$indent class(lang=${renderLanguage(definition.targetLanguage)}, kind=${definition.kind.name}, fields=${definition.fields.joinToString(prefix = "[", postfix = "]", transform = ::renderField)}, interfaces=${definition.interfaces}")
                definition.superClassId?.let { append(", super=$it") }
                definition.sealedPayloadFieldId?.let { append(", sealedPayloadField=$it") }
                definition.nestedInClassId?.let { append(", nestedIn=$it") }
                definition.outerCaptureFieldId?.let { append(", outerCaptureField=$it") }
                when (val lifecycle = definition.lifecycle) {
                    ScenarioClassLifecycle.None -> append(", lifecycle=none)")
                    is ScenarioClassLifecycle.Finalizer -> {
                        appendLine(", lifecycle=finalizer) {")
                        append(renderBody(lifecycle.body, "$indent  "))
                        append("$indent}")
                    }
                }
            }
        is ScenarioDefinition.Interface -> "$indent interface(lang=${renderLanguage(definition.targetLanguage)})"
        is ScenarioDefinition.SingletonObject ->
            "$indent singleton(lang=${renderLanguage(definition.targetLanguage)}, fields=${definition.fields.joinToString(prefix = "[", postfix = "]", transform = ::renderField)})"
        is ScenarioDefinition.Function -> buildString {
            appendLine("$indent function(lang=${renderLanguage(definition.targetLanguage)}, params=${definition.parameters.size}, return=${renderType(definition.returnType)}) {")
            append(renderBody(definition.body.body, "$indent  "))
            appendLine("$indent  return ${renderValue(definition.body.returnValue)}")
            append("$indent}")
        }
        is ScenarioDefinition.Global ->
            "$indent global(lang=${renderLanguage(definition.targetLanguage)}, field=${renderField(definition.field)}, storage=${renderStorage(definition.storage)})"
    }

    private fun renderBody(body: ScenarioBody, indent: String): String = buildString {
        body.statements.forEach { op ->
            appendLine(renderOp(op, indent))
        }
    }

    private fun renderNestedBody(statements: List<ScenarioOp>, indent: String): String = buildString {
        statements.forEach { op ->
            appendLine(renderOp(op, indent))
        }
    }

    private fun renderOp(op: ScenarioOp, indent: String): String = when (op) {
        is ScenarioOp.CreateObject ->
            "$indent alloc local=${op.localId} class=${op.classId} args=${op.args.joinToString(prefix = "[", postfix = "]", transform = ::renderValue)} domain=${op.domain.name}"
        is ScenarioOp.Store ->
            "$indent store ${renderLocation(op.location)} <- ${renderValue(op.value)} ref=${op.referenceKind.name}"
        is ScenarioOp.Clear ->
            "$indent clear ${renderLocation(op.location)}"
        is ScenarioOp.CompareAndSet ->
            "$indent compareAndSet ${renderLocation(op.location)} expected=${renderValue(op.expectedValue)} new=${renderValue(op.newValue)} domain=${op.domain.name}"
        is ScenarioOp.StoreBatch -> buildString {
            appendLine("${indent}storeBatch {")
            op.stores.forEach { store ->
                appendLine("$indent  store ${renderLocation(store.location)} <- ${renderValue(store.value)} ref=${store.referenceKind.name}")
            }
            append("$indent}")
        }
        is ScenarioOp.Observe ->
            "$indent observe ${renderValue(op.value)}"
        is ScenarioOp.ForeignRoundTrip ->
            "$indent foreignRoundTrip ${renderValue(op.value)} ref=${op.referenceKind.name} pattern=${op.pattern.name} repetitions=${op.repetitions}"
        is ScenarioOp.CreateReachabilityObservation ->
            "$indent createReachabilityObservation id=${op.observationId} value=${renderValue(op.value)} kind=${op.kind.name}"
        is ScenarioOp.CheckReachabilityObservation ->
            "$indent checkReachabilityObservation id=${op.observationId} expectation=${renderReachabilityExpectation(op.expectation)} label=${op.label}"
        is ScenarioOp.CheckReachability ->
            "$indent checkReachability ${renderValue(op.value)} expectation=${renderReachabilityExpectation(op.expectation)} label=${op.label}"
        is ScenarioOp.PerformGc ->
            "$indent gc domain=${op.domain?.name ?: "any"}"
        is ScenarioOp.GcEpoch ->
            "$indent gcEpoch count=${op.count} yieldBetween=${op.yieldBetween} domain=${op.domain?.name ?: "any"}"
        is ScenarioOp.Block -> buildString {
            appendLine("${indent}block {")
            append(renderNestedBody(op.body, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.ScopedRoot -> buildString {
            appendLine("${indent}scopedRoot local=${op.localId} value=${renderValue(op.value)} {")
            append(renderNestedBody(op.body, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.If -> buildString {
            appendLine("${indent}if ${renderValue(op.condition)} {")
            append(renderNestedBody(op.thenBody, "$indent  "))
            appendLine("$indent} else {")
            append(renderNestedBody(op.elseBody, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.TryFinally -> buildString {
            appendLine("${indent}try {")
            append(renderNestedBody(op.body, "$indent  "))
            appendLine("$indent} finally {")
            append(renderNestedBody(op.finallyBody, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.Return ->
            "$indent return ${renderValue(op.value)}"
        is ScenarioOp.Throw ->
            "$indent throw ${renderValue(op.value)}"
        is ScenarioOp.Spawn -> buildString {
            appendLine("${indent}spawnBody join=${op.join} {")
            append(renderNestedBody(op.body, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.SpawnWithResult -> buildString {
            appendLine("${indent}spawnWithResult local=${op.localId} returnValue=${renderValue(op.returnValue)} domain=${op.domain.name} {")
            append(renderNestedBody(op.body, "$indent  "))
            append("$indent}")
        }
        is ScenarioOp.SpawnFunction ->
            "$indent spawn fn=${op.functionId} args=${op.args.joinToString(prefix = "[", postfix = "]", transform = ::renderValue)} domain=${op.domain.name}"
        is ScenarioOp.AllocationBurst ->
            "$indent allocBurst class=${op.classId} count=${op.count} domain=${op.domain.name}"
        is ScenarioOp.Signal ->
            "$indent signal checkpoint=${op.checkpointId}"
        is ScenarioOp.Wait ->
            "$indent wait checkpoint=${op.checkpointId}"
        ScenarioOp.Yield ->
            "$indent yield"
        is ScenarioOp.CallFunction ->
            "$indent call fn=${op.functionId} args=${op.args.joinToString(prefix = "[", postfix = "]", transform = ::renderValue)} domain=${op.domain.name}"
        is ScenarioOp.InterfaceDispatch ->
            "$indent interfaceDispatch local=${op.localId} receiver=${renderValue(op.receiver)} interface=${op.interfaceId} domain=${op.domain.name}"
        is ScenarioOp.SealedDispatch ->
            "$indent sealedDispatch local=${op.localId} receiver=${renderValue(op.receiver)} sealedClass=${op.sealedClassId} domain=${op.domain.name}"
        is ScenarioOp.SingletonAccess ->
            "$indent singletonAccess local=${op.localId} singleton=${op.singletonId} field=${op.fieldId} domain=${op.domain.name}"
        is ScenarioOp.CreateInnerObject ->
            "$indent allocInner local=${op.localId} outer=${renderValue(op.outer)} class=${op.classId} args=${op.args.joinToString(prefix = "[", postfix = "]", transform = ::renderValue)} domain=${op.domain.name}"
        is ScenarioOp.OuterDispatch ->
            "$indent outerDispatch local=${op.localId} receiver=${renderValue(op.receiver)} class=${op.classId} domain=${op.domain.name}"
    }

    private fun renderValue(value: ScenarioValue): String = when (value) {
        ScenarioValue.DefaultValue -> "default"
        ScenarioValue.NullValue -> "null"
        is ScenarioValue.LocalRef -> "local(${value.localId}, path=${renderPath(value.path)}, domain=${value.domain.name})"
        is ScenarioValue.GlobalRef -> "global(${value.globalId}, path=${renderPath(value.path)}, domain=${value.domain.name})"
        is ScenarioValue.SingletonRef -> "singleton(${value.singletonId}, path=${renderPath(value.path)}, domain=${value.domain.name})"
    }

    private fun renderLocation(location: ScenarioLocation): String = when (location) {
        is ScenarioLocation.Local -> "local(${location.localId}, path=${renderPath(location.path)}, domain=${location.domain.name})"
        is ScenarioLocation.Global -> "global(${location.globalId}, path=${renderPath(location.path)}, domain=${location.domain.name})"
        is ScenarioLocation.Singleton -> "singleton(${location.singletonId}, path=${renderPath(location.path)}, domain=${location.domain.name})"
    }

    private fun renderPath(path: ScenarioPath): String =
        path.accessors.joinToString(prefix = "[", postfix = "]")

    private fun renderLanguage(language: ScenarioTargetLanguage): String = when (language) {
        ScenarioTargetLanguage.Kotlin -> "kotlin"
        ScenarioTargetLanguage.ObjC -> "objc"
        ScenarioTargetLanguage.Java -> "java"
        ScenarioTargetLanguage.ArkTs -> "arkts"
    }

    private fun renderStorage(storage: ScenarioGlobalStorage): String = when (storage) {
        ScenarioGlobalStorage.Shared -> "shared"
        ScenarioGlobalStorage.ThreadLocal -> "threadLocal"
    }

    private fun renderField(field: ScenarioField): String = when (field) {
        ScenarioField.StrongRef -> "strongRef"
        is ScenarioField.TypedStrongRef -> "typedStrongRef(${renderType(field.type)})"
        ScenarioField.WeakRef -> "weakRef"
        ScenarioField.IntValue -> "int"
        ScenarioField.BooleanValue -> "boolean"
        is ScenarioField.ObjectArray -> "objectArray(${field.size})"
    }

    private fun renderType(type: org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType): String = when (type) {
        org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType.AnyRef -> "anyRef"
        is org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType.InterfaceRef -> "interface(${type.interfaceId})"
        is org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType.ClassRef -> "class(${type.classId})"
        is org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType.SingletonRef -> "singleton(${type.singletonId})"
    }

    private fun renderReachabilityExpectation(expectation: ScenarioReachabilityExpectation): String = when (expectation) {
        ScenarioReachabilityExpectation.Alive -> "alive"
        ScenarioReachabilityExpectation.Dead -> "dead"
    }
}
