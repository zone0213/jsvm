/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBodyWithReturn
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioClassLifecycle
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignInteractionPattern
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioGlobalStorage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityExpectation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioReachabilityObservationKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend.PureKotlinScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.globalLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.globalValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.localLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.test.support.localValue
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import kotlin.test.assertContains
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PureKotlinScenarioTranslationTest {
    @Test
    fun pureKotlinInterfacePolymorphismUsesTypedSlotsAndDispatch() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0)),
                    ),
                    ScenarioDefinition.Interface(ScenarioTargetLanguage.Kotlin),
                    ScenarioDefinition.Class(
                        ScenarioTargetLanguage.Kotlin,
                        listOf(ScenarioField.StrongRef, ScenarioField.TypedStrongRef(ScenarioType.InterfaceRef(0))),
                        interfaces = listOf(0),
                        dispatchFieldId = 0,
                    ),
                    ScenarioDefinition.Class(
                        ScenarioTargetLanguage.Kotlin,
                        listOf(ScenarioField.StrongRef),
                        interfaces = listOf(0),
                        dispatchFieldId = 0,
                    ),
                    ScenarioDefinition.Function(
                        ScenarioTargetLanguage.Kotlin,
                        emptyList(),
                        ScenarioBodyWithReturn(
                            ScenarioBody(
                                listOf(
                                    ScenarioOp.CreateObject(0, 0, declaredType = ScenarioType.InterfaceRef(0)),
                                )
                            ),
                            ScenarioValue.LocalRef(0),
                        ),
                        returnType = ScenarioType.InterfaceRef(0),
                    ),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0, declaredType = ScenarioType.InterfaceRef(0)),
                        ScenarioOp.Store(ScenarioLocation.Global(0), ScenarioValue.LocalRef(0)),
                        ScenarioOp.InterfaceDispatch(1, ScenarioValue.LocalRef(0), 0),
                        ScenarioOp.InterfaceDispatch(2, ScenarioValue.GlobalRef(0), 0),
                    )
                ),
            )
        )

        val contents = output.contents
        assertContains(contents, "interface Interface1")
        assertContains(contents, "class Class2(f0: Any?, f1: Any?) : KotlinIndexAccess, Interface1")
        assertContains(contents, "override fun dispatchPayload(): Any? = f0")
        assertContains(contents, "private var g0: Interface1?")
        assertContains(contents, "var l0: Interface1? = alloc")
        assertContains(contents, "fun fun4(localsCount: Int): Interface1?")
        assertContains(contents, "as? Interface1)?.dispatchPayload()")
    }

    @Test
    fun pureKotlinSecondBatchTypeSystemStructuresUseSharedIr() {
        val output = PureKotlinScenarioBackend.lower(secondBatchTypeSystemScenario())

        val contents = output.contents
        assertContains(contents, "private var g0: Class2?")
        assertContains(contents, "object Object1 : KotlinIndexAccess")
        assertContains(contents, "sealed class Class2() : KotlinIndexAccess")
        assertContains(contents, "class Class3(f0: Any?) : Class2()")
        assertContains(contents, "class Class4(f0: Any?) : Class2()")
        assertContains(contents, "when (val sealedReceiver = g0 as? Class2)")
        assertContains(contents, "Object1.loadKotlinField(0)")
        assertContains(contents, "class Class5(f0: Any?) : KotlinIndexAccess")
        assertContains(contents, "inner class Class6(f0: Any?) : KotlinIndexAccess")
        assertContains(contents, "this@Class5.loadKotlinField(0)")
        assertContains(contents, "as? Class5)?.Class6")
        assertContains(contents, "as? Class5.Class6)?.outerPayload()")
    }

    @Test
    fun pureKotlinSharedFieldsAreAtomic() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.StrongRef,
                        storage = ScenarioGlobalStorage.ThreadLocal,
                    ),
                    ScenarioDefinition.Class(
                        ScenarioTargetLanguage.Kotlin,
                        listOf(ScenarioField.StrongRef, ScenarioField.WeakRef, ScenarioField.ObjectArray(4)),
                    ),
                ),
                mainBody = ScenarioBody(emptyList()),
            )
        )

        val contents = output.contents
        assertContains(contents, "import kotlin.concurrent.atomics.AtomicArray")
        assertContains(contents, "import kotlin.concurrent.atomics.AtomicReference")
        assertContains(contents, "private val g0Impl = AtomicReference<Any?>(null)")
        assertContains(contents, "@ThreadLocal\nprivate var g1: Any? = null")
        assertContains(contents, "private val f0Impl = AtomicReference<Any?>(f0)")
        assertContains(contents, "private val f1Impl = AtomicReference<WeakReference<Any>?>(f1?.let { WeakReference(it) })")
        assertContains(contents, "private val f2Impl = AtomicReference(anyToArrayBox(f2, 4))")
        assertContains(contents, "private val values = AtomicArray<Any?>(size.coerceAtLeast(1))")
    }

    @Test
    fun pureKotlinSchedulingOpsUseCheckpoints() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = emptyList(),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Signal(3),
                        ScenarioOp.Wait(3),
                        ScenarioOp.Yield,
                    )
                ),
            )
        )

        val contents = output.contents
        assertContains(contents, "private val checkpoints = AtomicArray<Int>(64) { 0 }")
        assertContains(contents, "private fun signalCheckpoint(id: Int)")
        assertContains(contents, "private fun waitCheckpoint(id: Int)")
        assertContains(contents, "private fun yieldCheckpoint()")
        assertContains(contents, "signalCheckpoint(3)")
        assertContains(contents, "waitCheckpoint(3)")
        assertContains(contents, "yieldCheckpoint()")
    }

    @Test
    fun pureKotlinGcLifecycleOpsAreRendered() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0),
                        ScenarioOp.Store(globalLocation(0), localValue(0)),
                        ScenarioOp.Clear(globalLocation(0)),
                        ScenarioOp.StoreBatch(
                            listOf(
                                ScenarioOp.Store(localLocation(0, 0), localValue(0)),
                                ScenarioOp.Store(localLocation(0, 0), ScenarioValue.NullValue),
                            )
                        ),
                        ScenarioOp.GcEpoch(count = 2),
                        ScenarioOp.ScopedRoot(
                            localId = 1,
                            value = localValue(0),
                            body = listOf(
                                ScenarioOp.Observe(localValue(1)),
                                ScenarioOp.Clear(localLocation(1)),
                            ),
                        ),
                        ScenarioOp.Spawn(
                            body = listOf(
                                ScenarioOp.Observe(globalValue(0)),
                            ),
                            join = true,
                        ),
                    )
                ),
            )
        )

        val contents = output.contents
        assertContains(contents, "g0 = null")
        assertContains(contents, "l0?.storeField(0, l0)")
        assertContains(contents, "l0?.storeField(0, null)")
        assertContains(contents, "repeat(2)")
        assertContains(contents, "performGC()")
        assertContains(contents, "run")
        assertContains(contents, "var l1: Any? = l0")
        assertContains(contents, "var l2: Any? = l1")
        assertContains(contents, "l1 = null")
        assertContains(contents, "spawnThreadAndJoin")
        assertContains(contents, "private fun spawnThreadAndJoin(block: () -> Unit)")
    }

    @Test
    fun pureKotlinWorkerResultAndGlobalCasUseRealAtomicOperations() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Global(
                        ScenarioTargetLanguage.Kotlin,
                        ScenarioField.StrongRef,
                        ScenarioGlobalStorage.Shared,
                    ),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 1),
                        ScenarioOp.CreateObject(1, 1),
                        ScenarioOp.SpawnWithResult(
                            localId = 2,
                            returnValue = ScenarioValue.LocalRef(3),
                            body = listOf(ScenarioOp.CreateObject(3, 1)),
                        ),
                        ScenarioOp.CompareAndSet(
                            location = ScenarioLocation.Global(0),
                            expectedValue = ScenarioValue.LocalRef(0),
                            newValue = ScenarioValue.LocalRef(1),
                        ),
                        ScenarioOp.Clear(ScenarioLocation.Local(2)),
                    ),
                ),
            ),
        )

        val contents = output.contents
        assertContains(contents, "var l2: Any? = spawnThreadWithResult")
        assertContains(contents, "if (completed.load()) return result.load()")
        assertContains(contents, "g0Impl.compareAndSet(l0, l1)")
        assertContains(contents, "l2 = null")
        assertFalse("compareAndSetSlot" in contents, "CAS must target the shared global AtomicReference directly")
    }

    @Test
    fun pureKotlinClassLifecycleFinalizerUsesCleaner() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(
                        ScenarioTargetLanguage.Kotlin,
                        listOf(ScenarioField.StrongRef),
                        ScenarioClassLifecycle.Finalizer(
                            ScenarioBody(
                                listOf(
                                    ScenarioOp.CreateObject(0, 1),
                                    ScenarioOp.Store(globalLocation(0), localValue(0)),
                                    ScenarioOp.AllocationBurst(1, 8),
                                )
                            )
                        ),
                    ),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ),
                mainBody = ScenarioBody(emptyList()),
            )
        )

        val contents = output.contents
        assertContains(contents, "import kotlin.native.ref.createCleaner")
        assertContains(contents, "private val lifecycleCleaner = createCleaner(Unit){")
        assertContains(contents, "var l0: Any? = alloc({ Class1() })")
        assertContains(contents, "g2 = l0")
        assertContains(contents, "repeat(8)")
        assertContains(contents, "alloc({ Class1() })")
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinPerformGcAfterRootMigration() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.BooleanValue, ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.WeakRef, ScenarioField.StrongRef)),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0),
                        ScenarioOp.CreateObject(1, 1),
                        ScenarioOp.CreateObject(2, 2),
                        ScenarioOp.Store(localLocation(0, 1), localValue(1)),
                        ScenarioOp.Store(globalLocation(0), localValue(0)),
                        ScenarioOp.Store(localLocation(2, 1), globalValue(0, 1)),
                        ScenarioOp.Store(localLocation(0, 1), ScenarioValue.NullValue),
                        ScenarioOp.Store(globalLocation(0), ScenarioValue.NullValue),
                        ScenarioOp.CreateReachabilityObservation(
                            0,
                            localValue(2, 1),
                            ScenarioReachabilityObservationKind.Weak,
                        ),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Alive,
                            "root-migration.target-alive-after-gc",
                        ),
                        ScenarioOp.Observe(localValue(2, 1)),
                    )
                ),
            )
        )

        val contents = output.contents
        assertContains(contents, "prepareRootMigrationProbe(")
        assertContains(contents, "{ owner, payload -> owner?.storeField(1, payload) }")
        assertContains(contents, "{ owner -> g3 = owner }")
        assertContains(contents, "{ target, owner -> target?.storeField(1, owner?.loadField(1)) }")
        assertContains(contents, "{ owner -> owner?.storeField(1, null) }")
        assertContains(contents, "{ g3 = null }")
        assertContains(contents, "assertReachability(\"root-migration.target-alive-after-gc\", ReachabilityExpectation.ALIVE, _rootMigrationProbe0.loadObserved())")
        assertContains(contents, "o0 = _rootMigrationProbe0.observation")
    }

    @Test
    fun pureKotlinWeakReachabilityStressIsRenderedAfterGc() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.WeakRef),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Block(
                            listOf(
                                ScenarioOp.CreateObject(0, 0),
                                ScenarioOp.Store(globalLocation(0), localValue(0)),
                                ScenarioOp.CreateReachabilityObservation(
                                    0,
                                    globalValue(0),
                                    ScenarioReachabilityObservationKind.Weak,
                                ),
                                ScenarioOp.Store(globalLocation(1), globalValue(0), referenceKind = org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind.Weak),
                                ScenarioOp.Store(globalLocation(0), ScenarioValue.NullValue),
                            )
                        ),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.Observe(globalValue(1)),
                    )
                ),
            )
        )

        assertContains(
            output.contents,
            "prepareWeakReachabilityProbe({ alloc({ Class0() }) }, { value -> g1 = value }, { value -> o0 = createReachabilityObservation(value, ReachabilityObservationKind.WEAK) }, { value -> g2 = value })",
        )
        assertContains(
            output.contents,
            "performGC()",
        )
        assertContains(
            output.contents,
            "var l0: Any? = g2",
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinWeakDeadCapsuleOracleIsRenderedAfterGc() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Block(
                            listOf(
                                ScenarioOp.CreateObject(0, 0),
                                ScenarioOp.CreateReachabilityObservation(
                                    0,
                                    localValue(0),
                                    ScenarioReachabilityObservationKind.Weak,
                                ),
                            )
                        ),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Dead,
                            "weak-dead-capsule.dead-after-first-gc",
                        ),
                    )
                ),
            )
        )

        assertContains(
            output.contents,
            "prepareWeakDeadObservationProbe({ alloc({ Class0() }) }, { value -> createReachabilityObservation(value, ReachabilityObservationKind.WEAK) })",
        )
        assertContains(output.contents, "o0 = _weakDeadProbe0.observation")
        assertContains(
            output.contents,
            "assertReachability(\"weak-dead-capsule.dead-after-first-gc\", ReachabilityExpectation.DEAD, _weakDeadProbe0.loadObserved())",
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinSingleStrongSlotOracleUsesStrongFieldSlot() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.BooleanValue, ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Block(
                            listOf(
                                ScenarioOp.CreateObject(0, 0),
                                ScenarioOp.CreateObject(1, 1),
                                ScenarioOp.Store(localLocation(0, 1), localValue(1)),
                                ScenarioOp.Store(globalLocation(0), localValue(0)),
                                ScenarioOp.CreateReachabilityObservation(
                                    0,
                                    globalValue(0, 1),
                                    ScenarioReachabilityObservationKind.Weak,
                                ),
                            )
                        ),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Alive,
                            "single-strong-slot.alive-after-publish",
                        ),
                        ScenarioOp.Store(globalLocation(0, 1), ScenarioValue.NullValue),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Dead,
                            "single-strong-slot.dead-after-clear",
                        ),
                    )
                ),
            )
        )

        assertContains(
            output.contents,
            "prepareReachabilityConsistencyProbe({ alloc({ Class0(null, null) }) }, { alloc({ Class1() }) }, { owner, payload -> owner?.storeField(1, payload) }, { owner -> g2 = owner }, { owner -> createReachabilityObservation(owner?.loadField(1), ReachabilityObservationKind.WEAK) }, { owner -> owner?.storeField(1, null) }, { owner -> owner?.loadField(1) })",
        )
        assertContains(
            output.contents,
            "assertReachability(\"single-strong-slot.alive-after-publish\", ReachabilityExpectation.ALIVE, _reachabilityProbe0.loadObserved())",
        )
        assertContains(
            output.contents,
            "assertReachability(\"single-strong-slot.dead-after-clear\", ReachabilityExpectation.DEAD, _reachabilityProbe0.loadObserved())",
        )
    }

    @Test
    @Disabled("Oracle capsule tests are disabled until oracle semantics are re-enabled")
    fun pureKotlinReachabilityConsistencyOracleReusesObservationAcrossCheckpoints() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.BooleanValue, ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, emptyList()),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.Block(
                            listOf(
                                ScenarioOp.CreateObject(0, 0),
                                ScenarioOp.CreateObject(1, 1),
                                ScenarioOp.Store(localLocation(0, 1), localValue(1)),
                                ScenarioOp.Store(globalLocation(0), localValue(0)),
                                ScenarioOp.CreateReachabilityObservation(
                                    0,
                                    globalValue(0, 1),
                                    ScenarioReachabilityObservationKind.Weak,
                                ),
                            )
                        ),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Alive,
                            "reachability-consistency.alive-after-publish",
                        ),
                        ScenarioOp.Store(globalLocation(0, 1), ScenarioValue.NullValue),
                        ScenarioOp.PerformGc(),
                        ScenarioOp.CheckReachabilityObservation(
                            0,
                            ScenarioReachabilityExpectation.Dead,
                            "reachability-consistency.dead-after-clear",
                        ),
                    )
                ),
            )
        )

        assertContains(
            output.contents,
            "prepareReachabilityConsistencyProbe({ alloc({ Class0(null, null) }) }, { alloc({ Class1() }) }, { owner, payload -> owner?.storeField(1, payload) }, { owner -> g2 = owner }, { owner -> createReachabilityObservation(owner?.loadField(1), ReachabilityObservationKind.WEAK) }, { owner -> owner?.storeField(1, null) }, { owner -> owner?.loadField(1) })",
        )
        assertContains(
            output.contents,
            "o0 = _reachabilityProbe0.observation",
        )
        assertContains(
            output.contents,
            "assertReachability(\"reachability-consistency.alive-after-publish\", ReachabilityExpectation.ALIVE, _reachabilityProbe0.loadObserved())",
        )
        assertContains(
            output.contents,
            "assertReachability(\"reachability-consistency.dead-after-clear\", ReachabilityExpectation.DEAD, _reachabilityProbe0.loadObserved())",
        )
    }

    @Test
    fun pureKotlinConcurrentRootMigrationUsesInlineThreadBody() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                    ScenarioDefinition.Global(ScenarioTargetLanguage.Kotlin, ScenarioField.StrongRef),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0),
                        ScenarioOp.CreateObject(1, 1),
                        ScenarioOp.CreateObject(2, 2),
                        ScenarioOp.Store(localLocation(0, 0), localValue(1)),
                        ScenarioOp.Store(globalLocation(0), localValue(0)),
                        ScenarioOp.Spawn(
                            listOf(
                                ScenarioOp.Store(localLocation(2, 0), globalValue(0, 0)),
                                ScenarioOp.Store(globalLocation(0, 0), ScenarioValue.NullValue),
                                ScenarioOp.Store(globalLocation(0), ScenarioValue.NullValue),
                                ScenarioOp.PerformGc(),
                                ScenarioOp.Observe(localValue(2, 0)),
                            )
                        ),
                    )
                ),
            )
        )

        val contents = output.contents
        val threadStart = contents.indexOf("spawnThread")
        val threadBody = contents.substring(threadStart)
        assertContains(threadBody, "l2?.storeField(0, g3?.loadField(0))")
        assertContains(threadBody, "g3?.storeField(0, null)")
        assertContains(threadBody, "g3 = null")
        val clearGlobalIndex = threadBody.indexOf("g3 = null")
        val gcIndex = threadBody.indexOf("performGC()", startIndex = clearGlobalIndex)
        assertTrue(clearGlobalIndex < gcIndex)
    }

    @Test
    fun pureKotlinReusesExistingScenarioLocalWithoutRedeclaration() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0),
                        ScenarioOp.CreateObject(0, 1),
                        ScenarioOp.Observe(localValue(0)),
                    )
                ),
            )
        )

        val contents = output.contents
        assertEquals(1, Regex("""var l0: Any\? = """).findAll(contents).count())
        assertContains(contents, "l0 = alloc({ Class1(null) })")
    }

    @Test
    fun pureKotlinCInteropAddsForeignBridgeFilesAndRoundTripHelper() {
        val output = PureKotlinScenarioBackend.lower(
            ScenarioProgram(
                definitions = listOf(
                    ScenarioDefinition.Class(ScenarioTargetLanguage.Kotlin, listOf(ScenarioField.StrongRef)),
                ),
                mainBody = ScenarioBody(
                    listOf(
                        ScenarioOp.CreateObject(0, 0),
                        ScenarioOp.ForeignRoundTrip(
                            localValue(0),
                            referenceKind = ScenarioForeignReferenceKind.Weak,
                            pattern = ScenarioForeignInteractionPattern.RepeatedCallback,
                            repetitions = 4,
                        ),
                    )
                ),
            ),
            ScenarioBackendConfig.DEFAULT.withCInterop(true),
        )

        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_callback")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_callback_repeated")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_identity")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_callback_wrapped")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_callback_then_identity")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_callback_nested")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_boxed_callback")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_box_identity")
        assertContains(output.contents, "import gcfuzz_purekotlin_bridge.bridge_run_boxed_callback_repeated")
        assertContains(output.contents, "private enum class ForeignReferenceKind { HANDLE, STRONG, WEAK }")
        assertContains(output.contents, "private enum class ForeignInteractionPattern { CALLBACK, REPEATED_CALLBACK, IDENTITY, WRAPPED_CALLBACK, CALLBACK_THEN_IDENTITY, NESTED_CALLBACK, BOXED_CALLBACK, BOXED_IDENTITY, BOXED_REPEATED_CALLBACK }")
        assertContains(output.contents, "private fun performForeignRoundTrip(")
        assertContains(output.contents, "performForeignRoundTrip(l0, ForeignReferenceKind.WEAK, ForeignInteractionPattern.REPEATED_CALLBACK, 4)")
        assertContains(output.contents, "val callback = staticCFunction(::consumeForeignRoundTripPayload)")
        assertContains(output.contents, "ForeignInteractionPattern.CALLBACK -> bridge_run_callback(callback, pointer)")
        assertContains(output.contents, "ForeignInteractionPattern.REPEATED_CALLBACK -> bridge_run_callback_repeated(callback, pointer, repetitions.coerceAtLeast(1))")
        assertContains(output.contents, "bridge_run_callback(callback, echoed)")
        assertContains(output.contents, "ForeignInteractionPattern.WRAPPED_CALLBACK -> bridge_run_callback_wrapped(callback, pointer)")
        assertContains(output.contents, "ForeignInteractionPattern.CALLBACK_THEN_IDENTITY -> bridge_run_callback_then_identity(callback, pointer)")
        assertContains(output.contents, "ForeignInteractionPattern.NESTED_CALLBACK -> bridge_run_callback_nested(callback, pointer, repetitions.coerceAtLeast(1))")
        assertContains(output.contents, "ForeignInteractionPattern.BOXED_CALLBACK -> bridge_run_boxed_callback(callback, pointer, repetitions)")
        assertContains(output.contents, "val boxed = bridge_box_identity(pointer, repetitions)")
        assertContains(output.contents, "ForeignInteractionPattern.BOXED_REPEATED_CALLBACK -> bridge_run_boxed_callback_repeated(callback, pointer, repetitions, repetitions.coerceAtLeast(1))")
        assertContains(output.files.getValue("bridge.h"), "typedef struct {")
        assertContains(output.files.getValue("bridge.h"), "void* payload;")
        assertContains(output.files.getValue("bridge.h"), "int tag;")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_callback_repeated(gcfuzz_callback_t callback, void* payload, int repeatCount);")
        assertContains(output.files.getValue("bridge.h"), "void* bridge_identity(void* payload);")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_callback_wrapped(gcfuzz_callback_t callback, void* payload);")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_callback_then_identity(gcfuzz_callback_t callback, void* payload);")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_callback_nested(gcfuzz_callback_t callback, void* payload, int depth);")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_boxed_callback(gcfuzz_callback_t callback, void* payload, int tag);")
        assertContains(output.files.getValue("bridge.h"), "void* bridge_box_identity(void* payload, int tag);")
        assertContains(output.files.getValue("bridge.h"), "void bridge_run_boxed_callback_repeated(gcfuzz_callback_t callback, void* payload, int tag, int repeatCount);")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_callback_repeated")
        assertContains(output.files.getValue("bridge.c"), "bridge_identity")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_callback_wrapped")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_callback_then_identity")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_callback_nested")
        assertContains(output.files.getValue("bridge.c"), "bridge_make_box")
        assertContains(output.files.getValue("bridge.c"), "bridge_unbox_payload")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_boxed_callback")
        assertContains(output.files.getValue("bridge.c"), "bridge_box_identity")
        assertContains(output.files.getValue("bridge.c"), "bridge_run_boxed_callback_repeated")
        assertTrue("cinterop.def" in output.files)
        assertTrue("bridge.h" in output.files)
        assertTrue("bridge.c" in output.files)
    }
}

internal fun secondBatchTypeSystemScenario(): ScenarioProgram =
    ScenarioProgram(
        definitions = listOf(
            ScenarioDefinition.Global(
                ScenarioTargetLanguage.Kotlin,
                ScenarioField.TypedStrongRef(ScenarioType.ClassRef(0)),
            ),
            ScenarioDefinition.SingletonObject(
                ScenarioTargetLanguage.Kotlin,
                listOf(ScenarioField.StrongRef),
            ),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.Kotlin,
                emptyList(),
                kind = ScenarioClassKind.Sealed,
            ),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.Kotlin,
                listOf(ScenarioField.StrongRef),
                superClassId = 0,
                sealedPayloadFieldId = 0,
            ),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.Kotlin,
                listOf(ScenarioField.StrongRef),
                superClassId = 0,
                sealedPayloadFieldId = 0,
            ),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.Kotlin,
                listOf(ScenarioField.StrongRef),
            ),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.Kotlin,
                listOf(ScenarioField.StrongRef),
                nestedInClassId = 3,
                outerCaptureFieldId = 0,
            ),
        ),
        mainBody = ScenarioBody(
            listOf(
                ScenarioOp.CreateObject(0, 1, declaredType = ScenarioType.ClassRef(0)),
                ScenarioOp.Store(ScenarioLocation.Global(0), ScenarioValue.LocalRef(0)),
                ScenarioOp.SealedDispatch(1, ScenarioValue.GlobalRef(0), 0),
                ScenarioOp.CreateObject(2, 2, declaredType = ScenarioType.ClassRef(0)),
                ScenarioOp.Store(ScenarioLocation.Global(0), ScenarioValue.LocalRef(2)),
                ScenarioOp.SealedDispatch(3, ScenarioValue.GlobalRef(0), 0),
                ScenarioOp.Store(ScenarioLocation.Singleton(0, ScenarioPath(listOf(0))), ScenarioValue.LocalRef(3)),
                ScenarioOp.SingletonAccess(4, 0, 0),
                ScenarioOp.CreateObject(5, 1),
                ScenarioOp.CreateObject(6, 3, listOf(ScenarioValue.LocalRef(5))),
                ScenarioOp.CreateInnerObject(7, ScenarioValue.LocalRef(6), 4, declaredType = ScenarioType.ClassRef(4)),
                ScenarioOp.OuterDispatch(8, ScenarioValue.LocalRef(7), 4),
                ScenarioOp.PerformGc(),
                ScenarioOp.Observe(ScenarioValue.LocalRef(1)),
                ScenarioOp.Observe(ScenarioValue.LocalRef(4)),
                ScenarioOp.Observe(ScenarioValue.LocalRef(8)),
            )
        ),
    )
