/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioCapabilityProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeature
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioFeatureSet

internal class ScenarioGenerationCapabilities(
    val core: ScenarioCapabilityProfile,
    val supportedTopologies: Set<ScenarioTopologyKind>,
) {
    fun supports(topologyKind: ScenarioTopologyKind): Boolean =
        topologyKind in supportedTopologies && topologyKind.requiredCapabilities().isSupportedBy(core)

    companion object {
        fun pureKotlin(features: ScenarioFeatureSet, enableCInterop: Boolean): ScenarioGenerationCapabilities {
            val featureSet = features.toSet()
            val core = ScenarioCapabilityProfile.pureKotlin(enableCInterop)
            return ScenarioGenerationCapabilities(
                core = core,
                supportedTopologies = ScenarioTopologyKind.entries
                    .filter { topologyKind ->
                        topologyKind.requiredFeature() in featureSet &&
                            (enableCInterop || topologyKind.family != ScenarioTopologyFamily.CFFI) &&
                            topologyKind.requiredCapabilities().isSupportedBy(core)
                    }
                    .toSet(),
            )
        }

        fun pureKotlin(features: ScenarioFeatureSet): ScenarioGenerationCapabilities =
            pureKotlin(
                features,
                enableCInterop = ScenarioFeature.CFFI_CALLBACK_ROUNDTRIP in features,
            )
    }
}
