/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.support

internal inline fun <T> withExecutionModel(executionModel: String, block: () -> T): T {
    val key = "gcfuzzing.executionModel"
    val previous = System.getProperty(key)
    System.setProperty(key, executionModel)
    return try {
        block()
    } finally {
        if (previous == null) {
            System.clearProperty(key)
        } else {
            System.setProperty(key, previous)
        }
    }
}
