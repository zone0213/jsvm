/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHostResolver
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ProgramId
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.SimpleFuzzer
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.execute
import org.junit.jupiter.api.DynamicTest
import org.junit.jupiter.api.TestFactory
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.stream.Stream
import kotlin.streams.asStream
import kotlin.test.fail
import kotlin.time.Duration
import kotlin.time.TimeSource

class GCFuzzingTest {
    @TestFactory
    fun simple(): Stream<DynamicTest> {
        val host = StandaloneExecutionHostResolver.fromSystemProperties()
        val executeSingleId = System.getProperty("gcfuzzing.single.id")
        if (executeSingleId != null) {
            val id = ProgramId.fromString(executeSingleId) ?: fail("Invalid program ID \"$executeSingleId\"")
            return listOf(DynamicTest.dynamicTest("$id") {
                host.execute(id)
            }).stream()
        }

        val timelimit = Duration.parse(System.getProperty("gcfuzzing.timelimit")!!)
        val start = TimeSource.Monotonic.markNow()

        val seed = System.getProperty("gcfuzzing.seed")!!.toInt()
        val parallelism = (System.getProperty("gcfuzzing.parallelism")?.toIntOrNull() ?: 1).coerceAtLeast(1)
        val fuzzer = SimpleFuzzer(seed)
        if (parallelism == 1) {
            var stepCounter = 0
            return generateSequence {
                if (start.elapsedNow() > timelimit) return@generateSequence null
                val stepId = fuzzer.nextStepId()
                DynamicTest.dynamicTest("SimpleFuzzer($seed) step #${stepCounter++} ($stepId)") {
                    host.execute(stepId)
                }
            }.asStream()
        }

        return listOf(
            DynamicTest.dynamicTest("SimpleFuzzer($seed) parallel x$parallelism") {
                runParallelFuzz(host, seed, fuzzer, parallelism, timelimit, start)
            }
        ).stream()
    }

    private fun runParallelFuzz(
        host: org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost,
        seed: Int,
        fuzzer: SimpleFuzzer,
        parallelism: Int,
        timelimit: Duration,
        start: TimeSource.Monotonic.ValueTimeMark,
    ) {
        val attemptedCounter = AtomicInteger(0)
        val completedCounter = AtomicInteger(0)
        val successCounter = AtomicInteger(0)
        val failures = ConcurrentLinkedQueue<Throwable>()
        val failureCounter = AtomicInteger(0)
        val activeWorkers = AtomicInteger(0)
        val nextProgressLogNanos = AtomicLong(0L)
        val workers = List(parallelism) { workerIndex ->
            Thread {
                activeWorkers.incrementAndGet()
                while (start.elapsedNow() <= timelimit) {
                    maybeLogProgress(
                        seed = seed,
                        parallelism = parallelism,
                        attemptedCounter = attemptedCounter,
                        completedCounter = completedCounter,
                        successCounter = successCounter,
                        failureCounter = failureCounter,
                        activeWorkers = activeWorkers,
                        start = start,
                        nextProgressLogNanos = nextProgressLogNanos,
                    )
                    val stepNumber = attemptedCounter.getAndIncrement()
                    val stepId = fuzzer.nextStepId()
                    try {
                        host.execute(stepId)
                        successCounter.incrementAndGet()
                    } catch (t: Throwable) {
                        failureCounter.incrementAndGet()
                        failures += AssertionError(
                            "Parallel worker #$workerIndex failed for SimpleFuzzer($seed) step #$stepNumber ($stepId)",
                            t
                        )
                    } finally {
                        completedCounter.incrementAndGet()
                    }
                }
                activeWorkers.decrementAndGet()
            }.apply {
                name = "gcfuzz-worker-$workerIndex"
            }
        }

        workers.forEach(Thread::start)
        workers.forEach(Thread::join)
        maybeLogProgress(
            seed = seed,
            parallelism = parallelism,
            attemptedCounter = attemptedCounter,
            completedCounter = completedCounter,
            successCounter = successCounter,
            failureCounter = failureCounter,
            activeWorkers = activeWorkers,
            start = start,
            nextProgressLogNanos = AtomicLong(Long.MAX_VALUE),
        )

        if (failures.isNotEmpty()) {
            val firstFailure = failures.poll()
            while (true) {
                val nextFailure = failures.poll() ?: break
                firstFailure.addSuppressed(nextFailure)
            }
            throw firstFailure
        }
    }

    private fun maybeLogProgress(
        seed: Int,
        parallelism: Int,
        attemptedCounter: AtomicInteger,
        completedCounter: AtomicInteger,
        successCounter: AtomicInteger,
        failureCounter: AtomicInteger,
        activeWorkers: AtomicInteger,
        start: TimeSource.Monotonic.ValueTimeMark,
        nextProgressLogNanos: AtomicLong,
    ) {
        val elapsed = start.elapsedNow()
        val elapsedNanos = elapsed.inWholeNanoseconds
        val currentThreshold = nextProgressLogNanos.get()
        if (elapsedNanos < currentThreshold) return
        if (!nextProgressLogNanos.compareAndSet(currentThreshold, elapsedNanos + 5_000_000_000L)) return
        val attempted = attemptedCounter.get()
        val completed = completedCounter.get()
        val succeeded = successCounter.get()
        val failed = failureCounter.get()
        println(
            "[gcfuzz] seed=$seed parallelism=$parallelism elapsed=$elapsed attempted=$attempted completed=$completed succeeded=$succeeded failed=$failed activeWorkers=${activeWorkers.get()}"
        )
    }
}
