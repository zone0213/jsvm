/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import java.io.File

/**
 * Output language of the generated case. ETS produces ArkTS (`.ets`, compiled with
 * `es2abc --extension=ts`); JavaScript produces plain JS (`.js`, compiled with
 * `es2abc --extension=js`) that also runs under `ark_js_vm`. The JS mode strips all TS-only
 * syntax (interface/type annotations/public/implements/generics/enum) so the output is valid
 * under `--extension=js` strict mode, where TS-only syntax (e.g. `interface`) is rejected.
 */
enum class ArkTsOutputMode { ETS, JavaScript }

/**
 * Output of ArkTS translation. [files] maps relative path -> source text; [entryFileName] is the
 * file passed to es2abc. P1 produces a single `main.ets` (ETS mode) or `main.js` (JavaScript mode).
 */
class ArkTsOutput(
    val files: Map<String, String>,
    val entryFileName: String,
    val args: List<String>,
) {
    val filename: String
        get() = entryFileName

    val contents: String
        get() = files.getValue(entryFileName)
}

class ArkTsConfig(
    val moduleName: String,
    val maximumStackDepth: Int,
    val mainLoopRepeatCount: Int,
    val softTimeoutMillis: Long,
    val outputMode: ArkTsOutputMode = ArkTsOutputMode.ETS,
)

fun ArkTsOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}
