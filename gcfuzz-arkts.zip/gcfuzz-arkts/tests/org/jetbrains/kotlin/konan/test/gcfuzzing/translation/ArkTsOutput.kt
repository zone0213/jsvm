/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import java.io.File

/**
 * Output of ArkTS translation. [files] maps relative path -> source text; [entryFileName] is the
 * file passed to es2abc. P1 produces a single `main.ets`.
 */
class ArkTsOutput(
    val files: Map<String, String>,
    val entryFileName: String,
    val args: List<String>,
) {
    val filename: String
        get() = entryFileName

    val contents: String
        get() = files.getValue(entryFileName)
}

class ArkTsConfig(
    val moduleName: String,
    val maximumStackDepth: Int,
    val mainLoopRepeatCount: Int,
    val softTimeoutMillis: Long,
)

fun ArkTsOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}
