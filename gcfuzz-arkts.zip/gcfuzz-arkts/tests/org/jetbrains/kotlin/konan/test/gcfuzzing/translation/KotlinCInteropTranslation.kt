/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import java.io.File

internal class KotlinCInteropOutput(
    val files: Map<String, String>,
    val kotlinFileName: String,
    val cinteropDefFileName: String,
    val cSourceFileName: String,
)

internal class KotlinCInteropTranslationConfig(
    val moduleName: String,
    val stableRefPayloadValue: Int,
    val repeatCount: Int,
)

internal fun produceKotlinCInteropSmoke(config: KotlinCInteropTranslationConfig): KotlinCInteropOutput {
    val cinteropPackageName = "gcfuzz_kotlincffi_bridge"
    val kotlinFileName = "${config.moduleName}.kt"
    val cinteropDefFileName = "cinterop.def"
    val headerFileName = "bridge.h"
    val cSourceFileName = "bridge.c"
    val kotlinContents = """
        @file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class, kotlin.native.runtime.NativeRuntimeApi::class)

        import $cinteropPackageName.bridge_run_callback
        import kotlinx.cinterop.COpaquePointer
        import kotlinx.cinterop.StableRef
        import kotlinx.cinterop.asStableRef
        import kotlinx.cinterop.staticCFunction
        import kotlin.native.runtime.GC

        private class Payload(val value: Int)

        private fun consumeStableRefFromC(raw: COpaquePointer?) {
            val payload = raw!!.asStableRef<Payload>().get()
            observe(payload)
        }

        private fun observe(payload: Payload) {
            check(payload.value == ${config.stableRefPayloadValue})
        }

        fun main() {
            val payload = Payload(${config.stableRefPayloadValue})
            val stableRef = StableRef.create(payload)
            try {
                repeat(${config.repeatCount}) {
                    bridge_run_callback(staticCFunction(::consumeStableRefFromC), stableRef.asCPointer())
                    GC.collect()
                }
            } finally {
                stableRef.dispose()
            }
        }
    """.trimIndent()
    val headerContents = """
        #ifndef GCFUZZ_KOTLINCFFI_BRIDGE_H
        #define GCFUZZ_KOTLINCFFI_BRIDGE_H

        typedef void (*gcfuzz_callback_t)(void* payload);

        void bridge_run_callback(gcfuzz_callback_t callback, void* payload);

        #endif
    """.trimIndent()
    val cSourceContents = """
        #include "bridge.h"

        void bridge_run_callback(gcfuzz_callback_t callback, void* payload) {
            callback(payload);
        }
    """.trimIndent()
    val cinteropDefContents = """
        headers = bridge.h
        headerFilter = bridge.h
        language = C
        package = $cinteropPackageName
    """.trimIndent()
    return KotlinCInteropOutput(
        files = linkedMapOf(
            kotlinFileName to kotlinContents,
            cinteropDefFileName to cinteropDefContents,
            headerFileName to headerContents,
            cSourceFileName to cSourceContents,
        ),
        kotlinFileName = kotlinFileName,
        cinteropDefFileName = cinteropDefFileName,
        cSourceFileName = cSourceFileName,
    )
}

internal fun KotlinCInteropOutput.save(root: File) {
    root.mkdirs()
    files.forEach { (relativePath, contents) ->
        root.resolve(relativePath).writeText(contents)
    }
}
