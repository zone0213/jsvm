/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.execution

import java.io.File
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

internal data class StandaloneExecutionHost(
    val nativeHomeDir: File,
    val targetName: String,
    val executionTimeout: Duration,
    val resultsRootDir: File,
    val runId: String?,
) {
    val sessionBuildDir: File
        get() = runId?.takeIf { it.isNotBlank() }?.let { resultsRootDir.resolve(it) } ?: resultsRootDir
}

internal object StandaloneExecutionHostResolver {
    fun fromSystemProperties(defaultExecutionTimeout: Duration = 5.minutes): StandaloneExecutionHost {
        val nativeHomeDir = resolveNativeHomeDir()
        val resultsRootDir = resolveResultsRootDir()
        return StandaloneExecutionHost(
            nativeHomeDir = nativeHomeDir,
            targetName = resolveTargetName(),
            executionTimeout = resolveExecutionTimeout(defaultExecutionTimeout),
            resultsRootDir = resultsRootDir,
            runId = System.getProperty("gcfuzzing.runId")?.takeIf { it.isNotBlank() },
        )
    }

    private fun resolveNativeHomeDir(): File {
        val configured = sequenceOf(
            System.getProperty("kn.nativeHome"),
            System.getProperty("kotlin.internal.native.test.nativeHome"),
            System.getenv("KONAN_HOME"),
        ).mapNotNull { it?.trim()?.takeIf(String::isNotEmpty) }.firstOrNull()
            ?: error(
                "Missing Kotlin/Native home. Specify -Dkn.nativeHome=/path/to/kotlin-native-prebuilt " +
                    "or -Dkotlin.internal.native.test.nativeHome=/path/to/kotlin-native-prebuilt"
            )
        return File(configured).absoluteFile.also {
            require(it.isDirectory) { "Kotlin/Native home does not exist: ${it.absolutePath}" }
        }
    }

    private fun resolveResultsRootDir(): File =
        sequenceOf(
            System.getProperty("gcfuzzing.resultsRoot"),
            System.getenv("GCFUZZ_RESULTS_ROOT"),
        ).mapNotNull { it?.trim()?.takeIf(String::isNotEmpty) }
            .firstOrNull()
            ?.let(::File)
            ?.absoluteFile
            ?: File("workspace/runs").absoluteFile

    private fun resolveTargetName(): String =
        sequenceOf(
            System.getProperty("gcfuzzing.target"),
            System.getProperty("kn.target"),
            System.getenv("KONAN_TARGET"),
        ).mapNotNull { it?.trim()?.takeIf(String::isNotEmpty) }.firstOrNull()
            ?: detectHostTarget()

    private fun resolveExecutionTimeout(defaultExecutionTimeout: Duration): Duration =
        System.getProperty("gcfuzzing.executionTimeout")
            ?.takeIf { it.isNotBlank() }
            ?.let(Duration::parse)
            ?: defaultExecutionTimeout

    private fun detectHostTarget(): String {
        val osName = System.getProperty("os.name").lowercase()
        val arch = System.getProperty("os.arch").lowercase()
        return when {
            osName.contains("mac") && (arch.contains("aarch64") || arch.contains("arm64")) -> "macos_arm64"
            osName.contains("mac") && arch.contains("x86_64") -> "macos_x64"
            osName.contains("linux") && (arch.contains("aarch64") || arch.contains("arm64")) -> "linux_arm64"
            osName.contains("linux") && arch.contains("x86_64") -> "linux_x64"
            else -> error(
                "Unable to infer Kotlin/Native target for os=$osName arch=$arch. Specify -Dgcfuzzing.target=<target>."
            )
        }
    }
}
