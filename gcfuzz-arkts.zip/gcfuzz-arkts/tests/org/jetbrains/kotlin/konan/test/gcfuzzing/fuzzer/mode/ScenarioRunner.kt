/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ProgramId
import kotlin.time.Duration

internal fun StandaloneExecutionHost.execute(id: ProgramId) {
    val config = ScenarioBackendConfig(
        maximumStackDepth = ScenarioBackendConfig.DEFAULT.maximumStackDepth,
        mainLoopRepeatCount = ScenarioBackendConfig.DEFAULT.mainLoopRepeatCount,
        maxThreadCount = ScenarioBackendConfig.DEFAULT.maxThreadCount,
        softTimeout = System.getProperty("gcfuzzing.softTimeout")?.let { Duration.parse(it) }
            ?: ScenarioBackendConfig.DEFAULT.softTimeout,
        enableCInterop = System.getProperty("gcfuzzing.cffi")?.toBoolean() == true,
    )
    ScenarioModeRegistry.resolve(System.getProperty("gcfuzzing.executionModel")).execute(this, id, config)
}
