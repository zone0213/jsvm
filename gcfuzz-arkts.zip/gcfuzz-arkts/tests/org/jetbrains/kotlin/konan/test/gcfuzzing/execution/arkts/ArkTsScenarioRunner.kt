/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.execution.arkts

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessExecutionException
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessRunner
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.ArkTsOutput
import java.io.File
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.test.fail

/**
 * Resolves the es2abc compiler shipped with the locally-installed HarmonyOS SDK.
 *
 * P1 uses the DevEco Studio SDK discovered at:
 *   <DevEco>\sdk\default\openharmony\ets\build-tools\ets-loader\bin\ark\build-win\bin\es2abc.exe
 * Override with -Dgcfuzzing.es2abc or GCFUZZ_ES2ABC.
 */
private fun resolveEs2abc(): File {
    val configured = System.getProperty("gcfuzzing.es2abc")?.takeIf { it.isNotBlank() }
        ?: System.getenv("GCFUZZ_ES2ABC")?.takeIf { it.isNotBlank() }
    if (configured != null) return File(configured).also { require(it.isFile) { "es2abc not found: $configured" } }
    val candidates = listOf(
        "C:\\Program Files\\Huawei\\DevEco Studio\\sdk\\default\\openharmony\\ets\\build-tools\\ets-loader\\bin\\ark\\build-win\\bin\\es2abc.exe",
        "${System.getProperty("user.home")}\\AppData\\Local\\Huawei\\DevEco Studio\\sdk\\default\\openharmony\\ets\\build-tools\\ets-loader\\bin\\ark\\build-win\\bin\\es2abc.exe",
    )
    return candidates.firstNotNullOfOrNull { p -> p.takeIf { File(p).isFile }?.let { File(it) } }
        ?: error(
            "es2abc not found. Specify -Dgcfuzzing.es2abc=<path> or GCFUZZ_ES2ABC=<path>. " +
                "Expected under DevEco Studio SDK: ...\\openharmony\\ets\\build-tools\\ets-loader\\bin\\ark\\build-win\\bin\\es2abc.exe"
        )
}

internal fun StandaloneExecutionHost.resolveArkTsScenarioBuildDir(testName: String): File = sessionBuildDir.resolve(testName)
internal fun StandaloneExecutionHost.resolveArkTsScenarioGeneratedSourceDir(testName: String): File =
    resolveArkTsScenarioBuildDir(testName).resolve("generated")

/**
 * P1 ArkTS runner: compile-only.
 *
 * Runs `es2abc main.ets --output main.abc` and captures the compile log. P1 does not execute the
 * produced abc (no standalone Ark VM runner ships with the SDK; device execution is P2). The
 * compile pass is the P1 acceptance gate: IR -> ArkTS source -> legal abc.
 */
internal fun StandaloneExecutionHost.runArkTsScenario(
    testName: String,
    output: ArkTsOutput,
    executionTimeout: Duration,
) {
    val baseDir = resolveArkTsScenarioBuildDir(testName)
    val generatedSourceDir = resolveArkTsScenarioGeneratedSourceDir(testName)
    baseDir.mkdirs()
    val sourceFile = generatedSourceDir.resolve(output.filename)
    require(sourceFile.isFile) { "Generated source not found: ${sourceFile.absolutePath}" }
    val es2abc = resolveEs2abc()
    val abcFile = baseDir.resolve("main.abc")
    // Pick the es2abc extension from the generated source's suffix: .ets -> ts (ArkTS mode,
    // DevEco's canonical path), .js -> js (plain-JS mode, runnable under ark_js_vm). The source
    // suffix is set by the translation layer's output mode, so the runner stays in sync with it.
    val es2abcExt = when (sourceFile.extension) {
        "js" -> "js"
        else -> "ts"
    }
    runTool(
        executable = es2abc.absolutePath,
        args = listOf(
            sourceFile.absolutePath,
            "--module",
            "--extension=$es2abcExt",
            "--merge-abc",
            "--output", abcFile.absolutePath,
            "--debug-info",
        ),
        logFile = baseDir.resolve("compile.log"),
        timeout = 5.minutes,
        toolName = "es2abc",
    )
}

private fun runTool(
    executable: String,
    args: List<String>,
    logFile: File,
    timeout: Duration,
    toolName: String,
): File {
    logFile.parentFile.mkdirs()
    val result = try {
        ProcessRunner.run(listOf(executable) + args, timeout)
    } catch (e: ProcessExecutionException) {
        val errorText = buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=${e.exitCode ?: -1}")
            appendLine("stdout:")
            appendLine(e.stdout)
            appendLine("stderr:")
            appendLine(e.stderr)
        }
        logFile.writeText(errorText)
        fail(errorText)
    }
    logFile.writeText(
        buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=0")
            appendLine("stdout:")
            appendLine(result.stdout)
            appendLine("stderr:")
            appendLine(result.stderr)
        }
    )
    return logFile
}
