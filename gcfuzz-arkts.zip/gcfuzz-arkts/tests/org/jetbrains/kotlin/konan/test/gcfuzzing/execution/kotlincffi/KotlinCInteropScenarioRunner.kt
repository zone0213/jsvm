/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.execution.kotlincffi

import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessExecutionException
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.ProcessRunner
import org.jetbrains.kotlin.konan.test.gcfuzzing.execution.StandaloneExecutionHost
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.KotlinCInteropOutput
import java.io.File
import kotlin.test.fail
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

internal fun StandaloneExecutionHost.resolveKotlinCInteropScenarioBuildDir(testName: String): File = sessionBuildDir.resolve(testName)
internal fun StandaloneExecutionHost.resolveKotlinCInteropScenarioGeneratedSourceDir(testName: String): File =
    resolveKotlinCInteropScenarioBuildDir(testName).resolve("generated")

internal fun StandaloneExecutionHost.runKotlinCInteropScenario(
    testName: String,
    output: KotlinCInteropOutput,
    executionTimeout: Duration,
) {
    val baseDir = resolveKotlinCInteropScenarioBuildDir(testName)
    val generatedSourceDir = resolveKotlinCInteropScenarioGeneratedSourceDir(testName)
    val cinteropExecutable = nativeHomeDir.resolve("bin/cinterop").absolutePath
    val konancExecutable = nativeHomeDir.resolve("bin/konanc").absolutePath
    val cinteropOutputBase = baseDir.resolve("interop/bridge")
    cinteropOutputBase.parentFile.mkdirs()
    val cinteropLibrary = runTool(
        executable = cinteropExecutable,
        args = listOf(
            "-def", generatedSourceDir.resolve(output.cinteropDefFileName).absolutePath,
            "-target", targetName,
            "-compiler-option", "-I${generatedSourceDir.absolutePath}",
            "-o", cinteropOutputBase.absolutePath,
        ),
        logFile = baseDir.resolve("cinterop.log"),
        timeout = 2.minutes,
        toolName = "cinterop",
    ).let {
        sequenceOf(
            cinteropOutputBase,
            cinteropOutputBase.resolveSibling(cinteropOutputBase.name + ".klib"),
        ).firstOrNull(File::exists) ?: fail("cinterop did not produce a klib under ${cinteropOutputBase.absolutePath}")
    }
    val objectFile = baseDir.resolve("bridge.o")
    runTool(
        executable = "/usr/bin/clang",
        args = listOf(
            "-c",
            generatedSourceDir.resolve(output.cSourceFileName).absolutePath,
            "-o",
            objectFile.absolutePath,
        ),
        logFile = baseDir.resolve("clang.log"),
        timeout = 2.minutes,
        toolName = "clang",
    )
    val executableFile = baseDir.resolve("app")
    runTool(
        executable = konancExecutable,
        args = listOf(
            generatedSourceDir.resolve(output.kotlinFileName).absolutePath,
            "-kotlin-home", nativeHomeDir.absolutePath,
            "-target", targetName,
            "-library", cinteropLibrary.absolutePath,
            "-linker-option", objectFile.absolutePath,
            "-produce", "program",
            "-output", executableFile.absolutePath,
        ),
        logFile = baseDir.resolve("konanc.log"),
        timeout = 5.minutes,
        toolName = "konanc",
    )
    val producedExecutable = sequenceOf(
        executableFile,
        executableFile.resolveSibling(executableFile.name + ".kexe"),
    ).firstOrNull(File::exists) ?: fail("konanc did not produce an executable for $testName")
    runTool(
        executable = producedExecutable.absolutePath,
        args = emptyList(),
        logFile = baseDir.resolve("run.log"),
        timeout = executionTimeout,
        toolName = "run",
    )
}

private fun runTool(
    executable: String,
    args: List<String>,
    logFile: File,
    timeout: Duration,
    toolName: String,
): File {
    logFile.parentFile.mkdirs()
    val result = try {
        ProcessRunner.run(listOf(executable) + args, timeout)
    } catch (e: ProcessExecutionException) {
        val output = buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=${e.exitCode ?: -1}")
            appendLine("stdout:")
            appendLine(e.stdout)
            appendLine("stderr:")
            appendLine(e.stderr)
        }
        logFile.writeText(output)
        fail(output)
    }
    logFile.writeText(
        buildString {
            appendLine("tool=$toolName")
            appendLine("command=${listOf(executable) + args}")
            appendLine("exitCode=0")
            appendLine("stdout:")
            appendLine(result.stdout)
            appendLine("stderr:")
            appendLine(result.stderr)
        }
    )
    return logFile
}
