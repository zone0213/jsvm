@file:JvmName("ArkTsGenSmokeMain")
package org.jetbrains.kotlin.konan.test.gcfuzzing

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.mode.ArkTsScenarioGenerationProfile
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.generation.generateScenarioWithMetadata
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.ArkTsOutput
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.save
import java.io.File

fun main(args: Array<String>) {
    val seedsEnv = System.getenv("GCFUZZ_SEEDS") ?: "0,1,2,3,4,5,6,7,8,9"
    val outDir = System.getenv("GCFUZZ_OUTDIR")?.let { File(it) }
        ?: error("GCFUZZ_OUTDIR must be set")
    outDir.mkdirs()

    // GCFUZZ_OUTPUT=js selects plain-JS output (runs under es2abc --extension=js + ark_js_vm);
    // unset/ets keeps the default ArkTS .ets output.
    System.getenv("GCFUZZ_OUTPUT")?.takeIf { it.isNotBlank() }?.let {
        System.setProperty("gcfuzzing.arkts.outputMode", it)
    }

    val profile = ArkTsScenarioGenerationProfile
    val capabilities = profile.capabilities
    val features = profile.features
    val cfg = ScenarioBackendConfig.DEFAULT

    val seeds = seedsEnv.split(",").map { it.trim().toUInt() }
    var ok = 0
    for (seed in seeds) {
        val generated = generateScenarioWithMetadata(seed, features, capabilities)
        val output = ArkTsScenarioBackend.lower(generated.program, cfg)
        val dir = File(outDir, "seed-${seed.toInt()}").apply { mkdirs() }
        output.save(dir)
        println("seed=${seed.toInt()} -> ${dir.resolve(output.filename)}")
        ok++
    }
    println("done: $ok/${seeds.size} cases generated")
}
