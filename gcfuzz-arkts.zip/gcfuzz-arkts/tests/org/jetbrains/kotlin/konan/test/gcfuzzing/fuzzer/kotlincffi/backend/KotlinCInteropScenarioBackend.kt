/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlincffi.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.KotlinCInteropOutput
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.KotlinCInteropTranslationConfig
import org.jetbrains.kotlin.konan.test.gcfuzzing.translation.produceKotlinCInteropSmoke

internal object KotlinCInteropScenarioBackend {
    fun lower(config: ScenarioBackendConfig = ScenarioBackendConfig.DEFAULT): KotlinCInteropOutput {
        return produceKotlinCInteropSmoke(
            KotlinCInteropTranslationConfig(
                moduleName = "main",
                stableRefPayloadValue = 42,
                repeatCount = config.mainLoopRepeatCount.coerceIn(1, 4),
            )
        )
    }
}
