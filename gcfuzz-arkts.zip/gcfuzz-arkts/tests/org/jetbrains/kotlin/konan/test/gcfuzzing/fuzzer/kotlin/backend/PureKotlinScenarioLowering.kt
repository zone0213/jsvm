/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.backend

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPreparation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.kotlin.profile.PureKotlinScenarioProfile

internal object PureKotlinScenarioLowering {
    fun lower(program: ScenarioProgram): ScenarioProgram = ScenarioPreparation.prepare(program, PureKotlinScenarioProfile).program
}
