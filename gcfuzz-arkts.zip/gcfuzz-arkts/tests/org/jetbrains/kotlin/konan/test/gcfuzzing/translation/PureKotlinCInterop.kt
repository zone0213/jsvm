/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioForeignInteractionPattern

class PureKotlinCInteropSupport(
    val cinteropDefFileName: String,
    val cSourceFileName: String,
)

internal class GeneratedPureKotlinCInteropFiles(
    val files: Map<String, String>,
    val support: PureKotlinCInteropSupport,
)

internal fun generatePureKotlinCInteropFiles(): GeneratedPureKotlinCInteropFiles {
    val cinteropDefFileName = "cinterop.def"
    val headerFileName = "bridge.h"
    val cSourceFileName = "bridge.c"
    return GeneratedPureKotlinCInteropFiles(
        files = linkedMapOf(
            cinteropDefFileName to """
                headers = bridge.h
                headerFilter = bridge.h
                language = C
                package = gcfuzz_purekotlin_bridge
            """.trimIndent(),
            headerFileName to """
                #ifndef GCFUZZ_PUREKOTLIN_BRIDGE_H
                #define GCFUZZ_PUREKOTLIN_BRIDGE_H

                typedef void (*gcfuzz_callback_t)(void* payload);
                typedef struct {
                    void* payload;
                    int tag;
                } gcfuzz_box_t;

                void bridge_run_callback(gcfuzz_callback_t callback, void* payload);
                void bridge_run_callback_repeated(gcfuzz_callback_t callback, void* payload, int repeatCount);
                void* bridge_identity(void* payload);
                void bridge_run_callback_wrapped(gcfuzz_callback_t callback, void* payload);
                void bridge_run_callback_then_identity(gcfuzz_callback_t callback, void* payload);
                void bridge_run_callback_nested(gcfuzz_callback_t callback, void* payload, int depth);
                void bridge_run_boxed_callback(gcfuzz_callback_t callback, void* payload, int tag);
                void* bridge_box_identity(void* payload, int tag);
                void bridge_run_boxed_callback_repeated(gcfuzz_callback_t callback, void* payload, int tag, int repeatCount);

                #endif
            """.trimIndent(),
            cSourceFileName to """
                #include "bridge.h"

                void bridge_run_callback(gcfuzz_callback_t callback, void* payload) {
                    callback(payload);
                }

                void bridge_run_callback_repeated(gcfuzz_callback_t callback, void* payload, int repeatCount) {
                    for (int index = 0; index < repeatCount; ++index) {
                        callback(payload);
                    }
                }

                void* bridge_identity(void* payload) {
                    return payload;
                }

                static void bridge_call_wrapper(gcfuzz_callback_t callback, void* payload) {
                    callback(payload);
                }

                void bridge_run_callback_wrapped(gcfuzz_callback_t callback, void* payload) {
                    bridge_call_wrapper(callback, payload);
                }

                void bridge_run_callback_then_identity(gcfuzz_callback_t callback, void* payload) {
                    callback(payload);
                    callback(bridge_identity(payload));
                }

                static void bridge_nested_callback(gcfuzz_callback_t callback, void* payload, int depth) {
                    if (depth <= 0) {
                        callback(payload);
                        return;
                    }
                    bridge_nested_callback(callback, payload, depth - 1);
                }

                void bridge_run_callback_nested(gcfuzz_callback_t callback, void* payload, int depth) {
                    bridge_nested_callback(callback, payload, depth);
                }

                static gcfuzz_box_t bridge_make_box(void* payload, int tag) {
                    gcfuzz_box_t box;
                    box.payload = payload;
                    box.tag = tag;
                    return box;
                }

                static void* bridge_unbox_payload(gcfuzz_box_t* box) {
                    return box->payload;
                }

                void bridge_run_boxed_callback(gcfuzz_callback_t callback, void* payload, int tag) {
                    gcfuzz_box_t box = bridge_make_box(payload, tag);
                    callback(bridge_unbox_payload(&box));
                }

                void* bridge_box_identity(void* payload, int tag) {
                    gcfuzz_box_t box = bridge_make_box(payload, tag);
                    return bridge_unbox_payload(&box);
                }

                void bridge_run_boxed_callback_repeated(gcfuzz_callback_t callback, void* payload, int tag, int repeatCount) {
                    gcfuzz_box_t box = bridge_make_box(payload, tag);
                    for (int index = 0; index < repeatCount; ++index) {
                        callback(bridge_unbox_payload(&box));
                    }
                }
            """.trimIndent(),
        ),
        support = PureKotlinCInteropSupport(
            cinteropDefFileName = cinteropDefFileName,
            cSourceFileName = cSourceFileName,
        ),
    )
}

internal fun translatePureKotlinForeignReferenceKind(referenceKind: ScenarioForeignReferenceKind): String = when (referenceKind) {
    ScenarioForeignReferenceKind.Handle -> "ForeignReferenceKind.HANDLE"
    ScenarioForeignReferenceKind.Strong -> "ForeignReferenceKind.STRONG"
    ScenarioForeignReferenceKind.Weak -> "ForeignReferenceKind.WEAK"
}

internal fun translatePureKotlinForeignInteractionPattern(pattern: ScenarioForeignInteractionPattern): String = when (pattern) {
    ScenarioForeignInteractionPattern.Callback -> "ForeignInteractionPattern.CALLBACK"
    ScenarioForeignInteractionPattern.RepeatedCallback -> "ForeignInteractionPattern.REPEATED_CALLBACK"
    ScenarioForeignInteractionPattern.Identity -> "ForeignInteractionPattern.IDENTITY"
    ScenarioForeignInteractionPattern.WrappedCallback -> "ForeignInteractionPattern.WRAPPED_CALLBACK"
    ScenarioForeignInteractionPattern.CallbackThenIdentity -> "ForeignInteractionPattern.CALLBACK_THEN_IDENTITY"
    ScenarioForeignInteractionPattern.NestedCallback -> "ForeignInteractionPattern.NESTED_CALLBACK"
    ScenarioForeignInteractionPattern.BoxedCallback -> "ForeignInteractionPattern.BOXED_CALLBACK"
    ScenarioForeignInteractionPattern.BoxedIdentity -> "ForeignInteractionPattern.BOXED_IDENTITY"
    ScenarioForeignInteractionPattern.BoxedRepeatedCallback -> "ForeignInteractionPattern.BOXED_REPEATED_CALLBACK"
}

internal fun renderPureKotlinCInteropPrelude(hasCInterop: Boolean): String =
    if (!hasCInterop) {
        ""
    } else {
        """
        |private class ForeignRoundTripPayload(
        |    private val referenceKind: ForeignReferenceKind,
        |    value: Any?,
        |) {
        |    private val strongValue: Any? = if (referenceKind == ForeignReferenceKind.WEAK) null else value
        |    private val weakValue: WeakReference<Any>? = if (referenceKind == ForeignReferenceKind.WEAK) value?.let { WeakReference(it) } else null
        |
        |    fun load(): Any? = when (referenceKind) {
        |        ForeignReferenceKind.HANDLE,
        |        ForeignReferenceKind.STRONG,
        |            -> strongValue
        |        ForeignReferenceKind.WEAK -> weakValue?.value
        |    }
        |}
        |
        |private fun touchForeignPayload(payload: Any?) {
        |    when (payload) {
        |        null -> Unit
        |        is KotlinIndexAccess -> {
        |            val field0 = payload.loadKotlinField(0)
        |            payload.storeKotlinField(0, field0)
        |        }
        |        is Int -> payload.inc()
        |        is Boolean -> !payload
        |        else -> payload.hashCode()
        |    }
        |}
        |
        |private fun consumeForeignRoundTripPayload(raw: COpaquePointer?) {
        |    val payload = raw?.asStableRef<ForeignRoundTripPayload>()?.get()?.load()
        |    touchForeignPayload(payload)
        |}
        |
        |private fun runForeignInteraction(
        |    pointer: COpaquePointer?,
        |    pattern: ForeignInteractionPattern,
        |    repetitions: Int,
        |    callback: kotlinx.cinterop.CPointer<kotlinx.cinterop.CFunction<(COpaquePointer?) -> Unit>>,
        |) {
        |    when (pattern) {
        |        ForeignInteractionPattern.CALLBACK -> bridge_run_callback(callback, pointer)
        |        ForeignInteractionPattern.REPEATED_CALLBACK -> bridge_run_callback_repeated(callback, pointer, repetitions.coerceAtLeast(1))
        |        ForeignInteractionPattern.IDENTITY -> {
        |            val echoed = bridge_identity(pointer)
        |            bridge_run_callback(callback, echoed)
        |        }
        |        ForeignInteractionPattern.WRAPPED_CALLBACK -> bridge_run_callback_wrapped(callback, pointer)
        |        ForeignInteractionPattern.CALLBACK_THEN_IDENTITY -> bridge_run_callback_then_identity(callback, pointer)
        |        ForeignInteractionPattern.NESTED_CALLBACK -> bridge_run_callback_nested(callback, pointer, repetitions.coerceAtLeast(1))
        |        ForeignInteractionPattern.BOXED_CALLBACK -> bridge_run_boxed_callback(callback, pointer, repetitions)
        |        ForeignInteractionPattern.BOXED_IDENTITY -> {
        |            val boxed = bridge_box_identity(pointer, repetitions)
        |            bridge_run_callback(callback, boxed)
        |        }
        |        ForeignInteractionPattern.BOXED_REPEATED_CALLBACK -> bridge_run_boxed_callback_repeated(callback, pointer, repetitions, repetitions.coerceAtLeast(1))
        |    }
        |}
        |
        |private fun performForeignRoundTrip(
        |    value: Any?,
        |    referenceKind: ForeignReferenceKind,
        |    pattern: ForeignInteractionPattern,
        |    repetitions: Int,
        |) {
        |    if (value == null && referenceKind != ForeignReferenceKind.HANDLE) return
        |    val normalizedRepetitions = repetitions.coerceAtLeast(1)
        |    val handle = StableRef.create(ForeignRoundTripPayload(referenceKind, value))
        |    val callback = staticCFunction(::consumeForeignRoundTripPayload)
        |    try {
        |        runForeignInteraction(handle.asCPointer(), pattern, normalizedRepetitions, callback)
        |        performGC()
        |    } finally {
        |        handle.dispose()
        |    }
        |}
        """.trimMargin()
    }
