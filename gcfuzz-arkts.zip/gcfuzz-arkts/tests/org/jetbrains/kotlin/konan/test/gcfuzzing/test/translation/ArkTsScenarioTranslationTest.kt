/*
 * Copyright 2010-2025 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.konan.test.gcfuzzing.test.translation

import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.arkts.backend.ArkTsScenarioBackend
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioBody
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioDefinition
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioField
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioLocation
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioOp
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioPath
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioProgram
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioStoreReferenceKind
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioTargetLanguage
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioType
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.core.ScenarioValue
import org.jetbrains.kotlin.konan.test.gcfuzzing.fuzzer.mode.ScenarioBackendConfig
import org.junit.jupiter.api.Test
import kotlin.test.assertTrue

class ArkTsScenarioTranslationTest {
    @Test
    fun translatesClassWithIndexAccessAndConstructor() {
        val output = ArkTsScenarioBackend.lower(classScenario(), ScenarioBackendConfig.DEFAULT)
        assertTrue("class Class0 implements ArkTsIndexAccess" in output.contents)
        assertTrue("constructor(f0: Object | null, f1: Object | null)" in output.contents, "expected ctor params")
        assertTrue("public loadField(index: number): Object | null" in output.contents)
        assertTrue("public storeField(index: number, value: Object | null): void" in output.contents)
    }

    @Test
    fun translatesCreateObjectStoreAndGc() {
        val output = ArkTsScenarioBackend.lower(classScenario(), ScenarioBackendConfig.DEFAULT)
        assertTrue("new Class0(" in output.contents, "expected Class0 construction")
        assertTrue("alloc(() =>" in output.contents, "expected alloc wrapper")
        assertTrue("g0 =" in output.contents, "expected global store")
        assertTrue("tryGc()" in output.contents, "expected tryGc for PerformGc")
    }

    @Test
    fun translatesAllocationBurstAsLoop() {
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(ScenarioTargetLanguage.ArkTs, listOf(ScenarioField.StrongRef)),
            ),
            mainBody = ScenarioBody(
                listOf(ScenarioOp.AllocationBurst(classId = 0, count = 3))
            )
        )
        val output = ArkTsScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
        assertTrue("for (let i = 0; i < 3; i++)" in output.contents, "expected burst loop")
        assertTrue("new Class0(null)" in output.contents, "expected null args")
    }

    @Test
    fun translatesFieldPathStoreViaLoadStoreField() {
        // store into g0.loadField(1).storeField(2, value)
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Global(ScenarioTargetLanguage.ArkTs, ScenarioField.StrongRef),
                ScenarioDefinition.Class(ScenarioTargetLanguage.ArkTs, listOf(ScenarioField.StrongRef, ScenarioField.StrongRef)),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(localId = 0, classId = 0),
                    ScenarioOp.Store(
                        location = ScenarioLocation.Global(0, ScenarioPath(listOf(1, 2))),
                        value = ScenarioValue.LocalRef(0, ScenarioPath(listOf())),
                        referenceKind = ScenarioStoreReferenceKind.Strong,
                    ),
                )
            )
        )
        val output = ArkTsScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
        assertTrue("g0?.loadField(1)?.storeField(2," in output.contents, "expected field-path store")
    }

    private fun classScenario(): ScenarioProgram = ScenarioProgram(
        definitions = listOf(
            ScenarioDefinition.Global(ScenarioTargetLanguage.ArkTs, ScenarioField.StrongRef),
            ScenarioDefinition.Class(
                ScenarioTargetLanguage.ArkTs,
                listOf(ScenarioField.StrongRef, ScenarioField.IntValue),
            ),
        ),
        mainBody = ScenarioBody(
            listOf(
                ScenarioOp.CreateObject(localId = 0, classId = 0),
                ScenarioOp.Store(
                    location = ScenarioLocation.Global(0),
                    value = ScenarioValue.LocalRef(0),
                ),
                ScenarioOp.PerformGc(),
            )
        )
    )

    @Test
    fun translatesRichFieldsTypedStrongRefAndObjectArray() {
        val program = ScenarioProgram(
            definitions = listOf(
                ScenarioDefinition.Class(
                    ScenarioTargetLanguage.ArkTs,
                    listOf(
                        ScenarioField.TypedStrongRef(ScenarioType.ClassRef(0)),
                        ScenarioField.ObjectArray(size = 4),
                    ),
                ),
            ),
            mainBody = ScenarioBody(
                listOf(
                    ScenarioOp.CreateObject(localId = 0, classId = 0),
                    // field-path store: g0?... no global; instead store into a local field path
                    ScenarioOp.Store(
                        location = ScenarioLocation.Local(0, ScenarioPath(listOf(1))),
                        value = ScenarioValue.LocalRef(0, ScenarioPath(listOf())),
                    ),
                    ScenarioOp.Observe(ScenarioValue.LocalRef(0, ScenarioPath(listOf(1)))),
                    ScenarioOp.PerformGc(),
                )
            )
        )
        val output = ArkTsScenarioBackend.lower(program, ScenarioBackendConfig.DEFAULT)
        assertTrue("public f0: Object | null" in output.contents, "TypedStrongRef -> Object|null field")
        assertTrue("public f1: Object | null" in output.contents, "ObjectArray -> Object|null field")
        assertTrue("l0?.storeField(1, l0)" in output.contents, "expected field-path store via storeField")
        assertTrue("l0?.loadField(1)" in output.contents, "expected field-path load via loadField")
    }
}
