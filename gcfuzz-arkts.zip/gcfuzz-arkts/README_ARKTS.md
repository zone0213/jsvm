# ArkTS 后端使用说明

本目录是 `gc-fuzzing-tests` 的一个**新增语言后端**:把原本生成 Kotlin/Native GC 测试用例的生成逻辑,平行镜像出一条 **ArkTS** 后端,用于自动生成可在 OpenHarmony/HarmonyOS 上编译运行的 ArkTS(`.ets`)GC 压力测试用例。

生成器(IR)是语言无关的,本后端**不改 Generator**,只新增 `profile / generationProfile / backend / translation / output / runner / modeDescriptor` 并注册,与已有的 `pure-kotlin` 后端平行。设计依据见 `docs/spec/GCFUZZ_ADD_LANGUAGE_BACKEND_CN.md`。

## 它能做什么

给定一个随机种子,生成器产出一份语言无关的 IR(`ScenarioProgram`),ArkTS 后端把它翻译成单个源文件,再用 HarmonyOS SDK 自带的 `es2abc` 编译成合法的字节码 `main.abc`。

支持两种输出模式(`gcfuzzing.arkts.outputMode`,smoke 入口用环境变量 `GCFUZZ_OUTPUT` 控制):
- **JavaScript 模式(`js`,推荐用于跑用例)**:产出纯 `.js`(无 TS 专用语法),用 `es2abc --extension=js --module --merge-abc` 编译,产出的 `.abc` 可直接用 `ark_js_vm --entry-point=main main.abc` 运行。**此模式已在真实 `ark_js_vm` 上验证**:10/10 种子编译通过、运行输出 `fuzz-case-done`、跑约 30 秒 GC 压力循环后正常退出。
- **ETS 模式(`ets`,默认)**:产出 ArkTS `.ets`,用 `es2abc --extension=ts` 编译。`.ets` 不能用 `--extension=js` 编(纯 JS 严格模式拒绝 `interface` 等 TS 语法),所以要在 `ark_js_vm` 上跑**必须用 JS 模式**。

每个生成的源文件包含:
- prelude:`tryGc()`(分配压力 + `FinalizationRegistry` 观测)、`shouldTerminate()`/`FuzzControlException`、`alloc()`、`anyToInt`/`anyToBoolean`、best-effort reachability oracle(`assertReachability`)、顶层 `main()` 调用(ark_js_vm 不自动调入口,必须显式调)
- 类定义(含 `this.` 前缀的 `loadField`/`storeField` 索引访问)、全局 `let`、函数定义
- main 循环:对象构造、字段存储/读取路径、`AllocationBurst`、`tryGc()`、全局 root 交接、`Block`、弱引用观测与 reachability 断言

## 当前能力边界(重要)

- **生成 + es2abc 编译 + ark_js_vm 运行:已端到端验证可用**(JS 模式)。10/10 种子经 `es2abc --extension=js --module --merge-abc` 全部产出合法 `.abc`,并在 `ark_js_vm` 上跑通(0.039s 空跑的三个 bug——顶层 main 未调、类名按全局索引错位、字段裸访问——已修)。
- **GC 断言是 best-effort**:ArkTS 无公开强制 GC API,故 `PerformGc` 翻译成 `tryGc()`(分配压力 + `FinalizationRegistry` 观测)。ALIVE 断言是硬 throw(确定性),DEAD 断言是 no-op(对象可能尚未被回收,硬断会淹没在假阳性里)。这是相对 pure-kotlin 的 `GC.collect()` 确定性 oracle 的有意降级。
- **oracle 观测路径在自然 fuzzing 时极少触发**:启用 `WEAK_DEAD_CAPSULE` 后,生成器的拓扑选择策略(`topologyAttemptOrder` 的 family 权重不含 ORACLE)在混合 family 下几乎不路由到 oracle capsule。oracle 翻译路径本身已用手写 IR 验证正确且 es2abc 合法(见 `smoke/ArkTsOracleSmokeMain.kt`),但常规随机生成基本不会产出含 reachability 断言的用例。要测该路径,用手写 IR。
- **未做**:并发(`Worker`/`TaskPool`,隔离堆模型,root handoff 需重设计)、设备/hap 执行(`ArkTsScenarioRunner` 的 device 档预留但未实现)、严格 GC 死活 oracle。

## 目录结构(仅 ArkTS 新增部分)

路径前缀 `tests/org/jetbrains/kotlin/konan/test/gcfuzzing/`:

```
fuzzer/arkts/
  profile/ArkTsScenarioProfile.kt            # ScenarioPreparationProfile
  profile/ArkTsScenarioCapabilities.kt       # 能力矩阵(支持的 op/field/def/storage)
  profile/ArkTsScenarioCffi.kt               # foreign reference kind 规约
  mode/ArkTsScenarioGenerationProfile.kt    # features + supportedTopologies
  mode/ArkTsScenarioModeDescriptor.kt        # 入口, aliases = {arkts, ark-ts, ark}
  backend/ArkTsScenarioBackend.kt           # prepare -> validate -> produceArkTs
translation/
  ArkTsTranslation.kt                        # ScenarioProgram -> .ets 主翻译层
  ArkTsOutput.kt                              # files/entryFileName + save()
execution/arkts/
  ArkTsScenarioRunner.kt                      # es2abc 编译(compile-only / device 两档)
smoke/                                        # standalone 入口(不依赖 Gradle,手编可跑)
  ArkTsGenSmokeMain.kt                        # 批量生成 .ets(读 GCFUZZ_SEEDS/GCFUZZ_OUTDIR)
  ArkTsOracleSmokeMain.kt                     # 手写 oracle IR,验证 reachability 翻译路径
```

`fuzzer/core/Scenario.kt` 的 IR 枚举新增了 `ScenarioTargetLanguage.ArkTs` 与 `ScenarioDomain.ArkTs`(纯加值,不改语义);`fuzzer/mode/ScenarioModeRegistry.kt` 注册了 `ArkTsScenarioModeDescriptor`。

测试文件(`test/backend/ArkTsScenarioBackendTest.kt` 等)需要 junit-jupiter;本仓库的 Gradle 构建能解析,手编则需排除(见下)。

## 怎么跑

### 方式 A:不依赖 Gradle,直接用 Kotlin 编译器(本机已验证)

需要:JDK 21(本机用 DevEco 自带 JBR `C:\Program Files\Huawei\DevEco Studio\jbr`)、Kotlin 编译器 `kotlinc`(含 `lib/kotlin-compiler.jar`)、HarmonyOS SDK 的 `es2abc.exe`。

```powershell
# 1) 编译(impl + smoke,排除 13 个 import junit 的测试文件)
$JAVA_HOME = "C:\Program Files\Huawei\DevEco Studio\jbr"
$jbr       = "$JAVA_HOME\bin\java.exe"
$lib       = "<kotlinc>\lib"
$cp        = "$lib\kotlin-compiler.jar;$lib\kotlin-stdlib.jar;$lib\kotlin-test.jar"
$srcCp     = "$lib\kotlin-stdlib.jar;$lib\kotlin-test.jar"
$out       = "build\classes"

# src.txt: 列出所有 impl .kt + smoke main,排除 import org.junit 的文件
# (Select-String -Pattern 'org\.junit' 找出要排除的)
[System.IO.File]::WriteAllLines("src.txt", $srcList, [System.Text.Encoding]::ASCII)

& $jbr -XX:-UseCompressedOops -XX:-TieredCompilation `
  -cp $cp org.jetbrains.kotlin.cli.jvm.K2JVMCompiler `
  -classpath $srcCp -d $out "@src.txt"

# 2) 跑生成器,产出 .js(GCFUZZ_OUTPUT=js;不设则产 .ets)
$env:GCFUZZ_SEEDS  = "0,1,2,3,4,5,6,7,8,9"
$env:GCFUZZ_OUTDIR = "out"
$env:GCFUZZ_OUTPUT = "js"
$runCp = "$lib\kotlin-stdlib.jar;$lib\kotlin-test.jar;$out"
& $jbr -XX:-UseCompressedOops -XX:-TieredCompilation `
  -cp $runCp org.jetbrains.kotlin.konan.test.gcfuzzing.ArkTsGenSmokeMain
# → out\seed-N\main.js

# 3) es2abc 编译成 .abc(--extension=js,对齐 ark_js_vm 路径)
$es2abc = "C:\Program Files\Huawei\DevEco Studio\sdk\default\openharmony\ets\build-tools\ets-loader\bin\ark\build-win\bin\es2abc.exe"
& $es2abc out\seed-0\main.js --extension=js --module --merge-abc --output out\seed-0\main.abc --debug-info
```

### 方式 B:在另一台机器上用 es2abc + ark_js_vm 跑用例

把生成的 `main.js`(或整批 `sample-cases-js/`)拷到装了 `es2abc` + `ark_js_vm` 的机器,用脚本跑(示例 `test.sh`):

```sh
#!/bin/bash
export PATH=/path/to/ark/bin:$PATH          # 含 es2abc、ark_js_vm
export LD_LIBRARY_PATH=/path/to/icu:/path/to/zlib
file=$1
filename=${file%.*}
abc=${filename}.abc
es2abc "$file" --extension=js --module --merge-abc --output "$abc"
time ark_js_vm --entry-point="$filename" "$abc"
```

```sh
bash test.sh seed-0/main.js     # 期望:跑约 30s(soft timeout),输出 fuzz-case-done
```

判断用例跑成功:耗时远大于 0.0x 秒(说明 main 真执行了 GC 压力循环)、输出含 `fuzz-case-done`。若中途 `ark_js_vm` 崩溃/段错误,可能是发现了 Ark VM 的 GC bug——保留那个 `.js` 用例去报。

`ArkTsGenSmokeMain` 必须与 impl 同模块编译(它在包 `org.jetbrains.kotlin.konan.test.gcfuzzing` 下,才能访问 `internal` 的 `ArkTsScenarioBackend`/`generateScenarioWithMetadata` 等)。seed 是 `UInt`。`save()` 是 `ArkTsOutput` 的顶层扩展函数,需 `import ...translation.save`。

### 方式 B:Gradle(需完整环境)

```sh
./gradlew :gc-fuzzing-tests:test \
  -Dgcfuzzing.executionModel=arkts \
  -Dgcfuzzing.target=compile \
  -Dgcfuzzing.seed=1
```

`gcfuzzing.target=compile` 走 compile-only 档(默认);有设备时 `=device`(需 `gcfuzzing.ohos.serial` 等)。Gradle 路径会编译并运行 JUnit 测试套件(含 `ArkTsScenarioBackendTest`/`ArkTsScenarioTranslationTest`/`ArkTsScenarioExecutionTest`/`ArkTsCapabilityNegativeTest`)。

## 验证状态

- impl + smoke 编译:exit=0(~20s,仅 3 个 cosmetic redundant-`else` warning)
- 生成器 JS 模式 seeds 0–9:10/10 产出 `.js`(7K–35K)
- es2abc `--extension=js --module --merge-abc`:10/10 产出合法 `.abc`(7.5K–44K)
- **真实 `ark_js_vm` 实测**(JS 模式 seed-7):`es2abc main.js --extension=js --module --merge-abc` → `ark_js_vm --entry-point=main main.abc` → 输出 `fuzz-case-done`,**real 30s / user 44s**(GC 在干活)
- Node v24 实跑 10/10 种子:全部输出 `fuzz-case-done`、无 ReferenceError(0.1–26s,耗时随用例复杂度)
- 手写 oracle IR(`ArkTsOracleSmokeMain`):产出含 `registerObservation(0, (l0))` + `assertReachability(..., DEAD, o0?.deref())` 的源码,es2abc 编译 → 合法 7452B `.abc`

## IR → 源码翻译映射(核心)

| IR | ArkTS(ets)/ JS | 说明 |
|---|---|---|
| `Class` | `class ClassN`(+`implements ArkTsIndexAccess` 仅 ets) | `loadField`/`storeField` 用 `this.fN` 索引访问 |
| `Global` | 模块级 `let gN` | 无 `public`(顶层非法) |
| `Function` | `function funN(params): Object\|null` | |
| `CreateObject` | `let lN = alloc(() => new ClassM(args))` | |
| `Store` | `loc = value` 或 `loc?.storeField(i, value)` | 弱 field/全局包 `new WeakRef` |
| `Clear` | `loc = null` | |
| `Observe` | `value`(keep-alive) | 无 oracle 时为占位 |
| `PerformGc` | `tryGc()` | 分配压力 + FinalizationRegistry |
| `AllocationBurst` | `for(...) alloc(() => new ClassM())` | |
| `Block` | 内联 flatten | |
| `CreateReachabilityObservation` | `let oN = new WeakRef(value)` + `registerObservation(N, value)` | 接线 FinalizationRegistry |
| `CheckReachabilityObservation` | `assertReachability(label, EXP, oN?.deref())` | ALIVE 硬 throw,DEAD no-op |

## 设计依据

- 不改 `Generator.kt`(IR 语言无关,只平行加后端)。
- 不在通用 IR 里塞 ArkTS 编译细节。
- translation 是 IR 的确定性映射,不随机插入 IR 无感知行为。
- `PerformGc` 适配是关键决策:ArkTS 无 force-GC,降级为 best-effort;oracle 标注为 best-effort 而非确定性。
