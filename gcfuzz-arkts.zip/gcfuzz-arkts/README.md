# GC Fuzz 工具说明

> **新增:ArkTS 后端** — 本仓库在原有 `pure-kotlin` 后端基础上,平行新增了一条 ArkTS 后端,用于自动生成可在 OpenHarmony/HarmonyOS 上编译的 ArkTS(`.ets`)GC 压力测试用例。详见 [README_ARKTS.md](README_ARKTS.md)。

`gc-fuzzing-tests` 是一个面向 Kotlin/Native GC 的 fuzz 工具，是 HLT `tools/gc-fuzz` 工具的核心模块。

它做的事情很直接：

- 随机生成一批带对象分配、字段更新、线程并发、GC 触发、oracle 断言的程序
- 用指定的本地 Kotlin/Native 工具链编译这些程序
- 运行生成的二进制
- 收集编译失败、运行崩溃、运行时断言失败、minidump 和 HTML 报告

这个模块从 Kotlin 主仓运行方式中解耦出来。daily 编排与归档由 ops 层承担，正式运行结果默认落在 `HLT/ops/gc-fuzz-daily/workspace/` 下。

## 目录定位

- [tests](tools/gc-fuzz/gc-fuzzing-tests/tests)
  - fuzz 生成、lower、执行、测试入口代码
- [testData](tools/gc-fuzz/gc-fuzzing-tests/testData)
  - 一些 DSL / lower 测试数据
- [HLT/ops/gc-fuzz-daily/scripts/run_gc_fuzz_daily.sh](ops/gc-fuzz-daily/scripts/run_gc_fuzz_daily.sh)
  - 最常用的正式运行入口（ops 层）

## 前置条件

需要一份本地 Kotlin/Native dist，例如：

```sh
/path/to/kotlin-native/dist
```

至少要满足：

- `bin/konanc` 或 `bin/kotlinc-native` 存在
- 当前机器可以直接运行编译出的本地可执行文件

如果跑 `cmc`，还需要可用的 `libcrt.so`：

- 可以通过 `DAILY_LIBCRT_PATH` 或 `GCFUZZ_LIBCRT_PATH` 显式指定
- 如果工具链目录下能自动找到，也可以直接复用

## 最常用运行方式

推荐直接用 ops 层的 daily 脚本。它会：

- 调 Gradle 跑 fuzz
- 把完整运行结果放到 `HLT/ops/gc-fuzz-daily/workspace/runs/<runId>`
- 把失败用例归档到 `HLT/ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases/<runId>`
- 把失败历史归档到 `HLT/ops/gc-fuzz-daily/workspace/archives/gcfuzz-failure-archive/<runId>`

示例：

```sh
env \
  DAILY_KN_NATIVE_HOME=/path/to/kotlin-native/dist \
  DAILY_GC=cms \
  GCFUZZ_TIMELIMIT=30m \
  GCFUZZ_PARALLELISM=4 \
  /bin/zsh ops/gc-fuzz-daily/scripts/run_gc_fuzz_daily.sh
```

如果要固定 seed：

```sh
env \
  DAILY_KN_NATIVE_HOME=/path/to/kotlin-native/dist \
  DAILY_GC=cms \
  GCFUZZ_TIMELIMIT=30m \
  GCFUZZ_PARALLELISM=4 \
  GCFUZZ_SEED=1 \
  /bin/zsh ops/gc-fuzz-daily/scripts/run_gc_fuzz_daily.sh
```

## 直接用 Gradle 运行

如果你只想手工跑，不走 daily 归档，也可以直接在工具目录跑：

```sh
cd tools/gc-fuzz

./gradlew :gc-fuzzing-tests:test \
  --tests org.jetbrains.kotlin.konan.test.gcfuzzing.GCFuzzingTest.simple \
  -Dkn.nativeHome=/path/to/kotlin-native/dist \
  -Dgcfuzzing.executionModel=pure-kotlin \
  -Dgcfuzzing.gc=cms \
  -Dgcfuzzing.timelimit=5m \
  -Dgcfuzzing.parallelism=1 \
  -Dgcfuzzing.seed=1
```

如果希望完整结果落到自定义目录，可以显式指定：

```sh
-Dgcfuzzing.resultsRoot=/path/to/runs
```

## 常用参数

daily 脚本最常用的环境变量：

- `DAILY_KN_NATIVE_HOME`
  - 本地 Kotlin/Native dist 路径
- `DAILY_GC`
  - `cms` 或 `cmc`
- `GCFUZZ_TIMELIMIT`
  - 单轮 fuzz 时长，例如 `1m`、`30m`
- `GCFUZZ_PARALLELISM`
  - fuzz 并发度
- `GCFUZZ_SEED`
  - 固定随机种子，便于复现
- `DAILY_FFI`
  - `true` 或 `false`，控制 pure-kotlin 模式下是否开启 FFI 能力
- `DAILY_EXECUTION_MODEL`
  - 当前正式支持 `pure-kotlin`
- `DAILY_LIBCRT_PATH`
  - `cmc` 模式需要时显式指定 `libcrt.so`

对应的 Gradle system properties：

- `-Dkn.nativeHome=...`
- `-Dgcfuzzing.gc=...`
- `-Dgcfuzzing.timelimit=...`
- `-Dgcfuzzing.parallelism=...`
- `-Dgcfuzzing.seed=...`
- `-Dgcfuzzing.ffi=...`
- `-Dgcfuzzing.executionModel=pure-kotlin`
- `-Dgcfuzzing.resultsRoot=...`

## 结果怎么看

### 1. 完整运行结果

每轮完整运行结果在：

- [HLT/ops/gc-fuzz-daily/workspace/runs](ops/gc-fuzz-daily/workspace/runs)

结构大致是：

```text
ops/gc-fuzz-daily/workspace/runs/<runId>/
  index.html
  case-index.html
  I1234567890/
    generated/
    app.kexe
    app.kexe.log
    run.log
    *.dmp
    app.kexe.dSYM/
```

其中：

- `index.html`
  - Gradle/JUnit 总报告
- `case-index.html`
  - case 维度的汇总页，更适合看 fuzz 结果
- `<caseId>/generated/`
  - 这个用例的生成源码
- `<caseId>/app.kexe.log`
  - 编译日志
- `<caseId>/run.log`
  - 运行日志
- `<caseId>/*.dmp`
  - 崩溃时的 minidump

### 2. 失败用例归档

每轮失败摘要和失败 case 复制件在：

- [HLT/ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases](ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases)

结构大致是：

```text
ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases/<runId>/
  failed-cases-summary.tsv
  failed-case-ids.txt
  case-index.html
  cases/
    I1234567890/
```

这个目录适合：

- 快速看这一轮新增了哪些失败
- 只拿失败 case 做复现
- 给 Jenkins 做归档

### 3. 长期失败历史

长期失败历史在：

- [HLT/ops/gc-fuzz-daily/workspace/archives/gcfuzz-failure-archive](ops/gc-fuzz-daily/workspace/archives/gcfuzz-failure-archive)

这个目录不会自动删，适合长期积累失败样本。

## 保留策略

当前默认策略：

- `ops/gc-fuzz-daily/workspace/runs`
  - 只保留最近 `5` 轮
- `ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases`
  - 不自动删
- `ops/gc-fuzz-daily/workspace/archives/gcfuzz-failure-archive`
  - 不自动删

## 出现失败后怎么排查

建议顺序：

1. 打开对应 run 的 `case-index.html`
2. 找到失败 case，例如 `I2763064752`
3. 进入该 case 目录，看：
   - `generated/`
   - `app.kexe.log`
   - `run.log`
   - `*.dmp`
4. 如果要单独复现，直接拿这个 case 目录里的源码和日志继续编译/运行

## 目前的正式能力范围

当前正式运行路径是：

- `pure-kotlin`
- 可通过开关决定是否启用 FFI 插入

这个仓库里还有不少架构文档和历史设计文档，但日常使用时，你主要只需要看：

- 本 README
- `HLT/ops/gc-fuzz-daily/scripts/run_gc_fuzz_daily.sh`
- `HLT/ops/gc-fuzz-daily/workspace/runs/<runId>`
- `HLT/ops/gc-fuzz-daily/workspace/archives/gcfuzz-failed-cases/<runId>`
