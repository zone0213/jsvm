class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
let g3 = null
let g4 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = anyToInt(null)
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

class Class2{
    constructor(f0, f1, f2, f3, f4, f5, f6)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = null
    f6 = null
    loadField(index){
        switch ((index % 7)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 7)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = value; break;
            default: break;
        }
    }
}

class Class3{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = anyToInt(null)
    f4 = null
    f5 = null
    f6 = anyToInt(null)
    f7 = null
    loadField(index){
        switch ((index % 8)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6;
            case 7: return this.f7;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 8)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = anyToInt(value); break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = anyToInt(value); break;
            case 7: this.f7 = value; break;
            default: break;
        }
    }
}

class Class4{
    constructor(f0, f1, f2, f3, f4, f5, f6)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = anyToInt(null)
    f4 = null
    f5 = anyToBoolean(null)
    f6 = null
    loadField(index){
        switch ((index % 7)){
            case 0: return this.f0;
            case 1: return this.f1?.deref();
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4?.deref();
            case 5: return this.f5;
            case 6: return this.f6?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 7)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value == null ? null : new WeakRef(value); break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = anyToInt(value); break;
            case 4: this.f4 = value == null ? null : new WeakRef(value); break;
            case 5: this.f5 = anyToBoolean(value); break;
            case 6: this.f6 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

function fun0(l0, l1, l2){
    tryGc()
    for (let i = 0; i < 59; i++){
        alloc(() => { return new Class3(null, null, null, null, null, null, null, null); })
    }
    g4
    let l4 = alloc(() => { return new Class2(l0, l1, g4, null, null, null, null); })
    g1 = g1
    tryGc()
    g1 = g2
    let l5 = alloc(() => { return new Class2(l4?.loadField(0), null, null, null, null, null, null); })
    tryGc()
    for (let i = 0; i < 43; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null, null); })
    }
    let l6 = alloc(() => { return new Class1(g0, g1); })
    g0 = g2
    let l7 = alloc(() => { return new Class4(l2, null, null, null, null, null, null); })
    g3 = g3
    let l8 = alloc(() => { return new Class4(g2, g3, g2, null, null, null, null); })
    let l9 = alloc(() => { return new Class2(g1, g2, g4, l4?.loadField(1), g4, g0, g0); })
    g1 = g4
    l7?.storeField(3, l5?.loadField(5))
    g3 = g4
    let l10 = alloc(() => { return new Class0(g0, g4); })
    g2 = g2
    g3 = l5?.loadField(5)
    l6?.loadField(0)
    l4 = l1
    g0 = l5?.loadField(4)
    return null
}

function fun1(l0, l1, l2, l3, l4, l5, l6, l7, l8, l9, l10){
    g2 = l9
    g1 = l7
    g1 = l7
    let l11 = alloc(() => { return new Class3(g3, l5, l10, null, null, null, null, null); })
    let l12 = alloc(() => { return new Class4(g0, g3, l3, l3, null, null, null); })
    g3 = g0
    l1
    let l14 = alloc(() => { return new Class3(g3, g1, l11?.loadField(4), l4, null, null, null, null); })
    let l15 = alloc(() => { return new Class1(g0, g0); })
    let l16 = alloc(() => { return new Class1(l1, g0); })
    let l17 = alloc(() => { return new Class2(null, null, null, null, null, null, null); })
    l12 = l0
    g3 = g0
    let l18 = alloc(() => { return new Class1(null, null); })
    let l19 = alloc(() => { return new Class1(g2, null); })
    g0
    g3 = l1
    let l21 = alloc(() => { return new Class2(l2, null, null, null, null, null, null); })
    g3 = null
    l21?.storeField(3, g0)
    g4 = g4
    tryGc()
    l14 = g4
    tryGc()
    let l22 = alloc(() => { return new Class2(l11?.loadField(4), null, null, null, null, null, null); })
    let l23 = alloc(() => { return new Class4(g1, g2, null, null, null, null, null); })
    g3 = l5
    let l24 = alloc(() => { return new Class2(l14?.loadField(1), l7, l10, g2, null, null, null); })
    let l25 = alloc(() => { return new Class4(g2, g3, g1, l3, l3, g4, null); })
    let l26 = alloc(() => { return new Class0(l18?.loadField(1), null); })
    return null
}

function fun2(){
    g4
    let l1 = alloc(() => { return new Class4(g1, null, null, null, null, null, null); })
    g4 = g2
    l1?.storeField(4, g1)
    l1 = g0
    for (let i = 0; i < 32; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null, null); })
    }
    g0 = l1?.loadField(2)
    for (let i = 0; i < 15; i++){
        alloc(() => { return new Class0(null, null); })
    }
    tryGc()
    for (let i = 0; i < 18; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null, null); })
    }
    tryGc()
    let l2 = alloc(() => { return new Class0(g1, g0); })
    tryGc()
    g1 = g3
    g4
    g0 = g0
    g2 = l2?.loadField(0)
    g2 = g1
    tryGc()
    g0 = g1
    g1
    l1?.storeField(4, l2?.loadField(0))
    let l5 = alloc(() => { return new Class2(g4, null, g1, null, null, null, null); })
    g1 = g4
    let l6 = alloc(() => { return new Class2(g0, l2?.loadField(1), g3, null, null, null, null); })
    l6 = g4
    let l7 = alloc(() => { return new Class1(g1, null); })
    l7 = g1
    let l8 = alloc(() => { return new Class4(g4, null, null, null, null, null, null); })
    tryGc()
    return null
}

function fun3(l0){
    let l1 = alloc(() => { return new Class2(g0, g2, null, null, null, null, null); })
    l1?.storeField(4, g4)
    g2
    g2 = g3
    g1 = g0
    g0 = g4
    g4 = l0
    g1 = l0
    let l3 = alloc(() => { return new Class4(g4, g2, g3, g3, null, null, null); })
    g1 = l0
    g3
    g2 = l0
    tryGc()
    let l5 = alloc(() => { return new Class4(l1?.loadField(1), null, null, null, null, null, null); })
    g4 = g2
    l5?.storeField(2, g2)
    null
    tryGc()
    let l7 = alloc(() => { return new Class4(g4, g4, g4, null, null, null, null); })
    let l8 = alloc(() => { return new Class3(null, null, null, null, null, null, null, null); })
    let l9 = alloc(() => { return new Class0(l0, l3?.loadField(3)); })
    let l10 = alloc(() => { return new Class2(g2, g0, null, null, null, null, null); })
    let l11 = alloc(() => { return new Class1(g3, null); })
    g0 = l1?.loadField(2)
    tryGc()
    let l12 = alloc(() => { return new Class0(l7?.loadField(3), l0); })
    g1 = g1
    l7?.storeField(1, l11?.loadField(0))
    l7 = g3
    g4 = l8?.loadField(2)
    g1 = l3?.loadField(4)
    let l13 = alloc(() => { return new Class2(g0, null, null, null, null, null, null); })
    return null
}

function fun4(l0, l1, l2, l3){
    g1 = g3
    g3 = g0
    g2 = g0
    g1
    l3
    g1 = g4
    g2 = l3
    g4
    g4 = l1
    g0
    let l8 = alloc(() => { return new Class0(g0, g2); })
    l8 = l8?.loadField(0)
    let l9 = alloc(() => { return new Class1(l1, l0); })
    let l10 = alloc(() => { return new Class2(g0, l2, g1, null, null, null, null); })
    let l11 = alloc(() => { return new Class3(l3, null, null, null, null, null, null, null); })
    return null
}

function fun5(l0, l1, l2){
    let l3 = alloc(() => { return new Class1(g0, g0); })
    g1 = g4
    g4
    l3?.storeField(1, l0)
    let l5 = alloc(() => { return new Class3(g2, g2, l0, g0, l2, l3?.loadField(0), l3?.loadField(0), null); })
    let l6 = alloc(() => { return new Class4(g3, g4, null, null, null, null, null); })
    l5?.loadField(0)
    let l8 = alloc(() => { return new Class2(l3?.loadField(0), null, null, null, null, null, null); })
    l6 = g0
    g2 = l2
    let l9 = alloc(() => { return new Class1(null, g1); })
    tryGc()
    let l10 = alloc(() => { return new Class1(g0, l0); })
    g3 = l2
    tryGc()
    let l11 = alloc(() => { return new Class3(g3, l10?.loadField(0), l2, null, null, null, null, null); })
    l3?.storeField(0, g2)
    let l12 = alloc(() => { return new Class3(l10?.loadField(0), g3, l2, l1, l1, l6?.loadField(0), g3, l10?.loadField(1)); })
    let l13 = alloc(() => { return new Class0(g0, null); })
    let l14 = alloc(() => { return new Class2(l5?.loadField(7), l10?.loadField(1), l13?.loadField(1), null, null, null, null); })
    let l15 = alloc(() => { return new Class4(null, null, null, null, null, null, null); })
    g1
    l14?.storeField(4, g0)
    for (let i = 0; i < 22; i++){
        alloc(() => { return new Class1(null, null); })
    }
    g4 = g0
    let l17 = alloc(() => { return new Class0(g3, g0); })
    let l18 = alloc(() => { return new Class0(g2, l5?.loadField(7)); })
    g0 = g1
    let l19 = alloc(() => { return new Class4(g4, g1, g0, null, null, null, null); })
    g2 = l0
    let l20 = alloc(() => { return new Class3(l15?.loadField(2), g3, g2, null, null, null, null, null); })
    return null
}

function fun6(l0, l1, l2){
    let l3 = alloc(() => { return new Class0(g1, null); })
    l2
    let l5 = alloc(() => { return new Class2(null, null, null, null, null, null, null); })
    g0 = g0
    g2 = g0
    g0 = g3
    l5 = l3?.loadField(0)
    let l6 = alloc(() => { return new Class3(g0, l0, g0, g3, l3?.loadField(0), l5?.loadField(6), g0, null); })
    let l7 = alloc(() => { return new Class4(g4, null, null, null, null, null, null); })
    let l8 = alloc(() => { return new Class0(l3?.loadField(0), null); })
    g0 = l6?.loadField(6)
    let l9 = alloc(() => { return new Class0(g2, null); })
    for (let i = 0; i < 46; i++){
        alloc(() => { return new Class0(null, null); })
    }
    tryGc()
    g2 = l7?.loadField(0)
    for (let i = 0; i < 57; i++){
        alloc(() => { return new Class1(null, null); })
    }
    let l10 = alloc(() => { return new Class1(l1, l1); })
    g3 = l5?.loadField(4)
    let l11 = alloc(() => { return new Class3(g0, g1, g1, l10?.loadField(1), g4, g3, g0, g3); })
    let l12 = alloc(() => { return new Class4(null, null, null, null, null, null, null); })
    let l13 = alloc(() => { return new Class3(l3?.loadField(1), g1, null, null, null, null, null, null); })
    let l14 = alloc(() => { return new Class1(g4, null); })
    let l15 = alloc(() => { return new Class2(g3, g4, null, null, null, null, null); })
    l3 = g1
    g0 = g1
    return null
}

function fun7(l0, l1){
    tryGc()
    let l2 = alloc(() => { return new Class4(g2, null, null, g1, null, null, null); })
    g3 = null
    tryGc()
    let l3 = alloc(() => { return new Class0(l0, g2); })
    let l4 = alloc(() => { return new Class2(null, null, null, null, null, null, null); })
    let l5 = alloc(() => { return new Class3(g0, l4?.loadField(1), l0, null, null, null, null, null); })
    g4 = g2
    let l6 = alloc(() => { return new Class0(l4?.loadField(3), l1); })
    l3 = g0
    return null
}


function mainBodyImpl(){
    g4
    let l1 = alloc(() => { return new Class1(g3, g4); })
    tryGc()
    let l2 = alloc(() => { return new Class4(g2, null, null, null, null, null, null); })
    let l3 = alloc(() => { return new Class2(g0, null, null, null, null, null, null); })
    g4
    let l5 = alloc(() => { return new Class1(null, l1?.loadField(1)); })
    let l6 = alloc(() => { return new Class0(g2, null); })
    g1
    let l8 = alloc(() => { return new Class3(g0, g2, g3, null, null, null, null, null); })
    let l9 = alloc(() => { return new Class3(l8?.loadField(2), null, null, null, null, null, null, null); })
    tryGc()
    l5?.loadField(1)
    let l11 = alloc(() => { return new Class1(g3, null); })
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
