class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
let g3 = null
let g4 = null
let g5 = null
let g6 = null
let g7 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0)
    {
        this.f0 = f0
    }
    f0 = anyToInt(null)
    loadField(index){
        switch ((index % 1)){
            case 0: return this.f0;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 1)){
            case 0: this.f0 = anyToInt(value); break;
            default: break;
        }
    }
}

function fun0(l0, l1, l2){
    g7 = g1
    g4 = g1
    let l3 = alloc(() => { return new Class0(g2, null); })
    let l4 = alloc(() => { return new Class0(g3, g3); })
    let l5 = alloc(() => { return new Class1(l2); })
    g6
    g6 = l0
    g1
    let l8 = alloc(() => { return new Class0(g3, g6); })
    let l9 = alloc(() => { return new Class0(g4, null); })
    for (let i = 0; i < 52; i++){
        alloc(() => { return new Class1(null); })
    }
    for (let i = 0; i < 29; i++){
        alloc(() => { return new Class1(null); })
    }
    g4 = g7
    return null
}

function fun1(l0){
    tryGc()
    g7 = g2
    let l1 = alloc(() => { return new Class1(g7); })
    l1 = g5
    let l2 = alloc(() => { return new Class0(g6, g2); })
    l2 = null
    l1 = l2?.loadField(1)
    l2 = l1?.loadField(0)
    g1
    g2 = l2?.loadField(0)
    g2
    tryGc()
    let l5 = alloc(() => { return new Class1(null); })
    g6 = g1
    l5 = l5?.loadField(0)
    let l6 = alloc(() => { return new Class1(g0); })
    g2 = g7
    let l7 = alloc(() => { return new Class0(l6?.loadField(0), g5); })
    return null
}

function fun2(l0){
    g1 = l0
    tryGc()
    g4
    g1 = l0
    let l2 = alloc(() => { return new Class1(l0); })
    g5
    g1 = g6
    tryGc()
    let l4 = alloc(() => { return new Class0(null, null); })
    let l5 = alloc(() => { return new Class1(null); })
    g6
    return null
}

function fun3(l0){
    tryGc()
    g0 = l0
    let l1 = alloc(() => { return new Class1(l0); })
    g6
    let l3 = alloc(() => { return new Class1(g7); })
    g0
    l3 = g2
    g7
    let l6 = alloc(() => { return new Class1(l1?.loadField(0)); })
    tryGc()
    for (let i = 0; i < 55; i++){
        alloc(() => { return new Class1(null); })
    }
    return null
}


function mainBodyImpl(){
    let l0 = alloc(() => { return new Class1(null); })
    tryGc()
    l0 = g4
    let l1 = alloc(() => { return new Class1(null); })
    l0?.loadField(0)
    let l3 = alloc(() => { return new Class1(l1?.loadField(0)); })
    l3 = g3
    let l4 = alloc(() => { return new Class1(l1?.loadField(0)); })
    let l5 = alloc(() => { return new Class0(l3?.loadField(0), g3); })
    for (let i = 0; i < 15; i++){
        alloc(() => { return new Class0(null, null); })
    }
    let l6 = alloc(() => { return new Class0(l5?.loadField(0), null); })
    l4?.loadField(0)
    l0?.storeField(0, l5?.loadField(1))
    tryGc()
    l3?.loadField(0)
    for (let i = 0; i < 24; i++){
        alloc(() => { return new Class1(null); })
    }
    let l9 = alloc(() => { return new Class0(l1?.loadField(0), g2); })
    let l10 = alloc(() => { return new Class1(l0?.loadField(0)); })
    g1
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
