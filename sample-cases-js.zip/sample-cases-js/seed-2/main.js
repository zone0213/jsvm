class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
let g3 = null
let g4 = null
let g5 = null
let g6 = null
let g7 = null
let g8 = null
let g9 = null
let g10 = null
let g11 = null
let g12 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = anyToInt(null)
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0)
    {
        this.f0 = f0
    }
    f0 = anyToInt(null)
    loadField(index){
        switch ((index % 1)){
            case 0: return this.f0;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 1)){
            case 0: this.f0 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class2{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

class Class3{
    constructor(f0, f1, f2, f3, f4)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
    }
    f0 = anyToBoolean(null)
    f1 = null
    f2 = null
    f3 = null
    f4 = anyToInt(null)
    loadField(index){
        switch ((index % 5)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3?.deref();
            case 4: return this.f4;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 5)){
            case 0: this.f0 = anyToBoolean(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value == null ? null : new WeakRef(value); break;
            case 4: this.f4 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class4{
    constructor(f0, f1, f2, f3, f4, f5)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
    }
    f0 = anyToBoolean(null)
    f1 = null
    f2 = anyToInt(null)
    f3 = anyToBoolean(null)
    f4 = null
    f5 = null
    loadField(index){
        switch ((index % 6)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 6)){
            case 0: this.f0 = anyToBoolean(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = anyToInt(value); break;
            case 3: this.f3 = anyToBoolean(value); break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

class Class5{
    constructor(f0, f1, f2, f3, f4, f5)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = null
    loadField(index){
        switch ((index % 6)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 6)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value; break;
            default: break;
        }
    }
}

class Class6{
    constructor(f0, f1, f2, f3, f4, f5)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
    }
    f0 = anyToBoolean(null)
    f1 = anyToInt(null)
    f2 = anyToInt(null)
    f3 = null
    f4 = null
    f5 = null
    loadField(index){
        switch ((index % 6)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 6)){
            case 0: this.f0 = anyToBoolean(value); break;
            case 1: this.f1 = anyToInt(value); break;
            case 2: this.f2 = anyToInt(value); break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

class Class7{
    constructor(f0, f1, f2, f3, f4, f5, f6)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = anyToBoolean(null)
    f6 = null
    loadField(index){
        switch ((index % 7)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            case 2: return this.f2?.deref();
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 7)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value == null ? null : new WeakRef(value); break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = anyToBoolean(value); break;
            case 6: this.f6 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

class Class8{
    constructor(f0, f1, f2)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
    }
    f0 = null
    f1 = null
    f2 = null
    loadField(index){
        switch ((index % 3)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 3)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            default: break;
        }
    }
}

function fun0(l0, l1, l2, l3, l4){
    let l5 = alloc(() => { return new Class0(g2, null); })
    l5 = l5?.loadField(0)
    g3 = g1
    let l6 = alloc(() => { return new Class3(l1, null, null, null, null); })
    g7 = l5?.loadField(0)
    g11 = l4
    let l7 = alloc(() => { return new Class7(g11, l1, null, null, null, null, null); })
    let l8 = alloc(() => { return new Class5(g2, null, null, null, null, null); })
    l7?.storeField(1, g12)
    tryGc()
    let l9 = alloc(() => { return new Class2(g10, g7); })
    let l10 = alloc(() => { return new Class8(null, null, null); })
    let l11 = alloc(() => { return new Class8(l1, null, null); })
    return null
}

function fun1(l0){
    g12 = l0
    g10 = g2
    let l1 = alloc(() => { return new Class0(g12, l0); })
    let l2 = alloc(() => { return new Class7(g11, g3, g7, g0, g11, g10, g11); })
    let l3 = alloc(() => { return new Class7(l1?.loadField(1), null, null, null, null, null, null); })
    g0
    for (let i = 0; i < 18; i++){
        alloc(() => { return new Class5(null, null, null, null, null, null); })
    }
    g11 = g8
    g1 = g12
    let l5 = alloc(() => { return new Class1(l3?.loadField(4)); })
    let l6 = alloc(() => { return new Class1(l0); })
    g12
    g9
    let l9 = alloc(() => { return new Class1(null); })
    return null
}

function fun2(l0, l1, l2){
    l1
    g11
    for (let i = 0; i < 15; i++){
        alloc(() => { return new Class7(null, null, null, null, null, null, null); })
    }
    tryGc()
    g11 = l0
    g0 = g2
    let l5 = alloc(() => { return new Class2(g9, null); })
    l2
    let l7 = alloc(() => { return new Class8(l5?.loadField(1), l0, g4); })
    g10 = g7
    let l8 = alloc(() => { return new Class6(g12, null, g7, null, null, null); })
    l7 = g7
    tryGc()
    let l9 = alloc(() => { return new Class6(g2, l1, g9, g9, null, null); })
    tryGc()
    for (let i = 0; i < 61; i++){
        alloc(() => { return new Class2(null, null); })
    }
    g3 = g1
    for (let i = 0; i < 15; i++){
        alloc(() => { return new Class7(null, null, null, null, null, null, null); })
    }
    tryGc()
    g2 = l2
    return null
}

function fun3(l0){
    let l1 = alloc(() => { return new Class6(null, g3, null, null, null, null); })
    g7
    let l3 = alloc(() => { return new Class5(null, null, null, null, null, null); })
    let l4 = alloc(() => { return new Class4(l0, l1?.loadField(1), null, null, null, null); })
    g2 = l0
    let l5 = alloc(() => { return new Class5(null, null, null, null, null, null); })
    let l6 = alloc(() => { return new Class7(g2, g7, null, null, null, null, null); })
    let l7 = alloc(() => { return new Class5(g4, null, null, null, null, null); })
    let l8 = alloc(() => { return new Class3(l5?.loadField(5), null, null, null, null); })
    l7?.loadField(1)
    l8 = g5
    return null
}

function fun4(l0, l1, l2){
    g10 = g3
    let l3 = alloc(() => { return new Class2(l0, g3); })
    l3 = g0
    let l4 = alloc(() => { return new Class7(l2, l3?.loadField(1), g1, g10, l1, g12, g4); })
    g12 = g1
    g8 = l3?.loadField(1)
    l2
    let l6 = alloc(() => { return new Class7(g6, l3?.loadField(1), null, null, null, null, null); })
    let l7 = alloc(() => { return new Class5(g9, g3, null, null, null, null); })
    g5 = g11
    g7 = l2
    let l8 = alloc(() => { return new Class0(g3, null); })
    tryGc()
    let l9 = alloc(() => { return new Class8(l2, l1, null); })
    let l10 = alloc(() => { return new Class1(g2); })
    tryGc()
    l4?.storeField(0, null)
    l6 = g12
    let l11 = alloc(() => { return new Class5(l10?.loadField(0), l2, l2, l2, null, null); })
    let l12 = alloc(() => { return new Class7(g11, null, null, null, null, null, null); })
    l11?.loadField(0)
    g0 = l11?.loadField(5)
    g3
    tryGc()
    l7 = l8?.loadField(1)
    l9?.storeField(0, g1)
    return null
}

function fun5(l0, l1, l2, l3, l4, l5, l6, l7, l8, l9, l10){
    let l11 = alloc(() => { return new Class1(g10); })
    for (let i = 0; i < 50; i++){
        alloc(() => { return new Class7(null, null, null, null, null, null, null); })
    }
    g3
    let l13 = alloc(() => { return new Class7(g12, g9, null, null, null, null, null); })
    let l14 = alloc(() => { return new Class0(g0, null); })
    let l15 = alloc(() => { return new Class1(g5); })
    let l16 = alloc(() => { return new Class1(null); })
    l15 = g11
    let l17 = alloc(() => { return new Class8(g6, g0, null); })
    l17?.storeField(2, g10)
    return null
}

function fun6(){
    let l0 = alloc(() => { return new Class7(null, null, g3, null, null, null, null); })
    let l1 = alloc(() => { return new Class2(null, g1); })
    g12 = g0
    g7 = g12
    let l2 = alloc(() => { return new Class0(g6, g6); })
    g3 = g0
    let l3 = alloc(() => { return new Class4(null, null, null, null, null, null); })
    let l4 = alloc(() => { return new Class5(null, null, null, null, null, null); })
    g3 = g7
    g3 = g12
    for (let i = 0; i < 52; i++){
        alloc(() => { return new Class8(null, null, null); })
    }
    for (let i = 0; i < 24; i++){
        alloc(() => { return new Class0(null, null); })
    }
    g6 = g5
    g12 = l2?.loadField(1)
    l1?.storeField(1, null)
    return null
}

function fun7(l0, l1, l2){
    let l3 = alloc(() => { return new Class2(g2, g6); })
    let l4 = alloc(() => { return new Class5(g4, null, null, null, null, null); })
    l4 = l1
    let l5 = alloc(() => { return new Class8(l2, null, null); })
    l3 = g7
    l5?.storeField(2, g3)
    let l6 = alloc(() => { return new Class4(g6, g3, null, null, null, null); })
    let l7 = alloc(() => { return new Class2(l3?.loadField(1), g11); })
    l4?.storeField(1, g1)
    let l8 = alloc(() => { return new Class2(g0, g5); })
    g7
    let l10 = alloc(() => { return new Class2(g4, l2); })
    g9 = l1
    tryGc()
    let l11 = alloc(() => { return new Class1(g4); })
    let l12 = alloc(() => { return new Class2(l4?.loadField(2), l3?.loadField(1)); })
    g7 = g9
    l8 = l5?.loadField(2)
    l4?.storeField(0, g3)
    tryGc()
    let l13 = alloc(() => { return new Class8(null, null, null); })
    tryGc()
    tryGc()
    g3 = g5
    return null
}

function fun8(l0, l1){
    let l2 = alloc(() => { return new Class2(g8, g4); })
    let l3 = alloc(() => { return new Class1(l1); })
    for (let i = 0; i < 55; i++){
        alloc(() => { return new Class8(null, null, null); })
    }
    l3 = g7
    let l4 = alloc(() => { return new Class3(g1, l2?.loadField(1), null, null, null); })
    g9 = g3
    tryGc()
    g4 = l1
    for (let i = 0; i < 30; i++){
        alloc(() => { return new Class1(null); })
    }
    return null
}


function mainBodyImpl(){
    tryGc()
    g6 = g0
    for (let i = 0; i < 25; i++){
        alloc(() => { return new Class2(null, null); })
    }
    let l0 = alloc(() => { return new Class1(null); })
    for (let i = 0; i < 24; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null); })
    }
    g1 = l0?.loadField(0)
    tryGc()
    let l1 = alloc(() => { return new Class4(l0?.loadField(0), null, null, null, null, null); })
    l0?.loadField(0)
    let l3 = alloc(() => { return new Class6(null, null, null, null, null, null); })
    l1?.loadField(5)
    let l5 = alloc(() => { return new Class7(null, null, null, null, null, null, null); })
    g12 = l5?.loadField(6)
    l5 = g8
    tryGc()
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
