class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0, f1, f2, f3, f4, f5)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = anyToInt(null)
    loadField(index){
        switch ((index % 6)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 6)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class2{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

function fun0(l0, l1){
    tryGc()
    for (let i = 0; i < 17; i++){
        alloc(() => { return new Class0(null, null); })
    }
    g0 = l1
    tryGc()
    g1 = l1
    let l2 = alloc(() => { return new Class0(null, null); })
    l2 = l2?.loadField(1)
    g1 = l1
    let l3 = alloc(() => { return new Class2(g1, null); })
    g0
    tryGc()
    g1 = g0
    let l5 = alloc(() => { return new Class0(null, null); })
    let l6 = alloc(() => { return new Class2(l5?.loadField(1), l0); })
    g0 = l3?.loadField(1)
    g1
    tryGc()
    let l8 = alloc(() => { return new Class0(null, null); })
    g1 = g0
    let l9 = alloc(() => { return new Class2(null, null); })
    l8 = g0
    l6?.loadField(0)
    g0 = null
    g0 = l8?.loadField(0)
    for (let i = 0; i < 37; i++){
        alloc(() => { return new Class0(null, null); })
    }
    g0 = l8?.loadField(1)
    tryGc()
    let l11 = alloc(() => { return new Class1(g1, l3?.loadField(0), g0, g1, l8?.loadField(1), g1); })
    l3 = g0
    return null
}


function mainBodyImpl(){
    tryGc()
    let l0 = alloc(() => { return new Class1(g1, null, g0, null, null, null); })
    for (let i = 0; i < 22; i++){
        alloc(() => { return new Class2(null, null); })
    }
    let l1 = alloc(() => { return new Class1(g1, g0, null, null, null, null); })
    let l2 = alloc(() => { return new Class0(null, l0?.loadField(5)); })
    let l3 = alloc(() => { return new Class2(g1, null); })
    let l4 = alloc(() => { return new Class0(g1, g1); })
    let l5 = alloc(() => { return new Class0(g0, g0); })
    l2?.storeField(1, g1)
    g0 = l5?.loadField(0)
    let l6 = alloc(() => { return new Class0(g1, g0); })
    tryGc()
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
