class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
let g3 = null
let g4 = null
let g5 = null
class Class0{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = anyToBoolean(null)
    f5 = null
    f6 = null
    f7 = anyToInt(null)
    loadField(index){
        switch ((index % 8)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6;
            case 7: return this.f7;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 8)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = anyToBoolean(value); break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = value; break;
            case 7: this.f7 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
        this.f8 = f8
        this.f9 = f9
        this.f10 = f10
        this.f11 = f11
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = anyToInt(null)
    f4 = null
    f5 = null
    f6 = null
    f7 = null
    f8 = null
    f9 = null
    f10 = null
    f11 = null
    loadField(index){
        switch ((index % 12)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4?.deref();
            case 5: return this.f5;
            case 6: return this.f6;
            case 7: return this.f7?.deref();
            case 8: return this.f8;
            case 9: return this.f9;
            case 10: return this.f10?.deref();
            case 11: return this.f11;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 12)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = anyToInt(value); break;
            case 4: this.f4 = value == null ? null : new WeakRef(value); break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = value; break;
            case 7: this.f7 = value == null ? null : new WeakRef(value); break;
            case 8: this.f8 = value; break;
            case 9: this.f9 = value; break;
            case 10: this.f10 = value == null ? null : new WeakRef(value); break;
            case 11: this.f11 = value; break;
            default: break;
        }
    }
}

class Class2{
    constructor(f0, f1, f2, f3, f4)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
    }
    f0 = anyToBoolean(null)
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    loadField(index){
        switch ((index % 5)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 5)){
            case 0: this.f0 = anyToBoolean(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            default: break;
        }
    }
}

class Class3{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = anyToBoolean(null)
    f1 = anyToInt(null)
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = anyToBoolean(value); break;
            case 1: this.f1 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class4{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
        this.f8 = f8
        this.f9 = f9
        this.f10 = f10
        this.f11 = f11
        this.f12 = f12
        this.f13 = f13
        this.f14 = f14
        this.f15 = f15
        this.f16 = f16
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = null
    f6 = anyToBoolean(null)
    f7 = null
    f8 = anyToBoolean(null)
    f9 = null
    f10 = null
    f11 = null
    f12 = null
    f13 = anyToBoolean(null)
    f14 = null
    f15 = null
    f16 = anyToBoolean(null)
    loadField(index){
        switch ((index % 17)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4?.deref();
            case 5: return this.f5;
            case 6: return this.f6;
            case 7: return this.f7;
            case 8: return this.f8;
            case 9: return this.f9;
            case 10: return this.f10;
            case 11: return this.f11;
            case 12: return this.f12;
            case 13: return this.f13;
            case 14: return this.f14;
            case 15: return this.f15;
            case 16: return this.f16;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 17)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value == null ? null : new WeakRef(value); break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = anyToBoolean(value); break;
            case 7: this.f7 = value; break;
            case 8: this.f8 = anyToBoolean(value); break;
            case 9: this.f9 = value; break;
            case 10: this.f10 = value; break;
            case 11: this.f11 = value; break;
            case 12: this.f12 = value; break;
            case 13: this.f13 = anyToBoolean(value); break;
            case 14: this.f14 = value; break;
            case 15: this.f15 = value; break;
            case 16: this.f16 = anyToBoolean(value); break;
            default: break;
        }
    }
}

class Class5{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = anyToInt(null)
    f6 = null
    f7 = null
    loadField(index){
        switch ((index % 8)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6;
            case 7: return this.f7;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 8)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = anyToInt(value); break;
            case 6: this.f6 = value; break;
            case 7: this.f7 = value; break;
            default: break;
        }
    }
}

class Class6{
    constructor(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
        this.f5 = f5
        this.f6 = f6
        this.f7 = f7
        this.f8 = f8
        this.f9 = f9
        this.f10 = f10
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = null
    f5 = null
    f6 = null
    f7 = null
    f8 = null
    f9 = null
    f10 = null
    loadField(index){
        switch ((index % 11)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2?.deref();
            case 3: return this.f3;
            case 4: return this.f4;
            case 5: return this.f5;
            case 6: return this.f6?.deref();
            case 7: return this.f7;
            case 8: return this.f8;
            case 9: return this.f9;
            case 10: return this.f10?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 11)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value == null ? null : new WeakRef(value); break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            case 5: this.f5 = value; break;
            case 6: this.f6 = value == null ? null : new WeakRef(value); break;
            case 7: this.f7 = value; break;
            case 8: this.f8 = value; break;
            case 9: this.f9 = value; break;
            case 10: this.f10 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

class Class7{
    constructor(f0)
    {
        this.f0 = f0
    }
    f0 = anyToInt(null)
    loadField(index){
        switch ((index % 1)){
            case 0: return this.f0;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 1)){
            case 0: this.f0 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class8{
    constructor(f0)
    {
        this.f0 = f0
    }
    f0 = null
    loadField(index){
        switch ((index % 1)){
            case 0: return this.f0;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 1)){
            case 0: this.f0 = value; break;
            default: break;
        }
    }
}

class Class9{
    constructor(f0, f1, f2, f3, f4)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
    }
    f0 = null
    f1 = null
    f2 = null
    f3 = null
    f4 = anyToInt(null)
    loadField(index){
        switch ((index % 5)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 5)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = value; break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = anyToInt(value); break;
            default: break;
        }
    }
}

function fun0(l0){
    g5 = g5
    g0
    g1 = l0
    let l2 = alloc(() => { return new Class5(l0, null, null, null, null, null, null, null); })
    let l3 = alloc(() => { return new Class8(l0); })
    let l4 = alloc(() => { return new Class5(l3?.loadField(0), null, null, null, null, null, null, null); })
    let l5 = alloc(() => { return new Class9(l4?.loadField(7), g1, null, null, null); })
    for (let i = 0; i < 31; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    }
    l3?.loadField(0)
    tryGc()
    let l7 = alloc(() => { return new Class4(l5?.loadField(2), l4?.loadField(3), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    return null
}

function fun1(l0, l1, l2, l3, l4, l5, l6, l7){
    for (let i = 0; i < 35; i++){
        alloc(() => { return new Class2(null, null, null, null, null); })
    }
    g3 = l2
    let l8 = alloc(() => { return new Class8(g2); })
    let l9 = alloc(() => { return new Class9(g2, l8?.loadField(0), null, null, null); })
    for (let i = 0; i < 24; i++){
        alloc(() => { return new Class0(null, null, null, null, null, null, null, null); })
    }
    let l10 = alloc(() => { return new Class0(g5, null, null, null, null, null, null, null); })
    g0 = g0
    g2 = g3
    let l11 = alloc(() => { return new Class5(null, null, null, null, null, null, null, null); })
    l0
    l11 = g4
    l8?.storeField(0, g2)
    l11?.storeField(3, l2)
    return null
}

function fun2(l0, l1){
    let l2 = alloc(() => { return new Class5(null, g5, null, null, null, null, null, null); })
    tryGc()
    l2 = l0
    for (let i = 0; i < 11; i++){
        alloc(() => { return new Class2(null, null, null, null, null); })
    }
    let l3 = alloc(() => { return new Class9(null, null, null, null, null); })
    g5 = l3?.loadField(4)
    g5
    for (let i = 0; i < 53; i++){
        alloc(() => { return new Class2(null, null, null, null, null); })
    }
    tryGc()
    l0
    for (let i = 0; i < 16; i++){
        alloc(() => { return new Class7(null); })
    }
    tryGc()
    g3
    g1 = g5
    let l7 = alloc(() => { return new Class9(l3?.loadField(4), l2?.loadField(6), null, null, null); })
    let l8 = alloc(() => { return new Class7(l1); })
    l8 = l3?.loadField(4)
    let l9 = alloc(() => { return new Class6(l3?.loadField(1), null, l0, g2, null, null, null, null, null, null, null); })
    tryGc()
    g0 = null
    l2?.storeField(5, g0)
    l3 = g5
    for (let i = 0; i < 13; i++){
        alloc(() => { return new Class8(null); })
    }
    return null
}

function fun3(l0, l1, l2){
    for (let i = 0; i < 26; i++){
        alloc(() => { return new Class3(null, null); })
    }
    let l3 = alloc(() => { return new Class8(l2); })
    let l4 = alloc(() => { return new Class0(l2, l1, null, null, null, null, null, null); })
    g4 = g2
    l3?.storeField(0, l4?.loadField(4))
    let l5 = alloc(() => { return new Class3(l4?.loadField(6), null); })
    let l6 = alloc(() => { return new Class6(g0, null, null, null, null, null, null, null, null, null, null); })
    for (let i = 0; i < 33; i++){
        alloc(() => { return new Class0(null, null, null, null, null, null, null, null); })
    }
    tryGc()
    let l7 = alloc(() => { return new Class8(g5); })
    let l8 = alloc(() => { return new Class4(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    l4?.storeField(3, g3)
    let l9 = alloc(() => { return new Class5(null, null, null, null, null, null, null, null); })
    tryGc()
    g3 = g0
    l8?.storeField(6, l0)
    let l10 = alloc(() => { return new Class9(null, null, null, null, null); })
    l4 = l9?.loadField(7)
    l4 = g3
    let l11 = alloc(() => { return new Class8(l5?.loadField(0)); })
    tryGc()
    let l12 = alloc(() => { return new Class9(l7?.loadField(0), g4, l0, l0, null); })
    tryGc()
    let l13 = alloc(() => { return new Class3(g5, l10?.loadField(3)); })
    g5 = l8?.loadField(3)
    g4 = g4
    return null
}

function fun4(l0, l1){
    g0 = g2
    g0 = l0
    g2 = g0
    let l2 = alloc(() => { return new Class1(g2, l0, null, null, null, null, null, null, null, null, null, null); })
    let l3 = alloc(() => { return new Class6(g0, g0, g4, null, null, null, null, null, null, null, null); })
    g3
    l2?.loadField(10)
    let l6 = alloc(() => { return new Class2(l2?.loadField(7), null, null, null, null); })
    let l7 = alloc(() => { return new Class1(null, g5, null, null, null, null, null, null, null, null, null, null); })
    tryGc()
    for (let i = 0; i < 27; i++){
        alloc(() => { return new Class2(null, null, null, null, null); })
    }
    l6?.loadField(1)
    g0 = l0
    for (let i = 0; i < 42; i++){
        alloc(() => { return new Class9(null, null, null, null, null); })
    }
    g4
    g4
    l7 = l6?.loadField(2)
    let l11 = alloc(() => { return new Class1(null, null, null, null, null, null, null, null, null, null, null, null); })
    g1 = g1
    let l12 = alloc(() => { return new Class8(l1); })
    g2 = l1
    tryGc()
    g4 = g4
    g3 = l11?.loadField(8)
    g4 = g1
    g2 = g5
    g4 = l11?.loadField(8)
    return null
}

function fun5(l0, l1, l2, l3){
    tryGc()
    g4 = g1
    g5 = l1
    g1 = g0
    let l4 = alloc(() => { return new Class6(g5, g5, null, null, null, null, null, null, null, null, null); })
    let l5 = alloc(() => { return new Class4(g0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    g5 = g4
    l5?.storeField(13, l4?.loadField(6))
    return null
}

function fun6(l0){
    g3
    l0
    l0
    g4 = g4
    g5
    for (let i = 0; i < 25; i++){
        alloc(() => { return new Class5(null, null, null, null, null, null, null, null); })
    }
    g4 = null
    g4
    g1
    l0
    g2 = null
    return null
}

function fun7(l0, l1, l2, l3){
    g4 = g0
    let l4 = alloc(() => { return new Class9(null, g3, l3, null, null); })
    let l5 = alloc(() => { return new Class7(l1); })
    g3
    l4 = g4
    l2
    tryGc()
    g1 = g1
    g0
    return null
}

function fun8(l0, l1){
    g1
    let l3 = alloc(() => { return new Class0(null, g2, null, null, null, null, null, null); })
    for (let i = 0; i < 30; i++){
        alloc(() => { return new Class4(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    }
    let l4 = alloc(() => { return new Class1(g2, null, null, null, null, null, null, null, null, null, null, null); })
    g4 = g4
    g2 = g1
    let l5 = alloc(() => { return new Class4(l3?.loadField(1), null, g5, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    let l6 = alloc(() => { return new Class5(g2, g2, l3?.loadField(5), g4, null, null, null, null); })
    g3 = l0
    tryGc()
    g1
    tryGc()
    l4?.storeField(3, g4)
    return null
}


function mainBodyImpl(){
    g0 = g4
    let l0 = alloc(() => { return new Class3(g1, g4); })
    g0 = l0?.loadField(0)
    g3
    g0 = l0?.loadField(0)
    l0?.storeField(0, l0?.loadField(1))
    g3 = g5
    let l2 = alloc(() => { return new Class5(l0?.loadField(0), g2, null, null, null, null, null, null); })
    let l3 = alloc(() => { return new Class4(g4, g5, g4, null, null, null, null, null, null, null, null, null, null, null, null, null, null); })
    l3?.loadField(3)
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
