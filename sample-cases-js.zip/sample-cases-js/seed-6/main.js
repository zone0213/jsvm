class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
let g3 = null
let g4 = null
let g5 = null
let g6 = null
let g7 = null
let g8 = null
let g9 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = null
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = value; break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0, f1, f2)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
    }
    f0 = anyToInt(null)
    f1 = anyToBoolean(null)
    f2 = null
    loadField(index){
        switch ((index % 3)){
            case 0: return this.f0;
            case 1: return this.f1;
            case 2: return this.f2;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 3)){
            case 0: this.f0 = anyToInt(value); break;
            case 1: this.f1 = anyToBoolean(value); break;
            case 2: this.f2 = value; break;
            default: break;
        }
    }
}

class Class2{
    constructor(f0)
    {
        this.f0 = f0
    }
    f0 = null
    loadField(index){
        switch ((index % 1)){
            case 0: return this.f0?.deref();
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 1)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            default: break;
        }
    }
}

function fun0(l0, l1, l2, l3){
    g7 = g5
    let l4 = alloc(() => { return new Class1(l2, l2, null); })
    l4 = g6
    let l5 = alloc(() => { return new Class2(null); })
    tryGc()
    let l6 = alloc(() => { return new Class1(l2, l3, g7); })
    l4 = l0
    let l7 = alloc(() => { return new Class1(g8, g2, g3); })
    tryGc()
    tryGc()
    l4 = g5
    g7
    return null
}

function fun1(l0, l1){
    l1
    tryGc()
    g8 = l1
    tryGc()
    g9 = l1
    let l3 = alloc(() => { return new Class2(null); })
    let l4 = alloc(() => { return new Class0(g7, g8); })
    tryGc()
    g2
    let l6 = alloc(() => { return new Class1(g9, g6, null); })
    return null
}

function fun2(l0, l1, l2){
    g6 = g2
    g5 = l0
    let l3 = alloc(() => { return new Class2(null); })
    let l4 = alloc(() => { return new Class0(g1, g3); })
    l1
    let l6 = alloc(() => { return new Class2(l4?.loadField(1)); })
    let l7 = alloc(() => { return new Class2(g6); })
    g3
    g9 = g3
    let l9 = alloc(() => { return new Class1(l3?.loadField(0), g1, g7); })
    g8 = l9?.loadField(1)
    for (let i = 0; i < 64; i++){
        alloc(() => { return new Class0(null, null); })
    }
    l9 = g2
    l6?.storeField(0, g1)
    g5 = null
    let l10 = alloc(() => { return new Class2(l6?.loadField(0)); })
    for (let i = 0; i < 30; i++){
        alloc(() => { return new Class1(null, null, null); })
    }
    l9?.storeField(1, g9)
    for (let i = 0; i < 57; i++){
        alloc(() => { return new Class2(null); })
    }
    g6
    for (let i = 0; i < 48; i++){
        alloc(() => { return new Class0(null, null); })
    }
    let l12 = alloc(() => { return new Class0(l7?.loadField(0), g7); })
    g0 = null
    g7
    let l14 = alloc(() => { return new Class2(g9); })
    l9?.storeField(0, l6?.loadField(0))
    return null
}


function mainBodyImpl(){
    g0 = g9
    g3 = g1
    for (let i = 0; i < 13; i++){
        alloc(() => { return new Class1(null, null, null); })
    }
    g9 = g4
    g4 = g7
    tryGc()
    g1 = g4
    let l0 = alloc(() => { return new Class1(g4, g6, null); })
    let l1 = alloc(() => { return new Class2(l0?.loadField(2)); })
    l0?.storeField(1, l1?.loadField(0))
    g5
    tryGc()
    l0 = g0
    let l3 = alloc(() => { return new Class0(g5, g2); })
    let l4 = alloc(() => { return new Class1(g7, null, null); })
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
