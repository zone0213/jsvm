class ArkTsArrayBox {
    values;
    constructor(size, seed) {
        const len = size > 0 ? size : 1;
        this.values = new Array(len).fill(null);
        if (len > 0) { this.values[0] = seed; }
    }
    loadField(index) {
        return this.values[index % this.values.length];
    }
    storeField(index, value) {
        this.values[index % this.values.length] = value;
    }
}

function anyToInt(value) {
    if (typeof value === "number") { return value; }
    if (typeof value === "boolean") { return value ? 1 : 0; }
    return 0;
}

function anyToBoolean(value) {
    if (typeof value === "boolean") { return value; }
    if (typeof value === "number") { return value !== 0; }
    return false;
}

class FuzzControlException extends Error {
    payload;
    constructor(payload) {
        super("FuzzControlException");
        this.payload = payload;
    }
}

let terminationRequested = false;
const startTimeMs = Date.now();
const GC_PRESSURE = 4096;
let pressureSink = new Array(GC_PRESSURE).fill(null);

function shouldTerminate() {
    if (terminationRequested) { return true; }
    if ((Date.now() - startTimeMs) <= 30000) { return false; }
    terminationRequested = true;
    return true;
}

function tryGc() {
    // Best-effort: ArkTS exposes no public GC trigger. Apply allocation pressure and refresh
    // the sink so unreachable objects become collectible; FinalizationRegistry (P5) observes.
    for (let i = 0; i < GC_PRESSURE; i++) {
        if (shouldTerminate()) { return; }
        pressureSink[i % GC_PRESSURE] = { n: i };
    }
    pressureSink = new Array(GC_PRESSURE).fill(null);
}

function alloc(block) {
    if (shouldTerminate()) { return null; }
    return block();
}

// ---- Best-effort reachability oracle (P5, DOWNGRADED from the pure-kotlin sample) ----
// ArkTS has no force-GC; DEAD assertions are best-effort. gcEpoch is bumped when a
// FinalizationRegistry callback fires, so DEAD checks can be gated behind "GC has plausibly
// run" to reduce false positives. ALIVE is deterministic. This cannot match the determinism
// of kotlin.native.runtime.GC.collect().
const ReachabilityExpectation = { ALIVE: 0, DEAD: 1 };
let gcEpoch = 0;
const fr = new FinalizationRegistry((_held) => { gcEpoch = gcEpoch + 1; });
function assertReachability(label, expectation, value) {
    if (expectation === ReachabilityExpectation.ALIVE) {
        if (value == null) { throw new Error("Reachability oracle failed [" + label + "]: expected alive"); }
    } else {
        // DEAD is best-effort: without force-GC the object may not yet be collected, so a
        // non-null value here is NOT treated as a hard failure (would drown in false positives).
        // Real GC bugs still surface as crashes/aborts from the runtime itself.
    }
}
function registerObservation(observationId, target) {
    if (target != null) { fr.register(target, target); }
}
let g0 = null
let g1 = null
let g2 = null
class Class0{
    constructor(f0, f1)
    {
        this.f0 = f0
        this.f1 = f1
    }
    f0 = null
    f1 = anyToInt(null)
    loadField(index){
        switch ((index % 2)){
            case 0: return this.f0;
            case 1: return this.f1;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 2)){
            case 0: this.f0 = value; break;
            case 1: this.f1 = anyToInt(value); break;
            default: break;
        }
    }
}

class Class1{
    constructor(f0, f1, f2, f3, f4)
    {
        this.f0 = f0
        this.f1 = f1
        this.f2 = f2
        this.f3 = f3
        this.f4 = f4
    }
    f0 = null
    f1 = null
    f2 = anyToBoolean(null)
    f3 = null
    f4 = null
    loadField(index){
        switch ((index % 5)){
            case 0: return this.f0?.deref();
            case 1: return this.f1;
            case 2: return this.f2;
            case 3: return this.f3;
            case 4: return this.f4;
            default: return null;
        }
    }
    storeField(index, value){
        switch ((index % 5)){
            case 0: this.f0 = value == null ? null : new WeakRef(value); break;
            case 1: this.f1 = value; break;
            case 2: this.f2 = anyToBoolean(value); break;
            case 3: this.f3 = value; break;
            case 4: this.f4 = value; break;
            default: break;
        }
    }
}

function fun0(l0, l1, l2, l3){
    g2 = g2
    tryGc()
    let l4 = alloc(() => { return new Class0(null, g1); })
    tryGc()
    let l5 = alloc(() => { return new Class1(l1, null, null, null, null); })
    g0 = l3
    let l6 = alloc(() => { return new Class1(l1, g1, null, null, null); })
    let l7 = alloc(() => { return new Class1(g0, null, null, null, null); })
    g1
    l5 = g0
    let l9 = alloc(() => { return new Class0(g0, g1); })
    g1
    tryGc()
    g1
    let l12 = alloc(() => { return new Class0(null, null); })
    return null
}

function fun1(){
    tryGc()
    let l0 = alloc(() => { return new Class1(g2, g0, null, null, null); })
    g0 = g2
    l0 = g0
    l0?.storeField(3, l0?.loadField(2))
    let l1 = alloc(() => { return new Class0(g2, g0); })
    l0?.loadField(1)
    let l3 = alloc(() => { return new Class1(g1, null, null, null, null); })
    for (let i = 0; i < 38; i++){
        alloc(() => { return new Class1(null, null, null, null, null); })
    }
    l3?.storeField(4, l0?.loadField(2))
    g2 = l3?.loadField(0)
    g2 = l1?.loadField(1)
    l1?.loadField(0)
    l0?.storeField(0, g1)
    g0 = l3?.loadField(1)
    return null
}

function fun2(l0, l1){
    g2 = g1
    g2 = g2
    g2
    g2 = g1
    g1 = g0
    g2 = l1
    g0 = l1
    g1 = g1
    tryGc()
    for (let i = 0; i < 54; i++){
        alloc(() => { return new Class1(null, null, null, null, null); })
    }
    g2 = g2
    g1 = g1
    tryGc()
    return null
}

function fun3(l0){
    g1 = g0
    let l1 = alloc(() => { return new Class0(null, g2); })
    g1
    g1 = l0
    g2 = g0
    let l3 = alloc(() => { return new Class1(l1?.loadField(1), g1, l0, g2, null); })
    g0 = g1
    let l4 = alloc(() => { return new Class0(g1, g2); })
    tryGc()
    tryGc()
    l3?.storeField(2, l3?.loadField(4))
    let l5 = alloc(() => { return new Class1(g2, l4?.loadField(0), l0, g2, g0); })
    g1
    return null
}


function mainBodyImpl(){
    let l0 = alloc(() => { return new Class1(null, null, g2, null, null); })
    l0 = g1
    let l1 = alloc(() => { return new Class0(g2, null); })
    l1?.loadField(1)
    let l3 = alloc(() => { return new Class0(l0?.loadField(4), g0); })
    l1 = l1?.loadField(1)
    let l4 = alloc(() => { return new Class0(null, l1?.loadField(0)); })
    tryGc()
    g0 = g1
    l3 = l3?.loadField(0)
    return null
}

function main(){
    for (let i = 0; i < 20000; i++){
        if (shouldTerminate()) return
        mainBodyImpl()
    }
    terminationRequested = true
    tryGc()
}

try {
    main()
} catch (e) {
    ;(typeof console !== "undefined") ? console.log("fuzz-terminated:", e) : print("fuzz-terminated:", e)
}
;(typeof console !== "undefined") ? console.log("fuzz-case-done") : print("fuzz-case-done")
