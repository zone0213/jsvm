@file:OptIn(
    kotlin.concurrent.atomics.ExperimentalAtomicApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.concurrent.atomics.AtomicInt
import kotlin.native.concurrent.ThreadLocal
import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Common test infrastructure for Kotlin/Native concurrent GC / mutator mutation tests.
 *
 * Scope:
 * - Validates GC behavior while mutator code allocates, publishes, clears, replaces and moves references.
 * - Covers field, global, ThreadLocal, array, list, map, lambda, weak-observer and stress-style mutations.
 * - Objective-C/Swift interop, StableRef and allocator size-class details are intentionally excluded.
 *
 * Notes:
 * - Concurrent GC tests should avoid relying on an exact GC phase boundary.
 * - Deletion cases assert eventual collection after repeated GC, because concurrent GC may leave floating garbage.
 * - Stress cases focus on no crash, no deadlock, successful completion and final-state sanity.
 */
open class ConcurrentGcTestSupport {

    @BeforeTest
    fun resetBeforeTest() {
        clearRoots()
        forceGc()
    }

    @AfterTest
    fun resetAfterTest() {
        clearRoots()
        forceGc()
    }

    protected fun clearRoots() {
        globalNode = null
        globalLambda = null
        globalHolder.ref = null
        threadLocalNode = null
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun forceGcLoop(iterations: Int = SMALL_ITERATIONS) {
        repeat(iterations) {
            GC.collect()
        }
    }

    protected fun allocateGarbage(count: Int = GARBAGE_COUNT) {
        var checksum = 0
        repeat(count) { index ->
            val node = Node(index)
            checksum += node.id
        }
        assertTrue(checksum >= 0)
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected object to remain reachable, but weak value was cleared."
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollectedEventually(
        weak: WeakReference<T>,
        message: String = "Expected object to become unreachable and eventually collected."
    ) {
        forceGcLoop()
        assertNull(weak.value, message)
    }

    protected fun <T : Any> assertAllWeakAlive(weaks: Iterable<WeakReference<T>>) {
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
    }

    protected fun <T : Any> assertAllWeakCollectedEventually(weaks: Iterable<WeakReference<T>>) {
        forceGcLoop()
        weaks.forEachIndexed { index, weak ->
            assertNull(weak.value, "Expected weak[$index] to be eventually cleared.")
        }
    }

    protected fun buildChain(length: Int, startId: Int): List<Node> {
        require(length > 0) { "length must be positive" }
        val nodes = List(length) { index -> Node(startId + index) }
        for (index in 0 until nodes.lastIndex) {
            nodes[index].next = nodes[index + 1]
        }
        return nodes
    }

    protected fun buildTree(startId: Int): List<Node> {
        val root = Node(startId)
        val left = Node(startId + 1)
        val right = Node(startId + 2)
        val leftLeaf = Node(startId + 3)
        val rightLeaf = Node(startId + 4)

        root.left = left
        root.right = right
        left.left = leftLeaf
        right.right = rightLeaf

        return listOf(root, left, right, leftLeaf, rightLeaf)
    }

    protected fun buildCycle(startId: Int): List<Node> {
        val a = Node(startId)
        val b = Node(startId + 1)
        a.next = b
        b.next = a
        return listOf(a, b)
    }

    protected fun buildSharedGraph(startId: Int): SharedGraph {
        val p1 = Node(startId)
        val p2 = Node(startId + 1)
        val shared = Node(startId + 2)
        p1.left = shared
        p2.left = shared
        return SharedGraph(p1, p2, shared)
    }

    protected fun runGcAroundMutation(mutation: () -> Unit) {
        forceGc()
        mutation()
        forceGc()
    }

    protected fun repeatMutationWithGc(
        iterations: Int = SMALL_ITERATIONS,
        mutation: (Int) -> Unit
    ): Int {
        var count = 0
        repeat(iterations) { index ->
            mutation(index)
            count++
            if (index % 4 == 0) {
                GC.collect()
            }
        }
        forceGc()
        return count
    }

    protected fun runWorkerTask(task: () -> Boolean): Boolean {
        val worker = Worker.start()
        return try {
            worker.execute(TransferMode.SAFE, { task }) { block ->
                block()
            }.result
        } finally {
            worker.requestTermination().result
        }
    }

    protected fun runWorkerMutationWithMainGc(task: () -> Boolean): Boolean {
        val worker = Worker.start()
        return try {
            val future = worker.execute(TransferMode.SAFE, { task }) { block ->
                block()
            }
            forceGcLoop()
            future.result
        } finally {
            worker.requestTermination().result
        }
    }

    protected fun runBoundedConcurrentWriters(
        writerCount: Int,
        iterations: Int = SMALL_ITERATIONS,
        mutation: (Int, Int) -> Unit
    ): Int {
        val completed = AtomicInt(0)
        val workers = List(writerCount) { workerIndex ->
            Worker.start().also { worker ->
                worker.execute(
                    TransferMode.SAFE,
                    { BoundedWriterTask(workerIndex, iterations, mutation, completed) },
                    ::runBoundedWriterTask
                )
            }
        }

        workers.forEach { worker ->
            worker.requestTermination().result
        }

        return completed.load()
    }

    protected fun singleThreadBaseline(): Boolean {
        val node = Node(1)
        val weak = WeakReference(node)

        forceGc()

        assertEquals(1, node.id)
        assertNotNull(weak.value)
        return true
    }

    protected fun publishField(id: Int = 10): Pair<Holder<Node>, WeakReference<Node>> {
        val holder = Holder<Node>(null)
        val node = Node(id)
        val weak = WeakReference(node)
        holder.ref = node
        assertEquals(id, holder.ref!!.id)
        return holder to weak
    }

    protected fun clearFieldEventually(id: Int = 20): WeakReference<Node> {
        val holder = Holder(Node(id))
        val weak = WeakReference(holder.ref!!)

        runGcAroundMutation {
            holder.ref = null
        }

        assertNull(holder.ref)
        return weak
    }

    protected fun replaceField(idOld: Int = 30, idNew: Int = 31): ReplacementResult<Holder<Node>, Node> {
        val oldNode = Node(idOld)
        val holder = Holder(oldNode)
        val oldWeak = WeakReference(oldNode)
        val newNode = Node(idNew)
        val newWeak = WeakReference(newNode)

        runGcAroundMutation {
            holder.ref = newNode
        }

        assertEquals(idNew, holder.ref!!.id)
        return ReplacementResult(holder, oldWeak, newWeak)
    }

    protected fun publishChain(id: Int = 40): Pair<Holder<Node>, List<WeakReference<Node>>> {
        val holder = Holder<Node>(null)
        val chain = buildChain(CHAIN_LENGTH, id)
        val weaks = chain.map { WeakReference(it) }
        holder.ref = chain.first()
        assertEquals(id, holder.ref!!.id)
        assertEquals(id + CHAIN_LENGTH - 1, weaks.last().value!!.id)
        return holder to weaks
    }

    protected fun publishTree(id: Int = 50): Pair<Holder<Node>, List<WeakReference<Node>>> {
        val holder = Holder<Node>(null)
        val tree = buildTree(id)
        val weaks = tree.map { WeakReference(it) }
        holder.ref = tree.first()
        assertEquals(id, holder.ref!!.id)
        assertEquals(id + 1, holder.ref!!.left!!.id)
        assertEquals(id + 2, holder.ref!!.right!!.id)
        return holder to weaks
    }

    protected fun publishCycle(id: Int = 60): Pair<Holder<Node>, List<WeakReference<Node>>> {
        val holder = Holder<Node>(null)
        val cycle = buildCycle(id)
        val weaks = cycle.map { WeakReference(it) }
        holder.ref = cycle.first()
        assertEquals(id + 1, holder.ref!!.next!!.id)
        return holder to weaks
    }

    protected fun listAddScenario(id: Int = 70): Pair<MutableList<Node>, WeakReference<Node>> {
        val list = mutableListOf<Node>()
        val node = Node(id)
        val weak = WeakReference(node)
        list.add(node)
        assertEquals(id, list.single().id)
        return list to weak
    }

    protected fun listRemoveScenario(id: Int = 71): WeakReference<Node> {
        val node = Node(id)
        val list = mutableListOf(node)
        val weak = WeakReference(node)

        runGcAroundMutation {
            list.remove(node)
        }

        assertTrue(list.isEmpty())
        return weak
    }

    protected fun mapPutScenario(id: Int = 80): Pair<MutableMap<String, Node>, WeakReference<Node>> {
        val map = mutableMapOf<String, Node>()
        val node = Node(id)
        val weak = WeakReference(node)
        map["k"] = node
        assertEquals(id, map["k"]!!.id)
        return map to weak
    }

    protected fun mapRemoveScenario(id: Int = 81): WeakReference<Node> {
        val node = Node(id)
        val map = mutableMapOf("k" to node)
        val weak = WeakReference(node)

        runGcAroundMutation {
            map.remove("k")
        }

        assertTrue(map.isEmpty())
        return weak
    }

    protected fun arrayPutScenario(id: Int = 90): Pair<Array<Node?>, WeakReference<Node>> {
        val array = arrayOfNulls<Node>(2)
        val node = Node(id)
        val weak = WeakReference(node)
        array[0] = node
        assertEquals(id, array[0]!!.id)
        return array to weak
    }

    protected fun arrayClearScenario(id: Int = 91): WeakReference<Node> {
        val node = Node(id)
        val array = arrayOfNulls<Node>(1)
        array[0] = node
        val weak = WeakReference(node)

        runGcAroundMutation {
            array[0] = null
        }

        assertNull(array[0])
        return weak
    }

    protected fun stressFieldReplacement(iterations: Int = MEDIUM_ITERATIONS): Pair<Holder<Node>, WeakReference<Node>> {
        val holder = Holder(Node(100))
        var lastWeak = WeakReference(holder.ref!!)
        repeat(iterations) { index ->
            val node = Node(1000 + index)
            holder.ref = node
            lastWeak = WeakReference(node)
        }
        assertNotNull(holder.ref)
        return holder to lastWeak
    }

    companion object {
        private const val GC_REPEAT_COUNT = 3
        protected const val SMALL_ITERATIONS = 32
        protected const val MEDIUM_ITERATIONS = 128
        protected const val CHAIN_LENGTH = 8
        protected const val GARBAGE_COUNT = 512
    }
}

class Node(
    val id: Int,
    var next: Node? = null,
    var left: Node? = null,
    var right: Node? = null
) {
    override fun toString(): String = "Node(id=$id)"
}

class Holder<T : Any>(var ref: T?)

class ArrayHolder(size: Int) {
    val refs: Array<Node?> = arrayOfNulls(size)
}

class ListHolder {
    val children: MutableList<Node> = mutableListOf()
}

class MapHolder {
    val refs: MutableMap<String, Node> = mutableMapOf()
}

class Box<T : Any>(var value: T?)

class LambdaHolder(var block: (() -> Int)?)

class Root<T : Any>(var ref: T?)

data class BoundedWriterTask(
    val workerIndex: Int,
    val iterations: Int,
    val mutation: (Int, Int) -> Unit,
    val completed: AtomicInt
)

data class SharedGraph(
    val parent1: Node,
    val parent2: Node,
    val shared: Node
)

data class ReplacementResult<R : Any, T : Any>(
    val root: R,
    val oldWeak: WeakReference<T>,
    val newWeak: WeakReference<T>
)

var globalNode: Node? = null
var globalLambda: (() -> Int)? = null
val globalHolder = Holder<Node>(null)

@ThreadLocal
var threadLocalNode: Node? = null

private fun runBoundedWriterTask(task: BoundedWriterTask): Boolean {
    repeat(task.iterations) { iteration ->
        task.mutation(task.workerIndex, iteration)
        if (iteration % 4 == 0) {
            GC.collect()
        }
    }
    task.completed.addAndFetch(1)
    return true
}
