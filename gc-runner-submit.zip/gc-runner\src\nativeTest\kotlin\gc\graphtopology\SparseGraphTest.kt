@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-G group: sparse graph and disconnected-component tests. */
class SparseGraphTest : GraphTopologyTestSupport() {

    private fun buildCycle(size: Int, startId: Int): List<GraphNode> {
        val nodes = List(size) { index -> GraphNode(startId + index) }
        for (index in nodes.indices) nodes[index].next = nodes[(index + 1) % nodes.size]
        return nodes
    }

    private fun reachableChainAndUnreachableChain(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val reachable = buildGraphNodeChain(3, 12000)
        val unreachable = buildGraphNodeChain(3, 12100)
        return MixedWeaks(GraphRoot(reachable.first()), weakRefs(reachable), weakRefs(unreachable))
    }

    /** GT-G01: one reachable chain and one unreachable chain are handled independently. */
    @Test
    fun gtG01_reachableChainAndUnreachableChainAreDistinguished() {
        val scenario = reachableChainAndUnreachableChain()
        forceGc()
        assertEquals(12002, scenario.aliveWeaks.last().value!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun reachableTreeAndUnreachableTree(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val reachable = buildFullBinaryTree(3, 12200)
        val unreachable = buildFullBinaryTree(3, 12300)
        return MixedWeaks(GraphRoot(reachable.first()), weakRefs(reachable), weakRefs(unreachable))
    }

    /** GT-G02: one reachable tree and one unreachable tree are handled independently. */
    @Test
    fun gtG02_reachableTreeAndUnreachableTreeAreDistinguished() {
        val scenario = reachableTreeAndUnreachableTree()
        forceGc()
        assertEquals(12206, scenario.aliveWeaks.last().value!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun reachableChainAndUnreachableCycle(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val reachable = buildGraphNodeChain(3, 12400)
        val unreachableCycle = buildCycle(3, 12500)
        return MixedWeaks(GraphRoot(reachable.first()), weakRefs(reachable), weakRefs(unreachableCycle))
    }

    /** GT-G03: a reachable chain and an unreachable cycle are handled independently. */
    @Test
    fun gtG03_reachableChainAndUnreachableCycleAreDistinguished() {
        val scenario = reachableChainAndUnreachableCycle()
        forceGc()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private data class MultiRootScenario(
        val rootA: GraphRoot<GraphNode>,
        val rootB: GraphRoot<GraphNode>,
        val aliveWeaks: List<WeakReference<GraphNode>>,
        val collectedWeaks: List<WeakReference<GraphNode>>
    )

    private fun multipleRootsScenario(): MultiRootScenario {
        val componentA = buildGraphNodeChain(2, 12600)
        val componentB = buildGraphNodeChain(2, 12700)
        val componentC = buildGraphNodeChain(2, 12800)
        return MultiRootScenario(
            rootA = GraphRoot(componentA.first()),
            rootB = GraphRoot(componentB.first()),
            aliveWeaks = weakRefs(componentA + componentB),
            collectedWeaks = weakRefs(componentC)
        )
    }

    /** GT-G04: multiple roots keep multiple components alive while an unrooted component is collected. */
    @Test
    fun gtG04_multipleRootsKeepMultipleComponentsAlive() {
        val scenario = multipleRootsScenario()
        forceGc()
        assertEquals(12600, scenario.rootA.ref!!.id)
        assertEquals(12700, scenario.rootB.ref!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun afterClearingOneOfTwoRoots(): MultiRootScenario {
        val componentA = buildGraphNodeChain(2, 12900)
        val componentB = buildGraphNodeChain(2, 13000)
        val rootA = GraphRoot(componentA.first())
        val rootB = GraphRoot(componentB.first())
        val collected = weakRefs(componentA)
        val alive = weakRefs(componentB)
        rootA.ref = null
        return MultiRootScenario(rootA, rootB, alive, collected)
    }

    /** GT-G05: clearing one root collects only its component while another root keeps its component alive. */
    @Test
    fun gtG05_clearingOneRootCollectsOnlyThatComponent() {
        val scenario = afterClearingOneOfTwoRoots()
        assertNull(scenario.rootA.ref)
        assertEquals(13000, scenario.rootB.ref!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun afterClearingAllRoots(): MultiRootScenario {
        val componentA = buildGraphNodeChain(2, 13100)
        val componentB = buildGraphNodeChain(2, 13200)
        val rootA = GraphRoot(componentA.first())
        val rootB = GraphRoot(componentB.first())
        val weaks = weakRefs(componentA + componentB)
        rootA.ref = null
        rootB.ref = null
        return MultiRootScenario(rootA, rootB, emptyList(), weaks)
    }

    /** GT-G06: clearing all roots allows all previously rooted components to be collected. */
    @Test
    fun gtG06_clearingAllRootsCollectsAllComponents() {
        val scenario = afterClearingAllRoots()
        assertNull(scenario.rootA.ref)
        assertNull(scenario.rootB.ref)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun weakOnlyIsolatedNodes(count: Int): List<WeakReference<GraphNode>> {
        val nodes = List(count) { index -> GraphNode(13300 + index) }
        return weakRefs(nodes)
    }

    /** GT-G07: 100 isolated nodes with only WeakReferences can be collected. */
    @Test
    fun gtG07_hundredWeakOnlyIsolatedNodesCanBeCollected() {
        assertAllCollected(weakOnlyIsolatedNodes(100))
    }

    private fun oneOfHundredComponentsRooted(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val components = List(100) { index -> buildGraphNodeChain(2, 14000 + index * 10) }
        val rooted = components[42]
        val unrooted = components.filterIndexed { index, _ -> index != 42 }.flatten()
        return MixedWeaks(GraphRoot(rooted.first()), weakRefs(rooted), weakRefs(unrooted))
    }

    /** GT-G08: among 100 components, only the rooted component remains alive. */
    @Test
    fun gtG08_onlyOneOfHundredComponentsIsKeptAlive() {
        val scenario = oneOfHundredComponentsRooted()
        forceGc()
        assertEquals(14420, scenario.root.ref!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun sparseSegmentedChains(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val segmentA = buildGraphNodeChain(50, 15000)
        val segmentB = buildGraphNodeChain(50, 15100)
        return MixedWeaks(GraphRoot(segmentA.first()), weakRefs(segmentA), weakRefs(segmentB))
    }

    /** GT-G09: a sparse big chain segment and an unrooted segment are handled independently. */
    @Test
    fun gtG09_sparseSegmentedChainsKeepOnlyRootedSegmentAlive() {
        val scenario = sparseSegmentedChains()
        forceGc()
        assertEquals(15049, scenario.aliveWeaks.last().value!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun forestPartialReachability(): MultiRootScenario {
        val treeA = buildFullBinaryTree(3, 15200)
        val treeB = buildFullBinaryTree(3, 15300)
        val treeC = buildFullBinaryTree(3, 15400)
        return MultiRootScenario(
            rootA = GraphRoot(treeA.first()),
            rootB = GraphRoot(treeB.first()),
            aliveWeaks = weakRefs(treeA + treeB),
            collectedWeaks = weakRefs(treeC)
        )
    }

    /** GT-G10: a forest with only some tree roots kept alive collects unrooted trees. */
    @Test
    fun gtG10_forestKeepsReachableTreesAndCollectsUnreachableTrees() {
        val scenario = forestPartialReachability()
        forceGc()
        assertEquals(15200, scenario.rootA.ref!!.id)
        assertEquals(15300, scenario.rootB.ref!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-G11: an initially orphan subgraph becomes alive after being attached to root. */
    @Test
    fun gtG11_orphanSubgraphBecomesAliveAfterAttachment() {
        val rootNode = GraphNode(15600)
        val orphan = buildGraphNodeChain(3, 15700)
        rootNode.next = orphan.first()
        val scenario = RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode) + orphan))
        forceGc()
        assertEquals(15702, scenario.root.ref!!.next!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun attachedSubgraphAfterDisconnect(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val rootNode = GraphNode(15800)
        val orphan = buildGraphNodeChain(3, 15900)
        rootNode.next = orphan.first()
        val root = GraphRoot(rootNode)
        rootNode.next = null
        return MixedWeaks(root, weakRefs(listOf(rootNode)), weakRefs(orphan))
    }

    /** GT-G12: after an attached subgraph is disconnected again, it can be collected. */
    @Test
    fun gtG12_attachedSubgraphCollectedAfterDisconnect() {
        val scenario = attachedSubgraphAfterDisconnect()
        assertNull(scenario.root.ref!!.next)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }
}
