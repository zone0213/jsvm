@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-J group: exception-path safepoints and precise stack maps.
 */
class PreciseStackSafepointExceptionTest : PreciseStackTestSupport() {
    private class PayloadException(
        val payload: StackPayload,
    ) : Throwable("payload")

    /**
     * PS-J01
     * Scenario: catch parameter carries a payload and GC runs inside catch.
     * Expectation: exception object and payload remain live while catch parameter is live.
     */
    @Test
    fun psJ01_exceptionPayloadSurvivesCatchGc() {
        try {
            throw PayloadException(StackPayload(10001))
        } catch (e: PayloadException) {
            val weak = WeakReference(e.payload)
            forceGc()
            assertEquals(10001, e.payload.id)
            assertEquals(10001, weak.value!!.id)
        }
    }

    /**
     * PS-J02
     * Scenario: catch block clears the only payload reference before returning weak.
     * Expectation: cleared catch local is not retained after catch exits.
     */
    @Test
    fun psJ02_clearedCatchLocalIsCollected() {
        fun createWeak(): WeakReference<StackPayload> {
            var payload: StackPayload? = null
            var weak: WeakReference<StackPayload>? = null

            try {
                error("force catch")
            } catch (_: Throwable) {
                payload = StackPayload(10002)
                weak = WeakReference(payload!!)
                payload = null
            }

            assertEquals(null, payload)
            return weak!!
        }

        assertWeakCollected(createWeak())
    }

    /**
     * PS-J03
     * Scenario: finally block holds a live root while GC runs.
     * Expectation: finally-frame root map keeps the object alive.
     */
    @Test
    fun psJ03_finallyLiveRootSurvivesGc() {
        val obj = StackPayload(10003)
        val weak = WeakReference(obj)

        try {
            assertEquals(10003, obj.id)
        } finally {
            forceGc()
            assertEquals(10003, obj.id)
            assertEquals(10003, weak.value!!.id)
        }
    }

    /**
     * PS-J04
     * Scenario: finally clears a local root before returning weak.
     * Expectation: finally edge does not retain the cleared object.
     */
    @Test
    fun psJ04_finallyClearedRootIsCollected() {
        fun createWeak(): WeakReference<StackPayload> {
            var obj: StackPayload? = StackPayload(10004)
            val weak = WeakReference(obj!!)

            try {
                assertEquals(10004, obj!!.id)
            } finally {
                obj = null
            }

            assertEquals(null, obj)
            return weak
        }

        assertWeakCollected(createWeak())
    }

    /**
     * PS-J05
     * Scenario: nested throw/catch keeps outer live root across inner exception safepoint.
     * Expectation: outer live root is still scanned through exception-control flow.
     */
    @Test
    fun psJ05_outerLiveRootSurvivesNestedExceptionGc() {
        val outer = StackPayload(10005)
        val outerWeak = WeakReference(outer)

        try {
            try {
                error("inner")
            } catch (_: Throwable) {
                forceGc()
                assertEquals(10005, outer.id)
                assertEquals(10005, outerWeak.value!!.id)
            }
        } finally {
            assertEquals(10005, outer.id)
        }
    }
}

