@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertNull

/**
 * Minimal smoke test for checking whether WeakReference target clearing works
 * when no strong reference to the target escapes.
 */
class CmcWeakReferenceSmokeTest {

    private fun createWeakOnlyTarget(): WeakReference<Payload> {
        val payload = Payload(999)
        return WeakReference(payload)
    }

    @Test
    fun weakOnlyTargetIsClearedAfterRepeatedGc() {
        val weak = createWeakOnlyTarget()

        repeat(1000) {
            GC.collect()
        }

        assertNull(weak.value)
    }
}
