﻿// @ts-nocheck
import { ReachabilityTestSupport, Payload, ChildPayload, DataPayload, PayloadHolder, AnyHolder, InterfaceHolder, BaseHolder, TwoLevelHolder, Box, LambdaHolder, RootedWeak, ReplacementResult, HolderReplacementResult, TwoLevelDisconnectResult, LoopReplacementResult, Marker, BasePayload, globalPayload, globalAny, globalMarker, GlobalHolder, CompanionRootHolder } from './ReachabilityTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * D group: reachability through object fields and field paths.
 */
export class FieldPathReachabilityTest extends ReachabilityTestSupport {
    private createPayloadHolderRoot(): RootedWeak<PayloadHolder, Payload> {
        const child = new Payload(301);
        const holder = new PayloadHolder(child);
        return new RootedWeak(holder, new WeakReference(child));
    }
    /**
     * RC-D01
     * Scenario: a root object has a direct field pointing to Payload.
     * Expectation: the field target remains reachable through the root object.
     */
    rcD01_rootObjectFieldKeepsChildAlive() {
        const scenario = this.createPayloadHolderRoot();
        this.forceGc();
        assertEquals(301, scenario.root.ref.id);
        assertNotNull(scenario.weak.value);
    }
    private createClearedPayloadHolderRoot(): RootedWeak<PayloadHolder, Payload> {
        const child = new Payload(302);
        const holder = new PayloadHolder(child);
        const weak = new WeakReference(child);
        holder.ref = null;
        return new RootedWeak(holder, weak);
    }
    /**
     * RC-D02
     * Scenario: a root object's direct field is cleared.
     * Expectation: after the helper stack frame returns, the former field target can be collected.
     */
    rcD02_clearingRootObjectFieldAllowsChildCollection() {
        const scenario = this.createClearedPayloadHolderRoot();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root.ref);
    }
    private createTwoLevelFieldPathRoot(): RootedWeak<TwoLevelHolder, Payload> {
        const leaf = new Payload(303);
        const mid = new PayloadHolder(leaf);
        const root = new TwoLevelHolder(mid);
        return new RootedWeak(root, new WeakReference(leaf));
    }
    /**
     * RC-D03
     * Scenario: a root object reaches Payload through a two-level field path.
     * Expectation: the leaf object remains reachable through root.child.ref.
     */
    rcD03_twoLevelFieldPathKeepsLeafAlive() {
        const scenario = this.createTwoLevelFieldPathRoot();
        this.forceGc();
        assertEquals(303, scenario.root.child.ref.id);
        assertNotNull(scenario.weak.value);
    }
    private createMiddleFieldDisconnectedResult(): TwoLevelDisconnectResult {
        const leaf = new Payload(304);
        const mid = new PayloadHolder(leaf);
        const root = new TwoLevelHolder(mid);
        const midWeak = new WeakReference(mid);
        const leafWeak = new WeakReference(leaf);
        root.child = null;
        return new TwoLevelDisconnectResult(root, midWeak, leafWeak);
    }
    /**
     * RC-D04
     * Scenario: the middle field in a two-level path is disconnected.
     * Expectation: both the middle holder and the leaf can be collected.
     */
    rcD04_disconnectingMiddleFieldAllowsSubgraphCollection() {
        const result = this.createMiddleFieldDisconnectedResult();
        this.forceGc();
        assertNull(result.root.child);
        result.midWeak.clear();
        assertNull(result.midWeak.value);
        result.leafWeak.clear();
        assertNull(result.leafWeak.value);
    }
    private createLeafFieldDisconnectedResult(): RootedWeak<TwoLevelHolder, Payload> {
        const leaf = new Payload(305);
        const mid = new PayloadHolder(leaf);
        const root = new TwoLevelHolder(mid);
        const leafWeak = new WeakReference(leaf);
        mid.ref = null;
        return new RootedWeak(root, leafWeak);
    }
    /**
     * RC-D05
     * Scenario: the leaf field in a two-level path is cleared while the middle holder remains reachable.
     * Expectation: the leaf can be collected, but the middle holder remains reachable through the root.
     */
    rcD05_clearingLeafFieldAllowsLeafCollectionButKeepsMiddleAlive() {
        const scenario = this.createLeafFieldDisconnectedResult();
        this.assertWeakCollected(scenario.weak);
        assertNotNull(scenario.root.child);
        assertNull(scenario.root.child.ref);
    }
    private createAnyFieldRoot(): RootedWeak<AnyHolder, any> {
        const obj: any = new Payload(306);
        const holder = new AnyHolder(obj);
        return new RootedWeak(holder, new WeakReference(obj));
    }
    /**
     * RC-D06
     * Scenario: a field has static type Any? and runtime type Payload.
     * Expectation: the runtime object remains reachable through the Any?-typed field.
     */
    rcD06_anyTypedFieldKeepsRuntimeObjectAlive() {
        const scenario = this.createAnyFieldRoot();
        this.forceGc();
        assertEquals(306, (scenario.root.ref as Payload).id);
        assertNotNull(scenario.weak.value);
    }
    private createInterfaceFieldRoot(): RootedWeak<InterfaceHolder, Marker> {
        const obj: Marker = new Payload(307);
        const holder = new InterfaceHolder(obj);
        return new RootedWeak(holder, new WeakReference(obj));
    }
    /**
     * RC-D07
     * Scenario: a field has static type Marker? and runtime type Payload.
     * Expectation: the runtime object remains reachable through the interface-typed field.
     */
    rcD07_interfaceTypedFieldKeepsRuntimeObjectAlive() {
        const scenario = this.createInterfaceFieldRoot();
        this.forceGc();
        assertEquals(307, scenario.root.ref.id);
        assertNotNull(scenario.weak.value);
    }
    private createNullableFieldRoot(): RootedWeak<PayloadHolder, Payload> {
        const obj = new Payload(308);
        const holder = new PayloadHolder(obj);
        return new RootedWeak(holder, new WeakReference(obj));
    }
    /**
     * RC-D08
     * Scenario: a nullable Payload? field holds a non-null Payload.
     * Expectation: the object remains reachable through the nullable field.
     */
    rcD08_nullableFieldNonNullReferenceKeepsObjectAlive() {
        const scenario = this.createNullableFieldRoot();
        this.forceGc();
        assertEquals(308, scenario.root.ref.id);
        assertNotNull(scenario.weak.value);
    }
    private createFieldReplacementResult(): HolderReplacementResult<PayloadHolder, Payload> {
        const oldObj = new Payload(309);
        const holder = new PayloadHolder(oldObj);
        const oldWeak = new WeakReference(oldObj);
        const newObj = new Payload(390);
        holder.ref = newObj;
        const newWeak = new WeakReference(newObj);
        return new HolderReplacementResult(holder, oldWeak, newWeak);
    }
    /**
     * RC-D09
     * Scenario: a root object's field is reassigned from an old object to a new object.
     * Expectation: the old object can be collected, while the new field target remains reachable.
     */
    rcD09_fieldReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        const result = this.createFieldReplacementResult();
        this.forceGc();
        result.oldWeak.clear();
        assertNull(result.oldWeak.value);
        assertNotNull(result.newWeak.value);
        assertEquals(390, result.holder.ref.id);
    }
}
