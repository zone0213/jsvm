@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-G group: thread stack, thread lifecycle and GC interaction tests.
 */
class ThreadLifecycleGcTest : ConcurrentGcTestSupport() {

    /**
     * CG-G01
     * Scenario: worker local root is alive while main triggers GC.
     * Expectation: worker reports valid object.
     */
    @Test
    fun cgG01_childStackLocalRootDuringMainGc() {
        assertTrue(runWorkerMutationWithMainGc { val node=Node(901)
        val weak=WeakReference(node)
        GC.collect()
        node.id==901 && weak.value!=null })
    }

    /**
     * CG-G02
     * Scenario: worker function parameter is alive during GC.
     * Expectation: parameter remains valid.
     */
    @Test
    fun cgG02_childStackParameterRootDuringGc() {
        assertTrue(runWorkerTask { fun check(node: Node): Boolean { val weak=WeakReference(node)
        GC.collect()
        return node.id==902 && weak.value!=null }
        check(Node(902)) })
    }

    /**
     * CG-G03
     * Scenario: worker lambda capture keeps object alive.
     * Expectation: captured object remains valid.
     */
    @Test
    fun cgG03_childLambdaCaptureRootDuringGc() {
        assertTrue(runWorkerTask { val node=Node(903)
        val weak=WeakReference(node)
        val f={node.id}
        GC.collect()
        f()==903 && weak.value!=null })
    }

    /**
     * CG-G04
     * Scenario: worker holder root keeps object alive.
     * Expectation: held object remains valid.
     */
    @Test
    fun cgG04_childHolderRootDuringGc() {
        assertTrue(runWorkerTask { val holder=Holder(Node(904))
        val weak=WeakReference(holder.ref!!)
        GC.collect()
        holder.ref!!.id==904 && weak.value!=null })
    }

    /**
     * CG-G05
     * Scenario: worker nulls root and remains running.
     * Expectation: old target can be collected.
     */
    @Test
    fun cgG05_childStackRootSetNullWhileRunning() {
        val weak = run { val node=Node(905)
        val w=WeakReference(node)
        w }
        forceGcLoop()
        assertNull(weak.value)
    }

    /**
     * CG-G06
     * Scenario: worker reassigns root old -> new.
     * Expectation: old collected and new alive in worker semantics.
     */
    @Test
    fun cgG06_childRootReassignmentDuringGc() {
        val r = replaceField(906, 907)
        assertWeakCollectedEventually(r.oldWeak)
        assertWeakAlive(r.newWeak)
        assertNotNull(r.root.ref)
    }

    /**
     * CG-G07
     * Scenario: object created in worker-like helper does not escape strongly.
     * Expectation: weak eventually clears.
     */
    @Test
    fun cgG07_threadExitAllowsObjectCollection() {
        fun makeWeak(): WeakReference<Node> { val n=Node(908)
        return WeakReference(n) }
        assertWeakCollectedEventually(makeWeak())
    }

    /**
     * CG-G08
     * Scenario: worker starts while main runs GC loop.
     * Expectation: worker completes.
     */
    @Test
    fun cgG08_gcInterleavesWithThreadStart() {
        assertTrue(runWorkerMutationWithMainGc { val n=Node(909)
        n.id==909 })
    }

    /**
     * CG-G09
     * Scenario: main runs GC around worker completion.
     * Expectation: no crash.
     */
    @Test
    fun cgG09_gcInterleavesWithThreadExit() {
        assertTrue(runWorkerMutationWithMainGc { allocateGarbage(64)
        true })
    }

    /**
     * CG-G10
     * Scenario: multiple workers each hold local objects.
     * Expectation: all complete.
     */
    @Test
    fun cgG10_multipleThreadStackRoots() {
        val completed=runBoundedConcurrentWriters(3,8){w,i-> val n=Node(9100+w*100+i)
        assertTrue(n.id>=9100)
        GC.collect() }
        assertEquals(3,completed)
    }

    /**
     * CG-G11
     * Scenario: worker holds root while allocating many short-lived objects.
     * Expectation: root remains valid.
     */
    @Test
    fun cgG11_childAllocationStormWithStackRoot() {
        assertTrue(runWorkerTask { val root=Node(911)
        val weak=WeakReference(root)
        repeat(256){ Node(it) }
        GC.collect()
        root.id==911 && weak.value!=null })
    }

    /**
     * CG-G12
     * Scenario: busy mutator loop interleaves with GC.
     * Expectation: no deadlock and loop completes.
     */
    @Test
    fun cgG12_busyMutatorLoopWithGc() {
        val count=repeatMutationWithGc(64){ allocateGarbage(8) }
        assertEquals(64,count)
    }

}
