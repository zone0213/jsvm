@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-E group: cyclic graph tests. */
class CycleGraphTest : GraphTopologyTestSupport() {

    private fun buildCycle(size: Int, startId: Int): List<GraphNode> {
        val nodes = List(size) { index -> GraphNode(startId + index) }
        for (index in nodes.indices) {
            nodes[index].next = nodes[(index + 1) % nodes.size]
        }
        return nodes
    }

    /** GT-E01: a reachable self-cycle remains alive. */
    @Test
    fun gtE01_reachableSelfCycleKeepsNodeAlive() {
        val node = GraphNode(9001)
        node.next = node
        val scenario = RootedWeaks(GraphRoot(node), listOf(WeakReference(node)))
        forceGc()
        assertEquals(9001, scenario.root.ref!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun weakOnlySelfCycle(): WeakReference<GraphNode> {
        val node = GraphNode(9002)
        node.next = node
        return WeakReference(node)
    }

    /** GT-E02: an unreachable self-cycle can be collected by tracing GC. */
    @Test
    fun gtE02_unreachableSelfCycleCanBeCollected() {
        assertWeakCollected(weakOnlySelfCycle())
    }

    private fun selfCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val node = GraphNode(9003)
        node.next = node
        val root = GraphRoot(node)
        val weak = WeakReference(node)
        root.ref = null
        return RootedWeaks(root, listOf(weak))
    }

    /** GT-E03: clearing root allows a self-cycle to be collected. */
    @Test
    fun gtE03_clearingRootAllowsSelfCycleCollection() {
        val scenario = selfCycleAfterRootClear()
        assertNull(scenario.root.ref)
        assertAllCollected(scenario.weaks)
    }

    /** GT-E04: a reachable two-node cycle remains alive. */
    @Test
    fun gtE04_reachableTwoNodeCycleKeepsBothNodesAlive() {
        val nodes = buildCycle(2, 9010)
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(9011, scenario.root.ref!!.next!!.id)
        assertEquals(9010, scenario.root.ref!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun weakOnlyTwoNodeCycle(): List<WeakReference<GraphNode>> {
        val nodes = buildCycle(2, 9020)
        return weakRefs(nodes)
    }

    /** GT-E05: an unreachable two-node cycle can be collected. */
    @Test
    fun gtE05_unreachableTwoNodeCycleCanBeCollected() {
        assertAllCollected(weakOnlyTwoNodeCycle())
    }

    private fun twoNodeCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildCycle(2, 9030)
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(nodes)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-E06: clearing root allows a two-node cycle to be collected. */
    @Test
    fun gtE06_clearingRootAllowsTwoNodeCycleCollection() {
        val scenario = twoNodeCycleAfterRootClear()
        assertAllCollected(scenario.weaks)
    }

    /** GT-E07: a reachable 3-node cycle keeps all nodes alive. */
    @Test
    fun gtE07_reachableThreeNodeCycleKeepsAllNodesAlive() {
        val nodes = buildCycle(3, 9040)
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(9042, scenario.root.ref!!.next!!.next!!.id)
        assertEquals(9040, scenario.root.ref!!.next!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun weakOnlyThreeNodeCycle(): List<WeakReference<GraphNode>> {
        val nodes = buildCycle(3, 9050)
        return weakRefs(nodes)
    }

    /** GT-E08: an unreachable 3-node cycle can be collected. */
    @Test
    fun gtE08_unreachableThreeNodeCycleCanBeCollected() {
        assertAllCollected(weakOnlyThreeNodeCycle())
    }

    /** GT-E09: a reachable 100-node cycle keeps representative nodes alive. */
    @Test
    fun gtE09_reachableHundredNodeCycleKeepsRepresentativeNodesAlive() {
        val nodes = buildCycle(100, 9060)
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(9060, scenario.weaks[0].value!!.id)
        assertEquals(9109, scenario.weaks[49].value!!.id)
        assertEquals(9159, scenario.weaks[99].value!!.id)
    }

    private fun hundredNodeCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildCycle(100, 9200)
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(nodes)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-E10: clearing root allows a 100-node cycle to be collected. */
    @Test
    fun gtE10_clearingRootAllowsHundredNodeCycleCollection() {
        val scenario = hundredNodeCycleAfterRootClear()
        assertAllCollected(scenario.weaks)
    }

    private fun chainIntoCycle(): List<GraphNode> {
        val head = GraphNode(9300)
        val a = GraphNode(9301)
        val b = GraphNode(9302)
        val c = GraphNode(9303)
        head.next = a
        a.next = b
        b.next = c
        c.next = a
        return listOf(head, a, b, c)
    }

    /** GT-E11: a chain entering a cycle keeps both the chain head and cycle nodes alive. */
    @Test
    fun gtE11_chainEnteringCycleKeepsWholeGraphAlive() {
        val nodes = chainIntoCycle()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(9303, scenario.root.ref!!.next!!.next!!.next!!.id)
        assertEquals(9301, scenario.root.ref!!.next!!.next!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun chainAfterDisconnectingCycleEntry(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = chainIntoCycle()
        nodes[0].next = null
        return MixedWeaks(GraphRoot(nodes.first()), weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-E12: disconnecting the chain from the cycle keeps the head alive and collects the cycle. */
    @Test
    fun gtE12_disconnectingChainFromCycleCollectsCycleOnly() {
        val scenario = chainAfterDisconnectingCycleEntry()
        forceGc()
        assertNull(scenario.root.ref!!.next)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-E13: a reachable cycle with an attached leaf keeps the leaf alive. */
    @Test
    fun gtE13_cycleWithAttachedLeafKeepsLeafAlive() {
        val nodes = buildCycle(2, 9400)
        val leaf = GraphNode(9402)
        nodes[0].left = leaf
        val all = nodes + leaf
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(all))
        forceGc()
        assertEquals(9402, scenario.root.ref!!.left!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun cycleWithLeafAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildCycle(2, 9410)
        val leaf = GraphNode(9412)
        nodes[0].left = leaf
        val all = nodes + leaf
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(all)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-E14: clearing root collects a cycle and its attached leaf. */
    @Test
    fun gtE14_clearingRootCollectsCycleAndAttachedLeaf() {
        val scenario = cycleWithLeafAfterRootClear()
        assertAllCollected(scenario.weaks)
    }

    /** GT-E15: breaking an internal cycle edge turns it into a reachable chain that remains alive. */
    @Test
    fun gtE15_breakingCycleInternalEdgeStillKeepsReachableChainAlive() {
        val nodes = buildCycle(3, 9500)
        nodes[2].next = null
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertNull(scenario.root.ref!!.next!!.next!!.next)
        assertAllAlive(scenario.weaks)
    }

    private fun brokenCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildCycle(3, 9600)
        nodes[2].next = null
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(nodes)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-E16: after breaking a cycle and clearing root, the whole former cycle can be collected. */
    @Test
    fun gtE16_brokenCycleCollectedAfterRootClear() {
        val scenario = brokenCycleAfterRootClear()
        assertAllCollected(scenario.weaks)
    }
}
