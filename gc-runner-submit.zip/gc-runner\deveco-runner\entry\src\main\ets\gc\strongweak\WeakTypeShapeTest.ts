﻿// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-H group: type-shape, generic, nullable and lambda combinations.
 */
export class WeakTypeShapeTest extends WeakReferenceTestSupport {
    private createConcreteWeakOnly(): WeakReference<Payload> {
        const obj = new Payload(801);
        return new WeakReference(obj);
    }
    /**
     * WR-H01
     * Scenario: WeakReference<Payload> is the only escaping reference.
     * Expectation: target can be collected.
     */
    wrH01_concreteWeakOnlyCanBeCollected() {
        const weak = this.createConcreteWeakOnly();
        this.assertWeakCollected(weak);
    }
    private createAnyWeakOnly(): WeakReference<any> {
        const obj: any = new Payload(802);
        return new WeakReference(obj);
    }
    /**
     * WR-H02
     * Scenario: WeakReference<Any> points to Payload runtime object.
     * Expectation: target can be collected.
     */
    wrH02_anyTypedWeakOnlyCanBeCollected() {
        const weak = this.createAnyWeakOnly();
        this.assertWeakCollected(weak);
    }
    private createMarkerWeakOnly(): WeakReference<Marker> {
        const obj: Marker = new MarkerPayload(803);
        return new WeakReference(obj);
    }
    /**
     * WR-H03
     * Scenario: WeakReference<Marker> points to interface-typed object.
     * Expectation: target can be collected.
     */
    wrH03_interfaceTypedWeakOnlyCanBeCollected() {
        const weak = this.createMarkerWeakOnly();
        this.assertWeakCollected(weak);
    }
    private createWeakBoxOnly(): WeakReference<Box<Payload>> {
        const box = new Box(new Payload(804));
        return new WeakReference(box);
    }
    /**
     * WR-H04
     * Scenario: WeakReference<Box<Payload>> is the only escaping reference to the box.
     * Expectation: box and its contained payload can be collected.
     */
    wrH04_weakBoxOnlyCanBeCollected() {
        const weak = this.createWeakBoxOnly();
        this.assertWeakCollected(weak);
    }
    private createStrongBoxWithPayload(): WeakOnlyResult<Box<Payload>, Payload> {
        const obj = new Payload(805);
        const box = new Box(obj);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(box, weak);
    }
    /**
     * WR-H05
     * Scenario: a strong Box holds Payload while WeakReference observes Payload.
     * Expectation: payload remains alive through Box.value.
     */
    wrH05_strongBoxPayloadKeepsWeakTargetAlive() {
        const scenario = this.createStrongBoxWithPayload();
        this.forceGc();
        assertEquals(805, scenario.root.value.id);
        assertNotNull(scenario.weak.value);
    }
    private createBoxAfterClear(): WeakOnlyResult<Box<Payload>, Payload> {
        const obj = new Payload(806);
        const box = new Box(obj);
        const weak = new WeakReference(obj);
        box.value = null;
        return new WeakOnlyResult(box, weak);
    }
    /**
     * WR-H06
     * Scenario: Box.value is cleared.
     * Expectation: payload can be collected.
     */
    wrH06_clearingBoxValueClearsWeak() {
        const scenario = this.createBoxAfterClear();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root.value);
    }
    /**
     * WR-H07
     * Scenario: nullable strong variable is non-null and WeakReference observes it.
     * Expectation: target remains alive while nullable strong reference is used.
     */
    wrH07_nullableStrongNonNullKeepsWeakTargetAlive() {
        const obj: Payload | null = new Payload(807);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(807, obj.id);
        assertNotNull(weak.value);
    }
    private createAfterNullableStrongNull(): WeakReference<Payload> {
        let obj: Payload | null = new Payload(808);
        const weak = new WeakReference(obj);
        obj = null;
        assertNull(obj);
        return weak;
    }
    /**
     * WR-H08
     * Scenario: nullable strong reference is set to null.
     * Expectation: target can be collected.
     */
    wrH08_nullableStrongSetNullClearsWeak() {
        const weak = this.createAfterNullableStrongNull();
        this.assertWeakCollected(weak);
    }
    private createGenericWeakHolderOnly(): WeakOnlyResult<WeakHolder<Payload>, Payload> {
        const obj = new Payload(809);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new WeakHolder(weak), weak);
    }
    /**
     * WR-H09
     * Scenario: generic WeakHolder<Payload> holds WeakReference only.
     * Expectation: target can be collected.
     */
    wrH09_genericWeakHolderOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createGenericWeakHolderOnly();
        this.forceGc();
        assertNotNull(scenario.root.weak);
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    /**
     * WR-H10
     * Scenario: generic MixedHolder<Payload> holds both strong and weak references to target.
     * Expectation: target remains alive through MixedHolder.strong.
     */
    wrH10_genericMixedHolderStrongAndWeakKeepsTargetAlive() {
        const obj = new Payload(810);
        const holder = new MixedHolder(obj, new WeakReference(obj));
        this.forceGc();
        assertEquals(810, holder.strong.id);
        assertNotNull(holder.weak.value);
    }
    /**
     * WR-H11
     * Scenario: lambda strongly captures target.
     * Expectation: target remains alive through lambda capture.
     */
    wrH11_lambdaStrongCaptureKeepsTargetAlive() {
        const obj = new Payload(811);
        const weak = new WeakReference(obj);
        const block = () => obj.id;
        this.forceGc();
        assertEquals(811, block());
        assertNotNull(weak.value);
    }
    private createLambdaWeakCaptureOnly(): any {
        const obj = new Payload(812);
        const weak = new WeakReference(obj);
        const block = () => weak.value?.id;
        return new WeakOnlyResult(new Root(block), weak);
    }
    /**
     * WR-H12
     * Scenario: lambda captures WeakReference but not the target.
     * Expectation: target can be collected.
     */
    wrH12_lambdaWeakCaptureOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createLambdaWeakCaptureOnly();
        this.forceGc();
        scenario.weak.clear();
        assertNull(scenario.root.ref());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    private createNestedLambdaWeakCaptureOnly(): any {
        const obj = new Payload(813);
        const weak = new WeakReference(obj);
        const outer = () => () => weak.value?.id ;
        return new WeakOnlyResult(new Root(outer), weak);
    }
    /**
     * WR-H13
     * Scenario: nested lambdas capture WeakReference but not the target.
     * Expectation: target can be collected.
     */
    wrH13_nestedLambdaWeakCaptureOnlyDoesNotKeepTargetAlive() {
        const scenario = this.createNestedLambdaWeakCaptureOnly();
        this.forceGc();
        const inner = scenario.root.ref();
        scenario.weak.clear();
        assertNull(inner());
        assertNull(scenario.weak.value);
    }
    private passWeakReferenceOnly(weak: WeakReference<Payload>): WeakReference<Payload> { return weak; }
    private createFunctionParameterWeakOnly(): WeakReference<Payload> {
        const obj = new Payload(814);
        const weak = new WeakReference(obj);
        return this.passWeakReferenceOnly(weak);
    }
    /**
     * WR-H14
     * Scenario: a helper receives and returns WeakReference without receiving target strongly.
     * Expectation: target can be collected after creator helper returns.
     */
    wrH14_functionParameterWeakOnlyDoesNotKeepTargetAlive() {
        const weak = this.createFunctionParameterWeakOnly();
        this.assertWeakCollected(weak);
    }
}


