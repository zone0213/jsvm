@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-G group: function-call safepoints and parameter root maps.
 */
class PreciseStackSafepointCallTest : PreciseStackTestSupport() {
    private fun consumeSingle(obj: StackPayload): WeakReference<StackPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    private fun consumeMany(
        first: StackPayload,
        second: StackPayload,
        third: StackPayload,
    ): List<WeakReference<StackPayload>> {
        val weaks = listOf(WeakReference(first), WeakReference(second), WeakReference(third))
        forceGc()
        assertEquals(7001, first.id)
        assertEquals(7002, second.id)
        assertEquals(7003, third.id)
        weaks.forEachIndexed { index, weak ->
            assertEquals(7001 + index, weak.value!!.id)
        }
        return weaks
    }

    private fun consumeMixed(
        obj: StackPayload,
        intValue: Int,
        longValue: Long,
        text: String,
    ): WeakReference<StackPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(7101, obj.id)
        assertEquals(42, intValue)
        assertEquals(84L, longValue)
        assertEquals("root", text)
        assertEquals(7101, weak.value!!.id)
        return weak
    }

    private fun consumeAny(obj: Any): WeakReference<Any> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(7201, (obj as StackPayload).id)
        assertEquals(7201, (weak.value as StackPayload).id)
        return weak
    }

    private fun <T : PreciseStackMarker> consumeGeneric(obj: T): WeakReference<T> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    /**
     * PS-G01
     * Scenario: a single reference parameter is live when callee triggers GC.
     * Expectation: parameter root is included in the call safepoint map.
     */
    @Test
    fun psG01_singleReferenceParameterSurvivesCalleeGc() {
        val obj = StackPayload(7000)
        val weak = consumeSingle(obj)

        assertEquals(7000, obj.id)
        assertEquals(7000, weak.value!!.id)
    }

    /**
     * PS-G02
     * Scenario: multiple reference parameters are live when callee triggers GC.
     * Expectation: all parameter locations are scanned.
     */
    @Test
    fun psG02_multipleReferenceParametersSurviveCalleeGc() {
        val first = StackPayload(7001)
        val second = StackPayload(7002)
        val third = StackPayload(7003)

        val weaks = consumeMany(first, second, third)

        assertEquals(7001, first.id)
        assertEquals(7002, second.id)
        assertEquals(7003, third.id)
        weaks.forEachIndexed { index, weak ->
            assertEquals(7001 + index, weak.value!!.id)
        }
    }

    /**
     * PS-G03
     * Scenario: reference parameter is mixed with primitive and object parameters.
     * Expectation: precise call safepoint map scans the reference parameter only as a root.
     */
    @Test
    fun psG03_referenceParameterMixedWithPrimitiveParametersSurvivesGc() {
        val obj = StackPayload(7101)
        val weak = consumeMixed(obj, 42, 84L, "root")

        assertEquals(7101, obj.id)
        assertEquals(7101, weak.value!!.id)
    }

    /**
     * PS-G04
     * Scenario: parameter has static type Any and runtime type StackPayload.
     * Expectation: erased parameter location is still scanned as a root.
     */
    @Test
    fun psG04_anyTypedParameterSurvivesCalleeGc() {
        val obj: Any = StackPayload(7201)
        val weak = consumeAny(obj)

        assertEquals(7201, (obj as StackPayload).id)
        assertEquals(7201, (weak.value as StackPayload).id)
    }

    /**
     * PS-G05
     * Scenario: generic parameter is live when callee triggers GC.
     * Expectation: generic parameter root is preserved in the safepoint map.
     */
    @Test
    fun psG05_genericParameterSurvivesCalleeGc() {
        val obj = StackPayload(7301)
        val weak = consumeGeneric(obj)

        assertEquals(7301, obj.id)
        assertEquals(7301, weak.value!!.id)
    }
}

