@file:OptIn(
    kotlin.ExperimentalStdlibApi::class,
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.native.runtime.GCInfo
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Shared support for long-stability GC tests.
 *
 * The tests in this package are intentionally bounded so they can run in CI smoke mode.
 * Increase SHORT_ITERATIONS, CHURN_PER_ITERATION and SPIKE_ITERATIONS in a long-run build
 * variant for daily/nightly stability runs.
 */
open class LongStabilityTestSupport {
    protected fun forceGc(times: Int = 3) {
        repeat(times) { GC.collect() }
    }

    protected fun gcInfo(): GCInfo {
        GC.collect()
        return GC.lastGCInfo!!
    }

    protected fun heapAfterBytes(): Long =
        gcInfo().memoryUsageAfter["heap"]?.totalObjectsSizeBytes ?: 0L

    protected fun sweptCount(info: GCInfo = gcInfo()): Long =
        info.sweepStatistics.values.sumOf { it.sweptCount.toLong() }

    protected fun keptCount(info: GCInfo = gcInfo()): Long =
        info.sweepStatistics.values.sumOf { it.keptCount.toLong() }

    protected fun assertGcInfoReadable() {
        val info = gcInfo()
        val heap = info.memoryUsageAfter["heap"]
        assertNotNull(heap, "Expected heap memory usage to be available.")
        assertTrue(heap.totalObjectsSizeBytes >= 0)
        assertTrue(sweptCount(info) >= 0)
        assertTrue(keptCount(info) >= 0)
    }

    protected fun assertNoSustainedMonotonicGrowth(samples: List<Long>, maxRun: Int = 4) {
        if (samples.size < 3) return

        var currentRun = 0
        var longestRun = 0

        for (index in 1 until samples.size) {
            if (samples[index] > samples[index - 1]) {
                currentRun++
                if (currentRun > longestRun) longestRun = currentRun
            } else {
                currentRun = 0
            }
        }

        assertTrue(
            longestRun <= maxRun,
            "Heap grew for too many consecutive samples: $samples"
        )
    }

    protected fun assertSpikeRecovered(before: Long, peak: Long, after: Long) {
        assertTrue(peak >= before, "Expected spike peak to be >= baseline.")
        assertTrue(after <= peak, "Expected heap after release to be <= spike peak.")
    }

    protected fun <T : Any> assertWeakCollectedEventually(weak: WeakReference<T>) {
        forceGc(6)
        assertNull(weak.value)
    }

    protected fun <T : Any> assertAllWeakCollectedEventually(weaks: Iterable<WeakReference<T>>) {
        forceGc(6)
        weaks.forEachIndexed { index, weak ->
            assertNull(weak.value, "Expected weak[$index] to be cleared.")
        }
    }

    protected fun shortLivedSamples(
        iterations: Int = SHORT_ITERATIONS,
        allocator: (Int) -> Any
    ): List<Long> {
        val samples = mutableListOf<Long>()
        repeat(iterations) { iteration ->
            repeat(CHURN_PER_ITERATION) { item -> allocator(iteration * CHURN_PER_ITERATION + item) }
            if (iteration % SAMPLE_EVERY == 0) {
                forceGc()
                samples.add(heapAfterBytes())
            }
        }
        forceGc()
        samples.add(heapAfterBytes())
        return samples
    }

    protected fun containerSamples(
        iterations: Int = SHORT_ITERATIONS,
        operation: (Int) -> Unit
    ): List<Long> {
        val samples = mutableListOf<Long>()
        repeat(iterations) { iteration ->
            operation(iteration)
            if (iteration % SAMPLE_EVERY == 0) {
                forceGc()
                samples.add(heapAfterBytes())
            }
        }
        forceGc()
        samples.add(heapAfterBytes())
        return samples
    }

    protected fun releaseReallocateSamples(
        iterations: Int = SHORT_ITERATIONS,
        allocate: () -> List<Any>
    ): List<Long> {
        val samples = mutableListOf<Long>()
        repeat(iterations) {
            val roots = allocate().toMutableList()
            assertTrue(roots.isNotEmpty())
            roots.clear()
            forceGc()
            samples.add(heapAfterBytes())
        }
        return samples
    }

    protected fun spikeLoop(
        iterations: Int = SPIKE_ITERATIONS,
        allocate: () -> MutableList<Any>
    ): Triple<Long, Long, Long> {
        val before = heapAfterBytes()
        var peak = before
        repeat(iterations) {
            val roots = allocate()
            forceGc()
            val during = heapAfterBytes()
            if (during > peak) peak = during
            roots.clear()
            forceGc()
        }
        return Triple(before, peak, heapAfterBytes())
    }

    protected fun longLivedWithGarbage(
        rootFactory: () -> Any,
        garbageFactory: (Int) -> Any
    ): WeakReference<Any> {
        val root = rootFactory()
        val weak = WeakReference(root)
        repeat(SHORT_ITERATIONS) { iteration ->
            repeat(CHURN_PER_ITERATION) { item ->
                garbageFactory(iteration * CHURN_PER_ITERATION + item)
            }
            if (iteration % SAMPLE_EVERY == 0) {
                forceGc()
            }
            assertNotNull(weak.value)
        }
        return weak
    }

    protected fun allocateSmallBatch(count: Int = SMALL_BATCH): List<LsNode> =
        List(count) { index -> LsNode(index) }

    protected fun allocateMediumBatch(count: Int = MEDIUM_BATCH): List<MediumPayload> =
        List(count) { index -> MediumPayload(index) }

    protected fun allocateLargeBatch(count: Int = LARGE_BATCH, size: Int = LARGE_BYTES): List<LargePayload> =
        List(count) { index -> LargePayload(index, ByteArray(size) { (it % 127).toByte() }) }

    protected fun allocateMixedBatch(count: Int = MIXED_BATCH): List<MixedPayload> =
        List(count) { index -> MixedPayload(index) }

    protected fun runPseudoWorkers(
        workerCount: Int = WORKER_COUNT,
        iterations: Int = WORKER_ITERATIONS,
        body: (Int, Int) -> Unit
    ): Int {
        var completed = 0
        repeat(workerCount) { worker ->
            repeat(iterations) { iteration ->
                body(worker, iteration)
                if (iteration % SAMPLE_EVERY == 0) {
                    forceGc(1)
                }
            }
            completed++
        }
        return completed
    }

    protected fun coroutineLikeBatch(count: Int = SHORT_ITERATIONS): List<WeakReference<LsNode>> {
        val continuations = mutableListOf<FakeContinuation>()
        val weaks = mutableListOf<WeakReference<LsNode>>()
        repeat(count) { index ->
            val payload = LsNode(index)
            continuations.add(FakeContinuation(payload))
            weaks.add(WeakReference(payload))
        }
        forceGc()
        continuations.forEach { it.resume() }
        continuations.clear()
        return weaks
    }

    protected fun pinnedLikeLoop(iterations: Int = SHORT_ITERATIONS, throwInside: Boolean = false): Int {
        var count = 0
        repeat(iterations) { index ->
            val bytes = ByteArray(MEDIUM_BYTES) { (it + index).toByte() }
            try {
                PinnedLike.use(bytes) { array ->
                    array[0] = index.toByte()
                    forceGc(1)
                    if (throwInside && index % 7 == 0) error("pinned-like failure")
                    assertEquals(index.toByte(), array[0])
                    count++
                }
            } catch (_: IllegalStateException) {
                count++
            }
        }
        return count
    }

    protected fun businessDtoSamples(iterations: Int = SHORT_ITERATIONS): List<Long> =
        containerSamples(iterations) { index ->
            val dto = FakeDto(
                id = index,
                name = "name-$index",
                children = List(8) { FakeDtoChild(it, "value-$index-$it") }
            )
            val decoded = FakeDto.decode(dto.encode())
            assertEquals(dto.id, decoded.id)
        }

    protected fun repositoryCacheStateSamples(iterations: Int = SHORT_ITERATIONS): List<Long> {
        val cache = LinkedHashMap<Int, LargePayload>()
        var state = FakeState(emptyList())
        return containerSamples(iterations) { index ->
            val dto = FakeDto(index, "repo-$index", List(4) { FakeDtoChild(it, "v$it") })
            state = state.reduce(dto)
            cache[index] = LargePayload(index, ByteArray(1024))
            if (cache.size > CACHE_LIMIT) cache.remove(cache.keys.first())
            assertTrue(state.items.isNotEmpty())
        }
    }

    companion object {
        const val SMALL_BATCH = 256
        const val MEDIUM_BATCH = 96
        const val LARGE_BATCH = 8
        const val MIXED_BATCH = 32
        const val SHORT_ITERATIONS = 24
        const val WORKER_ITERATIONS = 16
        const val WORKER_COUNT = 3
        const val CHURN_PER_ITERATION = 128
        const val SAMPLE_EVERY = 4
        const val MEDIUM_BYTES = 8 * 1024
        const val LARGE_BYTES = 64 * 1024
        const val SPIKE_ITERATIONS = 8
        const val CACHE_LIMIT = 16
    }
}

class LsNode(val id: Int, var child: LsNode? = null)

class MediumPayload(
    val id: Int,
    val refs: Array<LsNode?> = arrayOfNulls(64)
)

class LargePayload(
    val id: Int,
    val bytes: ByteArray
)

class MixedPayload(
    val id: Int,
    val node: LsNode = LsNode(id),
    val medium: MediumPayload = MediumPayload(id),
    val large: LargePayload = LargePayload(id, ByteArray(1024))
)

class Holder<T : Any>(var ref: T?)

class FakeContinuation(var payload: LsNode?) {
    fun resume(): Int {
        val id = payload!!.id
        payload = null
        return id
    }
}

object PinnedLike {
    inline fun <T> use(array: ByteArray, block: (ByteArray) -> T): T = block(array)
}

data class FakeDto(
    val id: Int,
    val name: String,
    val children: List<FakeDtoChild>
) {
    fun encode(): String =
        "$id|$name|" + children.joinToString(",") { "${it.id}:${it.value}" }

    companion object {
        fun decode(raw: String): FakeDto {
            val parts = raw.split("|")
            val id = parts[0].toInt()
            val name = parts[1]
            val children = if (parts.size > 2 && parts[2].isNotEmpty()) {
                parts[2].split(",").map {
                    val childParts = it.split(":")
                    FakeDtoChild(childParts[0].toInt(), childParts[1])
                }
            } else {
                emptyList()
            }
            return FakeDto(id, name, children)
        }
    }
}

data class FakeDtoChild(val id: Int, val value: String)

data class FakeState(val items: List<FakeDto>) {
    fun reduce(dto: FakeDto): FakeState = FakeState((items + dto).takeLast(32))
}

val globalHolder = Holder<LsNode>(null)
