@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.test.Test
import kotlin.test.assertTrue

/**
 * LS-M group: configuration and platform matrix smoke hooks.
 */
class ConfigurationMatrixLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-M01
     * Scenario: default config smoke.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m01_defaultConfigSmoke() {
        val descriptor = "default-smoke"
        assertTrue(descriptor.isNotBlank())
        assertNoSustainedMonotonicGrowth(shortLivedSamples { LsNode(it) })
    }

    /**
     * LS-M02
     * Scenario: cms daily descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m02_cmsDailyDescriptor() {
        assertTrue("gc=cms,duration=daily".isNotBlank())
    }

    /**
     * LS-M03
     * Scenario: pmcs daily descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m03_pmcsDailyDescriptor() {
        assertTrue("gc=pmcs,duration=daily".isNotBlank())
    }

    /**
     * LS-M04
     * Scenario: stwms daily descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m04_stwmsDailyDescriptor() {
        assertTrue("gc=stwms,duration=daily".isNotBlank())
    }

    /**
     * LS-M05
     * Scenario: gcMarkSingleThreaded descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m05_gcmarksinglethreadedDescriptor() {
        assertTrue("gcMarkSingleThreaded=true".isNotBlank())
    }

    /**
     * LS-M06
     * Scenario: pagedAllocator false descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m06_pagedallocatorFalseDescriptor() {
        assertTrue("pagedAllocator=false".isNotBlank())
    }

    /**
     * LS-M07
     * Scenario: disableMmap true descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m07_disablemmapTrueDescriptor() {
        assertTrue("disableMmap=true".isNotBlank())
    }

    /**
     * LS-M08
     * Scenario: combined allocator descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m08_combinedAllocatorDescriptor() {
        assertTrue("pagedAllocator=false,disableMmap=true".isNotBlank())
    }

    /**
     * LS-M09
     * Scenario: macOS arm64 nightly descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m09_macosArm64NightlyDescriptor() {
        assertTrue("macosArm64-nightly".isNotBlank())
    }

    /**
     * LS-M10
     * Scenario: Linux x64 nightly descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m10_linuxX64NightlyDescriptor() {
        assertTrue("linuxX64-nightly".isNotBlank())
    }

    /**
     * LS-M11
     * Scenario: iOS simulator smoke descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m11_iosSimulatorSmokeDescriptor() {
        assertTrue("iosSimulatorArm64-smoke".isNotBlank())
    }

    /**
     * LS-M12
     * Scenario: multi-platform result comparison descriptor.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_m12_multiPlatformResultComparisonDescriptor() {
        assertTrue("matrix-result-comparison".isNotBlank())
    }

}
