@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * RS-A group: stack local root tests.
 */
class StackLocalRootTest : RootSetTestSupport() {
    /**
     * RS-A01
     * Scenario: local val directly references a payload object.
     * Expectation: payload remains alive while the local val is used after GC.
     */
    @Test
    fun rsA01_localValRootKeepsObjectAlive() {
        val obj = RootPayload(1001)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1001, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A02
     * Scenario: local var directly references a payload object.
     * Expectation: payload remains alive while the local var is used after GC.
     */
    @Test
    fun rsA02_localVarRootKeepsObjectAlive() {
        var obj = RootPayload(1002)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1002, obj.id)
        assertNotNull(weak.value)
        obj = RootPayload(10020)
        assertEquals(10020, obj.id)
    }

/**
     * RS-A03
     * Scenario: local nullable reference holds a non-null payload.
     * Expectation: payload remains alive through the nullable local root.
     */
    @Test
    fun rsA03_localNullableRootKeepsObjectAlive() {
        val obj: RootPayload? = RootPayload(1003)
        val weak = WeakReference(obj!!)
        forceGc()
        assertEquals(1003, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A04
     * Scenario: local root has static type Any and runtime type RootPayload.
     * Expectation: runtime object remains alive.
     */
    @Test
    fun rsA04_localAnyRootKeepsRuntimeObjectAlive() {
        val obj: Any = RootPayload(1004)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1004, (obj as RootPayload).id)
        assertNotNull(weak.value)
    }

/**
     * RS-A05
     * Scenario: local root has static type RootMarker and runtime type RootPayload.
     * Expectation: runtime object remains alive.
     */
    @Test
    fun rsA05_localInterfaceRootKeepsRuntimeObjectAlive() {
        val obj: RootMarker = RootPayload(1005)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1005, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A06
     * Scenario: local generic box strongly references a payload.
     * Expectation: box and its value remain alive.
     */
    @Test
    fun rsA06_localGenericBoxRootKeepsValueAlive() {
        val obj = RootPayload(1006)
        val box = RootBox(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1006, box.value!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A07
     * Scenario: local holder strongly references a payload through a field.
     * Expectation: payload remains alive through holder.ref.
     */
    @Test
    fun rsA07_localHolderFieldRootKeepsValueAlive() {
        val obj = RootPayload(1007)
        val holder = RootHolder(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1007, holder.ref!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A08
     * Scenario: local root payload strongly references a child payload.
     * Expectation: both parent and child remain alive.
     */
    @Test
    fun rsA08_localRootWithChildGraphKeepsChildAlive() {
        val child = RootPayload(10081)
        val obj = RootPayload(1008, child)
        val childWeak = WeakReference(child)
        forceGc()
        assertEquals(1008, obj.id)
        assertEquals(10081, obj.child!!.id)
        assertNotNull(childWeak.value)
    }

/**
     * RS-A09
     * Scenario: local array contains a payload.
     * Expectation: payload remains alive through array element.
     */
    @Test
    fun rsA09_localArrayRootKeepsElementAlive() {
        val obj = RootPayload(1009)
        val array = arrayOfNulls<RootPayload>(1)
        array[0] = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1009, array[0]!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A10
     * Scenario: local list contains a payload.
     * Expectation: payload remains alive through list element.
     */
    @Test
    fun rsA10_localListRootKeepsElementAlive() {
        val obj = RootPayload(1010)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1010, list.single().id)
        assertNotNull(weak.value)
    }

/**
     * RS-A11
     * Scenario: local map contains a payload value.
     * Expectation: payload remains alive through map value.
     */
    @Test
    fun rsA11_localMapRootKeepsValueAlive() {
        val obj = RootPayload(1011)
        val map = mutableMapOf("k" to obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1011, map["k"]!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-A12
     * Scenario: local lambda captures a payload object.
     * Expectation: payload remains alive through the lambda object.
     */
    @Test
    fun rsA12_localLambdaCaptureRootKeepsObjectAlive() {
        val obj = RootPayload(1012)
        val weak = WeakReference(obj)
        val block = { obj.id }
        forceGc()
        assertEquals(1012, block())
        assertNotNull(weak.value)
    }

    private fun createWeakAfterLocalRootSetNull(): WeakReference<RootPayload> {
        var obj: RootPayload? = RootPayload(1013)
        val weak = WeakReference(obj!!)
        obj = null
        assertNull(obj)
        return weak
    }

/**
     * RS-A13
     * Scenario: local nullable root is set to null.
     * Expectation: after helper returns, payload can be collected.
     */
    @Test
    fun rsA13_localRootSetNullAllowsCollection() {
        val weak = createWeakAfterLocalRootSetNull()
        assertWeakCollected(weak)
    }

    private fun createLocalRootReplacement(): ReplacementRoot<RootPayload, RootPayload> {
        var obj: RootPayload? = RootPayload(1014)
        val oldWeak = WeakReference(obj!!)
        obj = RootPayload(10140)
        val newObj = obj!!
        val newWeak = WeakReference(newObj)
        return ReplacementRoot(newObj, oldWeak, newWeak)
    }

/**
     * RS-A14
     * Scenario: local root is reassigned from old object to new object.
     * Expectation: old payload can be collected and new payload remains alive.
     */
    @Test
    fun rsA14_localRootReassignmentCollectsOldKeepsNew() {
        val scenario = createLocalRootReplacement()
        forceGc()
        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(10140, scenario.root.id)
    }

/**
     * RS-A15
     * Scenario: object is created inside a block and observed after the block ends.
     * Expectation: result is diagnostic only because stack slots may keep stale references.
     */
    @Test
    fun rsA15_localBlockEndIsDiagnosticOnly() {
        var weak: WeakReference<RootPayload>? = null
        run {
            val obj = RootPayload(1015)
            weak = WeakReference(obj)
            assertEquals(1015, obj.id)
        }
        forceGc()
        val observed = weak!!.value
        assertTrue(observed == null || observed.id == 1015)
    }

    private fun createWeakAfterHelperLocalRootGone(): WeakReference<RootPayload> {
        val obj = RootPayload(1016)
        return WeakReference(obj)
    }

/**
     * RS-A16
     * Scenario: helper creates payload and only WeakReference escapes.
     * Expectation: after helper returns, payload can be collected.
     */
    @Test
    fun rsA16_helperReturnRemovesLocalStackRoot() {
        val weak = createWeakAfterHelperLocalRootGone()
        assertWeakCollected(weak)
    }
}
