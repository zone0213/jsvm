@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * RS-D group: lazy, lateinit and initialization root tests.
 */
class InitializationRootTest : RootSetTestSupport() {
    /**
     * RS-D01
     * Scenario: local lazy payload is declared but not accessed.
     * Expectation: lazy initializer is not executed.
     */
    @Test
    fun rsD01_lazyNotAccessedDoesNotInitialize() {
        val holder = LocalLazyRootHolder()
        val lazyValue = holder::payload
        forceGc()
        assertEquals(0, holder.initCount)
        assertNotNull(lazyValue)
    }

/**
     * RS-D02
     * Scenario: local lazy payload is accessed.
     * Expectation: initialized payload remains alive through lazy holder.
     */
    @Test
    fun rsD02_lazyAccessInitializesAndKeepsPayloadAlive() {
        val holder = LocalLazyRootHolder()
        val obj = holder.payload
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(1, holder.initCount)
        assertEquals(4002, holder.payload.id)
        assertNotNull(weak.value)
    }

/**
     * RS-D03
     * Scenario: lazy payload has child graph.
     * Expectation: parent and child remain alive after lazy initialization.
     */
    @Test
    fun rsD03_lazyPayloadWithChildKeepsChildAlive() {
        val holder = LocalLazyRootHolder()
        val obj = holder.payloadWithChild
        val childWeak = WeakReference(obj.child!!)
        forceGc()
        assertEquals(4003, obj.id)
        assertEquals(40031, obj.child!!.id)
        assertNotNull(childWeak.value)
    }

/**
     * RS-D04
     * Scenario: lazy holder contains payload.
     * Expectation: holder and value remain alive after lazy initialization.
     */
    @Test
    fun rsD04_lazyHolderKeepsValueAlive() {
        val lazyHolder = LocalLazyRootHolder()
        val holder = lazyHolder.holder
        val weak = WeakReference(holder.ref!!)
        forceGc()
        assertEquals(4004, holder.ref!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-D05
     * Scenario: object singleton lazy payload is accessed.
     * Expectation: payload remains alive through object lazy root.
     */
    @Test
    fun rsD05_objectLazyRootKeepsPayloadAlive() {
        val obj = ObjectLazyRootHolder.payload
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(4005, ObjectLazyRootHolder.payload.id)
        assertNotNull(weak.value)
    }

/**
     * RS-D06
     * Scenario: companion object lazy payload is accessed.
     * Expectation: payload remains alive through companion lazy root.
     */
    @Test
    fun rsD06_companionLazyRootKeepsPayloadAlive() {
        val obj = CompanionLazyRootHolder.payload
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(4006, CompanionLazyRootHolder.payload.id)
        assertNotNull(weak.value)
    }

/**
     * RS-D07
     * Scenario: lateinit global payload is initialized.
     * Expectation: payload remains alive through lateinit global root.
     */
    @Test
    fun rsD07_lateinitInitializedRootKeepsPayloadAlive() {
        lateinitPayload = RootPayload(4007)
        val weak = WeakReference(lateinitPayload)
        forceGc()
        assertEquals(4007, lateinitPayload.id)
        assertNotNull(weak.value)
    }

    private fun reassignLateinitPayload(): ReplacementRoot<RootPayload, RootPayload> {
        lateinitPayload = RootPayload(4008)
        val oldWeak = WeakReference(lateinitPayload)
        lateinitPayload = RootPayload(40080)
        val newWeak = WeakReference(lateinitPayload)
        return ReplacementRoot(lateinitPayload, oldWeak, newWeak)
    }

/**
     * RS-D08
     * Scenario: lateinit global payload is reassigned.
     * Expectation: old payload can be collected and new payload remains alive.
     */
    @Test
    fun rsD08_lateinitReassignmentCollectsOldKeepsNew() {
        val scenario = reassignLateinitPayload()
        forceGc()
        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(40080, scenario.root.id)
    }

/**
     * RS-D09
     * Scenario: lateinit global holder references payload.
     * Expectation: payload remains alive through lateinit holder.
     */
    @Test
    fun rsD09_lateinitHolderRootKeepsValueAlive() {
        val obj = RootPayload(4009)
        lateinitHolder = RootHolder(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(4009, lateinitHolder.ref!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-D10
     * Scenario: lateinit global payload references a child graph.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsD10_lateinitChildGraphRootKeepsChildAlive() {
        val child = RootPayload(40101)
        lateinitPayload = RootPayload(4010, child)
        val childWeak = WeakReference(child)
        forceGc()
        assertEquals(4010, lateinitPayload.id)
        assertNotNull(childWeak.value)
    }

    private fun clearLateinitLikeNullableRoot(): WeakReference<RootPayload> {
        val obj = RootPayload(4011)
        clearableLateinitLikePayload = obj
        val weak = WeakReference(obj)
        clearableLateinitLikePayload = null
        return weak
    }

/**
     * RS-D11
     * Scenario: nullable global is used as a clearable lateinit-like root.
     * Expectation: payload can be collected after the root is cleared.
     */
    @Test
    fun rsD11_clearableLateinitLikeNullableRootAllowsCollection() {
        val weak = clearLateinitLikeNullableRoot()
        assertWeakCollected(weak)
    }

    private fun createWeakFromFailedInitialization(): WeakReference<RootPayload> {
        lateinit var weak: WeakReference<RootPayload>
        try {
            FailingInitializer { payload -> weak = WeakReference(payload) }
        } catch (_: IllegalStateException) {
            // Expected failure during initialization.
        }
        return weak
    }

/**
     * RS-D12
     * Scenario: initializer creates a payload and then throws.
     * Expectation: payload is not kept alive after failed initialization helper returns.
     */
    @Test
    fun rsD12_failedInitializationDoesNotKeepPayloadAlive() {
        val weak = createWeakFromFailedInitialization()
        assertWeakCollected(weak)
    }
}
