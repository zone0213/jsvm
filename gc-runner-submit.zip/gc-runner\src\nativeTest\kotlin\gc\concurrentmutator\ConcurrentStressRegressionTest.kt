@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-J group: stress loops and regression-stability tests.
 */
class ConcurrentStressRegressionTest : ConcurrentGcTestSupport() {

    /**
     * CG-J01
     * Scenario: high-frequency field replacement with continuous GC.
     * Expectation: no crash and final ref accessible.
     */
    @Test
    fun cgJ01_stressHighFrequencyFieldReplacement() {
        forceGc()
        val (holder, weak) = stressFieldReplacement(128)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

    /**
     * CG-J02
     * Scenario: high-frequency array replacement with GC.
     * Expectation: no crash.
     */
    @Test
    fun cgJ02_stressHighFrequencyArrayReplacement() {
        val array=arrayOfNulls<Node>(1)
        repeatMutationWithGc(128){ array[0]=Node(1200+it) }
        assertNotNull(array[0])
    }

    /**
     * CG-J03
     * Scenario: high-frequency list add/remove with GC.
     * Expectation: no crash.
     */
    @Test
    fun cgJ03_stressHighFrequencyListAddRemove() {
        val list=mutableListOf<Node>()
        repeatMutationWithGc(128){ list.add(Node(1300+it))
        if(list.size>4) list.removeAt(0) }
        list.forEach{assertTrue(it.id>=1300)}
    }

    /**
     * CG-J04
     * Scenario: high-frequency map put/remove with GC.
     * Expectation: no crash.
     */
    @Test
    fun cgJ04_stressHighFrequencyMapPutRemove() {
        val map=mutableMapOf<Int,Node>()
        repeatMutationWithGc(128){ map[it]=Node(1400+it)
        map.remove(it-4) }
        map.values.forEach{assertTrue(it.id>=1400)}
    }

    /**
     * CG-J05
     * Scenario: child is moved between parents repeatedly.
     * Expectation: child remains reachable at final parent.
     */
    @Test
    fun cgJ05_stressHighFrequencySubgraphMove() {
        val child=Node(1500)
        val weak=WeakReference(child)
        val p1=Node(1501)
        val p2=Node(1502)
        repeatMutationWithGc(64){ if(it%2==0){p1.left=child;p2.left=null}else{p2.left=child;p1.left=null} }
        assertNotNull(weak.value)
        assertTrue(p1.left===child || p2.left===child)
    }

    /**
     * CG-J06
     * Scenario: producer/consumer handoff is repeated.
     * Expectation: no crash.
     */
    @Test
    fun cgJ06_stressProducerConsumerHandoff() {
        val shared=Holder<Node>(null)
        repeatMutationWithGc(128){ shared.ref=Node(1600+it)
        shared.ref?.id }
        assertNotNull(shared.ref)
    }

    /**
     * CG-J07
     * Scenario: multiple writers/readers and GC complete.
     * Expectation: all bounded workers complete.
     */
    @Test
    fun cgJ07_stressManyWritersReadersGc() {
        val completed=runBoundedConcurrentWriters(4,32){w,i-> globalHolder.ref=Node(1700+w*100+i)
        globalHolder.ref?.id
        GC.collect() }
        assertEquals(4,completed)
    }

    /**
     * CG-J08
     * Scenario: allocation pressure plus replacement.
     * Expectation: no crash.
     */
    @Test
    fun cgJ08_stressAllocationPressureMutation() {
        val holder=Holder(Node(1800))
        repeatMutationWithGc(128){ holder.ref=Node(1800+it)
        allocateGarbage(8) }
        assertNotNull(holder.ref)
    }

    /**
     * CG-J09
     * Scenario: weak observers with strong add/delete cycles.
     * Expectation: final weak state is coherent.
     */
    @Test
    fun cgJ09_stressWeakObserversMutation() {
        val holder=Holder(Node(1900))
        val weak=WeakReference(holder.ref!!)
        repeatMutationWithGc(64){ if(it%2==0) holder.ref=Node(1900+it) }
        assertNotNull(holder.ref)
        forceGc()
        assertTrue(weak.value == null || weak.value!!.id >= 1900)
    }

    /**
     * CG-J10
     * Scenario: large chain attach/detach loops.
     * Expectation: no crash and final state correct.
     */
    @Test
    fun cgJ10_stressLargeChainAttachDetach() {
        val holder=Holder<Node>(null)
        repeatMutationWithGc(64){ holder.ref = if(it%2==0) buildChain(8,2000+it).first() else null }
        forceGc()
        holder.ref?.let{assertTrue(it.id>=2000)}
    }

    /**
     * CG-J11
     * Scenario: tree attach/detach loops.
     * Expectation: no crash.
     */
    @Test
    fun cgJ11_stressLargeTreeAttachDetach() {
        val holder=Holder<Node>(null)
        repeatMutationWithGc(64){ holder.ref = if(it%2==0) buildTree(2100+it).first() else null }
        holder.ref?.let{assertTrue(it.id>=2100)}
    }

    /**
     * CG-J12
     * Scenario: DAG shared parent edges are added/removed repeatedly.
     * Expectation: shared is not incorrectly collected while an edge remains.
     */
    @Test
    fun cgJ12_stressDagSharedParentEdges() {
        val g=buildSharedGraph(2200)
        val weak=WeakReference(g.shared)
        repeatMutationWithGc(64){ if(it%2==0) g.parent1.left=g.shared else g.parent1.left=null
        g.parent2.left=g.shared }
        assertNotNull(weak.value)
    }

    /**
     * CG-J13
     * Scenario: cycle graph attach/detach loops.
     * Expectation: no crash.
     */
    @Test
    fun cgJ13_stressCycleAttachDetach() {
        val cycle=buildCycle(2300)
        val holder=Holder<Node>(null)
        repeatMutationWithGc(64){ holder.ref = if(it%2==0) cycle.first() else null }
        forceGc()
        assertTrue(holder.ref == null || holder.ref!!.id == 2300)
    }

    /**
     * CG-J14
     * Scenario: busy mutator with allocation and GC completes.
     * Expectation: no deadlock.
     */
    @Test
    fun cgJ14_stressBusyMutatorAllocationGc() {
        val count=repeatMutationWithGc(128){ allocateGarbage(16) }
        assertEquals(128,count)
    }

    /**
     * CG-J15
     * Scenario: field, array, list and map writes are mixed under GC.
     * Expectation: no crash.
     */
    @Test
    fun cgJ15_stressMixedFieldArrayListMap() {
        val holder=Holder<Node>(null)
        val array=arrayOfNulls<Node>(1)
        val list=mutableListOf<Node>()
        val map=mutableMapOf<Int,Node>()
        repeatMutationWithGc(128){ val n=Node(2400+it)
        holder.ref=n
        array[0]=n
        list.add(n)
        map[it]=n
        if(list.size>8) list.clear()
        if(map.size>8) map.clear() }
        assertNotNull(holder.ref)
        assertNotNull(array[0])
    }

    /**
     * CG-J16
     * Scenario: minimal regression entry reserved for future fuzz crash reproducer.
     * Expectation: test executes a representative mutation and GC sequence.
     */
    @Test
    fun cgJ16_stressRegressionEntryForFuzzCrashReproducer() {
        forceGc()
        val (holder, weak) = stressFieldReplacement(32)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

}
