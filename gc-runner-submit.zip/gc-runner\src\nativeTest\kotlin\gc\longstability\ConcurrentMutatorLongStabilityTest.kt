@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * LS-H group: concurrent mutator/write-barrier style long-stability tests.
 */
class ConcurrentMutatorLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-H01
     * Scenario: field replace long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h01_fieldReplaceLongRun() {
        val holder = Holder(LsNode(0))
        containerSamples { holder.ref = LsNode(it) }
        assertNotNull(holder.ref)
    }

    /**
     * LS-H02
     * Scenario: array replace long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h02_arrayReplaceLongRun() {
        val array = arrayOfNulls<LsNode>(16)
        containerSamples { array[it % array.size] = LsNode(it) }
        assertTrue(array.any { it != null })
    }

    /**
     * LS-H03
     * Scenario: list add/remove with GC long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h03_listAddRemoveWithGcLongRun() {
        val list = mutableListOf<LsNode>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                list.add(LsNode(i))
                if (list.size > 16) {
                    list.removeAt(0)
                }
            }
        )
    }

    /**
     * LS-H04
     * Scenario: map put/remove with GC long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h04_mapPutRemoveWithGcLongRun() {
        val map = mutableMapOf<Int, LsNode>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                map[i] = LsNode(i)
                map.remove(i - 16)
            }
        )
    }

    /**
     * LS-H05
     * Scenario: subgraph move long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h05_subgraphMoveLongRun() {
        val child = LsNode(5)
        val p1 = LsNode(1)
        val p2 = LsNode(2)
        containerSamples { i ->
            if (i % 2 == 0) {
                p1.child = child
                p2.child = null
            } else {
                p2.child = child
                p1.child = null
            }
        }
        assertTrue(p1.child === child || p2.child === child)
    }

    /**
     * LS-H06
     * Scenario: DAG parent edge churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h06_dagParentEdgeChurn() {
        val shared = LsNode(6)
        val p1 = LsNode(1, shared)
        val p2 = LsNode(2, shared)
        containerSamples { i ->
            p1.child = if (i % 2 == 0) shared else null
            p2.child = shared
        }
        assertEquals(6, p2.child!!.id)
    }

    /**
     * LS-H07
     * Scenario: cycle attach/detach long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h07_cycleAttachDetachLongRun() {
        val a = LsNode(7)
        val b = LsNode(8)
        a.child = b
        b.child = a
        val holder = Holder<LsNode>(null)
        containerSamples { i ->
            holder.ref = if (i % 2 == 0) a else null
        }
        assertTrue(holder.ref == null || holder.ref === a)
    }

    /**
     * LS-H08
     * Scenario: multi-writer same field.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h08_multiWriterSameField() {
        val completed = runPseudoWorkers { worker, i ->
            globalHolder.ref = LsNode(worker * 1000 + i)
        }
        assertEquals(WORKER_COUNT, completed)
        assertNotNull(globalHolder.ref)
    }

    /**
     * LS-H09
     * Scenario: writer-reader handoff long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h09_writerReaderHandoffLongRun() {
        val holder = Holder<LsNode>(null)
        containerSamples { i ->
            holder.ref = LsNode(i)
            holder.ref?.id
        }
        assertNotNull(holder.ref)
    }

    /**
     * LS-H10
     * Scenario: weak observer mutation long-run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_h10_weakObserverMutationLongRun() {
        val holder = Holder(LsNode(10))
        val firstWeak = WeakReference(holder.ref!!)
        containerSamples { i ->
            holder.ref = if (i % 2 == 0) LsNode(i) else holder.ref
        }
        forceGc()
        assertTrue(firstWeak.value == null || firstWeak.value!!.id == 10)
    }

}
