
package gc.sweepallocator

import kotlin.native.runtime.GC
import kotlin.native.ref.WeakReference
import kotlin.test.assertTrue

open class SweepAllocatorTestSupport {
    protected fun forceGc() {
        repeat(3) { GC.collect() }
    }

    protected fun weakCheck(obj: Any?): WeakReference<Any>? {
        return obj?.let { WeakReference(it) }
    }
}
