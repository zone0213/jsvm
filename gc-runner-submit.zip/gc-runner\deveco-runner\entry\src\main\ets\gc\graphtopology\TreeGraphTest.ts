﻿import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/** GT-C group: tree graph tests. */
export class TreeGraphTest extends GraphTopologyTestSupport {

    private binaryTreeRoot(levels: number, startId: number): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildFullBinaryTree(levels, startId);
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-C01: a one-level binary branching keeps both children alive. */
    gtC01_binaryTreeDepthOneKeepsBothChildrenAlive() {
        const scenario = this.binaryTreeRoot(2, 6000);
        this.forceGc();
        assertEquals(6001, scenario.root.ref!.left!.id);
        assertEquals(6002, scenario.root.ref!.right!.id);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-C02: a 7-node full binary tree keeps internal nodes and leaves alive. */
    gtC02_binaryTreeDepthTwoKeepsWholeTreeAlive() {
        const scenario = this.binaryTreeRoot(3, 6100);
        this.forceGc();
        assertEquals(6106, scenario.weaks.last().value!.id);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-C03: a 31-node binary tree keeps representative nodes alive. */
    gtC03_binaryTreeDepthFiveKeepsRepresentativeNodesAlive() {
        const scenario = this.binaryTreeRoot(5, 6200);
        this.forceGc();
        assertEquals(6200, scenario.root.ref!.id);
        assertEquals(6214, scenario.weaks[14].value!.id);
        assertEquals(6230, scenario.weaks[30].value!.id);
    }

    private binaryTreeAfterLeftClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildFullBinaryTree(3, 6300);
        const root = new GraphRoot(nodes.first());
        const left = [nodes[1], nodes[3], nodes[4]];
        const right = [nodes[2], nodes[5], nodes[6]];
        root.ref!.left = null;
        return new MixedWeaks(root, this.weakRefs([nodes[0], ...right]), this.weakRefs(left));
    }

    /** GT-C04: clearing left subtree collects left subtree and keeps right subtree alive. */
    gtC04_clearingLeftSubtreeCollectsLeftAndKeepsRightAlive() {
        const scenario = this.binaryTreeAfterLeftClear();
        this.forceGc();
        assertNull(scenario.root.ref!.left);
        assertEquals(6302, scenario.root.ref!.right!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private binaryTreeAfterRightClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildFullBinaryTree(3, 6400);
        const root = new GraphRoot(nodes.first());
        const left = [nodes[1], nodes[3], nodes[4]];
        const right = [nodes[2], nodes[5], nodes[6]];
        root.ref!.right = null;
        return new MixedWeaks(root, this.weakRefs([nodes[0], ...left]), this.weakRefs(right));
    }

    /** GT-C05: clearing right subtree collects right subtree and keeps left subtree alive. */
    gtC05_clearingRightSubtreeCollectsRightAndKeepsLeftAlive() {
        const scenario = this.binaryTreeAfterRightClear();
        this.forceGc();
        assertNull(scenario.root.ref!.right);
        assertEquals(6401, scenario.root.ref!.left!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private binaryTreeAfterMiddleSubtreeClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildFullBinaryTree(4, 6500);
        const root = new GraphRoot(nodes.first());
        const disconnected = [nodes[3], nodes[7], nodes[8]];
        const alive = nodes.filter(it => !disconnected.includes(it));
        nodes[1].left = null;
        return new MixedWeaks(root, this.weakRefs(alive), this.weakRefs(disconnected));
    }

    /** GT-C06: clearing an internal subtree edge collects only that disconnected subtree. */
    gtC06_clearingMiddleSubtreeCollectsOnlyDisconnectedSubtree() {
        const scenario = this.binaryTreeAfterMiddleSubtreeClear();
        this.forceGc();
        assertNull(scenario.root.ref!.left!.left);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private binaryTreeAfterLeafClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildFullBinaryTree(3, 6600);
        const root = new GraphRoot(nodes.first());
        const leaf = nodes[3];
        const alive = nodes.filter(it => it !== leaf);
        nodes[1].left = null;
        return new MixedWeaks(root, this.weakRefs(alive), this.weakRefs([leaf]));
    }

    /** GT-C07: clearing a leaf edge collects only the leaf. */
    gtC07_clearingLeafCollectsOnlyLeaf() {
        const scenario = this.binaryTreeAfterLeafClear();
        this.forceGc();
        assertNull(scenario.root.ref!.left!.left);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private unbalancedTreeRoot(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const rootNode = new GraphNode(6700);
        const leftChain = this.buildGraphNodeChain(5, 6710);
        const rightLeaf = new GraphNode(6799);
        rootNode.left = leftChain.first();
        rootNode.right = rightLeaf;
        return new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, ...leftChain, rightLeaf]));
    }

    /** GT-C08: an unbalanced tree keeps both deep and shallow branches alive. */
    gtC08_unbalancedTreeKeepsDeepAndShallowBranchesAlive() {
        const scenario = this.unbalancedTreeRoot();
        this.forceGc();
        assertEquals(6714, scenario.root.ref!.left!.next!.next!.next!.next!.id);
        assertEquals(6799, scenario.root.ref!.right!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private unbalancedTreeAfterDeepBranchClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const rootNode = new GraphNode(6800);
        const leftChain = this.buildGraphNodeChain(5, 6810);
        const rightLeaf = new GraphNode(6899);
        rootNode.left = leftChain.first();
        rootNode.right = rightLeaf;
        const root = new GraphRoot(rootNode);
        rootNode.left = null;
        return new MixedWeaks(root, this.weakRefs([rootNode, rightLeaf]), this.weakRefs(leftChain));
    }

    /** GT-C09: clearing the deep branch collects it and keeps the shallow branch alive. */
    gtC09_clearingDeepBranchCollectsThatBranchOnly() {
        const scenario = this.unbalancedTreeAfterDeepBranchClear();
        this.forceGc();
        assertNull(scenario.root.ref!.left);
        assertEquals(6899, scenario.root.ref!.right!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private multiTreeRoot(levels: number, branching: number, startId: number): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildMultiTree(levels, branching, startId);
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-C10: a small multi-way tree keeps all direct children alive. */
    gtC10_smallMultiWayTreeKeepsAllChildrenAlive() {
        const scenario = this.multiTreeRoot(2, 3, 6900);
        this.forceGc();
        assertEquals(3, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-C11: a wide multi-way tree keeps representative children alive. */
    gtC11_wideMultiWayTreeKeepsRepresentativeChildrenAlive() {
        const scenario = this.multiTreeRoot(2, 100, 7000);
        this.forceGc();
        assertEquals(7001, scenario.root.ref!.children[0].id);
        assertEquals(7051, scenario.root.ref!.children[50].id);
        assertEquals(7100, scenario.root.ref!.children[99].id);
        this.assertAllAlive(scenario.weaks);
    }

    private multiTreeAfterRemoveChild(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const rootNode = new MultiNode(7200);
        const removed = new MultiNode(7201);
        const grandChild = new MultiNode(7202);
        const remaining = new MultiNode(7203);
        removed.children.add(grandChild);
        rootNode.children.add(removed);
        rootNode.children.add(remaining);
        rootNode.children.remove(removed);
        return new MixedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, remaining]), this.weakRefs([removed, grandChild]));
    }

    /** GT-C12: removing one child from a multi-way tree collects the removed subtree only. */
    gtC12_removingMultiTreeChildCollectsRemovedSubtreeOnly() {
        const scenario = this.multiTreeAfterRemoveChild();
        this.forceGc();
        assertEquals(1, scenario.root.ref!.children.size);
        assertEquals(7203, scenario.root.ref!.children.first().id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private multiTreeAfterClearChildren(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.buildMultiTree(2, 3, 7300);
        const root = new GraphRoot(nodes.first());
        root.ref!.children.clear();
        return new MixedWeaks(root, this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-C13: clearing all children collects child subtrees and keeps root alive. */
    gtC13_clearingMultiTreeChildrenCollectsAllChildren() {
        const scenario = this.multiTreeAfterClearChildren();
        this.forceGc();
        assertEquals(0, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    /** GT-C14: a nested multi-way tree keeps grandchildren alive. */
    gtC14_nestedMultiWayTreeKeepsGrandChildrenAlive() {
        const scenario = this.multiTreeRoot(3, 2, 7400);
        this.forceGc();
        assertEquals(7401, scenario.root.ref!.children[0].id);
        assertEquals(7403, scenario.root.ref!.children[0].children[0].id);
        this.assertAllAlive(scenario.weaks);
    }
}
