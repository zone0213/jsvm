import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class ConcurrentMutatorLongStabilityTest extends LongStabilityTestSupport {

    ls_h01_fieldReplaceLongRun() {
        const holder = new Holder(new LsNode(0));
        this.containerSamples(it => { holder.ref = new LsNode(it); });
        assertNotNull(holder.ref);
    }

    ls_h02_arrayReplaceLongRun() {
        const array = new Array<LsNode | null>(16).fill(null);
        this.containerSamples(it => { array[it % array.length] = new LsNode(it); });
        assertTrue(array.some(it => it !== null));
    }

    ls_h03_listAddRemoveWithGcLongRun() {
        const list: LsNode[] = [];
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { list.push(new LsNode(i)); if (list.length > 16) list.shift(); }));
    }

    ls_h04_mapPutRemoveWithGcLongRun() {
        const map = new Map<number, LsNode>();
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { map.set(i, new LsNode(i)); map.delete(i - 16); }));
    }

    ls_h05_subgraphMoveLongRun() {
        const child = new LsNode(5);
        const p1 = new LsNode(1);
        const p2 = new LsNode(2);
        this.containerSamples(i => { if (i % 2 === 0) { p1.child = child; p2.child = null; } else { p2.child = child; p1.child = null; } });
        assertTrue(p1.child === child || p2.child === child);
    }

    ls_h06_dagParentEdgeChurn() {
        const shared = new LsNode(6);
        const p1 = new LsNode(1, shared);
        const p2 = new LsNode(2, shared);
        this.containerSamples(i => { p1.child = i % 2 === 0 ? shared : null; p2.child = shared; });
        assertEquals(6, p2.child!.id);
    }

    ls_h07_cycleAttachDetachLongRun() {
        const a = new LsNode(7);
        const b = new LsNode(8);
        a.child = b; b.child = a;
        const holder = new Holder<LsNode>(null);
        this.containerSamples(i => { holder.ref = i % 2 === 0 ? a : null; });
        assertTrue(holder.ref === null || holder.ref === a);
    }

    ls_h08_multiWriterSameField() {
        const completed = this.runPseudoWorkers((worker, i) => { globalHolder.ref = new LsNode(worker * 1000 + i); });
        assertEquals(WORKER_COUNT, completed);
        assertNotNull(globalHolder.ref);
    }

    ls_h09_writerReaderHandoffLongRun() {
        const holder = new Holder<LsNode>(null);
        this.containerSamples(i => { holder.ref = new LsNode(i); holder.ref?.id; });
        assertNotNull(holder.ref);
    }

    ls_h10_weakObserverMutationLongRun() {
        const holder = new Holder(new LsNode(10));
        const firstWeak = new WeakReference(holder.ref!);
        this.containerSamples(i => { holder.ref = i % 2 === 0 ? new LsNode(i) : holder.ref; });
        this.forceGc();
        assertTrue(firstWeak.value === null || firstWeak.value.id === 10);
    }
}
