@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-A group: basic strong-reference and WeakReference semantics.
 */
class StrongWeakBasicTest : WeakReferenceTestSupport() {

    /**
     * WR-A01
     * Scenario: a local strong reference and a local WeakReference point to the same object.
     * Expectation: while the local strong reference is still used after GC, weak.value remains non-null.
     */
    @Test
    fun wrA01_localStrongKeepsWeakTargetAlive() {
        val obj = Payload(101)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(101, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * WR-A02
     * Scenario: a holder field strongly references an object.
     * Expectation: the object remains alive through holder.ref.
     */
    @Test
    fun wrA02_holderStrongKeepsWeakTargetAlive() {
        val obj = Payload(102)
        val holder = StrongHolder(obj)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(102, holder.ref!!.id)
        assertNotNull(weak.value)
    }

    private fun setGlobalStrongAndWeak(): WeakReference<Payload> {
        val obj = Payload(103)
        globalPayload = obj
        return WeakReference(obj)
    }

    /**
     * WR-A03
     * Scenario: a global variable strongly references an object.
     * Expectation: the object remains alive through the global root.
     */
    @Test
    fun wrA03_globalStrongKeepsWeakTargetAlive() {
        val weak = setGlobalStrongAndWeak()

        forceGc()

        assertEquals(103, globalPayload!!.id)
        assertNotNull(weak.value)
    }

    /**
     * WR-A04
     * Scenario: a collection strongly references an object.
     * Expectation: the object remains alive through the collection element.
     */
    @Test
    fun wrA04_collectionStrongKeepsWeakTargetAlive() {
        val obj = Payload(104)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(104, list.single().id)
        assertNotNull(weak.value)
    }

    /**
     * WR-A05
     * Scenario: an array slot strongly references an object.
     * Expectation: the object remains alive through the array element.
     */
    @Test
    fun wrA05_arrayStrongKeepsWeakTargetAlive() {
        val obj = Payload(105)
        val array = arrayOfNulls<Payload>(1)
        array[0] = obj
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(105, array[0]!!.id)
        assertNotNull(weak.value)
    }

    /**
     * WR-A06
     * Scenario: a lambda strongly captures an object.
     * Expectation: the captured object remains alive through the lambda object.
     */
    @Test
    fun wrA06_lambdaStrongCaptureKeepsWeakTargetAlive() {
        val obj = Payload(106)
        val weak = WeakReference(obj)
        val block = { obj.id }

        forceGc()

        assertEquals(106, block())
        assertNotNull(weak.value)
    }

    /**
     * WR-A07
     * Scenario: local strong reference and local WeakReference coexist.
     * Expectation: the strong reference determines liveness; weak.value remains non-null.
     */
    @Test
    fun wrA07_localStrongAndWeakCoexistKeepsTargetAlive() {
        val obj = Payload(107)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(107, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * WR-A08
     * Scenario: a holder has both strong and weak fields pointing to the same object.
     * Expectation: the strong field keeps the object alive and the weak field remains non-null.
     */
    @Test
    fun wrA08_holderStrongAndWeakCoexistKeepsTargetAlive() {
        val obj = Payload(108)
        val holder = MixedHolder(obj, WeakReference(obj))

        forceGc()

        assertEquals(108, holder.strong!!.id)
        assertNotNull(holder.weak!!.value)
    }

    /**
     * WR-A09
     * Scenario: a list strongly holds an object and another list holds a weak reference to it.
     * Expectation: the strong list keeps the object alive.
     */
    @Test
    fun wrA09_collectionStrongAndWeakCoexistKeepsTargetAlive() {
        val obj = Payload(109)
        val strongList = mutableListOf(obj)
        val weakList = mutableListOf(WeakReference(obj))

        forceGc()

        assertEquals(109, strongList.single().id)
        assertNotNull(weakList.single().value)
    }

    /**
     * WR-A10
     * Scenario: local, holder and list strong references coexist with a weak reference.
     * Expectation: as long as at least one strong reference remains, weak.value remains non-null.
     */
    @Test
    fun wrA10_multipleStrongReferencesAndWeakKeepsTargetAlive() {
        val obj = Payload(110)
        val holder = StrongHolder(obj)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(110, obj.id)
        assertEquals(110, holder.ref!!.id)
        assertEquals(110, list.single().id)
        assertNotNull(weak.value)
    }
}
