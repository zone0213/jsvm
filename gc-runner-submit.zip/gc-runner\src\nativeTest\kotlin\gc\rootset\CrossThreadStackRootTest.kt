@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class,
)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * RS-F group: other-thread stack root tests.
 *
 * These tests use Kotlin/Native Worker tasks as deterministic cross-thread execution points.
 */
class CrossThreadStackRootTest : RootSetTestSupport() {
    /**
     * RS-F01
     * Scenario: worker creates a local stack payload and triggers GC.
     * Expectation: worker local stack root keeps payload alive.
     */
    @Test
    fun rsF01_workerLocalStackRootKeepsPayloadAlive() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(6001)
                val weak = WeakReference(obj)
                GC.collect()
                obj.id == 6001 && weak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-F02
     * Scenario: worker holds a local stack payload during its own GC checkpoint.
     * Expectation: payload is observed alive on worker stack.
     */
    @Test
    fun rsF02_mainTriggeredGcScenarioWithWorkerStackRoot() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(6002)
                val weak = WeakReference(obj)
                GC.collect()
                obj.id == 6002 && weak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-F03
     * Scenario: main thread holds a local payload while worker triggers GC.
     * Expectation: main stack root remains alive after worker task completes.
     */
    @Test
    fun rsF03_workerTriggeredGcMainStackRootKeepsPayloadAlive() {
        val obj = RootPayload(6003)
        val weak = WeakReference(obj)
        val result =
            runWorkerBoolean {
                GC.collect()
                true
            }
        forceGc()
        assertTrue(result)
        assertEquals(6003, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-F04
     * Scenario: worker function receives payload as parameter within worker task.
     * Expectation: parameter remains alive during GC.
     */
    @Test
    fun rsF04_workerFunctionParameterRootKeepsPayloadAlive() {
        val result =
            runWorkerBoolean {
                fun check(obj: RootPayload): Boolean {
                    val weak = WeakReference(obj)
                    GC.collect()
                    return obj.id == 6004 && weak.value != null
                }
                check(RootPayload(6004))
            }
        assertTrue(result)
    }

/**
     * RS-F05
     * Scenario: worker lambda captures a payload.
     * Expectation: captured payload remains alive during GC.
     */
    @Test
    fun rsF05_workerLambdaCaptureRootKeepsPayloadAlive() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(6005)
                val weak = WeakReference(obj)
                val block = { obj.id }
                GC.collect()
                block() == 6005 && weak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-F06
     * Scenario: worker stack holds a holder referencing payload.
     * Expectation: payload remains alive through holder.
     */
    @Test
    fun rsF06_workerHolderRootKeepsPayloadAlive() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(6006)
                val holder = RootHolder(obj)
                val weak = WeakReference(obj)
                GC.collect()
                holder.ref!!.id == 6006 && weak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-F07
     * Scenario: worker stack root references a child graph.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsF07_workerChildGraphRootKeepsChildAlive() {
        val result =
            runWorkerBoolean {
                val child = RootPayload(60071)
                val obj = RootPayload(6007, child)
                val childWeak = WeakReference(child)
                GC.collect()
                obj.child!!.id == 60071 && childWeak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-F08
     * Scenario: multiple worker tasks each hold a local stack payload.
     * Expectation: each worker observes its payload alive.
     */
    @Test
    fun rsF08_multipleWorkerStackRootsKeepPayloadsAlive() {
        val results =
            List(3) { index ->
                runWorkerBoolean {
                    val obj = RootPayload(60080 + index)
                    val weak = WeakReference(obj)
                    GC.collect()
                    weak.value != null && obj.id == 60080 + index
                }
            }
        assertTrue(results.all { it })
    }

/**
     * RS-F09
     * Scenario: worker creates a local payload and exits.
     * Expectation: test verifies worker completion and then performs GC.
     */
    @Test
    fun rsF09_workerExitRemovesStackRoot() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(6009)
                val weak = WeakReference(obj)
                GC.collect()
                obj.id == 6009 && weak.value != null
            }
        assertTrue(result)
        forceGc()
    }

/**
     * RS-F10
     * Scenario: worker clears local nullable root before GC.
     * Expectation: weak target is cleared inside worker.
     */
    @Test
    fun rsF10_workerRootSetNullWhileRunningAllowsCollection() {
        val result =
            runWorkerBoolean {
                var obj: RootPayload? = RootPayload(6010)
                val weak = WeakReference(obj!!)
                obj = null
                GC.collect()
                obj == null && weak.value == null
            }
        assertTrue(result)
    }

/**
     * RS-F11
     * Scenario: worker reassigns local root from old to new.
     * Expectation: old object clears and new object remains alive.
     */
    @Test
    fun rsF11_workerRootReassignmentCollectsOldKeepsNew() {
        val result =
            runWorkerBoolean {
                var obj: RootPayload? = RootPayload(6011)
                val oldWeak = WeakReference(obj!!)
                obj = RootPayload(60110)
                val newWeak = WeakReference(obj!!)
                GC.collect()
                oldWeak.value == null && newWeak.value != null && obj!!.id == 60110
            }
        assertTrue(result)
    }

/**
     * RS-F12
     * Scenario: worker passes temporary payload as call argument.
     * Expectation: callee observes temporary argument alive during GC.
     */
    @Test
    fun rsF12_workerTemporaryCallArgumentRootKeepsObjectAliveInCallee() {
        val result =
            runWorkerBoolean {
                fun consume(obj: RootPayload): Boolean {
                    val weak = WeakReference(obj)
                    GC.collect()
                    return obj.id == 6012 && weak.value != null
                }
                consume(RootPayload(6012))
            }
        assertTrue(result)
    }
}
