@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * RS-B group: function parameter, return value and temporary root tests.
 */
class FunctionRootTest : RootSetTestSupport() {
    private fun checkConcreteParameter(obj: RootPayload): WeakReference<RootPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    private fun checkNullableParameter(obj: RootPayload?): WeakReference<RootPayload> {
        val payload = obj!!
        val weak = WeakReference(payload)
        forceGc()
        assertEquals(payload.id, weak.value!!.id)
        return weak
    }

    private fun checkAnyParameter(obj: Any): WeakReference<Any> {
        val weak = WeakReference(obj)
        forceGc()
        assertNotNull(weak.value)
        return weak
    }

    private fun checkInterfaceParameter(obj: RootMarker): WeakReference<RootMarker> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    private fun <T : Any> checkGenericParameter(box: RootBox<T>): WeakReference<RootBox<T>> {
        val weak = WeakReference(box)
        forceGc()
        assertNotNull(box.value)
        assertNotNull(weak.value)
        return weak
    }

    private inline fun inlineCheckParameter(obj: RootPayload): WeakReference<RootPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    private fun createPayload(id: Int): RootPayload = RootPayload(id)

/**
     * RS-B01
     * Scenario: function parameter has concrete RootPayload type.
     * Expectation: callee stack parameter keeps object alive during GC.
     */
    @Test
    fun rsB01_concreteFunctionParameterRootKeepsObjectAlive() {
        val obj = RootPayload(2001)
        val weak = checkConcreteParameter(obj)
        assertEquals(2001, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B02
     * Scenario: function parameter has nullable RootPayload? type.
     * Expectation: non-null parameter keeps object alive during GC.
     */
    @Test
    fun rsB02_nullableFunctionParameterRootKeepsObjectAlive() {
        val obj: RootPayload? = RootPayload(2002)
        val weak = checkNullableParameter(obj)
        assertEquals(2002, obj!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B03
     * Scenario: function parameter has static type Any.
     * Expectation: runtime payload remains alive during GC.
     */
    @Test
    fun rsB03_anyFunctionParameterRootKeepsRuntimeObjectAlive() {
        val obj: Any = RootPayload(2003)
        val weak = checkAnyParameter(obj)
        assertEquals(2003, (obj as RootPayload).id)
        assertNotNull(weak.value)
    }

/**
     * RS-B04
     * Scenario: function parameter has static type RootMarker.
     * Expectation: runtime payload remains alive during GC.
     */
    @Test
    fun rsB04_interfaceFunctionParameterRootKeepsRuntimeObjectAlive() {
        val obj: RootMarker = RootPayload(2004)
        val weak = checkInterfaceParameter(obj)
        assertEquals(2004, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B05
     * Scenario: generic function parameter is RootBox<RootPayload>.
     * Expectation: box and value remain alive during GC.
     */
    @Test
    fun rsB05_genericFunctionParameterRootKeepsBoxValueAlive() {
        val obj = RootPayload(2005)
        val box = RootBox(obj)
        val weak = checkGenericParameter(box)
        assertEquals(2005, box.value!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B06
     * Scenario: function parameter points to a payload with child graph.
     * Expectation: parameter keeps parent and child alive.
     */
    @Test
    fun rsB06_parameterWithChildGraphKeepsChildAlive() {
        val child = RootPayload(20061)
        val obj = RootPayload(2006, child)
        val childWeak = WeakReference(child)
        val weak = checkConcreteParameter(obj)
        assertNotNull(weak.value)
        assertNotNull(childWeak.value)
        assertEquals(20061, obj.child!!.id)
    }

/**
     * RS-B07
     * Scenario: function receives a lambda that captures a payload.
     * Expectation: captured payload remains alive while lambda parameter is used.
     */
    @Test
    fun rsB07_lambdaParameterCaptureRootKeepsObjectAlive() {
        val obj = RootPayload(2007)
        val weak = WeakReference(obj)

        fun consume(block: () -> Int) {
            forceGc()
            assertEquals(2007, block())
        }
        consume { obj.id }
        assertNotNull(weak.value)
    }

/**
     * RS-B08
     * Scenario: inline function parameter holds a payload.
     * Expectation: payload remains alive inside inline function during GC.
     */
    @Test
    fun rsB08_inlineFunctionParameterRootKeepsObjectAlive() {
        val obj = RootPayload(2008)
        val weak = inlineCheckParameter(obj)
        assertEquals(2008, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B09
     * Scenario: function return value is stored by caller.
     * Expectation: returned object remains alive through caller local root.
     */
    @Test
    fun rsB09_returnValueStoredByCallerKeepsObjectAlive() {
        val obj = createPayload(2009)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(2009, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-B10
     * Scenario: function return value is stored as Any.
     * Expectation: runtime object remains alive.
     */
    @Test
    fun rsB10_returnValueStoredAsAnyKeepsObjectAlive() {
        val obj: Any = createPayload(2010)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(2010, (obj as RootPayload).id)
        assertNotNull(weak.value)
    }

/**
     * RS-B11
     * Scenario: function return value is stored as interface RootMarker.
     * Expectation: runtime object remains alive.
     */
    @Test
    fun rsB11_returnValueStoredAsInterfaceKeepsObjectAlive() {
        val obj: RootMarker = createPayload(2011)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(2011, obj.id)
        assertNotNull(weak.value)
    }

    private fun createReturnValueWeakOnly(): WeakReference<RootPayload> {
        val obj = createPayload(2012)
        return WeakReference(obj)
    }

/**
     * RS-B12
     * Scenario: created object is not saved by caller and only WeakReference escapes.
     * Expectation: object can be collected after helper returns.
     */
    @Test
    fun rsB12_returnValueNotSavedCanBeCollected() {
        val weak = createReturnValueWeakOnly()
        assertWeakCollected(weak)
    }

/**
     * RS-B13
     * Scenario: constructor expression is passed as function call argument.
     * Expectation: temporary call argument remains alive during callee GC.
     */
    @Test
    fun rsB13_callArgumentTemporaryRootKeepsObjectAliveInCallee() {
        fun consume(obj: RootPayload): Int {
            val weak = WeakReference(obj)
            forceGc()
            assertNotNull(weak.value)
            return obj.id
        }
        assertEquals(2013, consume(RootPayload(2013)))
    }

/**
     * RS-B14
     * Scenario: temporary Holder(Payload()) is passed as function argument.
     * Expectation: temporary holder and value remain alive during callee GC.
     */
    @Test
    fun rsB14_temporaryHolderArgumentKeepsValueAliveInCallee() {
        fun consume(holder: RootHolder<RootPayload>): Int {
            val weak = WeakReference(holder.ref!!)
            forceGc()
            assertNotNull(weak.value)
            return holder.ref!!.id
        }
        assertEquals(2014, consume(RootHolder(RootPayload(2014))))
    }

    private fun createTemporaryReturnWeakOnly(): WeakReference<RootPayload> {
        val weak = WeakReference(createPayload(2015))
        return weak
    }

/**
     * RS-B15
     * Scenario: created return object is observed only by WeakReference.
     * Expectation: object can be collected after helper returns.
     */
    @Test
    fun rsB15_temporaryReturnedObjectNotSavedCanBeCollected() {
        val weak = createTemporaryReturnWeakOnly()
        assertWeakCollected(weak)
    }

    private fun recursiveParameterCheck(
        depth: Int,
        obj: RootPayload,
        weak: WeakReference<RootPayload>,
    ): Int =
        if (depth == 0) {
            forceGc()
            assertNotNull(weak.value)
            obj.id
        } else {
            recursiveParameterCheck(depth - 1, obj, weak)
        }

/**
     * RS-B16
     * Scenario: recursive calls carry payload as parameter.
     * Expectation: payload remains alive on recursive stack.
     */
    @Test
    fun rsB16_recursiveParameterStackRootKeepsObjectAlive() {
        val obj = RootPayload(2016)
        val weak = WeakReference(obj)
        assertEquals(2016, recursiveParameterCheck(16, obj, weak))
        assertNotNull(weak.value)
    }

/**
     * RS-B17
     * Scenario: catch parameter contains payload in custom exception.
     * Expectation: payload remains alive while catch parameter is in scope.
     */
    @Test
    fun rsB17_exceptionCatchParameterRootKeepsPayloadAlive() {
        val payload = RootPayload(2017)
        val weak = WeakReference(payload)
        try {
            throw PayloadException(payload)
        } catch (e: PayloadException) {
            forceGc()
            assertEquals(2017, e.payload.id)
            assertNotNull(weak.value)
        }
    }

    private fun createWeakAfterFinallyClearsRoot(): WeakReference<RootPayload> {
        var obj: RootPayload? = RootPayload(2018)
        val weak = WeakReference(obj!!)
        try {
            assertEquals(2018, obj!!.id)
        } finally {
            obj = null
        }
        assertNull(obj)
        return weak
    }

/**
     * RS-B18
     * Scenario: finally block clears the last local stack root.
     * Expectation: object can be collected after helper returns.
     */
    @Test
    fun rsB18_finallyClearsStackRootAllowsCollection() {
        val weak = createWeakAfterFinallyClearsRoot()
        assertWeakCollected(weak)
    }
}
