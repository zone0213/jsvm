@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test

/**
 * Minimal reproduction extracted from LS-J06.
 *
 * It keeps only the exception-path allocation pattern:
 * - create a batch of objects,
 * - publish only WeakReference handles,
 * - throw/catch on every iteration,
 * - then require all weak targets to clear after GC.
 */
class CoroutineExceptionWeakClearSmokeTest : WeakReferenceTestSupport() {

    private fun createWeaksAfterExceptionBatch(count: Int = 32): List<WeakReference<Payload>> {
        val weaks = mutableListOf<WeakReference<Payload>>()

        repeat(count) { index ->
            val payload = Payload(6000 + index)
            weaks.add(WeakReference(payload))

            try {
                error("cancel-$index")
            } catch (_: Throwable) {
            }
        }

        return weaks
    }

    /**
     * Scenario: each short-lived object is created on an exception path and only a WeakReference escapes.
     * Expectation: all weak targets are cleared after repeated GC.
     */
    @Test
    fun weakTargetsCreatedOnExceptionPathAreCleared() {
        val weaks = createWeaksAfterExceptionBatch()

        assertAllWeakCollected(weaks)
    }
}
