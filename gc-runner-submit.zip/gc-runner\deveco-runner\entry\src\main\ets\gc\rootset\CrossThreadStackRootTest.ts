﻿import { RootSetTestSupport, RootPayload, RootHolder } from './RootSetTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals } from '../TestAssertions';

export class CrossThreadStackRootTest extends RootSetTestSupport {

    rsF01_workerLocalStackRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF02_mainTriggeredGcScenarioWithWorkerStackRoot() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF03_workerTriggeredGcMainStackRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF04_workerFunctionParameterRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    check() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF05_workerLambdaCaptureRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF06_workerHolderRootKeepsPayloadAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF07_workerChildGraphRootKeepsChildAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF08_multipleWorkerStackRootsKeepPayloadsAlive() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF09_workerExitRemovesStackRoot() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF10_workerRootSetNullWhileRunningAllowsCollection() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF11_workerRootReassignmentCollectsOldKeepsNew() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    rsF12_workerTemporaryCallArgumentRootKeepsObjectAliveInCallee() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }

    consume() {
        const payload = new RootPayload(1000);
        const holder = new RootHolder(payload);
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, holder.ref!.id);
        this.assertWeakAlive(weak);    }
}

