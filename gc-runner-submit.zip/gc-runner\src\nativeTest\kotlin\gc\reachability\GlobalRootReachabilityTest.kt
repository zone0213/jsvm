@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * C group: top-level global, object singleton, and companion-object roots.
 */
class GlobalRootReachabilityTest : ReachabilityTestSupport() {

    private fun setGlobalPayloadAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(201)
        globalPayload = obj
        return WeakReference(obj)
    }

    /**
     * RC-C01
     * Scenario: a top-level global variable strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    @Test
    fun rcC01_topLevelGlobalKeepsObjectAlive() {
        val weak = setGlobalPayloadAndReturnWeak()

        forceGc()

        assertEquals(201, globalPayload!!.id)
        assertNotNull(weak.value)
    }

    private fun clearGlobalPayloadAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(202)
        globalPayload = obj
        val weak = WeakReference(obj)

        globalPayload = null

        return weak
    }

    /**
     * RC-C02
     * Scenario: a top-level global variable is cleared.
     * Expectation: after the helper stack frame returns, the previously referenced object can be collected.
     */
    @Test
    fun rcC02_clearingTopLevelGlobalAllowsCollection() {
        val weak = clearGlobalPayloadAndReturnWeak()

        assertWeakCollected(weak)
    }

    private fun setGlobalAnyAndReturnWeak(): WeakReference<Any> {
        val obj: Any = Payload(203)
        globalAny = obj
        return WeakReference(obj)
    }

    /**
     * RC-C03
     * Scenario: a top-level global variable has static type Any? and runtime type Payload.
     * Expectation: the runtime object remains alive.
     */
    @Test
    fun rcC03_topLevelGlobalAnyKeepsRuntimeObjectAlive() {
        val weak = setGlobalAnyAndReturnWeak()

        forceGc()

        assertEquals(203, (globalAny as Payload).id)
        assertNotNull(weak.value)
    }

    private fun setGlobalMarkerAndReturnWeak(): WeakReference<Marker> {
        val obj: Marker = Payload(204)
        globalMarker = obj
        return WeakReference(obj)
    }

    /**
     * RC-C04
     * Scenario: a top-level global variable has static type Marker? and runtime type Payload.
     * Expectation: the runtime object remains alive.
     */
    @Test
    fun rcC04_topLevelGlobalInterfaceKeepsRuntimeObjectAlive() {
        val weak = setGlobalMarkerAndReturnWeak()

        forceGc()

        assertEquals(204, globalMarker!!.id)
        assertNotNull(weak.value)
    }

    private fun setObjectHolderAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(205)
        GlobalHolder.ref = obj
        return WeakReference(obj)
    }

    /**
     * RC-C05
     * Scenario: an object singleton field strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    @Test
    fun rcC05_objectSingletonFieldKeepsObjectAlive() {
        val weak = setObjectHolderAndReturnWeak()

        forceGc()

        assertEquals(205, GlobalHolder.ref!!.id)
        assertNotNull(weak.value)
    }

    private fun clearObjectHolderAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(206)
        GlobalHolder.ref = obj
        val weak = WeakReference(obj)

        GlobalHolder.ref = null

        return weak
    }

    /**
     * RC-C06
     * Scenario: an object singleton field is cleared.
     * Expectation: the previously referenced object can be collected.
     */
    @Test
    fun rcC06_clearingObjectSingletonFieldAllowsCollection() {
        val weak = clearObjectHolderAndReturnWeak()

        assertWeakCollected(weak)
    }

    private fun setCompanionHolderAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(207)
        CompanionRootHolder.ref = obj
        return WeakReference(obj)
    }

    /**
     * RC-C07
     * Scenario: a companion object field strongly references a Payload.
     * Expectation: the Payload remains alive after the creator helper returns.
     */
    @Test
    fun rcC07_companionObjectFieldKeepsObjectAlive() {
        val weak = setCompanionHolderAndReturnWeak()

        forceGc()

        assertEquals(207, CompanionRootHolder.ref!!.id)
        assertNotNull(weak.value)
    }

    private fun clearCompanionHolderAndReturnWeak(): WeakReference<Payload> {
        val obj = Payload(208)
        CompanionRootHolder.ref = obj
        val weak = WeakReference(obj)

        CompanionRootHolder.ref = null

        return weak
    }

    /**
     * RC-C08
     * Scenario: a companion object field is cleared.
     * Expectation: the previously referenced object can be collected.
     */
    @Test
    fun rcC08_clearingCompanionObjectFieldAllowsCollection() {
        val weak = clearCompanionHolderAndReturnWeak()

        assertWeakCollected(weak)
    }
}
