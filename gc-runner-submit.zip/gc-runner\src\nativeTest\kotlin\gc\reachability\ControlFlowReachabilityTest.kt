@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.test.fail

/**
 * G group: control-flow-related basic reachability.
 */
class ControlFlowReachabilityTest : ReachabilityTestSupport() {

    /**
     * RC-G01
     * Scenario: a nullable local variable is assigned inside an if branch.
     * Expectation: the assigned object remains reachable through the local variable.
     */
    @Test
    fun rcG01_ifBranchAssignmentKeepsObjectAlive() {
        var obj: Payload? = null

        if (true) {
            obj = Payload(601)
        }

        val weak = WeakReference(obj!!)

        forceGc()

        assertEquals(601, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-G02
     * Scenario: an if branch does not assign an object and the variable remains null.
     * Expectation: GC should not crash or treat null as a reference.
     */
    @Test
    fun rcG02_ifBranchWithoutAssignmentKeepsNullSafe() {
        var obj: Payload? = null

        if (false) {
            obj = Payload(602)
        }

        forceGc()

        assertNull(obj)
    }

    /**
     * RC-G03
     * Scenario: a nullable local variable is assigned inside a when branch.
     * Expectation: the assigned object remains reachable through the local variable.
     */
    @Test
    fun rcG03_whenBranchAssignmentKeepsObjectAlive() {
        val selector = 3
        var obj: Payload? = null

        when (selector) {
            3 -> obj = Payload(603)
            else -> fail("Unexpected branch")
        }

        val weak = WeakReference(obj!!)

        forceGc()

        assertEquals(603, obj.id)
        assertNotNull(weak.value)
    }

    private fun createLoopReplacementResult(): LoopReplacementResult {
        var current: Payload? = null
        val oldWeaks = mutableListOf<WeakReference<Payload>>()

        for (i in 0 until 5) {
            current?.let { oldWeaks.add(WeakReference(it)) }
            current = Payload(6040 + i)
        }

        val liveObject = current!!
        val liveWeak = WeakReference(liveObject)

        return LoopReplacementResult(
            liveObject = liveObject,
            oldWeaks = oldWeaks,
            liveWeak = liveWeak
        )
    }

    /**
     * RC-G04
     * Scenario: a loop repeatedly assigns a local variable to new Payload objects.
     * Expectation: only the last assigned object remains strongly reachable through the returned result;
     * earlier objects can be collected.
     */
    @Test
    fun rcG04_loopVariableKeepsLastObjectAndReleasesOldObjects() {
        val result = createLoopReplacementResult()

        forceGc()

        result.oldWeaks.forEach { oldWeak ->
            assertNull(oldWeak.value)
        }
        assertNotNull(result.liveWeak.value)
        assertEquals(6044, result.liveObject.id)
    }

    private fun createWeakReferencesFromLoopTemporaries(): List<WeakReference<Payload>> {
        val weaks = mutableListOf<WeakReference<Payload>>()

        for (i in 0 until 5) {
            val tmp = Payload(6050 + i)
            weaks.add(WeakReference(tmp))
            assertEquals(6050 + i, tmp.id)
        }

        return weaks
    }

    /**
     * RC-G05
     * Scenario: a loop creates temporary objects that are not kept by strong references.
     * Expectation: after the helper stack frame returns, loop temporary objects can be collected.
     */
    @Test
    fun rcG05_loopTemporaryObjectsCanBeCollected() {
        val weaks = createWeakReferencesFromLoopTemporaries()

        forceGc()

        weaks.forEach { weak ->
            assertNull(weak.value)
        }
    }

    /**
     * RC-G06
     * Scenario: an object is created and used inside a try block.
     * Expectation: the object remains reachable while used after GC inside the try block.
     */
    @Test
    fun rcG06_tryBlockLocalObjectKeepsAliveInsideTry() {
        try {
            val obj = Payload(606)
            val weak = WeakReference(obj)

            forceGc()

            assertEquals(606, obj.id)
            assertNotNull(weak.value)
        } catch (t: Throwable) {
            fail("Unexpected exception: ${t.message}")
        }
    }

    /**
     * RC-G07
     * Scenario: an object is created and used inside a catch block.
     * Expectation: the object remains reachable while used after GC inside the catch block.
     */
    @Test
    fun rcG07_catchBlockLocalObjectKeepsAliveInsideCatch() {
        try {
            error("Force catch branch")
        } catch (t: IllegalStateException) {
            val obj = Payload(607)
            val weak = WeakReference(obj)

            forceGc()

            assertEquals(607, obj.id)
            assertNotNull(weak.value)
            assertTrue(t.message!!.contains("Force"))
        }
    }

    private fun createWeakAfterFinallyCleanup(): WeakReference<Payload> {
        var obj: Payload? = Payload(608)
        val weak = WeakReference(obj!!)

        try {
            assertEquals(608, obj!!.id)
        } finally {
            obj = null
        }

        assertNull(obj)
        return weak
    }

    /**
     * RC-G08
     * Scenario: a finally block clears the last strong local reference.
     * Expectation: after the helper stack frame returns, the object can be collected.
     */
    @Test
    fun rcG08_finallyCleanupAllowsCollection() {
        val weak = createWeakAfterFinallyCleanup()

        assertWeakCollected(weak)
    }

    private fun createWeakWithEarlyReturn(): WeakReference<Payload> {
        val obj = Payload(609)
        val weak = WeakReference(obj)

        if (obj.id == 609) {
            return weak
        }

        return weak
    }

    /**
     * RC-G09
     * Scenario: a function returns early after creating an object, and only WeakReference escapes.
     * Expectation: after early return, the object can be collected.
     */
    @Test
    fun rcG09_earlyReturnAllowsLocalObjectCollection() {
        val weak = createWeakWithEarlyReturn()

        assertWeakCollected(weak)
    }

    private fun createNestedFunctionCaptureRoot(): RootedWeak<Function0<Int>, Payload> {
        val obj = Payload(610)

        fun readId(): Int = obj.id

        val block = { readId() }

        return RootedWeak(
            root = block,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-G10
     * Scenario: a nested local function captures a Payload and is invoked through a returned lambda.
     * Expectation: the captured object remains reachable through lambda -> local function capture.
     */
    @Test
    fun rcG10_nestedFunctionCaptureKeepsObjectAlive() {
        val scenario = createNestedFunctionCaptureRoot()

        forceGc()

        assertEquals(610, scenario.root())
        assertNotNull(scenario.weak.value)
    }
}
