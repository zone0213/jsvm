﻿import { assertEquals, assertNotNull, assertNull } from '../TestAssertions';
import {
    buildChain,
    buildTree,
    buildSharedGraph,
    forceGc,
    forceGcLoop,
    Holder,
    Node,
    WeakReference,
    assertWeakAlive,
    assertWeakCollectedEventually,
    runGcAroundMutation,
    repeatMutationWithGc,
    runBoundedConcurrentWriters,
    replaceField,
    stressFieldReplacement,
    globalHolder,
    LambdaHolder,
} from './ConcurrentGcTestSupport';

export class ConcurrentReferenceReplacementTest {
    cgD01_replaceNormalFieldDuringGc() {
        const r = replaceField(501, 502);
        assertWeakCollectedEventually(r.oldWeak);
        assertWeakAlive(r.newWeak);
        assertEquals(502, r.root.ref!.id);
    }

    cgD02_replaceNullableFieldDuringGc() {
        const r = replaceField(503, 504);
        assertWeakCollectedEventually(r.oldWeak);
        assertWeakAlive(r.newWeak);
        assertNotNull(r.root.ref);
    }

    cgD03_replaceChainSuffixDuringGc() {
        const old = buildChain(6, 510);
        const root = new Holder(old[0]);
        const oldWeaks = old.slice(3).map(node => new WeakReference(node));
        const newChain = buildChain(3, 520);
        const newWeaks = newChain.map(node => new WeakReference(node));
        forceGc();
        old[2].next = newChain[0];
        forceGc();
        assertEquals(520, old[2].next!.id);
        forceGcLoop();
        oldWeaks.forEach(w => w.clear());
        oldWeaks.forEach((w, i) => { if (w.value !== null) throw new Error(`Expected oldWeak[${i}] to be cleared.`); });
        forceGc();
        newWeaks.forEach((w, i) => assertNotNull(w.value, `Expected newWeak[${i}] to remain alive.`));
        assertNotNull(root.ref);
    }

    cgD04_replaceTreeSubtreeDuringGc() {
        const treeNodes = buildTree(530);
        const root = treeNodes[0];
        let oldLeft: Node | null = treeNodes[1];
        let oldLeaf: Node | null = treeNodes[3];
        const oldWeaks = [new WeakReference(oldLeft), new WeakReference(oldLeaf)];
        const newTree = buildTree(540);
        const newWeaks = newTree.map(node => new WeakReference(node));
        forceGc();
        root.left = newTree[0];
        oldLeft = null;
        oldLeaf = null;
        forceGc();
        assertEquals(540, root.left!.id);
        forceGcLoop();
        oldWeaks.forEach(w => w.clear());
        oldWeaks.forEach((w, i) => { if (w.value !== null) throw new Error(`Expected oldWeak[${i}] to be cleared.`); });
        forceGc();
        newWeaks.forEach((w, i) => assertNotNull(w.value, `Expected newWeak[${i}] to remain alive.`));
        assertNotNull(root.left);
    }

    cgD05_replaceOneSharedParentEdgeDuringGc() {
        const g = buildSharedGraph(550);
        const sharedWeak = new WeakReference(g.shared);
        const newNode = new Node(560);
        const newWeak = new WeakReference(newNode);
        runGcAroundMutation(() => { g.parent1.left = newNode; });
        assertEquals(552, g.parent2.left!.id);
        assertNotNull(sharedWeak.value);
        assertNotNull(newWeak.value);
    }

    cgD06_replaceAllSharedParentEdgesDuringGc() {
        const p1 = new Node(570);
        const p2 = new Node(571);
        let shared: Node | null = new Node(572);
        p1.left = shared;
        p2.left = shared;
        const oldWeak = new WeakReference(shared);
        const newShared = new Node(580);
        const newWeak = new WeakReference(newShared);
        forceGc();
        p1.left = newShared;
        p2.left = newShared;
        shared = null;
        forceGc();
        if (p1.left !== newShared) throw new Error('Expected newShared');
        forceGcLoop();
        oldWeak.clear();
        if (oldWeak.value !== null) throw new Error('Expected oldWeak to be cleared');
        forceGc();
        assertNotNull(newWeak.value);
        assertNotNull(p1.left);
    }

    cgD07_moveSubgraphToNewParentDuringGc() {
        const oldParent = new Node(590);
        const newParent = new Node(591);
        const child = new Node(592);
        oldParent.left = child;
        const weak = new WeakReference(child);
        runGcAroundMutation(() => { oldParent.left = null; newParent.left = child; });
        assertEquals(592, newParent.left!.id);
        assertNotNull(weak.value);
    }

    cgD08_detachThenAttachSameSubgraphDuringGc() {
        const oldParent = new Node(600);
        const newParent = new Node(601);
        const child = new Node(602);
        oldParent.left = child;
        const weak = new WeakReference(child);
        runGcAroundMutation(() => { oldParent.left = null; newParent.left = child; });
        assertEquals(602, newParent.left!.id);
        assertNotNull(weak.value);
    }

    cgD09_attachThenDetachOldParentDuringGc() {
        const oldParent = new Node(610);
        const newParent = new Node(611);
        const child = new Node(612);
        oldParent.left = child;
        const weak = new WeakReference(child);
        runGcAroundMutation(() => { newParent.left = child; oldParent.left = null; });
        assertEquals(612, newParent.left!.id);
        assertNotNull(weak.value);
    }

    cgD10_swapTwoHolderRefsDuringGc() {
        const a = new Node(620);
        const b = new Node(621);
        const h1 = new Holder(a);
        const h2 = new Holder(b);
        const wa = new WeakReference(a);
        const wb = new WeakReference(b);
        runGcAroundMutation(() => {
            const tmp = h1.ref;
            h1.ref = h2.ref;
            h2.ref = tmp;
        });
        assertEquals(621, h1.ref!.id);
        assertEquals(620, h2.ref!.id);
        assertNotNull(wa.value);
        assertNotNull(wb.value);
    }

    cgD11_abaReplacementDuringGc() {
        const a = new Node(630);
        const b = new Node(631);
        const holder = new Holder(a);
        const weakA = new WeakReference(a);
        runGcAroundMutation(() => { holder.ref = b; holder.ref = a; });
        assertEquals(630, holder.ref!.id);
        assertNotNull(weakA.value);
    }

    cgD12_highFrequencyFieldReplacementDuringGc() {
        forceGc();
        const [holder, weak] = stressFieldReplacement(64);
        forceGc();
        assertNotNull(weak.value);
        assertNotNull(holder.ref);
    }

    cgD13_multiThreadReplaceSameFieldDuringGc() {
        const completed = runBoundedConcurrentWriters(2, 16, (w, i) => { globalHolder.ref = new Node(640 + w * 100 + i); });
        assertEquals(2, completed);
        assertNotNull(globalHolder.ref);
    }

    cgD14_replaceLambdaCaptureDuringGc() {
        const oldNode = new Node(650);
        const oldWeak = new WeakReference(oldNode);
        const holder = new LambdaHolder(() => oldNode.id);
        const newNode = new Node(651);
        const newWeak = new WeakReference(newNode);
        forceGc();
        holder.block = () => newNode.id;
        forceGc();
        assertEquals(651, holder.block!());
        forceGcLoop();
        oldWeak.clear();
        if (oldWeak.value !== null) throw new Error('Expected oldWeak to be cleared');
        forceGc();
        assertNotNull(newWeak.value);
        assertNotNull(holder.block);
    }
}


