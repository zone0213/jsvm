@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-F group: dense graph tests. */
class DenseGraphTest : GraphTopologyTestSupport() {

    private fun completeGraphRoot(size: Int, startId: Int): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildCompleteMultiGraph(size, startId)
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-F01: a 5-node complete graph keeps every node alive. */
    @Test
    fun gtF01_fiveNodeCompleteGraphKeepsAllNodesAlive() {
        val scenario = completeGraphRoot(5, 10000)
        forceGc()
        assertEquals(4, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    private fun completeGraphAfterRootClear(size: Int, startId: Int): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildCompleteMultiGraph(size, startId)
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(nodes)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-F02: clearing root allows a 5-node complete graph to be collected. */
    @Test
    fun gtF02_clearingRootCollectsFiveNodeCompleteGraph() {
        val scenario = completeGraphAfterRootClear(5, 10100)
        assertNull(scenario.root.ref)
        assertAllCollected(scenario.weaks)
    }

    /** GT-F03: a 10-node complete graph keeps representative nodes alive. */
    @Test
    fun gtF03_tenNodeCompleteGraphKeepsRepresentativeNodesAlive() {
        val scenario = completeGraphRoot(10, 10200)
        forceGc()
        assertEquals(10200, scenario.weaks[0].value!!.id)
        assertEquals(10205, scenario.weaks[5].value!!.id)
        assertEquals(10209, scenario.weaks[9].value!!.id)
    }

    /** GT-F04: clearing root allows a 10-node complete graph to be collected. */
    @Test
    fun gtF04_clearingRootCollectsTenNodeCompleteGraph() {
        val scenario = completeGraphAfterRootClear(10, 10300)
        assertAllCollected(scenario.weaks)
    }

    private fun highOutDegreeRoot(): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildHighOutDegreeGraph(100, 10400)
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-F05: a high-out-degree center node keeps representative children alive. */
    @Test
    fun gtF05_highOutDegreeCenterGraphKeepsChildrenAlive() {
        val scenario = highOutDegreeRoot()
        forceGc()
        assertEquals(100, scenario.root.ref!!.children.size)
        assertEquals(10401, scenario.root.ref!!.children[0].id)
        assertEquals(10451, scenario.root.ref!!.children[50].id)
        assertEquals(10500, scenario.root.ref!!.children[99].id)
        assertAllAlive(scenario.weaks)
    }

    private fun highOutDegreeAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildHighOutDegreeGraph(100, 10550)
        val root = GraphRoot(nodes.first())
        root.ref!!.children.clear()
        return MixedWeaks(root, weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-F06: clearing high-out-degree children keeps center alive and collects children. */
    @Test
    fun gtF06_clearingHighOutDegreeChildrenCollectsChildrenOnly() {
        val scenario = highOutDegreeAfterClear()
        forceGc()
        assertEquals(0, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-F07: clearing one node's outgoing edges in a complete graph does not collect nodes still reachable from other edges. */
    @Test
    fun gtF07_clearingOneDenseNodeOutgoingEdgesKeepsGraphAlive() {
        val nodes = buildCompleteMultiGraph(5, 10700)
        nodes[1].children.clear()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(0, nodes[1].children.size)
        assertAllAlive(scenario.weaks)
    }

    /** GT-F08: repeated dense edges keep all shared nodes alive. */
    @Test
    fun gtF08_repeatedDenseEdgesKeepSharedNodesAlive() {
        val root = MultiNode(10800)
        val shared = List(5) { index -> MultiNode(10801 + index) }
        repeat(3) {
            root.children.addAll(shared)
        }
        val scenario = RootedWeaks(GraphRoot(root), weakRefs(listOf(root) + shared))
        forceGc()
        assertEquals(15, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    private fun repeatedDenseEdgesAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val root = MultiNode(10900)
        val shared = List(5) { index -> MultiNode(10901 + index) }
        repeat(3) { root.children.addAll(shared) }
        root.children.clear()
        return MixedWeaks(GraphRoot(root), weakRefs(listOf(root)), weakRefs(shared))
    }

    /** GT-F09: clearing the only repeated-edge container allows shared nodes to be collected. */
    @Test
    fun gtF09_clearingRepeatedDenseEdgesCollectsSharedNodes() {
        val scenario = repeatedDenseEdgesAfterClear()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-F10: an array-backed complete graph keeps representative nodes alive. */
    @Test
    fun gtF10_arrayBackedCompleteGraphKeepsRepresentativeNodesAlive() {
        val nodes = List(10) { index -> ArrayNode(11000 + index, refCount = 9) }
        nodes.forEachIndexed { index, node ->
            var out = 0
            nodes.forEachIndexed { candidateIndex, candidate ->
                if (candidateIndex != index) {
                    node.refs[out++] = candidate
                }
            }
        }
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(11000, scenario.weaks[0].value!!.id)
        assertEquals(11005, scenario.weaks[5].value!!.id)
        assertEquals(11009, scenario.weaks[9].value!!.id)
        assertAllAlive(scenario.weaks)
    }
}
