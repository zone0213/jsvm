@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * PS-E group: non-reference values must not be interpreted as stack roots.
 */
class PreciseStackNonReferenceValueTest : PreciseStackTestSupport() {
    /**
     * PS-E01
     * Scenario: dead reference slot is followed by Long values before GC.
     * Expectation: non-reference stack values do not retain the old object.
     */
    @Test
    fun psE01_longValuesDoNotRetainDeadReference() {
        var obj: StackPayload? = StackPayload(5001)
        val weak = WeakReference(obj!!)

        obj = null
        val values = LongArray(8) { index -> 0x1000_0000L + index }
        val checksum = values.sum()

        assertTrue(checksum > 0)
        assertEquals(null, obj)
        assertWeakCollected(weak)
    }

    /**
     * PS-E02
     * Scenario: dead reference slot is followed by ULong values before GC.
     * Expectation: unsigned integer stack values are not scanned as object references.
     */
    @Test
    fun psE02_ulongValuesDoNotRetainDeadReference() {
        var obj: StackPayload? = StackPayload(5002)
        val weak = WeakReference(obj!!)

        obj = null
        val values = ULongArray(6) { index -> 0x2000_0000UL + index.toULong() }
        var checksum = 0UL
        values.forEach { checksum += it }

        assertTrue(checksum > 0UL)
        assertEquals(null, obj)
        assertWeakCollected(weak)
    }

    /**
     * PS-E03
     * Scenario: dead reference slot is followed by mixed primitive locals.
     * Expectation: primitive stack slots do not keep the object alive.
     */
    @Test
    fun psE03_mixedPrimitiveLocalsDoNotRetainDeadReference() {
        var obj: StackPayload? = StackPayload(5003)
        val weak = WeakReference(obj!!)

        obj = null
        val intValue = 5003
        val longValue = 0x3000_0000L
        val doubleValue = 50.03
        val booleanValue = intValue + longValue > 0

        assertTrue(booleanValue)
        assertTrue(doubleValue > 0.0)
        assertEquals(null, obj)
        assertWeakCollected(weak)
    }

    /**
     * PS-E04
     * Scenario: object remains live while many non-reference locals are present.
     * Expectation: precise scanning still includes the actual live reference slot.
     */
    @Test
    fun psE04_liveReferenceSurvivesAmongPrimitiveLocals() {
        val obj = StackPayload(5004)
        val weak = WeakReference(obj)
        val values = LongArray(16) { index -> index.toLong() * 17L }
        val checksum = values.sum()

        assertTrue(checksum > 0)
        assertEquals(5004, assertWeakAlive(weak).id)
        assertEquals(5004, obj.id)
    }

    /**
     * PS-E05
     * Scenario: generic Any local is cleared while unrelated primitive values remain.
     * Expectation: cleared Any slot does not retain the old reference.
     */
    @Test
    fun psE05_clearedAnySlotIsNotRetainedByPrimitiveLocals() {
        var obj: Any? = StackPayload(5005)
        val weak = WeakReference(obj as StackPayload)

        obj = null
        val marker = 0x5005_5005

        assertEquals(0x5005_5005, marker)
        assertEquals(null, obj)
        assertWeakCollected(weak)
    }
}

