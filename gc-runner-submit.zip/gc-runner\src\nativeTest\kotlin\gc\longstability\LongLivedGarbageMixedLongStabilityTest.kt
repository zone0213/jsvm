@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * LS-C group: long-lived roots mixed with short-lived garbage.
 */
class LongLivedGarbageMixedLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-C01
     * Scenario: small long-lived with small garbage.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c01_smallLongLivedWithSmallGarbage() {
        val root = LsNode(1)
        val weak = WeakReference(root)
        for (iteration in 0 until SHORT_ITERATIONS) {
            for (item in 0 until CHURN_PER_ITERATION) {
                LsNode(item + iteration * CHURN_PER_ITERATION)
            }
            assertNotNull(weak.value)
        }
        forceGc()
        assertEquals(1, root.id)
        assertNotNull(weak.value)
    }

    /**
     * LS-C02
     * Scenario: large long-lived with small garbage.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c02_largeLongLivedWithSmallGarbage() {
        val root = LargePayload(2, ByteArray(MEDIUM_BYTES))
        val weak = WeakReference(root)
        for (iteration in 0 until SHORT_ITERATIONS) {
            for (item in 0 until CHURN_PER_ITERATION) {
                LsNode(item + iteration * CHURN_PER_ITERATION)
            }
            assertNotNull(weak.value)
        }
        forceGc()
        assertEquals(2, root.id)
        assertNotNull(weak.value)
    }

    /**
     * LS-C03
     * Scenario: mixed long-lived with mixed garbage.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c03_mixedLongLivedWithMixedGarbage() {
        val root = MixedPayload(3)
        val weak = WeakReference(root)
        for (iteration in 0 until SHORT_ITERATIONS) {
            for (item in 0 until CHURN_PER_ITERATION) {
                MixedPayload(item + iteration * CHURN_PER_ITERATION)
            }
            assertNotNull(weak.value)
        }
        forceGc()
        assertEquals(3, root.id)
        assertNotNull(weak.value)
    }

    /**
     * LS-C04
     * Scenario: long-lived list with churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c04_longLivedListWithChurn() {
        val roots = allocateSmallBatch(32).toMutableList()
        val weak = WeakReference(roots.first())
        shortLivedSamples(8) { LsNode(it) }
        assertNotNull(weak.value)
        assertEquals(0, roots.first().id)
    }

    /**
     * LS-C05
     * Scenario: long-lived map cache with churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c05_longLivedMapCacheWithChurn() {
        val cache = allocateSmallBatch(32).associateBy { it.id }.toMutableMap()
        val weak = WeakReference(cache[0]!!)
        shortLivedSamples(8) { MediumPayload(it) }
        assertNotNull(weak.value)
        assertEquals(0, cache[0]!!.id)
    }

    /**
     * LS-C06
     * Scenario: long-lived state tree with churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c06_longLivedStateTreeWithChurn() {
        val state = FakeState(listOf(FakeDto(1, "state", emptyList())))
        val weak = WeakReference(state)
        shortLivedSamples(8) { FakeDto(it, "garbage", emptyList()) }
        assertNotNull(weak.value)
        assertEquals(1, state.items[0].id)
    }

    /**
     * LS-C07
     * Scenario: periodic long-lived root replacement.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c07_periodicLongLivedRootReplacement() {
        val roots = MutableList(16) { LsNode(it) }
        val samples = containerSamples { i ->
            roots[i % roots.size] = LsNode(1000 + i)
        }
        assertNoSustainedMonotonicGrowth(samples)
        assertTrue(roots.all { it.id >= 0 })
    }

    /**
     * LS-C08
     * Scenario: bounded LRU growth.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c08_boundedLruGrowth() {
        val cache = LinkedHashMap<Int, LargePayload>()
        val samples = containerSamples { i ->
            cache[i] = LargePayload(i, ByteArray(1024))
            if (cache.size > CACHE_LIMIT) {
                cache.remove(cache.keys.first())
            }
        }
        assertTrue(cache.size <= CACHE_LIMIT)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-C09
     * Scenario: clear long-lived roots at end.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c09_clearLongLivedRootsAtEnd() {
        val roots = allocateSmallBatch(16).toMutableList()
        val weak = WeakReference(roots.first())
        roots.clear()
        assertWeakCollectedEventually(weak)
    }

    /**
     * LS-C10
     * Scenario: long-lived root with exception churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_c10_longLivedRootWithExceptionChurn() {
        val root = LsNode(10)
        val weak = WeakReference(root)
        containerSamples { i ->
            try {
                error("e$i")
            } catch (_: Throwable) {
            }
        }
        assertNotNull(weak.value)
        assertEquals(10, root.id)
    }

}
