@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * LS-D group: release-reallocate long-stability tests.
 */
class ReleaseReallocateLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-D01
     * Scenario: small release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d01_smallReleaseReallocate() {
        assertNoSustainedMonotonicGrowth(
            releaseReallocateSamples { allocateSmallBatch().map { it as Any } }
        )
    }

    /**
     * LS-D02
     * Scenario: medium release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d02_mediumReleaseReallocate() {
        assertNoSustainedMonotonicGrowth(
            releaseReallocateSamples { allocateMediumBatch().map { it as Any } }
        )
    }

    /**
     * LS-D03
     * Scenario: large release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d03_largeReleaseReallocate() {
        assertNoSustainedMonotonicGrowth(
            releaseReallocateSamples(8) { allocateLargeBatch(4, MEDIUM_BYTES).map { it as Any } }
        )
    }

    /**
     * LS-D04
     * Scenario: mixed release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d04_mixedReleaseReallocate() {
        assertNoSustainedMonotonicGrowth(
            releaseReallocateSamples { allocateMixedBatch().map { it as Any } }
        )
    }

    /**
     * LS-D05
     * Scenario: holder field replacement loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d05_holderFieldReplacementLoop() {
        val holder = Holder(LsNode(0))
        val samples = containerSamples { i ->
            holder.ref = null
            forceGc(1)
            holder.ref = LsNode(i)
        }
        assertNotNull(holder.ref)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-D06
     * Scenario: array slot replacement loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d06_arraySlotReplacementLoop() {
        val array = arrayOfNulls<LsNode>(16)
        val samples = containerSamples { i ->
            val slot = i % array.size
            array[slot] = null
            array[slot] = LsNode(i)
        }
        assertTrue(array.any { it != null })
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-D07
     * Scenario: list clear refill loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d07_listClearRefillLoop() {
        val list = mutableListOf<LsNode>()
        val samples = containerSamples { i ->
            list.clear()
            repeat(16) { index ->
                list.add(LsNode(i * 16 + index))
            }
        }
        assertTrue(list.isNotEmpty())
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-D08
     * Scenario: map clear refill loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d08_mapClearRefillLoop() {
        val map = mutableMapOf<Int, LsNode>()
        val samples = containerSamples { i ->
            map.clear()
            repeat(16) { index ->
                map[index] = LsNode(i * 16 + index)
            }
        }
        assertTrue(map.isNotEmpty())
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-D09
     * Scenario: partial release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d09_partialReleaseReallocate() {
        val roots = MutableList(32) { LsNode(it) }
        val retained = WeakReference(roots[1])
        val samples = containerSamples { i ->
            for (index in roots.indices step 2) {
                roots[index] = LsNode(i * 100 + index)
            }
        }
        assertNotNull(retained.value)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-D10
     * Scenario: alternating size reuse proxy.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_d10_alternatingSizeReuseProxy() {
        var toggle = false
        assertNoSustainedMonotonicGrowth(
            releaseReallocateSamples(12) {
                toggle = !toggle
                if (toggle) {
                    allocateSmallBatch(64).map { it as Any }
                } else {
                    allocateLargeBatch(2, MEDIUM_BYTES).map { it as Any }
                }
            }
        )
    }

}
