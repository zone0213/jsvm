@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Shared infrastructure for Kotlin/Native GC graph-topology reachability tests.
 *
 * Scope:
 * - Pure Kotlin strong-reference graph traversal only.
 * - WeakReference is used only as an observation mechanism.
 * - Weak-reference semantics, concurrency, interop, StableRef and allocator behavior are out of scope.
 */
open class GraphTopologyTestSupport {

    @BeforeTest
    fun beforeTest() {
        forceGc()
    }

    @AfterTest
    fun afterTest() {
        forceGc()
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected object to remain reachable, but WeakReference was cleared."
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollected(
        weak: WeakReference<T>,
        message: String = "Expected object to become unreachable and be collected."
    ) {
        forceGc()
        assertNull(weak.value, message)
    }

    protected fun <T : Any> assertAllAlive(weaks: Iterable<WeakReference<T>>) {
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
    }

    protected fun <T : Any> assertAllCollected(weaks: Iterable<WeakReference<T>>) {
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNull(weak.value, "Expected weak[$index] to be collected.")
        }
    }

    protected fun assertDiagnosticCollectedOrAlive(weak: WeakReference<GraphNode>, expectedId: Int) {
        forceGc()
        val value = weak.value
        assertTrue(value == null || value.id == expectedId)
    }

    protected fun buildGraphNodeChain(length: Int, startId: Int): List<GraphNode> {
        require(length > 0) { "length must be positive" }
        val nodes = List(length) { index -> GraphNode(startId + index) }
        for (index in 0 until nodes.lastIndex) {
            nodes[index].next = nodes[index + 1]
        }
        return nodes
    }

    protected fun buildFullBinaryTree(levels: Int, startId: Int): List<GraphNode> {
        require(levels > 0) { "levels must be positive" }
        val count = (1 shl levels) - 1
        val nodes = List(count) { index -> GraphNode(startId + index) }
        for (index in nodes.indices) {
            val leftIndex = index * 2 + 1
            val rightIndex = index * 2 + 2
            if (leftIndex < nodes.size) nodes[index].left = nodes[leftIndex]
            if (rightIndex < nodes.size) nodes[index].right = nodes[rightIndex]
        }
        return nodes
    }

    protected fun buildMultiTree(levels: Int, branchingFactor: Int, startId: Int): List<MultiNode> {
        require(levels > 0) { "levels must be positive" }
        require(branchingFactor > 0) { "branchingFactor must be positive" }
        val nodes = mutableListOf<MultiNode>()
        val root = MultiNode(startId)
        nodes.add(root)
        var currentLevel = listOf(root)
        var nextId = startId + 1
        repeat(levels - 1) {
            val nextLevel = mutableListOf<MultiNode>()
            currentLevel.forEach { parent ->
                repeat(branchingFactor) {
                    val child = MultiNode(nextId++)
                    parent.children.add(child)
                    nodes.add(child)
                    nextLevel.add(child)
                }
            }
            currentLevel = nextLevel
        }
        return nodes
    }

    protected fun buildCompleteMultiGraph(size: Int, startId: Int): List<MultiNode> {
        require(size > 0) { "size must be positive" }
        val nodes = List(size) { index -> MultiNode(startId + index) }
        nodes.forEach { node ->
            nodes.forEach { candidate ->
                if (candidate !== node) node.children.add(candidate)
            }
        }
        return nodes
    }

    protected fun buildHighOutDegreeGraph(childCount: Int, startId: Int): List<MultiNode> {
        require(childCount > 0) { "childCount must be positive" }
        val center = MultiNode(startId)
        val children = List(childCount) { index -> MultiNode(startId + index + 1) }
        center.children.addAll(children)
        return listOf(center) + children
    }

    protected fun <T : Any> weakRefs(nodes: List<T>): List<WeakReference<T>> =
        nodes.map { WeakReference(it) }

    companion object {
        private const val GC_REPEAT_COUNT = 3
    }
}

/** Fixed root wrapper. The second layer varies graph shape, not root source. */
class GraphRoot<T : Any>(var ref: T?)

/** Field-based graph node for chains, binary trees, DAGs and cycles. */
class GraphNode(val id: Int) {
    var next: GraphNode? = null
    var left: GraphNode? = null
    var right: GraphNode? = null
    override fun toString(): String = "GraphNode(id=$id)"
}

/** List-based graph node for multi-way trees, dense graphs and adjacency-list graphs. */
class MultiNode(
    val id: Int,
    val children: MutableList<MultiNode> = mutableListOf()
) {
    override fun toString(): String = "MultiNode(id=$id)"
}

/** Array-based graph node for adjacency-array graph tests. */
class ArrayNode(val id: Int, refCount: Int) {
    val refs: Array<ArrayNode?> = arrayOfNulls(refCount)
    override fun toString(): String = "ArrayNode(id=$id)"
}

/** Map-value-based graph node for map adjacency tests. */
class MapNode(
    val id: Int,
    val refs: MutableMap<String, MapNode> = mutableMapOf()
) {
    override fun toString(): String = "MapNode(id=$id)"
}

/** Set-based graph node for set adjacency tests. */
class SetNode(
    val id: Int,
    val children: MutableSet<SetNode> = mutableSetOf()
) {
    override fun toString(): String = "SetNode(id=$id)"
}

data class RootedWeaks<R : Any, T : Any>(
    val root: R,
    val weaks: List<WeakReference<T>>
)

data class MixedWeaks<R : Any, T : Any>(
    val root: R,
    val aliveWeaks: List<WeakReference<T>>,
    val collectedWeaks: List<WeakReference<T>>
)

data class ReplacementWeaks<R : Any, T : Any>(
    val root: R,
    val oldWeaks: List<WeakReference<T>>,
    val newWeaks: List<WeakReference<T>>
)
