@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * A group: local variable roots.
 */
class LocalRootReachabilityTest : ReachabilityTestSupport() {

    /**
     * RC-A01
     * Scenario: local val directly references a concrete Payload object.
     * Expectation: the object remains reachable while the local val is used after GC.
     */
    @Test
    fun rcA01_localValDirectReferenceKeepsObjectAlive() {
        val obj = Payload(1)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(1, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-A02
     * Scenario: local var directly references a concrete Payload object.
     * Expectation: the object remains reachable while the local var is used after GC.
     */
    @Test
    fun rcA02_localVarDirectReferenceKeepsObjectAlive() {
        var obj = Payload(2)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(2, obj.id)
        assertNotNull(weak.value)

        obj = Payload(20)
        assertEquals(20, obj.id)
    }

    private fun createWeakFromLocalObject(): WeakReference<Payload> {
        val obj = Payload(3)
        return WeakReference(obj)
    }

    /**
     * RC-A03
     * Scenario: a local object is created inside a helper function and only a WeakReference escapes.
     * Expectation: after the helper stack frame returns, the object can be collected.
     */
    @Test
    fun rcA03_localObjectCanBeCollectedAfterFunctionReturns() {
        val weak = createWeakFromLocalObject()

        assertWeakCollected(weak)
    }

    /**
     * RC-A04
     * Scenario: a local object is created inside an inner block and GC is triggered inside the block.
     * Expectation: the object remains reachable while the block-local variable is still used after GC.
     */
    @Test
    fun rcA04_innerBlockLocalObjectKeepsAliveInsideBlock() {
        run {
            val obj = Payload(4)
            val weak = WeakReference(obj)

            forceGc()

            assertEquals(4, obj.id)
            assertNotNull(weak.value)
        }
    }

    /**
     * RC-A05
     * Scenario: an object leaves an inner block, but the enclosing function has not returned.
     * Expectation: this is a diagnostic case only. Kotlin/Native may still keep the old stack slot alive,
     * so the test must not assert deterministic collection here.
     */
    @Test
    fun rcA05_innerBlockEndIsDiagnosticAndNotDeterministic() {
        var weak: WeakReference<Payload>? = null

        run {
            val obj = Payload(5)
            weak = WeakReference(obj)
            assertEquals(5, obj.id)
        }

        forceGc()

        val observed = weak!!.value
        assertTrue(observed == null || observed.id == 5)
    }

    private fun createWeakAfterLocalNullableSetNull(): WeakReference<Payload> {
        var obj: Payload? = Payload(6)
        val weak = WeakReference(obj!!)

        obj = null
        assertNull(obj)

        return weak
    }

    /**
     * RC-A06
     * Scenario: a local nullable variable is set to null.
     * Expectation: after the helper stack frame returns, the original object can be collected.
     */
    @Test
    fun rcA06_localNullableSetNullAllowsCollection() {
        val weak = createWeakAfterLocalNullableSetNull()

        assertWeakCollected(weak)
    }

    private fun createLocalReplacementResult(): ReplacementResult<Payload> {
        var obj: Payload? = Payload(7)
        val oldWeak = WeakReference(obj!!)

        obj = Payload(70)
        val newObj = obj!!
        val newWeak = WeakReference(newObj)

        return ReplacementResult(
            liveObject = newObj,
            oldWeak = oldWeak,
            newWeak = newWeak
        )
    }

    /**
     * RC-A07
     * Scenario: a local variable is reassigned from an old object to a new object.
     * Expectation: after the helper stack frame returns, the old object can be collected,
     * while the new object remains alive through the returned strong reference.
     */
    @Test
    fun rcA07_localReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        val result = createLocalReplacementResult()

        forceGc()

        assertNull(result.oldWeak.value)
        assertNotNull(result.newWeak.value)
        assertEquals(70, result.liveObject.id)
    }

    /**
     * RC-A08
     * Scenario: a local variable has static type Any and runtime type Payload.
     * Expectation: the runtime object remains reachable.
     */
    @Test
    fun rcA08_localAnyTypedReferenceKeepsRuntimeObjectAlive() {
        val obj: Any = Payload(8)
        val weak = WeakReference(obj)

        forceGc()

        assertTrue(obj is Payload)
        assertEquals(8, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-A09
     * Scenario: a local variable has static type Marker and runtime type Payload.
     * Expectation: the runtime object remains reachable through the interface-typed reference.
     */
    @Test
    fun rcA09_localInterfaceTypedReferenceKeepsRuntimeObjectAlive() {
        val obj: Marker = Payload(9)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(9, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-A10
     * Scenario: a local variable has static type BasePayload and runtime type ChildPayload.
     * Expectation: the runtime object remains reachable through the base-class-typed reference.
     */
    @Test
    fun rcA10_localBaseClassTypedReferenceKeepsRuntimeObjectAlive() {
        val obj: BasePayload = ChildPayload(10)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(10, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-A11
     * Scenario: a local nullable variable holds a non-null Payload object.
     * Expectation: the object remains reachable through the nullable-typed reference.
     */
    @Test
    fun rcA11_localNullableNonNullReferenceKeepsObjectAlive() {
        val obj: Payload? = Payload(11)
        val weak = WeakReference(obj!!)

        forceGc()

        assertEquals(11, obj.id)
        assertNotNull(weak.value)
    }

    /**
     * RC-A12
     * Scenario: a local val directly references a data class instance.
     * Expectation: data class instances are scanned and kept alive like normal objects.
     */
    @Test
    fun rcA12_localDataClassReferenceKeepsObjectAlive() {
        val obj = DataPayload(12)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(12, obj.id)
        assertNotNull(weak.value)
    }
}
