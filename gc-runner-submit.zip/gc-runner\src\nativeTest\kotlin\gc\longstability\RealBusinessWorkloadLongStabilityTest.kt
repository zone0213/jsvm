@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.test.Test
import kotlin.test.assertTrue

/**
 * LS-L group: real-business-model long-stability tests.
 */
class RealBusinessWorkloadLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-L01
     * Scenario: JSON DTO parse churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l01_jsonDtoParseChurn() {
        assertNoSustainedMonotonicGrowth(businessDtoSamples())
    }

    /**
     * LS-L02
     * Scenario: JSON encode/decode roundtrip.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l02_jsonEncodeDecodeRoundtrip() {
        assertNoSustainedMonotonicGrowth(businessDtoSamples())
    }

    /**
     * LS-L03
     * Scenario: CLI argument parse churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l03_cliArgumentParseChurn() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                val args = listOf("--user", "u$i", "--limit", "${i % 10}")
                assertTrue(args.contains("--user"))
            }
        )
    }

    /**
     * LS-L04
     * Scenario: git log parser workload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l04_gitLogParserWorkload() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                val parts = "abc$i|Author|2026-01-01|Message $i".split("|")
                kotlin.test.assertEquals(4, parts.size)
            }
        )
    }

    /**
     * LS-L05
     * Scenario: repository mock query loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l05_repositoryMockQueryLoop() {
        assertNoSustainedMonotonicGrowth(repositoryCacheStateSamples())
    }

    /**
     * LS-L06
     * Scenario: LRU cache workload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l06_lruCacheWorkload() {
        val cache = LinkedHashMap<Int, LargePayload>()
        val samples = containerSamples { i ->
            cache[i] = LargePayload(i, ByteArray(1024))
            cache[i - 1]
            if (cache.size > CACHE_LIMIT) {
                cache.remove(cache.keys.first())
            }
        }
        assertTrue(cache.size <= CACHE_LIMIT)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-L07
     * Scenario: ViewModel state reduce.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l07_viewmodelStateReduce() {
        assertNoSustainedMonotonicGrowth(repositoryCacheStateSamples())
    }

    /**
     * LS-L08
     * Scenario: coroutine task queue workload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l08_coroutineTaskQueueWorkload() {
        val queue = ArrayDeque<FakeDto>()
        val samples = containerSamples { i ->
            queue.addLast(FakeDto(i, "task", emptyList()))
            if (queue.size > 8) {
                queue.removeFirst()
            }
        }
        assertTrue(queue.size <= 8)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-L09
     * Scenario: error-heavy workload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l09_errorHeavyWorkload() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                try {
                    if (i % 3 == 0) {
                        error("bad input")
                    } else {
                        FakeDto.decode("$i|ok|")
                    }
                } catch (_: Throwable) {
                }
            }
        )
    }

    /**
     * LS-L10
     * Scenario: mixed business workload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_l10_mixedBusinessWorkload() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                FakeDto.decode(FakeDto(i, "mix", emptyList()).encode())
                repositoryCacheStateSamples(2)
                coroutineLikeBatch(2)
            }
        )
    }

}
