@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-E group: array, list and map mutator changes while GC is interleaved.
 */
class ConcurrentContainerMutationTest : ConcurrentGcTestSupport() {

    /**
     * CG-E01
     * Scenario: array element is written during GC window.
     * Expectation: written object remains alive.
     */
    @Test
    fun cgE01_arrayWriteElementDuringGc() {
        forceGc()
        val (array, weak) = arrayPutScenario(701)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(array[0])
    }

    /**
     * CG-E02
     * Scenario: array element is cleared during GC window.
     * Expectation: old object eventually collected.
     */
    @Test
    fun cgE02_arrayClearElementDuringGc() {
        assertWeakCollectedEventually(arrayClearScenario(702))
    }

    /**
     * CG-E03
     * Scenario: array element is replaced old -> new.
     * Expectation: old collected and new alive.
     */
    @Test
    fun cgE03_arrayReplaceElementDuringGc() {
        val old = Node(703)
        val array = arrayOfNulls<Node>(1)
        array[0] = old
        val oldWeak = WeakReference(old)
        val new = Node(704)
        val newWeak = WeakReference(new)
        runGcAroundMutation { array[0] = new }
        assertWeakCollectedEventually(oldWeak)
        assertWeakAlive(newWeak)
        assertEquals(704, array[0]!!.id)
    }

    /**
     * CG-E04
     * Scenario: array slot receives chain head.
     * Expectation: chain remains alive.
     */
    @Test
    fun cgE04_arrayWriteNewChainDuringGc() {
        forceGc()
        val array = arrayOfNulls<Node>(1)
        val chain = buildChain(4, 705)
        val weaks = chain.map { WeakReference(it) }
        array[0] = chain.first()
        forceGc()
        assertEquals(705, array[0]!!.id)
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
    }

    /**
     * CG-E05
     * Scenario: list add occurs during GC window.
     * Expectation: added object remains alive.
     */
    @Test
    fun cgE05_listAddDuringGc() {
        forceGc()
        val (list, weak) = listAddScenario(710)
        forceGc()
        assertNotNull(weak.value)
        assertTrue(list.isNotEmpty())
    }

    /**
     * CG-E06
     * Scenario: list remove occurs during GC window.
     * Expectation: removed object eventually collected.
     */
    @Test
    fun cgE06_listRemoveDuringGc() {
        assertWeakCollectedEventually(listRemoveScenario(711))
    }

    /**
     * CG-E07
     * Scenario: list clear occurs during GC window.
     * Expectation: elements eventually collected.
     */
    @Test
    fun cgE07_listClearDuringGc() {
        val nodes = List(4){Node(720+it)}
        val list = nodes.toMutableList()
        val weaks = nodes.map{WeakReference(it)}
        runGcAroundMutation { list.clear() }
        assertAllWeakCollectedEventually(weaks)
    }

    /**
     * CG-E08
     * Scenario: same object is added to two lists.
     * Expectation: shared object remains alive.
     */
    @Test
    fun cgE08_listAddSharedObjectDuringGc() {
        val shared = Node(730)
        val weak = WeakReference(shared)
        val l1 = mutableListOf<Node>()
        val l2 = mutableListOf<Node>()
        runGcAroundMutation { l1.add(shared)
        l2.add(shared) }
        assertEquals(730,l1[0].id)
        assertEquals(730,l2[0].id)
        assertNotNull(weak.value)
    }

    /**
     * CG-E09
     * Scenario: one list removes shared object while another keeps it.
     * Expectation: shared object remains alive.
     */
    @Test
    fun cgE09_listRemoveOneSharedEdgeDuringGc() {
        val shared=Node(731)
        val weak=WeakReference(shared)
        val l1=mutableListOf(shared)
        val l2=mutableListOf(shared)
        runGcAroundMutation { l1.remove(shared) }
        assertTrue(l1.isEmpty())
        assertEquals(731,l2[0].id)
        assertNotNull(weak.value)
    }

    /**
     * CG-E10
     * Scenario: all list edges to shared object are removed.
     * Expectation: shared object eventually collected.
     */
    @Test
    fun cgE10_listRemoveAllSharedEdgesDuringGc() {
        val shared=Node(732)
        val weak=WeakReference(shared)
        val l1=mutableListOf(shared)
        val l2=mutableListOf(shared)
        runGcAroundMutation { l1.clear()
        l2.clear() }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-E11
     * Scenario: map value is written during GC window.
     * Expectation: value remains alive.
     */
    @Test
    fun cgE11_mapPutValueDuringGc() {
        forceGc()
        val (map, weak) = mapPutScenario(740)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(map["k"])
    }

    /**
     * CG-E12
     * Scenario: map value is removed during GC window.
     * Expectation: old value eventually collected.
     */
    @Test
    fun cgE12_mapRemoveValueDuringGc() {
        assertWeakCollectedEventually(mapRemoveScenario(741))
    }

    /**
     * CG-E13
     * Scenario: map value is replaced.
     * Expectation: old value collected and new value alive.
     */
    @Test
    fun cgE13_mapReplaceValueDuringGc() {
        val old = Node(742)
        val map = mutableMapOf("k" to old)
        val oldWeak = WeakReference(old)
        val new = Node(743)
        val newWeak = WeakReference(new)
        forceGc()
        map["k"] = new
        forceGc()
        assertEquals(new, map["k"])
        forceGcLoop()
        assertNull(oldWeak.value)
        forceGc()
        assertNotNull(newWeak.value)
        assertEquals(743, map["k"]!!.id)
    }

    /**
     * CG-E14
     * Scenario: map key is an object.
     * Expectation: key remains alive while map holds entry.
     */
    @Test
    fun cgE14_mapKeyHoldsObjectDuringGc() {
        val key=Node(744)
        val weak=WeakReference(key)
        val map=mutableMapOf(key to "v")
        forceGc()
        assertEquals("v", map[key])
        assertNotNull(weak.value)
    }

    /**
     * CG-E15
     * Scenario: map entry with object key is removed.
     * Expectation: key object eventually collected.
     */
    @Test
    fun cgE15_mapRemoveKeyObjectDuringGc() {
        val key=Node(745)
        val weak=WeakReference(key)
        val map=mutableMapOf(key to "v")
        runGcAroundMutation { map.remove(key) }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-E16
     * Scenario: bounded list add/remove loop interleaves with GC.
     * Expectation: no crash and list is traversable.
     */
    @Test
    fun cgE16_concurrentListAddRemoveWithGc() {
        val list=mutableListOf<Node>()
        val count=repeatMutationWithGc(32){ if(it%2==0) list.add(Node(750+it)) else if(list.isNotEmpty()) list.removeAt(0) }
        assertEquals(32,count)
        list.forEach { assertTrue(it.id >= 750) }
    }

    /**
     * CG-E17
     * Scenario: bounded map put/remove loop interleaves with GC.
     * Expectation: no crash and map is traversable.
     */
    @Test
    fun cgE17_concurrentMapPutRemoveWithGc() {
        val map=mutableMapOf<Int,Node>()
        val count=repeatMutationWithGc(32){ map[it]=Node(760+it)
        if(it%2==1) map.remove(it-1) }
        assertEquals(32,count)
        map.values.forEach { assertTrue(it.id >= 760) }
    }

    /**
     * CG-E18
     * Scenario: container add/clear pressure interleaves with GC.
     * Expectation: no crash and final state is correct.
     */
    @Test
    fun cgE18_containerPressureAddClearWithGc() {
        val list=mutableListOf<Node>()
        repeatMutationWithGc(64){ list.add(Node(770+it))
        if(it%8==0) list.clear() }
        forceGc()
        list.forEach{ assertTrue(it.id>=770) }
    }

}
