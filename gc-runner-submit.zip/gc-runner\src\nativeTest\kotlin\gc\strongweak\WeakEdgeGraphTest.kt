@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-C group: weak edge does not participate in object graph reachability.
 */
class WeakEdgeGraphTest : WeakReferenceTestSupport() {

    private fun createParentWeakChild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(301)
        val child = Payload(302)
        parent.weak = WeakReference(child)
        return WeakOnlyResult(Root(parent), parent.weak!!)
    }

    /**
     * WR-C01
     * Scenario: root -> parent and parent weakly points to child.
     * Expectation: parent survives, but child can be collected.
     */
    @Test
    fun wrC01_parentWeakChildDoesNotKeepChildAlive() {
        val scenario = createParentWeakChild()

        forceGc()

        assertEquals(301, scenario.root.ref!!.id)
        assertNull(scenario.weak.value)
    }

    private fun createParentStrongChild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(303)
        val child = Payload(304)
        parent.strong = child
        return WeakOnlyResult(Root(parent), WeakReference(child))
    }

    /**
     * WR-C02
     * Scenario: root -> parent and parent strongly points to child.
     * Expectation: both parent and child survive.
     */
    @Test
    fun wrC02_parentStrongChildKeepsChildAlive() {
        val scenario = createParentStrongChild()

        forceGc()

        assertEquals(303, scenario.root.ref!!.id)
        assertEquals(304, scenario.root.ref!!.strong!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createParentStrongAndWeakChild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(305)
        val child = Payload(306)
        parent.strong = child
        parent.weak = WeakReference(child)
        return WeakOnlyResult(Root(parent), parent.weak!!)
    }

    /**
     * WR-C03
     * Scenario: parent has both strong and weak edges to child.
     * Expectation: child survives because of the strong edge.
     */
    @Test
    fun wrC03_parentStrongAndWeakChildKeepsChildAlive() {
        val scenario = createParentStrongAndWeakChild()

        forceGc()

        assertEquals(306, scenario.root.ref!!.strong!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createParentAfterClearingStrongChild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(307)
        val child = Payload(308)
        parent.strong = child
        parent.weak = WeakReference(child)
        parent.strong = null
        return WeakOnlyResult(Root(parent), parent.weak!!)
    }

    /**
     * WR-C04
     * Scenario: parent initially has strong and weak edges to child, then strong edge is cleared.
     * Expectation: child can be collected and weak.value becomes null.
     */
    @Test
    fun wrC04_clearingStrongChildLeavesOnlyWeakAndCollectsChild() {
        val scenario = createParentAfterClearingStrongChild()

        forceGc()

        assertEquals(307, scenario.root.ref!!.id)
        assertNull(scenario.root.ref!!.strong)
        assertNull(scenario.weak.value)
    }

    private fun createChildWeakParentWithOnlyChildRoot(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(309)
        val child = Payload(310)
        child.weak = WeakReference(parent)
        return WeakOnlyResult(Root(child), child.weak!!)
    }

    /**
     * WR-C05
     * Scenario: root points to child, and child weakly points to parent.
     * Expectation: parent is not kept alive by child's weak edge.
     */
    @Test
    fun wrC05_childWeakParentDoesNotKeepParentAlive() {
        val scenario = createChildWeakParentWithOnlyChildRoot()

        forceGc()

        assertEquals(310, scenario.root.ref!!.id)
        assertNull(scenario.weak.value)
    }

    /**
     * WR-C06
     * Scenario: root points to parent and child weakly points to parent.
     * Expectation: parent survives because of root, and child weak reference sees a non-null value.
     */
    @Test
    fun wrC06_childWeakParentSeesParentAliveWhenParentHasRoot() {
        val parent = Payload(311)
        val child = Payload(312)
        child.weak = WeakReference(parent)
        val root = Root(parent)

        forceGc()

        assertEquals(311, root.ref!!.id)
        assertNotNull(child.weak!!.value)
        assertEquals(312, child.id)
    }

    private fun createSiblingWeakEdge(): WeakOnlyResult<Root<Payload>, Payload> {
        val left = Payload(313)
        val right = Payload(314)
        left.weak = WeakReference(right)
        return WeakOnlyResult(Root(left), left.weak!!)
    }

    /**
     * WR-C07
     * Scenario: root -> left and left weakly points to right sibling.
     * Expectation: right sibling can be collected.
     */
    @Test
    fun wrC07_siblingWeakEdgeDoesNotKeepRightSiblingAlive() {
        val scenario = createSiblingWeakEdge()

        forceGc()

        assertEquals(313, scenario.root.ref!!.id)
        assertNull(scenario.weak.value)
    }

    private fun createSiblingStrongEdge(): WeakOnlyResult<Root<Payload>, Payload> {
        val left = Payload(315)
        val right = Payload(316)
        left.strong = right
        return WeakOnlyResult(Root(left), WeakReference(right))
    }

    /**
     * WR-C08
     * Scenario: root -> left and left strongly points to right sibling.
     * Expectation: right sibling survives.
     */
    @Test
    fun wrC08_siblingStrongEdgeKeepsRightSiblingAlive() {
        val scenario = createSiblingStrongEdge()

        forceGc()

        assertEquals(316, scenario.root.ref!!.strong!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createWeakGrandchild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(317)
        val grandChild = Payload(318)
        parent.weak = WeakReference(grandChild)
        return WeakOnlyResult(Root(parent), parent.weak!!)
    }

    /**
     * WR-C09
     * Scenario: root -> parent and parent weakly points to grandchild.
     * Expectation: grandchild can be collected.
     */
    @Test
    fun wrC09_weakEdgeToGrandChildDoesNotKeepGrandChildAlive() {
        val scenario = createWeakGrandchild()

        forceGc()

        assertEquals(317, scenario.root.ref!!.id)
        assertNull(scenario.weak.value)
    }

    private fun createStrongChildWeakGrandchild(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(319)
        val child = Payload(320)
        val grandChild = Payload(321)
        parent.strong = child
        child.weak = WeakReference(grandChild)
        return WeakOnlyResult(Root(parent), child.weak!!)
    }

    /**
     * WR-C10
     * Scenario: root -> parent -> child, and child weakly points to grandchild.
     * Expectation: parent and child survive, but grandchild can be collected.
     */
    @Test
    fun wrC10_strongChildWeakGrandChildDoesNotKeepGrandChildAlive() {
        val scenario = createStrongChildWeakGrandchild()

        forceGc()

        assertEquals(320, scenario.root.ref!!.strong!!.id)
        assertNull(scenario.weak.value)
    }

    /**
     * WR-C11
     * Scenario: target is strongly reachable from root and also weakly referenced by another holder.
     * Expectation: target survives and weak.value is non-null.
     */
    @Test
    fun wrC11_weakEdgeToAlreadyStrongReachableTargetRemainsNonNull() {
        val target = Payload(322)
        val holder = WeakHolder(WeakReference(target))
        val root = Root(target)

        forceGc()

        assertEquals(322, root.ref!!.id)
        assertNotNull(holder.weak!!.value)
    }

    private fun createWeakEdgeToSubgraphRoot(): MixedWeakResult<Root<WeakHolder<Payload>>, Payload> {
        val subRoot = Payload(323)
        val leaf = Payload(324)
        subRoot.strong = leaf
        val weakSubRoot = WeakReference(subRoot)
        val weakLeaf = WeakReference(leaf)
        val holder = WeakHolder(weakSubRoot)
        return MixedWeakResult(Root(holder), emptyList(), listOf(weakSubRoot, weakLeaf))
    }

    /**
     * WR-C12
     * Scenario: holder weakly points to the root of a child subgraph.
     * Expectation: weak edge does not keep either subgraph root or leaf alive.
     */
    @Test
    fun wrC12_weakEdgeToSubgraphRootDoesNotKeepSubgraphAlive() {
        val scenario = createWeakEdgeToSubgraphRoot()

        forceGc()

        assertNotNull(scenario.root.ref)
        assertAllWeakCollected(scenario.collectedWeaks)
    }
}
