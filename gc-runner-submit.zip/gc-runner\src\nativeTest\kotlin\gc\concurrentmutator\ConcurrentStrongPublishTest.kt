@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-B group: publishing new strong references while GC is interleaved.
 */
class ConcurrentStrongPublishTest : ConcurrentGcTestSupport() {

    /**
     * CG-B01
     * Scenario: mutator publishes object through normal field while GC is running around mutation.
     * Expectation: published object remains alive.
     */
    @Test
    fun cgB01_publishNormalFieldDuringGc() {
        forceGc()
        val (holder, weak) = publishField(201)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

    /**
     * CG-B02
     * Scenario: mutator publishes object through nullable field.
     * Expectation: published object remains alive.
     */
    @Test
    fun cgB02_publishNullableFieldDuringGc() {
        val holder = Holder<Node>(null)
        val node = Node(202)
        val weak = WeakReference(node)
        runGcAroundMutation { holder.ref = node }
        assertEquals(202, holder.ref!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B03
     * Scenario: mutator publishes objects through left and right fields.
     * Expectation: both published objects remain alive.
     */
    @Test
    fun cgB03_publishLeftRightFieldsDuringGc() {
        val root = Node(203)
        val left = Node(204)
        val right = Node(205)
        val weakLeft = WeakReference(left)
        val weakRight = WeakReference(right)
        runGcAroundMutation { root.left = left
        root.right = right }
        assertEquals(204, root.left!!.id)
        assertEquals(205, root.right!!.id)
        assertNotNull(weakLeft.value)
        assertNotNull(weakRight.value)
    }

    /**
     * CG-B04
     * Scenario: mutator attaches a new chain to a reachable holder.
     * Expectation: chain head and tail remain alive.
     */
    @Test
    fun cgB04_publishNewChainDuringGc() {
        forceGc()
        val (holder, weaks) = publishChain(206)
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
        assertNotNull(holder.ref)
    }

    /**
     * CG-B05
     * Scenario: mutator attaches a new tree to a reachable holder.
     * Expectation: tree nodes remain alive.
     */
    @Test
    fun cgB05_publishNewTreeDuringGc() {
        forceGc()
        val (holder, weaks) = publishTree(220)
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
        assertNotNull(holder.ref)
    }

    /**
     * CG-B06
     * Scenario: mutator attaches a new cycle to a reachable holder.
     * Expectation: cycle nodes remain alive.
     */
    @Test
    fun cgB06_publishNewCycleDuringGc() {
        forceGc()
        val (holder, weaks) = publishCycle(230)
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] to remain alive.")
        }
        assertNotNull(holder.ref)
    }

    /**
     * CG-B07
     * Scenario: object initially observed only by weak reference is later published strongly.
     * Expectation: published object remains alive.
     */
    @Test
    fun cgB07_publishPreviouslyWeakOnlyObjectDuringGc() {
        val holder = Holder<Node>(null)
        val node = Node(240)
        val weak = WeakReference(node)
        runGcAroundMutation { holder.ref = node }
        assertEquals(240, holder.ref!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B08
     * Scenario: two parents publish the same shared child.
     * Expectation: shared child remains alive.
     */
    @Test
    fun cgB08_publishSharedSubgraphDuringGc() {
        val graph = buildSharedGraph(250)
        val weak = WeakReference(graph.shared)
        runGcAroundMutation { globalHolder.ref = graph.parent1
        graph.parent1.right = graph.parent2 }
        assertEquals(252, graph.parent1.left!!.id)
        assertEquals(252, graph.parent2.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B09
     * Scenario: mutator publishes lambda capturing payload.
     * Expectation: captured object remains alive.
     */
    @Test
    fun cgB09_publishLambdaCaptureDuringGc() {
        val node = Node(260)
        val weak = WeakReference(node)
        val holder = LambdaHolder(null)
        runGcAroundMutation { holder.block = { node.id } }
        assertEquals(260, holder.block!!())
        assertNotNull(weak.value)
    }

    /**
     * CG-B10
     * Scenario: mutator writes object into generic Box.value.
     * Expectation: box value remains alive.
     */
    @Test
    fun cgB10_publishGenericBoxValueDuringGc() {
        val box = Box<Node>(null)
        val node = Node(270)
        val weak = WeakReference(node)
        runGcAroundMutation { box.value = node }
        assertEquals(270, box.value!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B11
     * Scenario: mutator publishes object through global root.
     * Expectation: global object remains alive.
     */
    @Test
    fun cgB11_publishGlobalObjectDuringGc() {
        val node = Node(280)
        val weak = WeakReference(node)
        runGcAroundMutation { globalNode = node }
        assertEquals(280, globalNode!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B12
     * Scenario: mutator publishes object through ThreadLocal root.
     * Expectation: ThreadLocal object remains alive in current thread.
     */
    @Test
    fun cgB12_publishThreadLocalObjectDuringGc() {
        val node = Node(290)
        val weak = WeakReference(node)
        runGcAroundMutation { threadLocalNode = node }
        assertEquals(290, threadLocalNode!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B13
     * Scenario: producer publishes object and consumer reads it after GC window.
     * Expectation: consumer sees valid object or null-safe state.
     */
    @Test
    fun cgB13_producerConsumerPublishDuringGc() {
        val shared = Holder<Node>(null)
        val produced = Node(300)
        val weak = WeakReference(produced)
        runGcAroundMutation { shared.ref = produced }
        val consumed = shared.ref
        assertEquals(300, consumed!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-B14
     * Scenario: writer repeatedly publishes new objects across repeated GC.
     * Expectation: last object remains alive.
     */
    @Test
    fun cgB14_repeatedStrongPublishAcrossGc() {
        forceGc()
        val (holder, weak) = stressFieldReplacement(32)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

}
