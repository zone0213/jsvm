@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * E group: reachability through arrays and Kotlin collections.
 */
class ArrayCollectionReachabilityTest : ReachabilityTestSupport() {

    private fun createArrayRoot(): RootedWeak<Array<Payload?>, Payload> {
        val obj = Payload(401)
        val array = arrayOfNulls<Payload>(1)
        array[0] = obj

        return RootedWeak(
            root = array,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-E01
     * Scenario: an array element strongly references a Payload.
     * Expectation: the element target remains reachable through the root array.
     */
    @Test
    fun rcE01_arrayElementKeepsObjectAlive() {
        val scenario = createArrayRoot()

        forceGc()

        assertEquals(401, scenario.root[0]!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createArrayClearedElementRoot(): RootedWeak<Array<Payload?>, Payload> {
        val obj = Payload(402)
        val array = arrayOfNulls<Payload>(1)
        array[0] = obj
        val weak = WeakReference(obj)

        array[0] = null

        return RootedWeak(
            root = array,
            weak = weak
        )
    }

    /**
     * RC-E02
     * Scenario: an array element is set to null.
     * Expectation: after the helper stack frame returns, the former element object can be collected.
     */
    @Test
    fun rcE02_clearingArrayElementAllowsCollection() {
        val scenario = createArrayClearedElementRoot()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root[0])
    }

    private fun createArrayReplacementRoot(): HolderReplacementResult<Array<Payload?>, Payload> {
        val oldObj = Payload(403)
        val array = arrayOfNulls<Payload>(1)
        array[0] = oldObj
        val oldWeak = WeakReference(oldObj)

        val newObj = Payload(430)
        array[0] = newObj
        val newWeak = WeakReference(newObj)

        return HolderReplacementResult(
            holder = array,
            oldWeak = oldWeak,
            newWeak = newWeak
        )
    }

    /**
     * RC-E03
     * Scenario: an array element is replaced.
     * Expectation: the old element can be collected, while the new element remains reachable.
     */
    @Test
    fun rcE03_arrayElementReplacementReleasesOldObjectAndKeepsNewObjectAlive() {
        val result = createArrayReplacementRoot()

        forceGc()

        assertNull(result.oldWeak.value)
        assertNotNull(result.newWeak.value)
        assertEquals(430, result.holder[0]!!.id)
    }

    private fun createListRoot(): RootedWeak<MutableList<Payload>, Payload> {
        val obj = Payload(404)
        val list = mutableListOf(obj)

        return RootedWeak(
            root = list,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-E04
     * Scenario: a MutableList element strongly references a Payload.
     * Expectation: the list element remains reachable through the root list.
     */
    @Test
    fun rcE04_mutableListElementKeepsObjectAlive() {
        val scenario = createListRoot()

        forceGc()

        assertEquals(404, scenario.root[0].id)
        assertNotNull(scenario.weak.value)
    }

    private fun createListAfterRemove(): RootedWeak<MutableList<Payload>, Payload> {
        val obj = Payload(405)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)

        list.remove(obj)

        return RootedWeak(
            root = list,
            weak = weak
        )
    }

    /**
     * RC-E05
     * Scenario: a MutableList element is removed.
     * Expectation: the removed object can be collected.
     */
    @Test
    fun rcE05_mutableListRemoveAllowsCollection() {
        val scenario = createListAfterRemove()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createListAfterClear(): RootedWeak<MutableList<Payload>, Payload> {
        val obj = Payload(406)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)

        list.clear()

        return RootedWeak(
            root = list,
            weak = weak
        )
    }

    /**
     * RC-E06
     * Scenario: a MutableList is cleared.
     * Expectation: the previously contained object can be collected.
     */
    @Test
    fun rcE06_mutableListClearAllowsCollection() {
        val scenario = createListAfterClear()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createMapKeyRoot(): RootedWeak<MutableMap<Payload, String>, Payload> {
        val key = Payload(407)
        val map = mutableMapOf(key to "value")

        return RootedWeak(
            root = map,
            weak = WeakReference(key)
        )
    }

    /**
     * RC-E07
     * Scenario: a MutableMap key strongly references a Payload.
     * Expectation: the key remains reachable through the root map.
     */
    @Test
    fun rcE07_mutableMapKeyKeepsObjectAlive() {
        val scenario = createMapKeyRoot()

        forceGc()

        val key = scenario.root.keys.single()
        assertEquals(407, key.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createMapValueRoot(): RootedWeak<MutableMap<String, Payload>, Payload> {
        val value = Payload(408)
        val map = mutableMapOf("key" to value)

        return RootedWeak(
            root = map,
            weak = WeakReference(value)
        )
    }

    /**
     * RC-E08
     * Scenario: a MutableMap value strongly references a Payload.
     * Expectation: the value remains reachable through the root map.
     */
    @Test
    fun rcE08_mutableMapValueKeepsObjectAlive() {
        val scenario = createMapValueRoot()

        forceGc()

        assertEquals(408, scenario.root["key"]!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createMapAfterRemovingPayloadKey(): RootedWeak<MutableMap<Payload, String>, Payload> {
        val key = Payload(409)
        val map = mutableMapOf(key to "value")
        val weak = WeakReference(key)

        map.remove(key)

        return RootedWeak(
            root = map,
            weak = weak
        )
    }

    /**
     * RC-E09
     * Scenario: a MutableMap entry is removed by its Payload key.
     * Expectation: the removed key object can be collected.
     */
    @Test
    fun rcE09_mutableMapRemoveKeyAllowsKeyCollection() {
        val scenario = createMapAfterRemovingPayloadKey()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createMapAfterRemovingPayloadValue(): RootedWeak<MutableMap<String, Payload>, Payload> {
        val value = Payload(410)
        val map = mutableMapOf("key" to value)
        val weak = WeakReference(value)

        map.remove("key")

        return RootedWeak(
            root = map,
            weak = weak
        )
    }

    /**
     * RC-E10
     * Scenario: a MutableMap entry containing a Payload value is removed.
     * Expectation: the removed value object can be collected.
     */
    @Test
    fun rcE10_mutableMapRemoveEntryAllowsValueCollection() {
        val scenario = createMapAfterRemovingPayloadValue()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createNestedListRoot(): RootedWeak<MutableList<MutableList<Payload>>, Payload> {
        val obj = Payload(411)
        val inner = mutableListOf(obj)
        val outer = mutableListOf(inner)

        return RootedWeak(
            root = outer,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-E11
     * Scenario: a nested collection path reaches Payload through outer[0][0].
     * Expectation: the object remains reachable through the nested collection path.
     */
    @Test
    fun rcE11_nestedCollectionKeepsObjectAlive() {
        val scenario = createNestedListRoot()

        forceGc()

        assertEquals(411, scenario.root[0][0].id)
        assertNotNull(scenario.weak.value)
    }

    private fun createNestedListAfterClear(): RootedWeak<MutableList<MutableList<Payload>>, Payload> {
        val obj = Payload(412)
        val inner = mutableListOf(obj)
        val outer = mutableListOf(inner)
        val weak = WeakReference(obj)

        inner.clear()

        return RootedWeak(
            root = outer,
            weak = weak
        )
    }

    /**
     * RC-E12
     * Scenario: the inner collection in a nested collection path is cleared.
     * Expectation: the previously contained object can be collected.
     */
    @Test
    fun rcE12_nestedCollectionClearAllowsCollection() {
        val scenario = createNestedListAfterClear()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root[0].size)
    }
}
