@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-I group: return-value safepoints and caller temporaries.
 */
class PreciseStackSafepointReturnTest : PreciseStackTestSupport() {
    private fun createPayload(id: Int): StackPayload = StackPayload(id)

    private fun createAnyPayload(id: Int): Any = StackPayload(id)

    private fun createMarkerPayload(id: Int): PreciseStackMarker = StackPayload(id)

    private fun <T : PreciseStackMarker> identity(value: T): T = value

    private fun consumeReturned(value: StackPayload): WeakReference<StackPayload> {
        val weak = WeakReference(value)
        forceGc()
        assertEquals(value.id, weak.value!!.id)
        return weak
    }

    /**
     * PS-I01
     * Scenario: caller stores a returned object and GC runs before last use.
     * Expectation: caller return-value local remains live at safepoint.
     */
    @Test
    fun psI01_storedReturnValueSurvivesGcBeforeUse() {
        val obj = createPayload(9001)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(9001, obj.id)
        assertEquals(9001, weak.value!!.id)
    }

    /**
     * PS-I02
     * Scenario: returned object is passed directly into another callee that triggers GC.
     * Expectation: return/call temporary remains live through the callee safepoint.
     */
    @Test
    fun psI02_returnValuePassedAsCallArgumentSurvivesGc() {
        val weak = consumeReturned(createPayload(9002))

        assertEquals(9002, weak.value!!.id)
    }

    /**
     * PS-I03
     * Scenario: returned object has static type Any and is cast after GC.
     * Expectation: erased return-value local remains live.
     */
    @Test
    fun psI03_anyTypedReturnValueSurvivesGc() {
        val obj: Any = createAnyPayload(9003)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(9003, (obj as StackPayload).id)
        assertEquals(9003, (weak.value as StackPayload).id)
    }

    /**
     * PS-I04
     * Scenario: returned object has interface static type and is used after GC.
     * Expectation: interface-typed return local is scanned as a root.
     */
    @Test
    fun psI04_interfaceTypedReturnValueSurvivesGc() {
        val obj: PreciseStackMarker = createMarkerPayload(9004)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(9004, obj.id)
        assertEquals(9004, weak.value!!.id)
    }

    /**
     * PS-I05
     * Scenario: generic identity returns a payload used after GC.
     * Expectation: generic return value is preserved in caller root map.
     */
    @Test
    fun psI05_genericReturnValueSurvivesGc() {
        val obj = identity(StackPayload(9005))
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(9005, obj.id)
        assertEquals(9005, weak.value!!.id)
    }
}

