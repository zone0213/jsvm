﻿import { runAllGcTests } from './src/nativeTest/arkts/GcTestRunner';

async function main(): Promise<void> {
    const summary = await runAllGcTests();
    console.log(`Passed ${summary.passed} tests in ${summary.classes} classes.`);

    if (summary.failed > 0) {
        console.error(`Failed ${summary.failed} tests:`);
        for (const failure of summary.failures) {
            console.error(`${failure.suite} ${failure.test}: ${failure.message}`);
        }
        process.exit(1);
    }
}

main().catch((error: unknown) => {
    console.error(error);
    process.exit(1);
});
