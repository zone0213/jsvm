@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * PS-F group: allocation safepoints and precise stack roots.
 */
class PreciseStackSafepointAllocationTest : PreciseStackTestSupport() {
    private fun allocateGarbage(count: Int) {
        var checksum = 0
        repeat(count) { index ->
            checksum += StackPayload(6000 + index).id
        }
        assertTrue(checksum > 0)
    }

    /**
     * PS-F01
     * Scenario: a live local reference exists while allocation pressure creates GC safepoints.
     * Expectation: allocation safepoint root map keeps the live local object alive.
     */
    @Test
    fun psF01_liveLocalSurvivesAllocationSafepoints() {
        val obj = StackPayload(6001)
        val weak = WeakReference(obj)

        allocateGarbage(256)
        forceGc()

        assertEquals(6001, obj.id)
        assertEquals(6001, weak.value!!.id)
    }

    /**
     * PS-F02
     * Scenario: a live child graph is reachable through a local root during allocation pressure.
     * Expectation: allocation safepoints keep both parent and child reachable.
     */
    @Test
    fun psF02_liveChildGraphSurvivesAllocationSafepoints() {
        val root = StackPayload(6002, StackPayload(6020))
        val childWeak = WeakReference(root.child!!)

        allocateGarbage(256)
        forceGc()

        assertEquals(6020, root.child!!.id)
        assertEquals(6020, childWeak.value!!.id)
    }

    /**
     * PS-F03
     * Scenario: a dead local root is cleared before allocation pressure.
     * Expectation: allocation safepoints do not retain the cleared stack slot.
     */
    @Test
    fun psF03_clearedLocalIsCollectedAfterAllocationSafepoints() {
        var obj: StackPayload? = StackPayload(6003)
        val weak = WeakReference(obj!!)

        obj = null
        allocateGarbage(256)

        assertEquals(null, obj)
        assertWeakCollected(weak)
    }

    /**
     * PS-F04
     * Scenario: a live lambda capture exists while allocation pressure runs.
     * Expectation: captured object remains reachable through the live lambda object.
     */
    @Test
    fun psF04_liveLambdaCaptureSurvivesAllocationSafepoints() {
        val obj = StackPayload(6004)
        val weak = WeakReference(obj)
        val block = { obj.id }

        allocateGarbage(256)
        forceGc()

        assertEquals(6004, block())
        assertEquals(6004, weak.value!!.id)
    }

    /**
     * PS-F05
     * Scenario: a live local root is present while a large allocation happens before GC.
     * Expectation: large allocation path does not lose the live stack root.
     */
    @Test
    fun psF05_liveLocalSurvivesLargeAllocationSafepoint() {
        val obj = StackPayload(6005)
        val weak = WeakReference(obj)
        val bytes = ByteArray(64 * 1024) { index -> index.toByte() }

        forceGc()

        assertEquals(0, bytes[0].toInt())
        assertEquals(6005, obj.id)
        assertEquals(6005, weak.value!!.id)
    }
}

