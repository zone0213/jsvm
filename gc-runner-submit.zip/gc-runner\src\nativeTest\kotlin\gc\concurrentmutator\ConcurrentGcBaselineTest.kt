@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-A group: concurrent GC baseline and synchronization-window tests.
 */
class ConcurrentGcBaselineTest : ConcurrentGcTestSupport() {

    /**
     * CG-A01
     * Scenario: single-thread mutator and manual GC baseline.
     * Expectation: object remains alive after GC.
     */
    @Test
    fun cgA01_singleThreadGcBaseline() {
        assertTrue(singleThreadBaseline())
    }

    /**
     * CG-A02
     * Scenario: worker holds object while main thread performs GC.
     * Expectation: worker can still access object.
     */
    @Test
    fun cgA02_workerHoldsObjectMainThreadGc() {
        assertTrue(runWorkerMutationWithMainGc { val node = Node(102)
        val weak = WeakReference(node)
        GC.collect()
        node.id == 102 && weak.value != null })
    }

    /**
     * CG-A03
     * Scenario: main holds object while worker thread performs GC.
     * Expectation: main object remains alive.
     */
    @Test
    fun cgA03_mainHoldsObjectWorkerThreadGc() {
        val node = Node(103)
        val weak = WeakReference(node)
        assertTrue(runWorkerTask { GC.collect()
        true })
        assertEquals(103, node.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-A04
     * Scenario: independent worker repeatedly triggers GC while mutator is idle.
     * Expectation: no crash and worker completes.
     */
    @Test
    fun cgA04_gcWorkerLoopWithIdleMutator() {
        assertTrue(runWorkerTask { repeat(16) { GC.collect() }
        true })
    }

    /**
     * CG-A05
     * Scenario: mutator repeatedly writes holder.ref while GC is repeatedly triggered.
     * Expectation: no crash and writes occur.
     */
    @Test
    fun cgA05_mutatorLoopWritesWhileGcCollects() {
        val holder = Holder<Node>(null)
        val count = repeatMutationWithGc { holder.ref = Node(1050 + it) }
        assertEquals(SMALL_ITERATIONS, count)
        assertNotNull(holder.ref)
    }

    /**
     * CG-A06
     * Scenario: multiple bounded mutators start and complete write loops.
     * Expectation: all bounded writers complete.
     */
    @Test
    fun cgA06_multipleMutatorEmptyWriteBaseline() {
        val completed = runBoundedConcurrentWriters(2) { writer, i -> globalHolder.ref = Node(10600 + writer * 100 + i) }
        assertEquals(2, completed)
        assertNotNull(globalHolder.ref)
    }

    /**
     * CG-A07
     * Scenario: bounded mutation window around GC is exercised.
     * Expectation: mutation completes without deadlock.
     */
    @Test
    fun cgA07_readyContinueGateLikeBaseline() {
        var mutated = false
        runGcAroundMutation { mutated = true }
        assertTrue(mutated)
    }

    /**
     * CG-A08
     * Scenario: single-thread allocation pressure with GC.
     * Expectation: no crash.
     */
    @Test
    fun cgA08_allocationPressureBaseline() {
        allocateGarbage()
        forceGc()
        assertTrue(true)
    }

    /**
     * CG-A09
     * Scenario: repeated GC collect baseline.
     * Expectation: no crash.
     */
    @Test
    fun cgA09_repeatedGcCollectBaseline() {
        forceGcLoop()
        assertTrue(true)
    }

    /**
     * CG-A10
     * Scenario: bounded loop simulates timeout-safe concurrent test structure.
     * Expectation: loop completes.
     */
    @Test
    fun cgA10_boundedTimeoutStyleBaseline() {
        val count = repeatMutationWithGc(8) { allocateGarbage(16) }
        assertEquals(8, count)
    }

}
