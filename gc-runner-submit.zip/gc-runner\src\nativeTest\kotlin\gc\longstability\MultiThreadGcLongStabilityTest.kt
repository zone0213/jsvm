@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * LS-G group: multi-thread allocator and GC long-stability tests.
 */
class MultiThreadGcLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-G01
     * Scenario: multi-thread small churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g01_multiThreadSmallChurn() {
        assertEquals(WORKER_COUNT, runPseudoWorkers { _, i -> LsNode(i) })
    }

    /**
     * LS-G02
     * Scenario: multi-thread large churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g02_multiThreadLargeChurn() {
        assertEquals(WORKER_COUNT, runPseudoWorkers { _, i -> LargePayload(i, ByteArray(1024)) })
    }

    /**
     * LS-G03
     * Scenario: multi-thread mixed churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g03_multiThreadMixedChurn() {
        assertEquals(WORKER_COUNT, runPseudoWorkers { _, i -> MixedPayload(i) })
    }

    /**
     * LS-G04
     * Scenario: multi-thread long-lived roots.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g04_multiThreadLongLivedRoots() {
        val completed = runPseudoWorkers { worker, i ->
            val root = LsNode(worker)
            repeat(8) { index ->
                LsNode(i * 10 + index)
            }
            assertEquals(worker, root.id)
        }
        assertEquals(WORKER_COUNT, completed)
    }

    /**
     * LS-G05
     * Scenario: worker exit releases objects.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g05_workerExitReleasesObjects() {
        fun makeWeak(): WeakReference<LsNode> {
            val node = LsNode(5)
            return WeakReference(node)
        }
        assertWeakCollectedEventually(makeWeak())
        assertEquals(WORKER_COUNT, WORKER_COUNT)
    }

    /**
     * LS-G06
     * Scenario: GC thread with mutator progress.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g06_gcThreadWithMutatorProgress() {
        val completed = runPseudoWorkers { _, i ->
            LsNode(i)
            if (i % 3 == 0) {
                kotlin.native.runtime.GC.collect()
            }
        }
        assertEquals(WORKER_COUNT, completed)
    }

    /**
     * LS-G07
     * Scenario: each worker runs GC.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g07_eachWorkerRunsGc() {
        val completed = runPseudoWorkers { _, i ->
            LsNode(i)
            kotlin.native.runtime.GC.collect()
        }
        assertEquals(WORKER_COUNT, completed)
    }

    /**
     * LS-G08
     * Scenario: main samples GCInfo while workers run.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g08_mainSamplesGcinfoWhileWorkersRun() {
        val completed = runPseudoWorkers { _, i -> MediumPayload(i) }
        assertGcInfoReadable()
        assertEquals(WORKER_COUNT, completed)
    }

    /**
     * LS-G09
     * Scenario: multi-thread spike.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g09_multiThreadSpike() {
        assertEquals(WORKER_COUNT, runPseudoWorkers { _, i -> LargePayload(i, ByteArray(2048)) })
    }

    /**
     * LS-G10
     * Scenario: multi-thread release-reallocate.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_g10_multiThreadReleaseReallocate() {
        val completed = runPseudoWorkers { _, i ->
            val list = mutableListOf<LsNode>()
            list.add(LsNode(i))
            list.clear()
        }
        assertEquals(WORKER_COUNT, completed)
    }

}
