@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class,
    kotlinx.cinterop.ExperimentalForeignApi::class,
)

package gc.rootset

import kotlinx.cinterop.StableRef
import kotlin.native.concurrent.ThreadLocal
import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Common infrastructure for Kotlin/Native GC root-set reachability tests.
 *
 * Scope:
 * - Validates whether different root-set categories keep objects alive.
 * - Uses WeakReference as the main lifetime oracle.
 * - Keeps the graph behind each root intentionally small so the focus remains on root scanning.
 */
open class RootSetTestSupport {
    @BeforeTest
    fun resetBeforeTest() {
        clearMutableRoots()
        forceGc()
    }

    @AfterTest
    fun resetAfterTest() {
        clearMutableRoots()
        forceGc()
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun clearMutableRoots() {
        globalPayload = null
        globalAny = null
        globalMarker = null
        globalHolder = null
        globalArray = null
        globalList = null
        globalMap = null
        ObjectRootHolder.payload = null
        ObjectRootHolder.holder = null
        CompanionRootHolder.payload = null
        CompanionRootHolder.holder = null
        clearableLateinitLikePayload = null
        threadLocalPayload = null
        threadLocalAny = null
        threadLocalMarker = null
        threadLocalHolder = null
        threadLocalList = null
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected object to remain reachable from a root.",
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollected(
        weak: WeakReference<T>,
        message: String = "Expected object to become unreachable after root disappears.",
    ) {
        forceGc()
        assertNull(weak.value, message)
    }

    protected fun <T : Any> assertAllWeakAlive(weaks: Iterable<WeakReference<T>>) {
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] value to remain alive.")
        }
    }

    protected fun <T : Any> assertAllWeakCollected(weaks: Iterable<WeakReference<T>>) {
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNull(weak.value, "Expected weak[$index] value to be cleared.")
        }
    }

    protected fun <T : Any> stableRefOf(value: T): StableRef<T> = StableRef.create(value)

    protected fun runWorkerBoolean(task: () -> Boolean): Boolean {
        val worker = Worker.start()
        return try {
            worker.execute(TransferMode.SAFE, { task }) { it() }.result
        } finally {
            worker.requestTermination().result
        }
    }

    companion object {
        private const val GC_REPEAT_COUNT = 3
    }
}

interface RootMarker {
    val id: Int
}

class RootPayload(
    override val id: Int,
    var child: RootPayload? = null,
) : RootMarker {
    override fun toString(): String = "RootPayload(id=$id)"
}

class MarkerPayload(
    override val id: Int,
) : RootMarker

class RootHolder<T : Any>(
    var ref: T?,
)

class RootBox<T : Any>(
    var value: T?,
)

class RootWrapper<T : Any>(
    var ref: T?,
)

data class RootedWeak<R : Any, T : Any>(
    val root: R,
    val weak: WeakReference<T>,
)

data class MixedRootWeaks<R : Any, T : Any>(
    val root: R,
    val aliveWeaks: List<WeakReference<T>>,
    val collectedWeaks: List<WeakReference<T>>,
)

data class ReplacementRoot<R : Any, T : Any>(
    val root: R,
    val oldWeak: WeakReference<T>,
    val newWeak: WeakReference<T>,
)

class PayloadException(
    val payload: RootPayload,
) : Throwable("payload exception")

class FailingInitializer(
    observer: (RootPayload) -> Unit,
) {
    val payload: RootPayload = RootPayload(4012).also(observer)

    init {
        error("intentional initialization failure")
    }
}

class LocalLazyRootHolder {
    var initCount: Int = 0
    val payload: RootPayload by lazy {
        initCount += 1
        RootPayload(4002)
    }
    val payloadWithChild: RootPayload by lazy {
        initCount += 1
        RootPayload(4003, RootPayload(40031))
    }
    val holder: RootHolder<RootPayload> by lazy {
        initCount += 1
        RootHolder(RootPayload(4004))
    }
}

object ObjectLazyRootHolder {
    val payload: RootPayload by lazy { RootPayload(4005) }
}

class CompanionLazyRootHolder {
    companion object {
        val payload: RootPayload by lazy { RootPayload(4006) }
    }
}

var globalPayload: RootPayload? = null
var globalAny: Any? = null
var globalMarker: RootMarker? = null
var globalHolder: RootHolder<RootPayload>? = null
var globalArray: Array<RootPayload?>? = null
var globalList: MutableList<RootPayload>? = null
var globalMap: MutableMap<String, RootPayload>? = null

lateinit var lateinitPayload: RootPayload
lateinit var lateinitHolder: RootHolder<RootPayload>
var clearableLateinitLikePayload: RootPayload? = null

object ObjectRootHolder {
    var payload: RootPayload? = null
    var holder: RootHolder<RootPayload>? = null
}

class CompanionRootHolder {
    companion object {
        var payload: RootPayload? = null
        var holder: RootHolder<RootPayload>? = null
    }
}

@ThreadLocal
var threadLocalPayload: RootPayload? = null

@ThreadLocal
var threadLocalAny: Any? = null

@ThreadLocal
var threadLocalMarker: RootMarker? = null

@ThreadLocal
var threadLocalHolder: RootHolder<RootPayload>? = null

@ThreadLocal
var threadLocalList: MutableList<RootPayload>? = null
