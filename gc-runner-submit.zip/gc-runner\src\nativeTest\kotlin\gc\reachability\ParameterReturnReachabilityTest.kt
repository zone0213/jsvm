@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

/**
 * B group: function parameter roots and returned-value roots.
 */
class ParameterReturnReachabilityTest : ReachabilityTestSupport() {

    private fun checkPayloadParameter(obj: Payload): WeakReference<Payload> {
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    /**
     * RC-B01
     * Scenario: function parameter has static type Payload.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    @Test
    fun rcB01_functionParameterKeepsPayloadAlive() {
        val obj = Payload(101)
        val weak = checkPayloadParameter(obj)

        assertEquals(101, obj.id)
        assertNotNull(weak.value)
    }

    private fun checkAnyParameter(obj: Any): WeakReference<Any> {
        val weak = WeakReference(obj)

        forceGc()

        assertNotNull(weak.value)
        return weak
    }

    /**
     * RC-B02
     * Scenario: function parameter has static type Any and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    @Test
    fun rcB02_anyTypedFunctionParameterKeepsRuntimeObjectAlive() {
        val obj: Any = Payload(102)
        val weak = checkAnyParameter(obj)

        assertEquals(102, (obj as Payload).id)
        assertNotNull(weak.value)
    }

    private fun checkInterfaceParameter(obj: Marker): WeakReference<Marker> {
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    /**
     * RC-B03
     * Scenario: function parameter has static type Marker and runtime type Payload.
     * Expectation: the parameter keeps the runtime object alive inside the callee.
     */
    @Test
    fun rcB03_interfaceTypedFunctionParameterKeepsRuntimeObjectAlive() {
        val obj: Marker = Payload(103)
        val weak = checkInterfaceParameter(obj)

        assertEquals(103, obj.id)
        assertNotNull(weak.value)
    }

    private fun checkNullableParameter(obj: Payload?): WeakReference<Payload> {
        val nonNullObj = obj!!
        val weak = WeakReference(nonNullObj)

        forceGc()

        assertEquals(nonNullObj.id, weak.value!!.id)
        return weak
    }

    /**
     * RC-B04
     * Scenario: function parameter has nullable static type Payload? and holds a non-null object.
     * Expectation: the parameter keeps the object alive inside the callee.
     */
    @Test
    fun rcB04_nullableFunctionParameterKeepsObjectAlive() {
        val obj: Payload? = Payload(104)
        val weak = checkNullableParameter(obj)

        assertEquals(104, obj!!.id)
        assertNotNull(weak.value)
    }

    private fun createPayload(id: Int): Payload = Payload(id)

    /**
     * RC-B05
     * Scenario: a function returns a Payload and the caller stores the returned value.
     * Expectation: the returned object remains alive through the caller's local root.
     */
    @Test
    fun rcB05_returnedValueStoredByCallerKeepsObjectAlive() {
        val obj = createPayload(105)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(105, obj.id)
        assertNotNull(weak.value)
    }

    private fun createReturnedValueButOnlyWeakEscapes(): WeakReference<Payload> {
        val obj = createPayload(106)
        return WeakReference(obj)
    }

    /**
     * RC-B06
     * Scenario: a created returned-like object is not kept by a strong reference;
     * only WeakReference escapes the helper frame.
     * Expectation: the object can be collected.
     */
    @Test
    fun rcB06_returnedValueWithoutStrongCallerReferenceCanBeCollected() {
        val weak = createReturnedValueButOnlyWeakEscapes()

        assertWeakCollected(weak)
    }

    /**
     * RC-B07
     * Scenario: a returned Payload is stored in a caller local variable with static type Any.
     * Expectation: the object remains reachable.
     */
    @Test
    fun rcB07_returnedValueStoredAsAnyKeepsObjectAlive() {
        val obj: Any = createPayload(107)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(107, (obj as Payload).id)
        assertNotNull(weak.value)
    }

    /**
     * RC-B08
     * Scenario: a returned Payload is stored in a caller local variable with static type Marker.
     * Expectation: the object remains reachable.
     */
    @Test
    fun rcB08_returnedValueStoredAsInterfaceKeepsObjectAlive() {
        val obj: Marker = createPayload(108)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(108, obj.id)
        assertNotNull(weak.value)
    }
}
