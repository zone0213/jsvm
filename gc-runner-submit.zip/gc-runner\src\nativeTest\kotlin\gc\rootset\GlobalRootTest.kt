@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * RS-C group: global, object singleton and companion root tests.
 */
class GlobalRootTest : RootSetTestSupport() {
    private fun setGlobalPayloadRoot(id: Int): WeakReference<RootPayload> {
        val obj = RootPayload(id)
        globalPayload = obj
        return WeakReference(obj)
    }

/**
     * RS-C01
     * Scenario: top-level var strongly references payload.
     * Expectation: payload remains alive through global root.
     */
    @Test
    fun rsC01_topLevelVarRootKeepsObjectAlive() {
        val weak = setGlobalPayloadRoot(3001)
        forceGc()
        assertEquals(3001, globalPayload!!.id)
        assertNotNull(weak.value)
    }

    private fun clearGlobalPayloadRoot(): WeakReference<RootPayload> {
        val obj = RootPayload(3002)
        globalPayload = obj
        val weak = WeakReference(obj)
        globalPayload = null
        return weak
    }

/**
     * RS-C02
     * Scenario: top-level var root is cleared.
     * Expectation: payload can be collected.
     */
    @Test
    fun rsC02_topLevelVarClearAllowsCollection() {
        val weak = clearGlobalPayloadRoot()
        assertWeakCollected(weak)
    }

    private fun replaceGlobalPayloadRoot(): ReplacementRoot<RootPayload, RootPayload> {
        val oldObj = RootPayload(3003)
        globalPayload = oldObj
        val oldWeak = WeakReference(oldObj)
        val newObj = RootPayload(30030)
        globalPayload = newObj
        val newWeak = WeakReference(newObj)
        return ReplacementRoot(newObj, oldWeak, newWeak)
    }

/**
     * RS-C03
     * Scenario: top-level var root is reassigned.
     * Expectation: old object can be collected and new object remains alive.
     */
    @Test
    fun rsC03_topLevelVarReassignmentCollectsOldKeepsNew() {
        val scenario = replaceGlobalPayloadRoot()
        forceGc()
        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(30030, scenario.root.id)
    }

/**
     * RS-C04
     * Scenario: top-level Any variable references payload.
     * Expectation: runtime payload remains alive.
     */
    @Test
    fun rsC04_topLevelAnyRootKeepsObjectAlive() {
        val obj: Any = RootPayload(3004)
        globalAny = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3004, (globalAny as RootPayload).id)
        assertNotNull(weak.value)
    }

/**
     * RS-C05
     * Scenario: top-level interface variable references payload.
     * Expectation: runtime payload remains alive.
     */
    @Test
    fun rsC05_topLevelInterfaceRootKeepsObjectAlive() {
        val obj: RootMarker = RootPayload(3005)
        globalMarker = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3005, globalMarker!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-C06
     * Scenario: top-level holder variable references payload through field.
     * Expectation: payload remains alive through holder field.
     */
    @Test
    fun rsC06_topLevelHolderRootKeepsValueAlive() {
        val obj = RootPayload(3006)
        globalHolder = RootHolder(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3006, globalHolder!!.ref!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-C07
     * Scenario: top-level payload root references a child.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsC07_topLevelChildGraphRootKeepsChildAlive() {
        val child = RootPayload(30071)
        val obj = RootPayload(3007, child)
        globalPayload = obj
        val childWeak = WeakReference(child)
        forceGc()
        assertEquals(3007, globalPayload!!.id)
        assertEquals(30071, globalPayload!!.child!!.id)
        assertNotNull(childWeak.value)
    }

/**
     * RS-C08
     * Scenario: top-level array contains payload.
     * Expectation: payload remains alive through global array.
     */
    @Test
    fun rsC08_topLevelArrayRootKeepsElementAlive() {
        val obj = RootPayload(3008)
        globalArray = arrayOfNulls<RootPayload>(1)
        globalArray!![0] = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3008, globalArray!![0]!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-C09
     * Scenario: top-level list contains payload.
     * Expectation: payload remains alive through global list.
     */
    @Test
    fun rsC09_topLevelListRootKeepsElementAlive() {
        val obj = RootPayload(3009)
        globalList = mutableListOf(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3009, globalList!!.single().id)
        assertNotNull(weak.value)
    }

/**
     * RS-C10
     * Scenario: top-level map contains payload value.
     * Expectation: payload remains alive through global map.
     */
    @Test
    fun rsC10_topLevelMapRootKeepsValueAlive() {
        val obj = RootPayload(3010)
        globalMap = mutableMapOf("k" to obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3010, globalMap!!["k"]!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-C11
     * Scenario: object singleton field references payload.
     * Expectation: payload remains alive through object root.
     */
    @Test
    fun rsC11_objectSingletonFieldRootKeepsObjectAlive() {
        val obj = RootPayload(3011)
        ObjectRootHolder.payload = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3011, ObjectRootHolder.payload!!.id)
        assertNotNull(weak.value)
    }

    private fun clearObjectSingletonField(): WeakReference<RootPayload> {
        val obj = RootPayload(3012)
        ObjectRootHolder.payload = obj
        val weak = WeakReference(obj)
        ObjectRootHolder.payload = null
        return weak
    }

/**
     * RS-C12
     * Scenario: object singleton field root is cleared.
     * Expectation: payload can be collected.
     */
    @Test
    fun rsC12_objectSingletonFieldClearAllowsCollection() {
        val weak = clearObjectSingletonField()
        assertWeakCollected(weak)
    }

    private fun replaceObjectSingletonField(): ReplacementRoot<RootPayload, RootPayload> {
        val oldObj = RootPayload(3013)
        ObjectRootHolder.payload = oldObj
        val oldWeak = WeakReference(oldObj)
        val newObj = RootPayload(30130)
        ObjectRootHolder.payload = newObj
        val newWeak = WeakReference(newObj)
        return ReplacementRoot(newObj, oldWeak, newWeak)
    }

/**
     * RS-C13
     * Scenario: object singleton field is reassigned.
     * Expectation: old object can be collected and new object remains alive.
     */
    @Test
    fun rsC13_objectFieldReassignmentCollectsOldKeepsNew() {
        val scenario = replaceObjectSingletonField()
        forceGc()
        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(30130, scenario.root.id)
    }

/**
     * RS-C14
     * Scenario: companion object field references payload.
     * Expectation: payload remains alive through companion root.
     */
    @Test
    fun rsC14_companionFieldRootKeepsObjectAlive() {
        val obj = RootPayload(3014)
        CompanionRootHolder.payload = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(3014, CompanionRootHolder.payload!!.id)
        assertNotNull(weak.value)
    }

    private fun clearCompanionField(): WeakReference<RootPayload> {
        val obj = RootPayload(3015)
        CompanionRootHolder.payload = obj
        val weak = WeakReference(obj)
        CompanionRootHolder.payload = null
        return weak
    }

/**
     * RS-C15
     * Scenario: companion object field root is cleared.
     * Expectation: payload can be collected.
     */
    @Test
    fun rsC15_companionFieldClearAllowsCollection() {
        val weak = clearCompanionField()
        assertWeakCollected(weak)
    }

/**
     * RS-C16
     * Scenario: companion field references payload with child.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsC16_companionFieldChildGraphKeepsChildAlive() {
        val child = RootPayload(30161)
        val obj = RootPayload(3016, child)
        CompanionRootHolder.payload = obj
        val childWeak = WeakReference(child)
        forceGc()
        assertEquals(3016, CompanionRootHolder.payload!!.id)
        assertNotNull(childWeak.value)
    }

    private fun removeFromGlobalContainer(): WeakReference<RootPayload> {
        val obj = RootPayload(3017)
        globalList = mutableListOf(obj)
        val weak = WeakReference(obj)
        globalList!!.remove(obj)
        return weak
    }

    private fun clearGlobalContainer(): WeakReference<RootPayload> {
        val obj = RootPayload(3018)
        globalList = mutableListOf(obj)
        val weak = WeakReference(obj)
        globalList!!.clear()
        return weak
    }

/**
     * RS-C17
     * Scenario: payload is removed from global list root.
     * Expectation: removed payload can be collected.
     */
    @Test
    fun rsC17_globalContainerRemoveAllowsCollection() {
        val weak = removeFromGlobalContainer()
        assertWeakCollected(weak)
        assertEquals(0, globalList!!.size)
    }

/**
     * RS-C18
     * Scenario: global list root is cleared.
     * Expectation: previous element can be collected.
     */
    @Test
    fun rsC18_globalContainerClearAllowsCollection() {
        val weak = clearGlobalContainer()
        assertWeakCollected(weak)
        assertEquals(0, globalList!!.size)
    }
}
