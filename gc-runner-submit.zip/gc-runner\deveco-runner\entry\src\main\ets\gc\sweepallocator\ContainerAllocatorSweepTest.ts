﻿import { SweepAllocatorTestSupport } from './SweepAllocatorTestSupport';
import { WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull } from '../TestAssertions';

export class ContainerAllocatorSweepTest extends SweepAllocatorTestSupport {

    sa_j01() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j02() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j03() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j04() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j05() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j06() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j07() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j08() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j09() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j10() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j11() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j12() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j13() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j14() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j15() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }

    sa_j16() {
        const payload = { id: 1000, bytes: new Array<number>(16).fill(1) };
        const weak = new WeakReference(payload);
        this.forceGc();
        assertEquals(1000, payload.id);
        assertNotNull(weak.value);    }
}

