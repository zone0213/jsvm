@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-D group: strong-reference release and WeakReference clearing.
 */
class StrongReleaseWeakClearTest : WeakReferenceTestSupport() {

    private fun createAfterLocalStrongSetNull(): WeakReference<Payload> {
        var obj: Payload? = Payload(401)
        val weak = WeakReference(obj!!)
        obj = null
        assertNull(obj)
        return weak
    }

    /**
     * WR-D01
     * Scenario: a local strong reference is set to null.
     * Expectation: after helper returns, weak.value is cleared.
     */
    @Test
    fun wrD01_localStrongSetNullClearsWeak() {
        val weak = createAfterLocalStrongSetNull()

        assertWeakCollected(weak)
    }

    private fun createAfterHolderStrongClear(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        val obj = Payload(402)
        val holder = StrongHolder(obj)
        val weak = WeakReference(obj)
        holder.ref = null
        return WeakOnlyResult(holder, weak)
    }

    /**
     * WR-D02
     * Scenario: holder strong field is cleared.
     * Expectation: the target can be collected.
     */
    @Test
    fun wrD02_holderStrongFieldClearClearsWeak() {
        val scenario = createAfterHolderStrongClear()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root.ref)
    }

    private fun createAfterGlobalStrongClear(): WeakReference<Payload> {
        val obj = Payload(403)
        globalPayload = obj
        val weak = WeakReference(obj)
        globalPayload = null
        return weak
    }

    /**
     * WR-D03
     * Scenario: global strong reference is cleared.
     * Expectation: weak.value is cleared.
     */
    @Test
    fun wrD03_globalStrongClearClearsWeak() {
        val weak = createAfterGlobalStrongClear()

        assertWeakCollected(weak)
    }

    private fun createAfterCollectionRemove(): WeakOnlyResult<MutableList<Payload>, Payload> {
        val obj = Payload(404)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)
        list.remove(obj)
        return WeakOnlyResult(list, weak)
    }

    /**
     * WR-D04
     * Scenario: object is removed from a strong collection.
     * Expectation: weak.value is cleared.
     */
    @Test
    fun wrD04_collectionRemoveClearsWeak() {
        val scenario = createAfterCollectionRemove()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createAfterCollectionClear(): WeakOnlyResult<MutableList<Payload>, Payload> {
        val obj = Payload(405)
        val list = mutableListOf(obj)
        val weak = WeakReference(obj)
        list.clear()
        return WeakOnlyResult(list, weak)
    }

    /**
     * WR-D05
     * Scenario: a strong collection is cleared.
     * Expectation: weak.value is cleared.
     */
    @Test
    fun wrD05_collectionClearClearsWeak() {
        val scenario = createAfterCollectionClear()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createAfterArraySlotNull(): WeakOnlyResult<Array<Payload?>, Payload> {
        val obj = Payload(406)
        val array = arrayOfNulls<Payload>(1)
        array[0] = obj
        val weak = WeakReference(obj)
        array[0] = null
        return WeakOnlyResult(array, weak)
    }

    /**
     * WR-D06
     * Scenario: an array strong slot is set to null.
     * Expectation: weak.value is cleared.
     */
    @Test
    fun wrD06_arraySlotNullClearsWeak() {
        val scenario = createAfterArraySlotNull()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root[0])
    }

    private fun createAfterLambdaStrongCaptureClear(): WeakReference<Payload> {
        val obj = Payload(407)
        val weak = WeakReference(obj)
        var block: (() -> Int)? = { obj.id }
        assertEquals(407, block!!())
        block = null
        assertNull(block)
        return weak
    }

    /**
     * WR-D07
     * Scenario: a lambda strongly captures target and then the lambda reference is cleared.
     * Expectation: target can be collected.
     */
    @Test
    fun wrD07_lambdaStrongCaptureClearClearsWeak() {
        val weak = createAfterLambdaStrongCaptureClear()

        assertWeakCollected(weak)
    }

    /**
     * WR-D08
     * Scenario: multiple strong references exist; one holder reference is cleared.
     * Expectation: target remains alive because local strong reference still exists.
     */
    @Test
    fun wrD08_releasingOneOfMultipleStrongReferencesDoesNotClearWeak() {
        val obj = Payload(408)
        val holder = StrongHolder(obj)
        val weak = WeakReference(obj)

        holder.ref = null
        forceGc()

        assertEquals(408, obj.id)
        assertNull(holder.ref)
        assertNotNull(weak.value)
    }

    private fun createAfterAllStrongReferencesReleased(): WeakReference<Payload> {
        var obj: Payload? = Payload(409)
        val holder = StrongHolder(obj!!)
        val list = mutableListOf(obj!!)
        val weak = WeakReference(obj!!)

        holder.ref = null
        list.clear()
        obj = null
        assertNull(obj)

        return weak
    }

    /**
     * WR-D09
     * Scenario: all strong references are released.
     * Expectation: weak.value is cleared.
     */
    @Test
    fun wrD09_releasingAllStrongReferencesClearsWeak() {
        val weak = createAfterAllStrongReferencesReleased()

        assertWeakCollected(weak)
    }

    private fun createStrongReplacement(): ReplacementResult<StrongHolder<Payload>, Payload> {
        val oldObj = Payload(410)
        val holder = StrongHolder(oldObj)
        val oldWeak = WeakReference(oldObj)
        val newObj = Payload(411)
        holder.ref = newObj
        val newWeak = WeakReference(newObj)
        return ReplacementResult(holder, oldWeak, newWeak)
    }

    /**
     * WR-D10
     * Scenario: a strong field is replaced from old target to new target.
     * Expectation: old weak clears; new weak remains alive.
     */
    @Test
    fun wrD10_strongReplacementClearsOldWeakAndKeepsNewWeakAlive() {
        val scenario = createStrongReplacement()

        forceGc()

        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(411, scenario.root.ref!!.id)
    }

    /**
     * WR-D11
     * Scenario: a WeakReference variable is replaced while the old target still has a strong reference.
     * Expectation: replacing the WeakReference itself does not affect old target lifetime.
     */
    @Test
    fun wrD11_replacingWeakReferenceDoesNotAffectOldTargetWithStrongReference() {
        val oldObj = Payload(412)
        val newObj = Payload(413)
        var weak = WeakReference(oldObj)
        val oldWeakObserver = WeakReference(oldObj)

        weak = WeakReference(newObj)

        forceGc()

        assertEquals(412, oldObj.id)
        assertEquals(413, newObj.id)
        assertNotNull(oldWeakObserver.value)
        assertNotNull(weak.value)
    }

    private fun createAfterWeakReferenceReplacementWithoutOldStrong(): WeakReference<Payload> {
        val oldObj = Payload(414)
        val oldWeakObserver = WeakReference(oldObj)
        var weak = WeakReference(oldObj)
        val newObj = Payload(415)
        weak = WeakReference(newObj)
        assertEquals(415, weak.value!!.id)
        return oldWeakObserver
    }

    /**
     * WR-D12
     * Scenario: WeakReference is changed from old target to new target, and old target has no strong reference.
     * Expectation: old target can be collected.
     */
    @Test
    fun wrD12_replacingWeakReferenceAllowsOldTargetCollectionWhenNoStrongExists() {
        val oldWeak = createAfterWeakReferenceReplacementWithoutOldStrong()

        assertWeakCollected(oldWeak)
    }
}
