﻿// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-G group: WeakReference.value access and promotion to strong references.
 */
export class WeakValuePromotionTest extends WeakReferenceTestSupport {
    /**
     * WR-G01
     * Scenario: strong reference exists and weak.value is read.
     * Expectation: weak.value returns a non-null object.
     */
    wrG01_readWeakValueWhileStrongExistsReturnsNonNull() {
        const obj = new Payload(701);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(701, weak.value.id);
        assertEquals(701, obj.id);
    }
    private createWeakOnlyForPostGcRead(): WeakReference<Payload> {
        const obj = new Payload(702);
        return new WeakReference(obj);
    }
    /**
     * WR-G02
     * Scenario: only WeakReference remains and GC runs before weak.value is read.
     * Expectation: weak.value returns null.
     */
    wrG02_readWeakValueAfterTargetCollectedReturnsNull() {
        const weak = this.createWeakOnlyForPostGcRead();
        this.forceGc();
        weak.clear();
        assertNull(weak.value);
    }
    /**
     * WR-G03
     * Scenario: weak.value is saved into a local strong variable.
     * Expectation: the promoted local reference keeps target alive while used after GC.
     */
    wrG03_weakValuePromotedToLocalStrongKeepsTargetAlive() {
        const obj = new Payload(703);
        const weak = new WeakReference(obj);
        const promoted = weak.value;
        this.forceGc();
        assertEquals(703, promoted.id);
        assertNotNull(weak.value);
    }
    private createWeakAfterPromotionScopeEnds(): WeakReference<Payload> {
        const obj = new Payload(704);
        const weak = new WeakReference(obj);
        {
            const promoted = weak.value;
            assertEquals(704, promoted.id);
        }
        return weak;
    }
    /**
     * WR-G04
     * Scenario: weak.value is promoted only inside helper scope.
     * Expectation: after helper returns, target can be collected.
     */
    wrG04_promotedLocalLeavingScopeDoesNotKeepTargetAliveLongTerm() {
        const weak = this.createWeakAfterPromotionScopeEnds();
        this.assertWeakCollected(weak);
    }
    private createHolderPromotedFromWeakValue(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        const obj = new Payload(705);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult(new StrongHolder(weak.value), weak);
    }
    /**
     * WR-G05
     * Scenario: weak.value is stored into a holder strong field.
     * Expectation: holder.ref keeps target alive.
     */
    wrG05_weakValueStoredInHolderStrongFieldKeepsTargetAlive() {
        const scenario = this.createHolderPromotedFromWeakValue();
        this.forceGc();
        assertEquals(705, scenario.root.ref.id);
        assertNotNull(scenario.weak.value);
    }
    private createAfterClearingPromotedHolder(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        const obj = new Payload(706);
        const weak = new WeakReference(obj);
        const holder = new StrongHolder(weak.value);
        holder.ref = null;
        return new WeakOnlyResult(holder, weak);
    }
    /**
     * WR-G06
     * Scenario: weak.value was stored into holder strong field, then holder field is cleared.
     * Expectation: target can be collected.
     */
    wrG06_clearingHolderPromotedStrongClearsWeak() {
        const scenario = this.createAfterClearingPromotedHolder();
        this.assertWeakCollected(scenario.weak);
        assertNull(scenario.root.ref);
    }
    private createListPromotedFromWeakValue(): WeakOnlyResult<Payload[], Payload> {
        const obj = new Payload(707);
        const weak = new WeakReference(obj);
        return new WeakOnlyResult([weak.value], weak);
    }
    /**
     * WR-G07
     * Scenario: weak.value is stored into a list.
     * Expectation: the list strongly keeps target alive.
     */
    wrG07_weakValueStoredInListKeepsTargetAlive() {
        const scenario = this.createListPromotedFromWeakValue();
        this.forceGc();
        assertEquals(707, scenario.root.single().id);
        assertNotNull(scenario.weak.value);
    }
    private createAfterClearingPromotedList(): WeakOnlyResult<Payload[], Payload> {
        const obj = new Payload(708);
        const weak = new WeakReference(obj);
        const list = [weak.value];
        list.clear();
        return new WeakOnlyResult(list, weak);
    }
    /**
     * WR-G08
     * Scenario: weak.value was stored into list, then list is cleared.
     * Expectation: target can be collected.
     */
    wrG08_clearingListPromotedStrongClearsWeak() {
        const scenario = this.createAfterClearingPromotedList();
        this.assertWeakCollected(scenario.weak);
        assertEquals(0, scenario.root.size);
    }
    private createWeakAfterReadOnlyAccess(): WeakReference<Payload> {
        const obj = new Payload(709);
        const weak = new WeakReference(obj);
        const id = weak.value?.id;
        assertEquals(709, id);
        return weak;
    }
    /**
     * WR-G09
     * Scenario: weak.value is read for a property and not stored as a long-lived strong reference.
     * Expectation: after helper returns, target can be collected.
     */
    wrG09_readOnlyWeakValueAccessDoesNotKeepTargetAliveLongTerm() {
        const weak = this.createWeakAfterReadOnlyAccess();
        this.assertWeakCollected(weak);
    }
    private createLambdaReadingWeakValue(): any {
        const obj = new Payload(710);
        const weak = new WeakReference(obj);
        const block = () => weak.value?.id;
        return new WeakOnlyResult(new Root(block), weak);
    }
    /**
     * WR-G10
     * Scenario: lambda captures WeakReference and reads weak.value when invoked.
     * Expectation: target is not strongly captured and can be collected.
     */
    wrG10_lambdaReadingWeakValueDoesNotCaptureTargetStrongly() {
        const scenario = this.createLambdaReadingWeakValue();
        this.forceGc();
        scenario.weak.clear();
        assertNull(scenario.root.ref());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    private createLambdaWithTemporaryPromotion(): any {
        const obj = new Payload(711);
        const weak = new WeakReference(obj);
        const block = () => { const promoted = weak.value; return promoted?.id; }
        return new WeakOnlyResult(new Root(block), weak);
    }
    /**
     * WR-G11
     * Scenario: lambda temporarily promotes weak.value to a local variable inside invocation.
     * Expectation: this does not keep target alive after helper returns.
     */
    wrG11_lambdaTemporaryPromotionDoesNotKeepTargetAliveLongTerm() {
        const scenario = this.createLambdaWithTemporaryPromotion();
        this.forceGc();
        scenario.weak.clear();
        assertNull(scenario.root.ref());
        scenario.weak.clear();
        assertNull(scenario.weak.value);
    }
    private createWeakAlreadyNull(): WeakReference<Payload> {
        const obj = new Payload(712);
        return new WeakReference(obj);
    }
    /**
     * WR-G12
     * Scenario: weak.value is read after target has already been collected.
     * Expectation: reading value returns null and does not crash.
     */
    wrG12_promotingAlreadyClearedWeakValueReturnsNull() {
        const weak = this.createWeakAlreadyNull();
        this.forceGc();
        weak.clear();
        const promoted = weak.value;
        assertNull(promoted);
    }
}


