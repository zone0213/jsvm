@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-H group: container-backed graph tests. */
class ContainerGraphTest : GraphTopologyTestSupport() {

    /** GT-H01: Array refs can carry a chain-shaped graph. */
    @Test
    fun gtH01_arrayBackedChainKeepsTailAlive() {
        val head = ArrayNode(16000, 1)
        val mid = ArrayNode(16001, 1)
        val tail = ArrayNode(16002, 0)
        head.refs[0] = mid
        mid.refs[0] = tail
        val scenario = RootedWeaks(GraphRoot(head), weakRefs(listOf(head, mid, tail)))
        forceGc()
        assertEquals(16002, scenario.root.ref!!.refs[0]!!.refs[0]!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-H02: Array refs can carry a tree-shaped graph. */
    @Test
    fun gtH02_arrayBackedTreeKeepsLeavesAlive() {
        val rootNode = ArrayNode(16010, 2)
        val left = ArrayNode(16011, 1)
        val right = ArrayNode(16012, 1)
        val leftLeaf = ArrayNode(16013, 0)
        val rightLeaf = ArrayNode(16014, 0)
        rootNode.refs[0] = left
        rootNode.refs[1] = right
        left.refs[0] = leftLeaf
        right.refs[0] = rightLeaf
        val scenario = RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, left, right, leftLeaf, rightLeaf)))
        forceGc()
        assertEquals(16013, scenario.root.ref!!.refs[0]!!.refs[0]!!.id)
        assertEquals(16014, scenario.root.ref!!.refs[1]!!.refs[0]!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-H03: Array null holes are skipped while non-null refs are still scanned. */
    @Test
    fun gtH03_arrayNullHoleKeepsNonNullChildrenAlive() {
        val rootNode = ArrayNode(16020, 3)
        val child1 = ArrayNode(16021, 0)
        val child2 = ArrayNode(16022, 0)
        rootNode.refs[0] = child1
        rootNode.refs[1] = null
        rootNode.refs[2] = child2
        val scenario = RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, child1, child2)))
        forceGc()
        assertNull(scenario.root.ref!!.refs[1])
        assertEquals(16021, scenario.root.ref!!.refs[0]!!.id)
        assertEquals(16022, scenario.root.ref!!.refs[2]!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun arrayAfterSetNull(): MixedWeaks<GraphRoot<ArrayNode>, ArrayNode> {
        val rootNode = ArrayNode(16030, 2)
        val removed = ArrayNode(16031, 0)
        val remaining = ArrayNode(16032, 0)
        rootNode.refs[0] = removed
        rootNode.refs[1] = remaining
        rootNode.refs[0] = null
        return MixedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, remaining)), weakRefs(listOf(removed)))
    }

    /** GT-H04: setting an Array edge to null collects only the removed child. */
    @Test
    fun gtH04_arraySetNullCollectsRemovedChildOnly() {
        val scenario = arrayAfterSetNull()
        forceGc()
        assertNull(scenario.root.ref!!.refs[0])
        assertEquals(16032, scenario.root.ref!!.refs[1]!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun arrayAfterReplace(): ReplacementWeaks<GraphRoot<ArrayNode>, ArrayNode> {
        val rootNode = ArrayNode(16040, 1)
        val oldChild = ArrayNode(16041, 0)
        val newChild = ArrayNode(16042, 0)
        rootNode.refs[0] = oldChild
        val oldWeak = WeakReference(oldChild)
        rootNode.refs[0] = newChild
        val newWeak = WeakReference(newChild)
        return ReplacementWeaks(GraphRoot(rootNode), listOf(oldWeak), listOf(newWeak))
    }

    /** GT-H05: replacing an Array edge collects old child and keeps new child alive. */
    @Test
    fun gtH05_arrayReplaceCollectsOldChildAndKeepsNewChildAlive() {
        val scenario = arrayAfterReplace()
        forceGc()
        assertEquals(16042, scenario.root.ref!!.refs[0]!!.id)
        assertAllCollected(scenario.oldWeaks)
        assertAllAlive(scenario.newWeaks)
    }

    /** GT-H06: List adjacency can carry a chain-shaped graph. */
    @Test
    fun gtH06_listAdjacencyChainKeepsTailAlive() {
        val head = MultiNode(16100)
        val mid = MultiNode(16101)
        val tail = MultiNode(16102)
        head.children.add(mid)
        mid.children.add(tail)
        val scenario = RootedWeaks(GraphRoot(head), weakRefs(listOf(head, mid, tail)))
        forceGc()
        assertEquals(16102, scenario.root.ref!!.children[0].children[0].id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-H07: List adjacency can carry a multi-way tree. */
    @Test
    fun gtH07_listAdjacencyMultiWayTreeKeepsChildrenAlive() {
        val nodes = buildMultiTree(2, 3, 16110)
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(16110, scenario.root.ref!!.id)
        assertEquals(3, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    private fun listAfterRemoveChild(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val rootNode = MultiNode(16120)
        val removed = MultiNode(16121)
        val removedLeaf = MultiNode(16122)
        val remaining = MultiNode(16123)
        removed.children.add(removedLeaf)
        rootNode.children.add(removed)
        rootNode.children.add(remaining)
        rootNode.children.remove(removed)
        return MixedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, remaining)), weakRefs(listOf(removed, removedLeaf)))
    }

    /** GT-H08: removing a List child collects the removed subtree only. */
    @Test
    fun gtH08_listRemoveChildCollectsRemovedSubtreeOnly() {
        val scenario = listAfterRemoveChild()
        forceGc()
        assertEquals(1, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun listAfterClearChildren(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildMultiTree(2, 3, 16130)
        val root = GraphRoot(nodes.first())
        root.ref!!.children.clear()
        return MixedWeaks(root, weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-H09: clearing List children collects all child nodes and keeps root alive. */
    @Test
    fun gtH09_listClearCollectsAllChildren() {
        val scenario = listAfterClearChildren()
        assertEquals(0, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-H10: Map value can carry a graph edge. */
    @Test
    fun gtH10_mapValueEdgeKeepsChildAlive() {
        val rootNode = MapNode(16200)
        val child = MapNode(16201)
        rootNode.refs["next"] = child
        val scenario = RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, child)))
        forceGc()
        assertEquals(16201, scenario.root.ref!!.refs["next"]!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun mapValueAfterRemove(): MixedWeaks<GraphRoot<MapNode>, MapNode> {
        val rootNode = MapNode(16210)
        val child = MapNode(16211)
        rootNode.refs["next"] = child
        rootNode.refs.remove("next")
        return MixedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode)), weakRefs(listOf(child)))
    }

    /** GT-H11: removing a Map value edge allows the child to be collected. */
    @Test
    fun gtH11_mapValueRemoveCollectsChild() {
        val scenario = mapValueAfterRemove()
        assertEquals(0, scenario.root.ref!!.refs.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-H12: two Map value edges sharing one child keep the shared child alive. */
    @Test
    fun gtH12_mapValueDagSharedChildRemainsAlive() {
        val parent1 = MapNode(16220)
        val parent2 = MapNode(16221)
        val shared = MapNode(16222)
        val root = MapNode(16223)
        root.refs["p1"] = parent1
        root.refs["p2"] = parent2
        parent1.refs["shared"] = shared
        parent2.refs["shared"] = shared
        val scenario = RootedWeaks(GraphRoot(root), weakRefs(listOf(root, parent1, parent2, shared)))
        forceGc()
        assertEquals(16222, scenario.root.ref!!.refs["p1"]!!.refs["shared"]!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-H13: removing one Map edge to shared child still keeps it alive through another edge. */
    @Test
    fun gtH13_mapValueDagSharedChildSurvivesOneEdgeRemoval() {
        val parent1 = MapNode(16230)
        val parent2 = MapNode(16231)
        val shared = MapNode(16232)
        val root = MapNode(16233)
        root.refs["p1"] = parent1
        root.refs["p2"] = parent2
        parent1.refs["shared"] = shared
        parent2.refs["shared"] = shared
        parent1.refs.remove("shared")
        val scenario = RootedWeaks(GraphRoot(root), weakRefs(listOf(root, parent1, parent2, shared)))
        forceGc()
        assertEquals(16232, scenario.root.ref!!.refs["p2"]!!.refs["shared"]!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun mapDagAfterAllSharedEdgesRemoved(): MixedWeaks<GraphRoot<MapNode>, MapNode> {
        val parent1 = MapNode(16240)
        val parent2 = MapNode(16241)
        val shared = MapNode(16242)
        val root = MapNode(16243)
        root.refs["p1"] = parent1
        root.refs["p2"] = parent2
        parent1.refs["shared"] = shared
        parent2.refs["shared"] = shared
        parent1.refs.remove("shared")
        parent2.refs.remove("shared")
        return MixedWeaks(GraphRoot(root), weakRefs(listOf(root, parent1, parent2)), weakRefs(listOf(shared)))
    }

    /** GT-H14: removing all Map edges to a shared child allows it to be collected. */
    @Test
    fun gtH14_mapValueDagSharedChildCollectedAfterAllEdgesRemoved() {
        val scenario = mapDagAfterAllSharedEdgesRemoved()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-H15: Set elements used as children are scanned and kept alive. */
    @Test
    fun gtH15_setChildrenKeepChildAlive() {
        val rootNode = SetNode(16300)
        val child = SetNode(16301)
        rootNode.children.add(child)
        val scenario = RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, child)))
        forceGc()
        assertEquals(1, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    private fun setAfterRemoveChild(): MixedWeaks<GraphRoot<SetNode>, SetNode> {
        val rootNode = SetNode(16310)
        val child = SetNode(16311)
        rootNode.children.add(child)
        rootNode.children.remove(child)
        return MixedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode)), weakRefs(listOf(child)))
    }

    /** GT-H16: removing a Set child allows that child to be collected. */
    @Test
    fun gtH16_setRemoveChildCollectsChild() {
        val scenario = setAfterRemoveChild()
        assertEquals(0, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-H17: a Map key can keep a node alive. */
    @Test
    fun gtH17_mapKeyKeepsNodeAlive() {
        val key = MapNode(16400)
        val map = mutableMapOf(key to "metadata")
        val scenario = RootedWeaks(GraphRoot(map), listOf(WeakReference(key)))
        forceGc()
        assertEquals(16400, scenario.root.ref!!.keys.single().id)
        assertAllAlive(scenario.weaks)
    }

    private fun mapKeyAfterRemove(): MixedWeaks<GraphRoot<MutableMap<MapNode, String>>, MapNode> {
        val key = MapNode(16410)
        val map = mutableMapOf(key to "metadata")
        val weak = WeakReference(key)
        map.remove(key)
        return MixedWeaks(GraphRoot(map), emptyList(), listOf(weak))
    }

    /** GT-H18: removing a Map key allows that key node to be collected. */
    @Test
    fun gtH18_mapKeyRemoveCollectsKeyNode() {
        val scenario = mapKeyAfterRemove()
        assertEquals(0, scenario.root.ref!!.size)
        assertAllCollected(scenario.collectedWeaks)
    }
}
