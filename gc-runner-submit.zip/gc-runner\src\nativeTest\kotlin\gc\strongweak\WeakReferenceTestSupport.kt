@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * Common test infrastructure for Kotlin/Native GC strong/weak-reference tests.
 *
 * Scope:
 * - Validates pure Kotlin strong-reference and WeakReference semantics.
 * - Does not cover Objective-C/Swift interop, StableRef, concurrency, allocator behavior or GC option matrix.
 * - WeakReference is the feature under test in this layer.
 */
open class WeakReferenceTestSupport {

    @BeforeTest
    fun resetBeforeTest() {
        clearGlobalRoots()
        forceGc()
    }

    @AfterTest
    fun resetAfterTest() {
        clearGlobalRoots()
        forceGc()
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun clearGlobalRoots() {
        globalPayload = null
        globalAny = null
        globalMarker = null
        globalWeak = null
        ObjectStrongWeakHolder.strong = null
        ObjectStrongWeakHolder.weak = null
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected weak reference value to remain alive."
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollected(
        weak: WeakReference<T>,
        message: String = "Expected weak reference value to be cleared."
    ) {
        forceGc()
        assertNull(weak.value, message)
    }

    protected fun <T : Any> assertAllWeakAlive(weaks: Iterable<WeakReference<T>>) {
        weaks.forEachIndexed { index, weak ->
            assertNotNull(weak.value, "Expected weak[$index] value to remain alive.")
        }
    }

    protected fun <T : Any> assertAllWeakCollected(weaks: Iterable<WeakReference<T>>) {
        forceGc()
        weaks.forEachIndexed { index, weak ->
            assertNull(weak.value, "Expected weak[$index] value to be cleared.")
        }
    }

    companion object {
        private const val GC_REPEAT_COUNT = 3
    }
}

interface Marker {
    val id: Int
}

class Payload(
    val id: Int,
    var strong: Payload? = null,
    var weak: WeakReference<Payload>? = null
) {
    override fun toString(): String = "Payload(id=$id)"
}

class MarkerPayload(
    override val id: Int
) : Marker

class StrongHolder<T : Any>(var ref: T?)
class WeakHolder<T : Any>(var weak: WeakReference<T>?)
class MixedHolder<T : Any>(var strong: T?, var weak: WeakReference<T>?)
class Box<T : Any>(var value: T?)
class Root<T : Any>(var ref: T?)
data class DataWeakHolder<T : Any>(var weak: WeakReference<T>?)

data class WeakOnlyResult<R : Any, T : Any>(
    val root: R,
    val weak: WeakReference<T>
)

data class MixedWeakResult<R : Any, T : Any>(
    val root: R,
    val aliveWeaks: List<WeakReference<T>>,
    val collectedWeaks: List<WeakReference<T>>
)

data class ReplacementResult<R : Any, T : Any>(
    val root: R,
    val oldWeak: WeakReference<T>,
    val newWeak: WeakReference<T>
)

var globalPayload: Payload? = null
var globalAny: Any? = null
var globalMarker: Marker? = null
var globalWeak: WeakReference<Payload>? = null

object ObjectStrongWeakHolder {
    var strong: Payload? = null
    var weak: WeakReference<Payload>? = null
}
