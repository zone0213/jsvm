@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-C group: tree graph tests. */
class TreeGraphTest : GraphTopologyTestSupport() {

    private fun binaryTreeRoot(levels: Int, startId: Int): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildFullBinaryTree(levels, startId)
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-C01: a one-level binary branching keeps both children alive. */
    @Test
    fun gtC01_binaryTreeDepthOneKeepsBothChildrenAlive() {
        val scenario = binaryTreeRoot(2, 6000)
        forceGc()
        assertEquals(6001, scenario.root.ref!!.left!!.id)
        assertEquals(6002, scenario.root.ref!!.right!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-C02: a 7-node full binary tree keeps internal nodes and leaves alive. */
    @Test
    fun gtC02_binaryTreeDepthTwoKeepsWholeTreeAlive() {
        val scenario = binaryTreeRoot(3, 6100)
        forceGc()
        assertEquals(6106, scenario.weaks.last().value!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-C03: a 31-node binary tree keeps representative nodes alive. */
    @Test
    fun gtC03_binaryTreeDepthFiveKeepsRepresentativeNodesAlive() {
        val scenario = binaryTreeRoot(5, 6200)
        forceGc()
        assertEquals(6200, scenario.root.ref!!.id)
        assertEquals(6214, scenario.weaks[14].value!!.id)
        assertEquals(6230, scenario.weaks[30].value!!.id)
    }

    private fun binaryTreeAfterLeftClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildFullBinaryTree(3, 6300)
        val root = GraphRoot(nodes.first())
        val left = listOf(nodes[1], nodes[3], nodes[4])
        val right = listOf(nodes[2], nodes[5], nodes[6])
        root.ref!!.left = null
        return MixedWeaks(root, weakRefs(listOf(nodes[0]) + right), weakRefs(left))
    }

    /** GT-C04: clearing left subtree collects left subtree and keeps right subtree alive. */
    @Test
    fun gtC04_clearingLeftSubtreeCollectsLeftAndKeepsRightAlive() {
        val scenario = binaryTreeAfterLeftClear()
        forceGc()
        assertNull(scenario.root.ref!!.left)
        assertEquals(6302, scenario.root.ref!!.right!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun binaryTreeAfterRightClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildFullBinaryTree(3, 6400)
        val root = GraphRoot(nodes.first())
        val left = listOf(nodes[1], nodes[3], nodes[4])
        val right = listOf(nodes[2], nodes[5], nodes[6])
        root.ref!!.right = null
        return MixedWeaks(root, weakRefs(listOf(nodes[0]) + left), weakRefs(right))
    }

    /** GT-C05: clearing right subtree collects right subtree and keeps left subtree alive. */
    @Test
    fun gtC05_clearingRightSubtreeCollectsRightAndKeepsLeftAlive() {
        val scenario = binaryTreeAfterRightClear()
        forceGc()
        assertNull(scenario.root.ref!!.right)
        assertEquals(6401, scenario.root.ref!!.left!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun binaryTreeAfterMiddleSubtreeClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildFullBinaryTree(4, 6500)
        val root = GraphRoot(nodes.first())
        val disconnected = listOf(nodes[3], nodes[7], nodes[8])
        val alive = nodes.filter { it !in disconnected }
        nodes[1].left = null
        return MixedWeaks(root, weakRefs(alive), weakRefs(disconnected))
    }

    /** GT-C06: clearing an internal subtree edge collects only that disconnected subtree. */
    @Test
    fun gtC06_clearingMiddleSubtreeCollectsOnlyDisconnectedSubtree() {
        val scenario = binaryTreeAfterMiddleSubtreeClear()
        forceGc()
        assertNull(scenario.root.ref!!.left!!.left)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun binaryTreeAfterLeafClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildFullBinaryTree(3, 6600)
        val root = GraphRoot(nodes.first())
        val leaf = nodes[3]
        val alive = nodes.filter { it !== leaf }
        nodes[1].left = null
        return MixedWeaks(root, weakRefs(alive), weakRefs(listOf(leaf)))
    }

    /** GT-C07: clearing a leaf edge collects only the leaf. */
    @Test
    fun gtC07_clearingLeafCollectsOnlyLeaf() {
        val scenario = binaryTreeAfterLeafClear()
        forceGc()
        assertNull(scenario.root.ref!!.left!!.left)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun unbalancedTreeRoot(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val rootNode = GraphNode(6700)
        val leftChain = buildGraphNodeChain(5, 6710)
        val rightLeaf = GraphNode(6799)
        rootNode.left = leftChain.first()
        rootNode.right = rightLeaf
        return RootedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode) + leftChain + rightLeaf))
    }

    /** GT-C08: an unbalanced tree keeps both deep and shallow branches alive. */
    @Test
    fun gtC08_unbalancedTreeKeepsDeepAndShallowBranchesAlive() {
        val scenario = unbalancedTreeRoot()
        forceGc()
        assertEquals(6714, scenario.root.ref!!.left!!.next!!.next!!.next!!.next!!.id)
        assertEquals(6799, scenario.root.ref!!.right!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun unbalancedTreeAfterDeepBranchClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val rootNode = GraphNode(6800)
        val leftChain = buildGraphNodeChain(5, 6810)
        val rightLeaf = GraphNode(6899)
        rootNode.left = leftChain.first()
        rootNode.right = rightLeaf
        val root = GraphRoot(rootNode)
        rootNode.left = null
        return MixedWeaks(root, weakRefs(listOf(rootNode, rightLeaf)), weakRefs(leftChain))
    }

    /** GT-C09: clearing the deep branch collects it and keeps the shallow branch alive. */
    @Test
    fun gtC09_clearingDeepBranchCollectsThatBranchOnly() {
        val scenario = unbalancedTreeAfterDeepBranchClear()
        forceGc()
        assertNull(scenario.root.ref!!.left)
        assertEquals(6899, scenario.root.ref!!.right!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun multiTreeRoot(levels: Int, branching: Int, startId: Int): RootedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildMultiTree(levels, branching, startId)
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-C10: a small multi-way tree keeps all direct children alive. */
    @Test
    fun gtC10_smallMultiWayTreeKeepsAllChildrenAlive() {
        val scenario = multiTreeRoot(2, 3, 6900)
        forceGc()
        assertEquals(3, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    /** GT-C11: a wide multi-way tree keeps representative children alive. */
    @Test
    fun gtC11_wideMultiWayTreeKeepsRepresentativeChildrenAlive() {
        val scenario = multiTreeRoot(2, 100, 7000)
        forceGc()
        assertEquals(7001, scenario.root.ref!!.children[0].id)
        assertEquals(7051, scenario.root.ref!!.children[50].id)
        assertEquals(7100, scenario.root.ref!!.children[99].id)
        assertAllAlive(scenario.weaks)
    }

    private fun multiTreeAfterRemoveChild(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val rootNode = MultiNode(7200)
        val removed = MultiNode(7201)
        val grandChild = MultiNode(7202)
        val remaining = MultiNode(7203)
        removed.children.add(grandChild)
        rootNode.children.add(removed)
        rootNode.children.add(remaining)
        rootNode.children.remove(removed)
        return MixedWeaks(GraphRoot(rootNode), weakRefs(listOf(rootNode, remaining)), weakRefs(listOf(removed, grandChild)))
    }

    /** GT-C12: removing one child from a multi-way tree collects the removed subtree only. */
    @Test
    fun gtC12_removingMultiTreeChildCollectsRemovedSubtreeOnly() {
        val scenario = multiTreeAfterRemoveChild()
        forceGc()
        assertEquals(1, scenario.root.ref!!.children.size)
        assertEquals(7203, scenario.root.ref!!.children.first().id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun multiTreeAfterClearChildren(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = buildMultiTree(2, 3, 7300)
        val root = GraphRoot(nodes.first())
        root.ref!!.children.clear()
        return MixedWeaks(root, weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-C13: clearing all children collects child subtrees and keeps root alive. */
    @Test
    fun gtC13_clearingMultiTreeChildrenCollectsAllChildren() {
        val scenario = multiTreeAfterClearChildren()
        forceGc()
        assertEquals(0, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    /** GT-C14: a nested multi-way tree keeps grandchildren alive. */
    @Test
    fun gtC14_nestedMultiWayTreeKeepsGrandChildrenAlive() {
        val scenario = multiTreeRoot(3, 2, 7400)
        forceGc()
        assertEquals(7401, scenario.root.ref!!.children[0].id)
        assertEquals(7403, scenario.root.ref!!.children[0].children[0].id)
        assertAllAlive(scenario.weaks)
    }
}
