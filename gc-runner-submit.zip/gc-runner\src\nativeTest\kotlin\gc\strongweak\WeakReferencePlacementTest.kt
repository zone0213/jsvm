@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-E group: WeakReference object placement tests.
 */
class WeakReferencePlacementTest : WeakReferenceTestSupport() {

    private fun createRootedWeakHolder(): WeakOnlyResult<Root<WeakHolder<Payload>>, Payload> {
        val obj = Payload(501)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(WeakHolder(weak)), weak)
    }

    /**
     * WR-E01
     * Scenario: root holds WeakHolder, which holds WeakReference to target.
     * Expectation: holder survives, target can be collected.
     */
    @Test
    fun wrE01_rootedWeakHolderDoesNotKeepTargetAlive() {
        val scenario = createRootedWeakHolder()

        forceGc()

        assertNotNull(scenario.root.ref)
        assertNull(scenario.weak.value)
    }

    private fun createRootedWeakList(): WeakOnlyResult<Root<MutableList<WeakReference<Payload>>>, Payload> {
        val obj = Payload(502)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableListOf(weak)), weak)
    }

    /**
     * WR-E02
     * Scenario: root holds a list containing WeakReference.
     * Expectation: list and WeakReference object survive, target can be collected.
     */
    @Test
    fun wrE02_rootedWeakListDoesNotKeepTargetAlive() {
        val scenario = createRootedWeakList()

        forceGc()

        assertEquals(1, scenario.root.ref!!.size)
        assertNull(scenario.weak.value)
    }

    private fun createRootedWeakArray(): WeakOnlyResult<Root<Array<WeakReference<Payload>?>>, Payload> {
        val obj = Payload(503)
        val weak = WeakReference(obj)
        val array = arrayOfNulls<WeakReference<Payload>>(1)
        array[0] = weak
        return WeakOnlyResult(Root(array), weak)
    }

    /**
     * WR-E03
     * Scenario: root holds an array containing WeakReference.
     * Expectation: array and WeakReference object survive, target can be collected.
     */
    @Test
    fun wrE03_rootedWeakArrayDoesNotKeepTargetAlive() {
        val scenario = createRootedWeakArray()

        forceGc()

        assertNotNull(scenario.root.ref!![0])
        assertNull(scenario.weak.value)
    }

    private fun createRootedWeakMapValue(): WeakOnlyResult<Root<MutableMap<String, WeakReference<Payload>>>, Payload> {
        val obj = Payload(504)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableMapOf("target" to weak)), weak)
    }

    /**
     * WR-E04
     * Scenario: root holds a map whose value is WeakReference.
     * Expectation: map and WeakReference object survive, target can be collected.
     */
    @Test
    fun wrE04_rootedWeakMapValueDoesNotKeepTargetAlive() {
        val scenario = createRootedWeakMapValue()

        forceGc()

        assertNotNull(scenario.root.ref!!["target"])
        assertNull(scenario.weak.value)
    }

    private fun createRootedWeakMapKey(): WeakOnlyResult<Root<MutableMap<WeakReference<Payload>, String>>, Payload> {
        val obj = Payload(505)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableMapOf(weak to "value")), weak)
    }

    /**
     * WR-E05
     * Scenario: root holds a map whose key is WeakReference.
     * Expectation: map and key object survive, target can be collected.
     */
    @Test
    fun wrE05_rootedWeakMapKeyDoesNotKeepTargetAlive() {
        val scenario = createRootedWeakMapKey()

        forceGc()

        assertEquals(1, scenario.root.ref!!.size)
        assertNull(scenario.weak.value)
    }

    private fun createRootedBoxOfWeak(): WeakOnlyResult<Root<Box<WeakReference<Payload>>>, Payload> {
        val obj = Payload(506)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(Box(weak)), weak)
    }

    /**
     * WR-E06
     * Scenario: root holds Box containing WeakReference.
     * Expectation: box and WeakReference object survive, target can be collected.
     */
    @Test
    fun wrE06_rootedBoxOfWeakDoesNotKeepTargetAlive() {
        val scenario = createRootedBoxOfWeak()

        forceGc()

        assertNotNull(scenario.root.ref!!.value)
        assertNull(scenario.weak.value)
    }

    private fun createRootedDataWeakHolder(): WeakOnlyResult<Root<DataWeakHolder<Payload>>, Payload> {
        val obj = Payload(507)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(DataWeakHolder(weak)), weak)
    }

    /**
     * WR-E07
     * Scenario: root holds data-style holder containing WeakReference.
     * Expectation: holder survives, target can be collected.
     */
    @Test
    fun wrE07_rootedDataWeakHolderDoesNotKeepTargetAlive() {
        val scenario = createRootedDataWeakHolder()

        forceGc()

        assertNotNull(scenario.root.ref!!.weak)
        assertNull(scenario.weak.value)
    }

    private fun createNullableWeakFieldHolder(): WeakOnlyResult<Root<WeakHolder<Payload>>, Payload> {
        val obj = Payload(508)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(WeakHolder<Payload>(weak)), weak)
    }

    /**
     * WR-E08
     * Scenario: WeakReference is stored in a nullable field.
     * Expectation: field can stay non-null while weak.value becomes null.
     */
    @Test
    fun wrE08_nullableWeakFieldSurvivesButTargetCanBeCollected() {
        val scenario = createNullableWeakFieldHolder()

        forceGc()

        assertNotNull(scenario.root.ref!!.weak)
        assertNull(scenario.weak.value)
    }

    private fun createWeakObjectAfterClearingWeakField(): WeakReference<WeakReference<Payload>> {
        val obj = Payload(509)
        val weak = WeakReference(obj)
        val weakObjectObserver = WeakReference(weak)
        val holder = WeakHolder(weak)
        holder.weak = null
        return weakObjectObserver
    }

    /**
     * WR-E09
     * Scenario: a holder weak field is cleared.
     * Expectation: the WeakReference object itself can be collected when no strong reference keeps it.
     */
    @Test
    fun wrE09_clearingWeakFieldAllowsWeakReferenceObjectCollection() {
        val weakObjectObserver = createWeakObjectAfterClearingWeakField()

        assertWeakCollected(weakObjectObserver)
    }

    private fun createWeakObjectAfterClearingWeakList(): WeakReference<WeakReference<Payload>> {
        val obj = Payload(510)
        val weak = WeakReference(obj)
        val weakObjectObserver = WeakReference(weak)
        val list = mutableListOf(weak)
        list.clear()
        return weakObjectObserver
    }

    /**
     * WR-E10
     * Scenario: a list containing WeakReference is cleared.
     * Expectation: the WeakReference object itself can be collected.
     */
    @Test
    fun wrE10_clearingWeakListAllowsWeakReferenceObjectCollection() {
        val weakObjectObserver = createWeakObjectAfterClearingWeakList()

        assertWeakCollected(weakObjectObserver)
    }

    private fun createWeakObjectAfterArraySlotNull(): WeakReference<WeakReference<Payload>> {
        val obj = Payload(511)
        val weak = WeakReference(obj)
        val weakObjectObserver = WeakReference(weak)
        val array = arrayOfNulls<WeakReference<Payload>>(1)
        array[0] = weak
        array[0] = null
        return weakObjectObserver
    }

    /**
     * WR-E11
     * Scenario: an array slot containing WeakReference is set to null.
     * Expectation: the WeakReference object itself can be collected.
     */
    @Test
    fun wrE11_nullingWeakArraySlotAllowsWeakReferenceObjectCollection() {
        val weakObjectObserver = createWeakObjectAfterArraySlotNull()

        assertWeakCollected(weakObjectObserver)
    }

    private fun createWeakObjectAfterMapRemove(): WeakReference<WeakReference<Payload>> {
        val obj = Payload(512)
        val weak = WeakReference(obj)
        val weakObjectObserver = WeakReference(weak)
        val map = mutableMapOf("target" to weak)
        map.remove("target")
        return weakObjectObserver
    }

    /**
     * WR-E12
     * Scenario: a map entry containing WeakReference is removed.
     * Expectation: the WeakReference object itself can be collected.
     */
    @Test
    fun wrE12_removingWeakMapEntryAllowsWeakReferenceObjectCollection() {
        val weakObjectObserver = createWeakObjectAfterMapRemove()

        assertWeakCollected(weakObjectObserver)
    }

    private fun createWeakHolderWithUnrelatedStrongObject(): MixedWeakResult<Root<StrongHolder<Payload>>, Payload> {
        val weakTarget = Payload(513)
        val unrelated = Payload(514)
        val weak = WeakReference(weakTarget)
        val weakHolder = WeakHolder(weak)
        val strongHolder = StrongHolder(unrelated)
        weakHolder.weak = weak
        return MixedWeakResult(Root(strongHolder), listOf(WeakReference(unrelated)), listOf(weak))
    }

    /**
     * WR-E13
     * Scenario: root holds an unrelated strong object while another holder contains WeakReference to target.
     * Expectation: unrelated strong object survives; weak target can be collected.
     */
    @Test
    fun wrE13_unrelatedStrongObjectSurvivesWhileWeakTargetIsCollected() {
        val scenario = createWeakHolderWithUnrelatedStrongObject()

        forceGc()

        assertEquals(514, scenario.root.ref!!.ref!!.id)
        assertAllWeakAlive(scenario.aliveWeaks)
        assertAllWeakCollected(scenario.collectedWeaks)
    }

    private fun createMultiLevelHolderWithWeak(): WeakOnlyResult<Root<StrongHolder<WeakHolder<Payload>>>, Payload> {
        val obj = Payload(515)
        val weak = WeakReference(obj)
        val inner = WeakHolder(weak)
        val outer = StrongHolder(inner)
        return WeakOnlyResult(Root(outer), weak)
    }

    /**
     * WR-E14
     * Scenario: root -> holder1 -> holder2 -> WeakReference -> target.
     * Expectation: holder chain survives, but target can be collected.
     */
    @Test
    fun wrE14_multiLevelHolderWeakDoesNotKeepTargetAlive() {
        val scenario = createMultiLevelHolderWithWeak()

        forceGc()

        assertNotNull(scenario.root.ref!!.ref)
        assertNull(scenario.weak.value)
    }
}
