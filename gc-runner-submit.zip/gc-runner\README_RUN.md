﻿# Run Notes

Computer-side check:
1. Open this folder in a terminal.
2. Run `npm install` if `node_modules` is missing.
3. Run `npm test`.

Real-device check:
1. Open `deveco-runner` with DevEco Studio.
2. Select a real device.
3. Run the `entry` module.
4. Tap `Run All Tests` on the first page.
