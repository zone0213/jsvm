﻿// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * Minimal two-test reproduction for the LS-J05 -> LS-J06 sequence.
 *
 * The first test intentionally mirrors the known J05-style failure pattern.
 * The second test immediately follows with the J06-style exception-path batch.
 */
export class CoroutineExceptionAfterFailureSmokeTest extends WeakReferenceTestSupport {
    private createWeaksAfterStrongHolderClear(count: number = 32): WeakReference<Payload>[] {
        const holders = Array.from({ length: count }, (_, index) => {
            return new StrongHolder(new Payload(7000 + index));
        });
        const weaks = holders.map((holder) => {
            return new WeakReference(holder.ref);
        });
        holders.forEach((holder) => {
            holder.ref = null;
        });
        return weaks;
    }
    private createWeaksAfterExceptionBatch(count: number = 32): WeakReference<Payload>[] {
        const weaks = [];
        for (let index = 0; index < count; index++) {
            const payload = new Payload(8000 + index);
            weaks.add(new WeakReference(payload));
            try {
                throw new Error(`cancel-${index}`);
            } catch (_: Throwable) {
            }
        }
        return weaks;
    }
    /**
     * Phase 1: mirrors the LS-J05 pattern and is expected to fail today.
     */
    phase1_holderClearLeavesLastWeakAlive() {
        const weaks = this.createWeaksAfterStrongHolderClear();
        this.assertAllWeakCollected(weaks);
    }
    /**
     * Phase 2: mirrors the LS-J06 pattern and should still run after phase 1.
     */
    phase2_exceptionBatchWeakTargetsAreCleared() {
        const weaks = this.createWeaksAfterExceptionBatch();
        this.assertAllWeakCollected(weaks);
    }
}

