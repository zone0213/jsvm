@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/** GT-A group: single-node graph tests. */
class SingleNodeGraphTest : GraphTopologyTestSupport() {

    private fun singleNodeRoot(id: Int): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val node = GraphNode(id)
        return RootedWeaks(GraphRoot(node), listOf(WeakReference(node)))
    }

    /** GT-A01: root directly keeps a single-node graph alive. */
    @Test
    fun gtA01_singleNodeGraphRootKeepsNodeAlive() {
        val scenario = singleNodeRoot(101)
        forceGc()
        assertEquals(101, scenario.root.ref!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun singleNodeAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val node = GraphNode(102)
        val root = GraphRoot(node)
        val weak = WeakReference(node)
        root.ref = null
        return RootedWeaks(root, listOf(weak))
    }

    /** GT-A02: clearing root allows the single node to be collected. */
    @Test
    fun gtA02_clearingRootAllowsSingleNodeCollection() {
        val scenario = singleNodeAfterRootClear()
        assertNull(scenario.root.ref)
        assertAllCollected(scenario.weaks)
    }

    private fun singleNodeReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        val oldNode = GraphNode(103)
        val root = GraphRoot(oldNode)
        val oldWeak = WeakReference(oldNode)
        val newNode = GraphNode(130)
        root.ref = newNode
        val newWeak = WeakReference(newNode)
        return ReplacementWeaks(root, listOf(oldWeak), listOf(newWeak))
    }

    /** GT-A03: replacing root releases the old node and keeps the new node alive. */
    @Test
    fun gtA03_replacingSingleNodeRootReleasesOldNodeAndKeepsNewNodeAlive() {
        val scenario = singleNodeReplacement()
        forceGc()
        assertAllCollected(scenario.oldWeaks)
        assertAllAlive(scenario.newWeaks)
        assertEquals(130, scenario.root.ref!!.id)
    }

    /** GT-A04: a single node with an empty next field remains alive through root. */
    @Test
    fun gtA04_singleNodeWithEmptyReferenceFieldRemainsAlive() {
        val scenario = singleNodeRoot(104)
        scenario.root.ref!!.next = null
        forceGc()
        assertEquals(104, scenario.root.ref!!.id)
        assertNull(scenario.root.ref!!.next)
        assertAllAlive(scenario.weaks)
    }

    /** GT-A05: a single node with multiple empty reference fields remains alive through root. */
    @Test
    fun gtA05_singleNodeWithMultipleEmptyReferenceFieldsRemainsAlive() {
        val scenario = singleNodeRoot(105)
        scenario.root.ref!!.next = null
        scenario.root.ref!!.left = null
        scenario.root.ref!!.right = null
        forceGc()
        assertEquals(105, scenario.root.ref!!.id)
        assertNull(scenario.root.ref!!.left)
        assertNull(scenario.root.ref!!.right)
        assertAllAlive(scenario.weaks)
    }

    private fun weakOnlySingleNode(): WeakReference<GraphNode> {
        val node = GraphNode(106)
        return WeakReference(node)
    }

    /** GT-A06: a helper creates a single node and only WeakReference escapes. */
    @Test
    fun gtA06_weakOnlySingleNodeCanBeCollected() {
        assertWeakCollected(weakOnlySingleNode())
    }
}
