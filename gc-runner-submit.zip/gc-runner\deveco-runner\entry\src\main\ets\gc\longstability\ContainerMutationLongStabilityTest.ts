import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class ContainerMutationLongStabilityTest extends LongStabilityTestSupport {

    ls_f01_arrayReplaceChurn() {
        const array = new Array<LsNode | null>(32).fill(null);
        const samples = this.containerSamples(i => { array[i % array.length] = new LsNode(i); });
        assertTrue(array.some(it => it !== null));
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f02_listAddRemoveChurn() {
        const list: LsNode[] = [];
        const samples = this.containerSamples(i => { list.push(new LsNode(i)); if (list.length > 16) list.shift(); });
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f03_listClearRefillChurn() {
        const list: LsNode[] = [];
        const samples = this.containerSamples(i => { list.length = 0; for (let index = 0; index < 16; index++) list.push(new LsNode(i * 16 + index)); });
        assertTrue(list.length > 0);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f04_mapPutRemoveChurn() {
        const map = new Map<number, LsNode>();
        const samples = this.containerSamples(i => { map.set(i, new LsNode(i)); map.delete(i - 16); });
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f05_mapClearRefillChurn() {
        const map = new Map<number, LsNode>();
        const samples = this.containerSamples(i => { map.clear(); for (let index = 0; index < 16; index++) map.set(index, new LsNode(i * 16 + index)); });
        assertTrue(map.size > 0);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f06_setAddRemoveChurn() {
        const set = new Set<LsNode>();
        const samples = this.containerSamples(i => { set.add(new LsNode(i)); if (set.size > 16) set.delete(Array.from(set)[0]); });
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f07_lruLikeCacheChurn() {
        const cache = new Map<number, LargePayload>();
        const samples = this.containerSamples(i => { cache.set(i, new LargePayload(i, new Array(MEDIUM_BYTES).fill(0))); if (cache.size > CACHE_LIMIT) cache.delete(Array.from(cache.keys())[0]); });
        assertTrue(cache.size <= CACHE_LIMIT);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f08_imageCacheSimulation() {
        const cache = new Map<number, LargePayload>();
        const samples = this.containerSamples(i => { cache.set(i, new LargePayload(i, new Array(MEDIUM_BYTES).fill(0))); if (cache.size > CACHE_LIMIT) cache.delete(Array.from(cache.keys())[0]); });
        assertTrue(cache.size <= CACHE_LIMIT);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f09_nestedContainerChurn() {
        const outer: Map<number, FakeDto>[] = [];
        const samples = this.containerSamples(i => { outer.push(new Map([[i, new FakeDto(i, `n${i}`, [])]])); if (outer.length > 16) outer.shift(); });
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_f10_containerMutationExceptionPath() {
        const list: LsNode[] = [];
        const samples = this.containerSamples(i => { try { list.push(new LsNode(i)); if (i % 5 === 0) throw new Error("mutation"); } catch (_e) { list.length = 0; } });
        this.assertNoSustainedMonotonicGrowth(samples);
    }
}
