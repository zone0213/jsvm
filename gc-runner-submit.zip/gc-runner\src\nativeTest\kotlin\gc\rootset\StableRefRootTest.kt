@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlinx.cinterop.ExperimentalForeignApi::class,
)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * RS-G group: StableRef root tests.
 */
class StableRefRootTest : RootSetTestSupport() {
    /**
     * RS-G01
     * Scenario: StableRef is created for a single payload.
     * Expectation: payload remains alive until StableRef is disposed.
     */
    @Test
    fun rsG01_stableRefKeepsSingleObjectAlive() {
        val obj = RootPayload(7001)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        try {
            forceGc()
            assertEquals(7001, stable.get().id)
            assertNotNull(weak.value)
        } finally {
            stable.dispose()
        }
    }

    private fun createWeakAfterStableRefDisposed(): WeakReference<RootPayload> {
        val obj = RootPayload(7002)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        stable.dispose()
        return weak
    }

/**
     * RS-G02
     * Scenario: StableRef is disposed after creation.
     * Expectation: payload can be collected after dispose.
     */
    @Test
    fun rsG02_stableRefDisposeAllowsCollection() {
        val weak = createWeakAfterStableRefDisposed()
        assertWeakCollected(weak)
    }

/**
     * RS-G03
     * Scenario: StableRef points to holder that references payload.
     * Expectation: holder and payload remain alive.
     */
    @Test
    fun rsG03_stableRefToHolderKeepsHolderAndValueAlive() {
        val obj = RootPayload(7003)
        val holder = RootHolder(obj)
        val weak = WeakReference(obj)
        val stable = stableRefOf(holder)
        try {
            forceGc()
            assertEquals(7003, stable.get().ref!!.id)
            assertNotNull(weak.value)
        } finally {
            stable.dispose()
        }
    }

    private fun createWeaksAfterHolderStableRefDisposed(): List<WeakReference<RootPayload>> {
        val obj = RootPayload(7004)
        val holder = RootHolder(obj)
        val objWeak = WeakReference(obj)
        val holderPayloadWeak = WeakReference(holder.ref!!)
        val stable = stableRefOf(holder)
        stable.dispose()
        return listOf(objWeak, holderPayloadWeak)
    }

/**
     * RS-G04
     * Scenario: StableRef to holder is disposed.
     * Expectation: holder value can be collected when no other root remains.
     */
    @Test
    fun rsG04_disposeHolderStableRefAllowsHolderValueCollection() {
        val weaks = createWeaksAfterHolderStableRefDisposed()
        assertAllWeakCollected(weaks)
    }

/**
     * RS-G05
     * Scenario: StableRef points to payload with child graph.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsG05_stableRefToChildGraphKeepsGraphAlive() {
        val child = RootPayload(70051)
        val obj = RootPayload(7005, child)
        val childWeak = WeakReference(child)
        val stable = stableRefOf(obj)
        try {
            forceGc()
            assertEquals(70051, stable.get().child!!.id)
            assertNotNull(childWeak.value)
        } finally {
            stable.dispose()
        }
    }

    private fun createWeaksAfterChildGraphStableRefDisposed(): List<WeakReference<RootPayload>> {
        val child = RootPayload(70061)
        val obj = RootPayload(7006, child)
        val objWeak = WeakReference(obj)
        val childWeak = WeakReference(child)
        val stable = stableRefOf(obj)
        stable.dispose()
        return listOf(objWeak, childWeak)
    }

/**
     * RS-G06
     * Scenario: StableRef to child graph root is disposed.
     * Expectation: parent and child can be collected.
     */
    @Test
    fun rsG06_disposeChildGraphStableRefAllowsGraphCollection() {
        val weaks = createWeaksAfterChildGraphStableRefDisposed()
        assertAllWeakCollected(weaks)
    }

/**
     * RS-G07
     * Scenario: two StableRefs point to the same payload.
     * Expectation: payload remains alive while either StableRef exists.
     */
    @Test
    fun rsG07_twoStableRefsToSameObjectKeepObjectAlive() {
        val obj = RootPayload(7007)
        val weak = WeakReference(obj)
        val stable1 = stableRefOf(obj)
        val stable2 = stableRefOf(obj)
        try {
            forceGc()
            assertEquals(7007, stable1.get().id)
            assertEquals(7007, stable2.get().id)
            assertNotNull(weak.value)
        } finally {
            stable1.dispose()
            stable2.dispose()
        }
    }

/**
     * RS-G08
     * Scenario: one of two StableRefs is disposed.
     * Expectation: payload remains alive through the remaining StableRef.
     */
    @Test
    fun rsG08_disposeOneOfTwoStableRefsKeepsObjectAlive() {
        val obj = RootPayload(7008)
        val weak = WeakReference(obj)
        val stable1 = stableRefOf(obj)
        val stable2 = stableRefOf(obj)
        stable1.dispose()
        try {
            forceGc()
            assertEquals(7008, stable2.get().id)
            assertNotNull(weak.value)
        } finally {
            stable2.dispose()
        }
    }

    private fun createWeakAfterAllStableRefsDisposed(): WeakReference<RootPayload> {
        val obj = RootPayload(7009)
        val weak = WeakReference(obj)
        val stable1 = stableRefOf(obj)
        val stable2 = stableRefOf(obj)
        stable1.dispose()
        stable2.dispose()
        return weak
    }

/**
     * RS-G09
     * Scenario: all StableRefs to an object are disposed.
     * Expectation: payload can be collected.
     */
    @Test
    fun rsG09_disposeAllStableRefsAllowsCollection() {
        val weak = createWeakAfterAllStableRefsDisposed()
        assertWeakCollected(weak)
    }

/**
     * RS-G10
     * Scenario: StableRef is created for Any-typed payload.
     * Expectation: runtime payload remains alive.
     */
    @Test
    fun rsG10_stableRefToAnyKeepsRuntimeObjectAlive() {
        val obj: Any = RootPayload(7010)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        try {
            forceGc()
            assertEquals(7010, (stable.get() as RootPayload).id)
            assertNotNull(weak.value)
        } finally {
            stable.dispose()
        }
    }

/**
     * RS-G11
     * Scenario: StableRef is created for interface-typed payload.
     * Expectation: runtime payload remains alive.
     */
    @Test
    fun rsG11_stableRefToInterfaceKeepsRuntimeObjectAlive() {
        val obj: RootMarker = RootPayload(7011)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        try {
            forceGc()
            assertEquals(7011, stable.get().id)
            assertNotNull(weak.value)
        } finally {
            stable.dispose()
        }
    }

/**
     * RS-G12
     * Scenario: many StableRefs point to different payload objects.
     * Expectation: all payloads remain alive while StableRefs exist.
     */
    @Test
    fun rsG12_batchStableRefsKeepAllObjectsAlive() {
        val objects = List(20) { index -> RootPayload(70120 + index) }
        val weaks = objects.map { WeakReference(it) }
        val stableRefs = objects.map { stableRefOf(it) }
        try {
            forceGc()
            assertAllWeakAlive(weaks)
            assertEquals(70120, stableRefs.first().get().id)
        } finally {
            stableRefs.forEach { it.dispose() }
        }
    }

    private fun createBatchWeaksAfterStableRefsDisposed(): List<WeakReference<RootPayload>> {
        val objects = List(20) { index -> RootPayload(70130 + index) }
        val weaks = objects.map { WeakReference(it) }
        val stableRefs = objects.map { stableRefOf(it) }
        stableRefs.forEach { it.dispose() }
        return weaks
    }

/**
     * RS-G13
     * Scenario: many StableRefs are disposed.
     * Expectation: all payloads can be collected.
     */
    @Test
    fun rsG13_batchDisposeStableRefsAllowsCollection() {
        val weaks = createBatchWeaksAfterStableRefsDisposed()
        assertAllWeakCollected(weaks)
    }

/**
     * RS-G14
     * Scenario: StableRef is disposed exactly once in test code.
     * Expectation: the test documents the no-double-dispose rule and avoids invalid double disposal.
     */
    @Test
    fun rsG14_stableRefDisposeIsCalledExactlyOnce() {
        val obj = RootPayload(7014)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        stable.dispose()
        forceGc()
        assertNull(weak.value)
    }
}
