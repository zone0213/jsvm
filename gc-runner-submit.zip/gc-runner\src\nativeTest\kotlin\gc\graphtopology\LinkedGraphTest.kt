@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/** GT-B group: linear linked graph tests. */
class LinkedGraphTest : GraphTopologyTestSupport() {

    private fun chainRoot(length: Int, startId: Int): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildGraphNodeChain(length, startId)
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-B01: a 2-node chain keeps head and tail alive. */
    @Test
    fun gtB01_twoNodeChainKeepsAllNodesAlive() {
        val scenario = chainRoot(2, 201)
        forceGc()
        assertEquals(201, scenario.root.ref!!.id)
        assertEquals(202, scenario.root.ref!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-B02: a 3-node chain keeps head, middle and tail alive. */
    @Test
    fun gtB02_threeNodeChainKeepsAllNodesAlive() {
        val scenario = chainRoot(3, 210)
        forceGc()
        assertEquals(212, scenario.root.ref!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-B03: a 10-node chain keeps representative nodes alive. */
    @Test
    fun gtB03_tenNodeChainKeepsHeadMiddleAndTailAlive() {
        val scenario = chainRoot(10, 220)
        forceGc()
        assertEquals(220, scenario.weaks[0].value!!.id)
        assertEquals(225, scenario.weaks[5].value!!.id)
        assertEquals(229, scenario.weaks[9].value!!.id)
        assertAllAlive(scenario.weaks)
    }

    /** GT-B04: a 100-node chain keeps head, middle and tail alive. */
    @Test
    fun gtB04_hundredNodeChainKeepsRepresentativeNodesAlive() {
        val scenario = chainRoot(100, 240)
        forceGc()
        assertEquals(240, scenario.weaks[0].value!!.id)
        assertEquals(289, scenario.weaks[49].value!!.id)
        assertEquals(339, scenario.weaks[99].value!!.id)
        assertNotNull(scenario.root.ref)
    }

    private fun chainAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildGraphNodeChain(100, 350)
        val root = GraphRoot(nodes.first())
        val weaks = weakRefs(nodes)
        root.ref = null
        return RootedWeaks(root, weaks)
    }

    /** GT-B05: clearing root allows the entire chain to be collected. */
    @Test
    fun gtB05_clearingRootAllowsEntireChainCollection() {
        val scenario = chainAfterRootClear()
        assertNull(scenario.root.ref)
        assertAllCollected(scenario.weaks)
    }

    private fun chainAfterHeadNextClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildGraphNodeChain(10, 460)
        val root = GraphRoot(nodes.first())
        nodes[0].next = null
        return MixedWeaks(root, weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-B06: clearing head.next keeps head alive and collects the suffix. */
    @Test
    fun gtB06_clearingHeadNextCollectsSuffixOnly() {
        val scenario = chainAfterHeadNextClear()
        forceGc()
        assertEquals(460, scenario.root.ref!!.id)
        assertNull(scenario.root.ref!!.next)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun chainAfterMiddleNextClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildGraphNodeChain(100, 500)
        val root = GraphRoot(nodes.first())
        nodes[49].next = null
        return MixedWeaks(root, weakRefs(nodes.take(50)), weakRefs(nodes.drop(50)))
    }

    /** GT-B07: clearing a middle edge keeps the prefix alive and collects the suffix. */
    @Test
    fun gtB07_clearingMiddleNextCollectsSuffixOnly() {
        val scenario = chainAfterMiddleNextClear()
        forceGc()
        assertEquals(549, scenario.aliveWeaks.last().value!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun chainAfterTailBeforeClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = buildGraphNodeChain(100, 700)
        val root = GraphRoot(nodes.first())
        nodes[98].next = null
        return MixedWeaks(root, weakRefs(nodes.take(99)), weakRefs(nodes.drop(99)))
    }

    /** GT-B08: clearing the edge before the tail collects only the tail. */
    @Test
    fun gtB08_clearingTailBeforeEdgeCollectsTailOnly() {
        val scenario = chainAfterTailBeforeClear()
        forceGc()
        assertEquals(798, scenario.aliveWeaks.last().value!!.id)
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun headSubChainReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        val oldNodes = buildGraphNodeChain(10, 820)
        val root = GraphRoot(oldNodes.first())
        val oldSuffixWeaks = weakRefs(oldNodes.drop(1))
        val newNodes = buildGraphNodeChain(3, 900)
        root.ref!!.next = newNodes.first()
        return ReplacementWeaks(root, oldSuffixWeaks, weakRefs(newNodes))
    }

    /** GT-B09: replacing head.next collects the old suffix and keeps the new suffix alive. */
    @Test
    fun gtB09_replacingHeadSubChainCollectsOldSuffixAndKeepsNewSuffixAlive() {
        val scenario = headSubChainReplacement()
        forceGc()
        assertEquals(900, scenario.root.ref!!.next!!.id)
        assertAllCollected(scenario.oldWeaks)
        assertAllAlive(scenario.newWeaks)
    }

    private fun middleSubChainReplacement(): ReplacementWeaks<GraphRoot<GraphNode>, GraphNode> {
        val oldNodes = buildGraphNodeChain(100, 1000)
        val root = GraphRoot(oldNodes.first())
        val oldSuffixWeaks = weakRefs(oldNodes.drop(50))
        val newNodes = buildGraphNodeChain(5, 2000)
        oldNodes[49].next = newNodes.first()
        return ReplacementWeaks(root, oldSuffixWeaks, weakRefs(newNodes))
    }

    /** GT-B10: replacing middle.next collects the old suffix and keeps the new suffix alive. */
    @Test
    fun gtB10_replacingMiddleSubChainCollectsOldSuffixAndKeepsNewSuffixAlive() {
        val scenario = middleSubChainReplacement()
        forceGc()
        assertEquals(2000, scenario.newWeaks.first().value!!.id)
        assertAllCollected(scenario.oldWeaks)
        assertAllAlive(scenario.newWeaks)
    }

    private fun nullTerminatedChainWithOrphans(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val reachable = buildGraphNodeChain(3, 3000)
        val orphans = buildGraphNodeChain(3, 4000)
        val root = GraphRoot(reachable.first())
        reachable.last().next = null
        return MixedWeaks(root, weakRefs(reachable), weakRefs(orphans))
    }

    /** GT-B11: a null-terminated chain keeps reachable prefix and collects orphan nodes. */
    @Test
    fun gtB11_nullTerminatedChainKeepsPrefixAndCollectsOrphans() {
        val scenario = nullTerminatedChainWithOrphans()
        forceGc()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun weakOnlyDeepChain(): List<WeakReference<GraphNode>> {
        val nodes = buildGraphNodeChain(100, 5000)
        return weakRefs(nodes)
    }

    /** GT-B12: a helper creates a 100-node chain and only WeakReferences escape. */
    @Test
    fun gtB12_weakOnlyDeepChainCanBeCollected() {
        assertAllCollected(weakOnlyDeepChain())
    }
}
