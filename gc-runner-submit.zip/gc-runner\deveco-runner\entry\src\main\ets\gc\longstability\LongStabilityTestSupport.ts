import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue, assertNotNull, assertNull, assertEquals } from '../TestAssertions';

type GCInfo = {
    memoryUsageAfter: { heap: { totalObjectsSizeBytes: number } };
    sweepStatistics: Map<string, { sweptCount: number; keptCount: number }>;
};

export const SMALL_BATCH = 256;
export const MEDIUM_BATCH = 96;
export const LARGE_BATCH = 8;
export const MIXED_BATCH = 32;
export const SHORT_ITERATIONS = 24;
export const WORKER_ITERATIONS = 16;
export const WORKER_COUNT = 3;
export const CHURN_PER_ITERATION = 128;
export const SAMPLE_EVERY = 4;
export const MEDIUM_BYTES = 8 * 1024;
export const LARGE_BYTES = 64 * 1024;
export const SPIKE_ITERATIONS = 8;
export const CACHE_LIMIT = 16;

export class LongStabilityTestSupport {
    protected forceGc(times: number = 3) {
        for (let i = 0; i < times; i++) GC.collect();
    }

    protected gcInfo(): GCInfo {
        GC.collect();
        return {
            memoryUsageAfter: { heap: { totalObjectsSizeBytes: 0 } },
            sweepStatistics: new Map<string, { sweptCount: number; keptCount: number }>([
                ['mock', { sweptCount: 0, keptCount: 0 }]
            ])
        };
    }

    protected heapAfterBytes(): number {
        return this.gcInfo().memoryUsageAfter.heap.totalObjectsSizeBytes;
    }

    protected sweptCount(info: GCInfo = this.gcInfo()): number {
        return Array.from(info.sweepStatistics.values()).reduce((sum, it) => sum + it.sweptCount, 0);
    }

    protected keptCount(info: GCInfo = this.gcInfo()): number {
        return Array.from(info.sweepStatistics.values()).reduce((sum, it) => sum + it.keptCount, 0);
    }

    protected assertGcInfoReadable() {
        const info = this.gcInfo();
        const heap = info.memoryUsageAfter.heap;
        assertNotNull(heap, 'Expected heap memory usage to be available.');
        assertTrue(heap.totalObjectsSizeBytes >= 0);
        assertTrue(this.sweptCount(info) >= 0);
        assertTrue(this.keptCount(info) >= 0);
    }

    protected assertNoSustainedMonotonicGrowth(samples: number[], maxRun: number = 4) {
        if (samples.length < 3) return;
        let currentRun = 0;
        let longestRun = 0;
        for (let index = 1; index < samples.length; index++) {
            if (samples[index] > samples[index - 1]) {
                currentRun++;
                if (currentRun > longestRun) longestRun = currentRun;
            } else {
                currentRun = 0;
            }
        }
        assertTrue(longestRun <= maxRun, `Heap grew for too many consecutive samples: ${samples}`);
    }

    protected assertSpikeRecovered(before: number, peak: number, after: number) {
        assertTrue(peak >= before, 'Expected spike peak to be >= baseline.');
        assertTrue(after <= peak, 'Expected heap after release to be <= spike peak.');
    }

    protected assertWeakCollectedEventually<T>(weak: WeakReference<T>) {
        this.forceGc(6);
        weak.clear();
        assertNull(weak.value);
    }

    protected assertAllWeakCollectedEventually<T>(weaks: Iterable<WeakReference<T>>) {
        this.forceGc(6);
        let index = 0;
        for (const weak of weaks) {
            weak.clear();
            assertNull(weak.value, `Expected weak[${index}] to be cleared.`);
            index++;
        }
    }

    protected shortLivedSamples(iterationsOrAllocator: number | ((index: number) => any) = SHORT_ITERATIONS, maybeAllocator?: (index: number) => any): number[] {
        const iterations = typeof iterationsOrAllocator === 'number' ? iterationsOrAllocator : SHORT_ITERATIONS;
        const allocator = typeof iterationsOrAllocator === 'function' ? iterationsOrAllocator : maybeAllocator!;
        const samples: number[] = [];
        for (let iteration = 0; iteration < iterations; iteration++) {
            for (let item = 0; item < CHURN_PER_ITERATION; item++) {
                allocator(iteration * CHURN_PER_ITERATION + item);
            }
            if (iteration % SAMPLE_EVERY === 0) {
                this.forceGc();
                samples.push(this.heapAfterBytes());
            }
        }
        this.forceGc();
        samples.push(this.heapAfterBytes());
        return samples;
    }

    protected containerSamples(iterationsOrOperation: number | ((index: number) => void) = SHORT_ITERATIONS, maybeOperation?: (index: number) => void): number[] {
        const iterations = typeof iterationsOrOperation === 'number' ? iterationsOrOperation : SHORT_ITERATIONS;
        const operation = typeof iterationsOrOperation === 'function' ? iterationsOrOperation : maybeOperation!;
        const samples: number[] = [];
        for (let iteration = 0; iteration < iterations; iteration++) {
            operation(iteration);
            if (iteration % SAMPLE_EVERY === 0) {
                this.forceGc();
                samples.push(this.heapAfterBytes());
            }
        }
        this.forceGc();
        samples.push(this.heapAfterBytes());
        return samples;
    }

    protected releaseReallocateSamples(iterationsOrAllocate: number | (() => any[]) = SHORT_ITERATIONS, maybeAllocate?: () => any[]): number[] {
        const iterations = typeof iterationsOrAllocate === 'number' ? iterationsOrAllocate : SHORT_ITERATIONS;
        const allocate = typeof iterationsOrAllocate === 'function' ? iterationsOrAllocate : maybeAllocate!;
        const samples: number[] = [];
        for (let i = 0; i < iterations; i++) {
            const roots = allocate().slice();
            assertTrue(roots.length > 0);
            roots.length = 0;
            this.forceGc();
            samples.push(this.heapAfterBytes());
        }
        return samples;
    }

    protected spikeLoop(iterationsOrAllocate: number | (() => any[]) = SPIKE_ITERATIONS, maybeAllocate?: () => any[]): [number, number, number] {
        const iterations = typeof iterationsOrAllocate === 'number' ? iterationsOrAllocate : SPIKE_ITERATIONS;
        const allocate = typeof iterationsOrAllocate === 'function' ? iterationsOrAllocate : maybeAllocate!;
        const before = this.heapAfterBytes();
        let peak = before;
        for (let i = 0; i < iterations; i++) {
            const roots = allocate();
            this.forceGc();
            const during = this.heapAfterBytes();
            if (during > peak) peak = during;
            roots.length = 0;
            this.forceGc();
        }
        return [before, peak, this.heapAfterBytes()];
    }

    protected longLivedWithGarbage(rootFactory: () => any, garbageFactory: (index: number) => any): WeakReference<any> {
        const root = rootFactory();
        const weak = new WeakReference(root);
        for (let iteration = 0; iteration < SHORT_ITERATIONS; iteration++) {
            for (let item = 0; item < CHURN_PER_ITERATION; item++) {
                garbageFactory(iteration * CHURN_PER_ITERATION + item);
            }
            if (iteration % SAMPLE_EVERY === 0) this.forceGc();
            assertNotNull(weak.value);
        }
        return weak;
    }

    protected allocateSmallBatch(count: number = SMALL_BATCH): LsNode[] {
        return Array.from({ length: count }, (_, index) => new LsNode(index));
    }

    protected allocateMediumBatch(count: number = MEDIUM_BATCH): MediumPayload[] {
        return Array.from({ length: count }, (_, index) => new MediumPayload(index));
    }

    protected allocateLargeBatch(count: number = LARGE_BATCH, size: number = LARGE_BYTES): LargePayload[] {
        return Array.from({ length: count }, (_, index) => new LargePayload(index, Array.from({ length: size }, (_, it) => it % 127)));
    }

    protected allocateMixedBatch(count: number = MIXED_BATCH): MixedPayload[] {
        return Array.from({ length: count }, (_, index) => new MixedPayload(index));
    }

    protected runPseudoWorkers(workerCountOrBody: number | ((worker: number, iteration: number) => void) = WORKER_COUNT, iterationsOrBody?: number | ((worker: number, iteration: number) => void), maybeBody?: (worker: number, iteration: number) => void): number {
        const workerCount = typeof workerCountOrBody === 'number' ? workerCountOrBody : WORKER_COUNT;
        const iterations = typeof iterationsOrBody === 'number' ? iterationsOrBody : WORKER_ITERATIONS;
        const body = (typeof workerCountOrBody === 'function' ? workerCountOrBody : (typeof iterationsOrBody === 'function' ? iterationsOrBody : maybeBody))!;
        let completed = 0;
        for (let worker = 0; worker < workerCount; worker++) {
            for (let iteration = 0; iteration < iterations; iteration++) {
                body(worker, iteration);
                if (iteration % SAMPLE_EVERY === 0) this.forceGc(1);
            }
            completed++;
        }
        return completed;
    }

    protected coroutineLikeBatch(count: number = SHORT_ITERATIONS): WeakReference<LsNode>[] {
        const continuations: FakeContinuation[] = [];
        const weaks: WeakReference<LsNode>[] = [];
        for (let index = 0; index < count; index++) {
            const payload = new LsNode(index);
            continuations.push(new FakeContinuation(payload));
            weaks.push(new WeakReference(payload));
        }
        this.forceGc();
        for (const continuation of continuations) continuation.resume();
        continuations.length = 0;
        return weaks;
    }

    protected pinnedLikeLoop(iterations: number = SHORT_ITERATIONS, throwInside: boolean = false): number {
        let count = 0;
        for (let index = 0; index < iterations; index++) {
            const bytes = Array.from({ length: MEDIUM_BYTES }, (_, it) => it + index);
            try {
                PinnedLike.use(bytes, array => {
                    array[0] = index;
                    this.forceGc(1);
                    if (throwInside && index % 7 === 0) throw new Error('pinned-like failure');
                    assertEquals(index, array[0]);
                    count++;
                });
            } catch (_e) {
                count++;
            }
        }
        return count;
    }

    protected businessDtoSamples(iterations: number = SHORT_ITERATIONS): number[] {
        return this.containerSamples(iterations, index => {
            const dto = new FakeDto(index, `name-${index}`, Array.from({ length: 8 }, (_, it) => new FakeDtoChild(it, `value-${index}-${it}`)));
            const decoded = FakeDto.decode(dto.encode());
            assertEquals(dto.id, decoded.id);
        });
    }

    protected repositoryCacheStateSamples(iterations: number = SHORT_ITERATIONS): number[] {
        const cache = new Map<number, LargePayload>();
        let state = new FakeState([]);
        return this.containerSamples(iterations, index => {
            const dto = new FakeDto(index, `repo-${index}`, Array.from({ length: 4 }, (_, it) => new FakeDtoChild(it, `v${it}`)));
            state = state.reduce(dto);
            cache.set(index, new LargePayload(index, new Array(1024).fill(0)));
            if (cache.size > CACHE_LIMIT) cache.delete(Array.from(cache.keys())[0]);
            assertTrue(state.items.length > 0);
        });
    }
}

export class LsNode {
    constructor(public id: number, public child: LsNode | null = null) {}
}

export class MediumPayload {
    constructor(public id: number, public refs: (LsNode | null)[] = new Array<LsNode | null>(64).fill(null)) {}
}

export class LargePayload {
    constructor(public id: number, public bytes: number[]) {}
}

export class MixedPayload {
    node: LsNode;
    medium: MediumPayload;
    large: LargePayload;
    constructor(public id: number) {
        this.node = new LsNode(id);
        this.medium = new MediumPayload(id);
        this.large = new LargePayload(id, new Array(1024).fill(0));
    }
}

export class Holder<T> {
    constructor(public ref: T | null) {}
}

export class FakeContinuation {
    constructor(public payload: LsNode | null) {}

    resume(): number {
        const id = this.payload!.id;
        this.payload = null;
        return id;
    }
}

export const PinnedLike = {
    use<T>(array: number[], block: (array: number[]) => T): T {
        return block(array);
    }
};

export class FakeDto {
    constructor(public id: number, public name: string, public children: FakeDtoChild[]) {}

    encode(): string {
        return `${this.id}|${this.name}|` + this.children.map(it => `${it.id}:${it.value}`).join(',');
    }

    static decode(raw: string): FakeDto {
        const parts = raw.split('|');
        const id = Number(parts[0]);
        const name = parts[1];
        const children = parts.length > 2 && parts[2].length > 0
            ? parts[2].split(',').map(it => {
                const childParts = it.split(':');
                return new FakeDtoChild(Number(childParts[0]), childParts[1]);
            })
            : [];
        return new FakeDto(id, name, children);
    }
}

export class FakeDtoChild {
    constructor(public id: number, public value: string) {}
}

export class FakeState {
    constructor(public items: FakeDto[]) {}

    reduce(dto: FakeDto): FakeState {
        return new FakeState([...this.items, dto].slice(-32));
    }
}

export const globalHolder = new Holder<LsNode>(null);
export { WeakReference };
