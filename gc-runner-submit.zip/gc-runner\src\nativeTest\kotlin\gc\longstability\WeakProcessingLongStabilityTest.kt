@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * LS-I group: WeakReference processing long-stability tests.
 */
class WeakProcessingLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-I01
     * Scenario: many weak same target alive.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i01_manyWeakSameTargetAlive() {
        val target = LsNode(1)
        val weaks = List(256) { WeakReference(target) }
        forceGc()
        assertTrue(weaks.all { it.value != null })
        assertEquals(1, target.id)
    }

    /**
     * LS-I02
     * Scenario: many weak same target released.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i02_manyWeakSameTargetReleased() {
        fun makeWeaks(): List<WeakReference<LsNode>> {
            val target = LsNode(2)
            return List(256) { WeakReference(target) }
        }

        assertAllWeakCollectedEventually(makeWeaks())
    }

    /**
     * LS-I03
     * Scenario: one weak per short-lived object.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i03_oneWeakPerShortLivedObject() {
        fun makeWeaks(): List<WeakReference<LsNode>> {
            return List(256) { WeakReference(LsNode(it)) }
        }

        assertAllWeakCollectedEventually(makeWeaks())
    }

    /**
     * LS-I04
     * Scenario: partial strong weak batch.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i04_partialStrongWeakBatch() {
        val roots = mutableListOf<LsNode>()
        val alive = mutableListOf<WeakReference<LsNode>>()
        val dead = mutableListOf<WeakReference<LsNode>>()
        repeat(64) {
            val node = LsNode(it)
            val weak = WeakReference(node)
            if (it % 2 == 0) {
                roots.add(node)
                alive.add(weak)
            } else {
                dead.add(weak)
            }
        }
        forceGc()
        assertTrue(alive.all { it.value != null })
        assertTrue(roots.isNotEmpty())
        assertAllWeakCollectedEventually(dead)
    }

    /**
     * LS-I05
     * Scenario: weak list churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i05_weakListChurn() {
        val list = mutableListOf<WeakReference<LsNode>>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                list.add(WeakReference(LsNode(i)))
                if (list.size > 64) {
                    list.removeAt(0)
                }
            }
        )
    }

    /**
     * LS-I06
     * Scenario: weak map churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i06_weakMapChurn() {
        val map = mutableMapOf<Int, WeakReference<LsNode>>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                map[i] = WeakReference(LsNode(i))
                map.remove(i - 64)
            }
        )
    }

    /**
     * LS-I07
     * Scenario: toggle strong root.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i07_toggleStrongRoot() {
        val holder = Holder<LsNode>(null)
        var weak: WeakReference<LsNode>? = null
        containerSamples { i ->
            if (i % 2 == 0) {
                holder.ref = LsNode(i)
                weak = WeakReference(holder.ref!!)
            } else {
                holder.ref = null
            }
        }
        forceGc()
        assertTrue(holder.ref != null || weak?.value == null)
    }

    /**
     * LS-I08
     * Scenario: weak with memory pressure.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i08_weakWithMemoryPressure() {
        val weaks = mutableListOf<WeakReference<LsNode>>()
        containerSamples { i ->
            weaks.add(WeakReference(LsNode(i)))
            LargePayload(i, ByteArray(1024))
        }
        forceGc()
        assertTrue(weaks.all { it.value == null || it.value!!.id >= 0 })
    }

    /**
     * LS-I09
     * Scenario: weak coroutine-like completion.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i09_weakCoroutineLikeCompletion() {
        assertAllWeakCollectedEventually(coroutineLikeBatch())
    }

    /**
     * LS-I10
     * Scenario: weak processing regression loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_i10_weakProcessingRegressionLoop() {
        val roots = mutableListOf<LsNode>()
        val weaks = mutableListOf<WeakReference<LsNode>>()
        containerSamples { i ->
            val node = LsNode(i)
            weaks.add(WeakReference(node))
            if (i % 4 == 0) {
                roots.add(node)
            }
            if (roots.size > 16) {
                roots.removeAt(0)
            }
        }
        forceGc()
        assertTrue(weaks.all { it.value == null || it.value!!.id >= 0 })
    }

}
