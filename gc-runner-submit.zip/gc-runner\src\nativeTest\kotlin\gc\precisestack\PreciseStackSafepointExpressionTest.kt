@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-H group: expression temporary safepoints.
 */
class PreciseStackSafepointExpressionTest : PreciseStackTestSupport() {
    private fun makePayload(id: Int): StackPayload = StackPayload(id)

    private fun makeHolder(id: Int): StackHolder<StackPayload> = StackHolder(StackPayload(id))

    private fun checkExpressionValue(obj: StackPayload): WeakReference<StackPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    /**
     * PS-H01
     * Scenario: constructor expression is passed directly to a callee that triggers GC.
     * Expectation: call argument temporary remains live at the callee safepoint.
     */
    @Test
    fun psH01_constructorCallArgumentTemporarySurvivesGc() {
        val weak = checkExpressionValue(StackPayload(8001))

        assertEquals(8001, weak.value!!.id)
    }

    /**
     * PS-H02
     * Scenario: safe-call expression obtains a child used after GC.
     * Expectation: expression temporary root keeps the child alive while it is still needed.
     */
    @Test
    fun psH02_safeCallExpressionTemporarySurvivesGc() {
        val root = StackPayload(8002, StackPayload(8020))
        val child = root.child ?: error("missing child")
        val childWeak = WeakReference(child)

        forceGc()

        assertEquals(8020, child.id)
        assertEquals(8020, childWeak.value!!.id)
        assertEquals(8020, root.child!!.id)
    }

    /**
     * PS-H03
     * Scenario: cast expression result is live across GC.
     * Expectation: cast temporary is scanned as a live reference.
     */
    @Test
    fun psH03_castExpressionTemporarySurvivesGc() {
        val anyValue: Any = makePayload(8003)
        val payload = anyValue as StackPayload
        val weak = WeakReference(payload)

        forceGc()

        assertEquals(8003, payload.id)
        assertEquals(8003, weak.value!!.id)
    }

    /**
     * PS-H04
     * Scenario: collection expression contains a payload used after GC.
     * Expectation: collection and selected element temporaries remain live until last use.
     */
    @Test
    fun psH04_collectionExpressionTemporarySurvivesGc() {
        val list = listOf(makePayload(8004))
        val first = list.first()
        val weak = WeakReference(first)

        forceGc()

        assertEquals(8004, first.id)
        assertEquals(8004, weak.value!!.id)
        assertEquals(8004, list.first().id)
    }

    /**
     * PS-H05
     * Scenario: holder factory result is used to extract a live payload before GC.
     * Expectation: extracted expression temporary remains live at safepoint.
     */
    @Test
    fun psH05_holderExpressionTemporarySurvivesGc() {
        val holder = makeHolder(8005)
        val obj = holder.ref!!
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(8005, obj.id)
        assertEquals(8005, weak.value!!.id)
        assertEquals(8005, holder.ref!!.id)
    }
}

