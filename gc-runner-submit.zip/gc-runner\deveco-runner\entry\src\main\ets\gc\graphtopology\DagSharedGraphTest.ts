﻿import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/** GT-D group: DAG and shared-subgraph tests. */
export class DagSharedGraphTest extends GraphTopologyTestSupport {

    private diamond(): GraphNode[] {
        const a = new GraphNode(8000);
        const b = new GraphNode(8001);
        const c = new GraphNode(8002);
        const d = new GraphNode(8003);
        a.left = b;
        a.right = c;
        b.next = d;
        c.next = d;
        return [a, b, c, d];
    }

    /** GT-D01: a diamond DAG keeps both branches and the shared leaf alive. */
    gtD01_diamondDagKeepsWholeGraphAlive() {
        const nodes = this.diamond();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(8003, scenario.root.ref!.left!.next!.id);
        assertEquals(8003, scenario.root.ref!.right!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private diamondAfterOneParentEdgeClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.diamond();
        const root = new GraphRoot(nodes.first());
        nodes[1].next = null;
        return new RootedWeaks(root, this.weakRefs(nodes));
    }

    /** GT-D02: clearing one parent edge does not collect a shared node that still has another parent. */
    gtD02_clearingOneParentEdgeKeepsSharedNodeAlive() {
        const scenario = this.diamondAfterOneParentEdgeClear();
        this.forceGc();
        assertNull(scenario.root.ref!.left!.next);
        assertEquals(8003, scenario.root.ref!.right!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private diamondAfterAllParentEdgesClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.diamond();
        const root = new GraphRoot(nodes.first());
        const shared = nodes[3];
        nodes[1].next = null;
        nodes[2].next = null;
        return new MixedWeaks(root, this.weakRefs(nodes.take(3)), this.weakRefs([shared]));
    }

    /** GT-D03: clearing all parent edges allows the shared leaf to be collected. */
    gtD03_clearingAllParentEdgesCollectsSharedNode() {
        const scenario = this.diamondAfterAllParentEdgesClear();
        this.forceGc();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private sharedSubChain(): GraphNode[] {
        const a = new GraphNode(8100);
        const b = new GraphNode(8101);
        const c = new GraphNode(8102);
        const d = new GraphNode(8103);
        const e = new GraphNode(8104);
        const f = new GraphNode(8105);
        a.left = b;
        a.right = c;
        b.next = d;
        c.next = d;
        d.next = e;
        e.next = f;
        return [a, b, c, d, e, f];
    }

    /** GT-D04: a shared sub-chain remains alive when both parents point to its head. */
    gtD04_sharedSubChainKeepsAllSharedNodesAlive() {
        const nodes = this.sharedSubChain();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(8105, nodes[3].next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private sharedSubChainAfterOneParentClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.sharedSubChain();
        nodes[1].next = null;
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-D05: a shared sub-chain survives when one of two parent edges is cleared. */
    gtD05_sharedSubChainSurvivesOneParentEdgeClear() {
        const scenario = this.sharedSubChainAfterOneParentClear();
        this.forceGc();
        assertEquals(8103, scenario.root.ref!.right!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private sharedSubChainAfterAllParentsClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.sharedSubChain();
        nodes[1].next = null;
        nodes[2].next = null;
        return new MixedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes.take(3)), this.weakRefs(nodes.drop(3)));
    }

    /** GT-D06: a shared sub-chain is collected after all parent edges are cleared. */
    gtD06_sharedSubChainCollectedAfterAllParentEdgesClear() {
        const scenario = this.sharedSubChainAfterAllParentsClear();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private threeParentsSharedLeaf(): GraphNode[] {
        const root = new GraphNode(8200);
        const p1 = new GraphNode(8201);
        const p2 = new GraphNode(8202);
        const p3 = new GraphNode(8203);
        const shared = new GraphNode(8204);
        root.left = p1;
        root.right = p2;
        root.next = p3;
        p1.next = shared;
        p2.next = shared;
        p3.next = shared;
        return [root, p1, p2, p3, shared];
    }

    /** GT-D07: three parents sharing one leaf keep the shared leaf alive. */
    gtD07_threeParentSharedLeafKeepsSharedLeafAlive() {
        const nodes = this.threeParentsSharedLeaf();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(8204, scenario.weaks.last().value!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private threeParentsAfterTwoEdgesClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.threeParentsSharedLeaf();
        nodes[1].next = null;
        nodes[2].next = null;
        return new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
    }

    /** GT-D08: clearing two of three parent edges still keeps the shared leaf alive. */
    gtD08_threeParentSharedLeafSurvivesPartialParentEdgeClear() {
        const scenario = this.threeParentsAfterTwoEdgesClear();
        this.forceGc();
        assertEquals(8204, scenario.root.ref!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private threeParentsAfterAllEdgesClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.threeParentsSharedLeaf();
        nodes[1].next = null;
        nodes[2].next = null;
        nodes[3].next = null;
        return new MixedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes.take(4)), this.weakRefs(nodes.drop(4)));
    }

    /** GT-D09: clearing all three parent edges allows the shared leaf to be collected. */
    gtD09_threeParentSharedLeafCollectedAfterAllParentEdgesClear() {
        const scenario = this.threeParentsAfterAllEdgesClear();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private repeatedFieldSharedNode(): GraphNode[] {
        const parent = new GraphNode(8300);
        const shared = new GraphNode(8301);
        parent.left = shared;
        parent.right = shared;
        parent.next = shared;
        return [parent, shared];
    }

    /** GT-D10: multiple fields from one parent to the same child keep the child alive. */
    gtD10_repeatedFieldReferencesKeepSharedNodeAlive() {
        const nodes = this.repeatedFieldSharedNode();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-D11: clearing one repeated field still keeps the shared node alive through other fields. */
    gtD11_clearingOneRepeatedFieldKeepsSharedNodeAlive() {
        const nodes = this.repeatedFieldSharedNode();
        nodes[0].left = null;
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertNull(scenario.root.ref!.left);
        assertEquals(8301, scenario.root.ref!.right!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private repeatedFieldAfterAllClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.repeatedFieldSharedNode();
        nodes[0].left = null;
        nodes[0].right = null;
        nodes[0].next = null;
        return new MixedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-D12: clearing all repeated fields allows the shared node to be collected. */
    gtD12_clearingAllRepeatedFieldsCollectsSharedNode() {
        const scenario = this.repeatedFieldAfterAllClear();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private repeatedListSharedNode(): MultiNode[] {
        const parent = new MultiNode(8400);
        const shared = new MultiNode(8401);
        parent.children.add(shared);
        parent.children.add(shared);
        parent.children.add(shared);
        return [parent, shared];
    }

    /** GT-D13: repeated List entries to the same node keep that node alive. */
    gtD13_listRepeatedReferencesKeepSharedNodeAlive() {
        const nodes = this.repeatedListSharedNode();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(3, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }

    /** GT-D14: removing one repeated List entry still keeps the shared node alive. */
    gtD14_removingOneRepeatedListReferenceKeepsSharedNodeAlive() {
        const nodes = this.repeatedListSharedNode();
        nodes[0].children.splice(0, 1);
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(2, scenario.root.ref!.children.size);
        this.assertAllAlive(scenario.weaks);
    }

    private repeatedListAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        const nodes = this.repeatedListSharedNode();
        nodes[0].children.clear();
        return new MixedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-D15: clearing all repeated List references allows the shared node to be collected. */
    gtD15_clearingRepeatedListReferencesCollectsSharedNode() {
        const scenario = this.repeatedListAfterClear();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
}
