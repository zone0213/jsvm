import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class ReleaseReallocateLongStabilityTest extends LongStabilityTestSupport {

    ls_d01_smallReleaseReallocate() {
        this.assertNoSustainedMonotonicGrowth(this.releaseReallocateSamples(() => this.allocateSmallBatch().map(it => it as any)));
    }

    ls_d02_mediumReleaseReallocate() {
        this.assertNoSustainedMonotonicGrowth(this.releaseReallocateSamples(() => this.allocateMediumBatch().map(it => it as any)));
    }

    ls_d03_largeReleaseReallocate() {
        this.assertNoSustainedMonotonicGrowth(this.releaseReallocateSamples(8, () => this.allocateLargeBatch(4, MEDIUM_BYTES).map(it => it as any)));
    }

    ls_d04_mixedReleaseReallocate() {
        this.assertNoSustainedMonotonicGrowth(this.releaseReallocateSamples(() => this.allocateMixedBatch().map(it => it as any)));
    }

    ls_d05_holderFieldReplacementLoop() {
        const holder = new Holder(new LsNode(0));
        const samples = this.containerSamples(i => { holder.ref = null; this.forceGc(1); holder.ref = new LsNode(i); });
        assertNotNull(holder.ref);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_d06_arraySlotReplacementLoop() {
        const array = new Array<LsNode | null>(16).fill(null);
        const samples = this.containerSamples(i => { const slot = i % array.length; array[slot] = null; array[slot] = new LsNode(i); });
        assertTrue(array.some(it => it !== null));
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_d07_listClearRefillLoop() {
        const list: LsNode[] = [];
        const samples = this.containerSamples(i => { list.length = 0; for (let index = 0; index < 16; index++) list.push(new LsNode(i * 16 + index)); });
        assertTrue(list.length > 0);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_d08_mapClearRefillLoop() {
        const map = new Map<number, LsNode>();
        const samples = this.containerSamples(i => { map.clear(); for (let index = 0; index < 16; index++) map.set(index, new LsNode(i * 16 + index)); });
        assertTrue(map.size > 0);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_d09_partialReleaseReallocate() {
        const roots = Array.from({ length: 32 }, (_, it) => new LsNode(it));
        const retained = new WeakReference(roots[1]);
        const samples = this.containerSamples(i => { for (let index = 0; index < roots.length; index += 2) roots[index] = new LsNode(i * 100 + index); });
        assertNotNull(retained.value);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_d10_alternatingSizeReuseProxy() {
        let toggle = false;
        this.assertNoSustainedMonotonicGrowth(this.releaseReallocateSamples(12, () => { toggle = !toggle; return toggle ? this.allocateSmallBatch(64).map(it => it as any) : this.allocateLargeBatch(2, MEDIUM_BYTES).map(it => it as any); }));
    }
}
