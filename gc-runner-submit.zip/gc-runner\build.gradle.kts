@file:Suppress("DEPRECATION")

import org.jetbrains.kotlin.gradle.plugin.mpp.KotlinNativeTarget

plugins {
    kotlin("multiplatform") version "2.1.21"
}

group = "gc.reachability"
version = "1.0.0"

val gcMode: String? = project.findProperty("gc") as? String
val selectedTargetName: String = project.findProperty("target") as? String ?: "macos_arm64"
val buildMode: String = project.findProperty("buildMode") as? String ?: "debug"
val nativeHome: String? = project.findProperty("kotlin.native.home") as? String
val dyldPath: String? = project.findProperty("dyldPath") as? String ?: nativeHome
val hdcTarget: String? = project.findProperty("hdcTarget") as? String

val targetDslName =
    when (selectedTargetName) {
        "macos_arm64" -> "macosArm64"
        "ohos_arm64" -> "ohosArm64"
        else -> error("Unsupported target: $selectedTargetName")
    }
val buildTypeName = if (buildMode == "opt") "Release" else "Debug"
val buildTypeDir = if (buildMode == "opt") "release" else "debug"
val macosLinkTaskName = "link${buildTypeName}TestMacosArm64"
val ohosCompileTaskName = "compile${buildTypeName}OhosArm64TestBinary"
val delegatedTestTask =
    when (selectedTargetName) {
        "macos_arm64" -> "macosArm64Test"
        "ohos_arm64" -> "ohosArm64DeviceTest"
        else -> error("Unsupported target: $selectedTargetName")
    }

fun KotlinNativeTarget.configureGcReachabilityTestCompilation() {
    compilations.getByName("test").compileTaskProvider.configure {
        compilerOptions {
            freeCompilerArgs.addAll("-linker-option", "-lz")

            when (buildMode) {
                "opt" -> {
                    freeCompilerArgs.add("-opt")
                    freeCompilerArgs.add("-Xadd-light-debug=disable")
                }
                "debug" -> Unit
                else -> error("Unsupported buildMode: $buildMode")
            }

            when (gcMode) {
                "cms" -> freeCompilerArgs.addAll(
                    "-Xbinary=gc=cms",
                    "-Xallocator=custom"
                )

                "cmc" -> {
                    freeCompilerArgs.addAll(
                        "-Xbinary=gc=cmc",
                        "-Xallocator=crt"
                    )
                    if (selectedTargetName == "macos_arm64") {
                        freeCompilerArgs.addAll(
                            "-linker-option",
                            "-rpath",
                            "-linker-option",
                            nativeHome ?: ""
                        )
                    }
                }

                null -> Unit
                else -> error("Unsupported gc mode: $gcMode")
            }
        }
    }
}

kotlin {
    macosArm64 {
        configureGcReachabilityTestCompilation()
    }

    sourceSets {
        commonTest {
            dependencies {
                implementation(kotlin("test"))
            }
        }

        val nativeTest by creating {
            dependsOn(commonTest.get())
        }

        macosArm64Test {
            dependsOn(nativeTest)
        }
    }

    sourceSets.all {
        languageSettings {
            optIn("kotlin.experimental.ExperimentalNativeApi")
            optIn("kotlin.native.runtime.NativeRuntimeApi")
        }
    }
}

tasks.withType<Test>().configureEach {
    environment("DYLD_LIBRARY_PATH", dyldPath ?: "")
    testLogging {
        events("passed", "failed", "skipped")
        showStandardStreams = true
    }
}

fun hdcCommand(vararg extra: String): List<String> =
    buildList {
        add("hdc")
        if (!hdcTarget.isNullOrBlank()) {
            add("-t")
            add(hdcTarget)
        }
        addAll(extra)
    }

fun runExternal(command: List<String>) {
    val process = ProcessBuilder(command)
        .redirectErrorStream(true)
        .start()
    val output = process.inputStream.bufferedReader().use { it.readText() }
    val exitCode = process.waitFor()
    if (output.isNotBlank()) {
        println(output)
    }
    check(exitCode == 0) {
        "Command failed with exit code $exitCode: ${command.joinToString(" ")}\n$output"
    }
}

fun gcCompilerArgs(): List<String> =
    when (gcMode) {
        "cms" -> listOf("-Xbinary=gc=cms", "-Xallocator=custom")
        "cmc" -> listOf("-Xbinary=gc=cmc", "-Xallocator=crt")
        null -> emptyList()
        else -> error("Unsupported gc mode: $gcMode")
    }

fun commonCompilerOptIns(): List<String> =
    listOf(
        "kotlin.experimental.ExperimentalNativeApi",
        "kotlin.native.runtime.NativeRuntimeApi",
        "kotlin.native.concurrent.ObsoleteWorkersApi",
        "kotlin.concurrent.atomics.ExperimentalAtomicApi",
        "kotlin.ExperimentalStdlibApi"
    ).flatMap { listOf("-opt-in", it) }

fun ohosBuiltinsArchive(): File? =
    listOf(
        file("/Users/suyue/.konan/dependencies/cpf-llvm-19-aarch64-macos-dev-14/lib/clang/19/lib/aarch64-linux-ohos/libclang_rt.builtins.a"),
        file("/Users/suyue/.konan/dependencies/llvm-1914-aarch64-macos-dev-10/lib/clang/19/lib/aarch64-linux-ohos/libclang_rt.builtins.a")
    ).firstOrNull { it.exists() }

tasks.register(ohosCompileTaskName) {
    group = "build"
    description = "Compiles the OHOS Arm64 native test runner via konanc."

    val sourceDirs = listOf("src/nativeMain/kotlin", "src/nativeTest/kotlin")
    inputs.files(fileTree("src/nativeMain/kotlin") { include("**/*.kt") })
    inputs.files(fileTree("src/nativeTest/kotlin") { include("**/*.kt") })

    val outputFile = layout.buildDirectory.file("bin/ohosArm64/${buildTypeDir}Test/test.kexe")
    outputs.file(outputFile)

    doLast {
        val home = nativeHome ?: error("kotlin.native.home must be provided for target=ohos_arm64")
        val konanc = file("$home/bin/konanc")
        check(konanc.exists()) {
            "konanc not found at ${konanc.absolutePath}"
        }

        val sources = sourceDirs.flatMap { dir ->
            fileTree(dir) { include("**/*.kt") }.files.map { it.absolutePath }
        }.sorted()
        check(sources.isNotEmpty()) { "No Kotlin sources found for OHOS test compilation." }

        val output = outputFile.get().asFile
        output.parentFile.mkdirs()

        val command = mutableListOf(
            konanc.absolutePath,
            "-target",
            "ohos_arm64",
            "-generate-test-runner",
            "-linker-option",
            "-lz",
            "-o",
            output.absolutePath
        )
        command += commonCompilerOptIns()
        if (buildMode == "opt") {
            command += "-opt"
        }
        command += gcCompilerArgs()
        if (gcMode == "cmc") {
            val builtins = ohosBuiltinsArchive()
                ?: error("Unable to locate OHOS libclang_rt.builtins.a for cmc linking")
            command += listOf(
                "-linker-option",
                "--allow-shlib-undefined",
                "-linker-option",
                builtins.absolutePath
            )
        }
        command += sources

        runExternal(command)
    }
}

tasks.register("ohosArm64DeviceTest") {
    group = "verification"
    description = "Links the OHOS Arm64 test binary, pushes it to device, and runs it via hdc."
    dependsOn(ohosCompileTaskName)

    doLast {
        val executable =
            layout.buildDirectory.file("bin/ohosArm64/${buildTypeDir}Test/test.kexe").get().asFile
        check(executable.exists()) {
            "Expected linked OHOS test binary at ${executable.absolutePath}"
        }

        runExternal(hdcCommand("shell", "mkdir", "-p", "/data/local/tmp"))
        runExternal(hdcCommand("file", "send", executable.absolutePath, "/data/local/tmp/test.kexe"))

        if (gcMode == "cmc") {
            val libcrt =
                listOfNotNull(
                    nativeHome?.let { file("$it/konan/targets/ohos_arm64/native/libcrt.so") },
                    nativeHome?.let { file("$it/libcrt.so") }
                ).firstOrNull { it.exists() }
                    ?: error("Unable to locate libcrt.so under kotlin.native.home=$nativeHome")

            runExternal(hdcCommand("file", "send", libcrt.absolutePath, "/data/local/tmp/libcrt.so"))
        }

        val exportLdLibraryPath =
            if (gcMode == "cmc") {
                "export LD_LIBRARY_PATH=/data/local/tmp:\$LD_LIBRARY_PATH && "
            } else {
                ""
            }

        runExternal(
            hdcCommand(
                "shell",
                "${exportLdLibraryPath}chmod 755 /data/local/tmp/test.kexe && /data/local/tmp/test.kexe"
            )
        )
    }
}

tasks.register<GradleBuild>("debugTest") {
    group = "verification"
    description = "Runs tests with debug Kotlin/Native binaries for the selected target."
    tasks = listOf(delegatedTestTask)
    startParameter.projectProperties =
        startParameter.projectProperties + mapOf("buildMode" to "debug")
}

tasks.register<GradleBuild>("releaseTest") {
    group = "verification"
    description = "Runs tests with optimized Kotlin/Native binaries for the selected target."
    tasks = listOf(delegatedTestTask)
    startParameter.projectProperties =
        startParameter.projectProperties + mapOf("buildMode" to "opt")
}
