﻿import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/** GT-E group: cyclic graph tests. */
export class CycleGraphTest extends GraphTopologyTestSupport {

    private buildCycle(size: number, startId: number): GraphNode[] {
        const nodes = Array.from({ length: size }, (_, index) => new GraphNode(startId + index));
        for (let index = 0; index < nodes.length; index++) {
            nodes[index].next = nodes[(index + 1) % nodes.length];
        }
        return nodes;
    }

    /** GT-E01: a reachable self-cycle remains alive. */
    gtE01_reachableSelfCycleKeepsNodeAlive() {
        const node = new GraphNode(9001);
        node.next = node;
        const scenario = new RootedWeaks(new GraphRoot(node), [new WeakReference(node)]);
        this.forceGc();
        assertEquals(9001, scenario.root.ref!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private weakOnlySelfCycle(): WeakReference<GraphNode> {
        const node = new GraphNode(9002);
        node.next = node;
        return new WeakReference(node);
    }

    /** GT-E02: an unreachable self-cycle can be collected by tracing GC. */
    gtE02_unreachableSelfCycleCanBeCollected() {
        this.assertWeakCollected(this.weakOnlySelfCycle());
    }

    private selfCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const node = new GraphNode(9003);
        node.next = node;
        const root = new GraphRoot(node);
        const weak = new WeakReference(node);
        root.ref = null;
        return new RootedWeaks(root, [weak]);
    }

    /** GT-E03: clearing root allows a self-cycle to be collected. */
    gtE03_clearingRootAllowsSelfCycleCollection() {
        const scenario = this.selfCycleAfterRootClear();
        assertNull(scenario.root.ref);
        this.assertAllCollected(scenario.weaks);
    }

    /** GT-E04: a reachable two-node cycle remains alive. */
    gtE04_reachableTwoNodeCycleKeepsBothNodesAlive() {
        const nodes = this.buildCycle(2, 9010);
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(9011, scenario.root.ref!.next!.id);
        assertEquals(9010, scenario.root.ref!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private weakOnlyTwoNodeCycle(): WeakReference<GraphNode>[] {
        const nodes = this.buildCycle(2, 9020);
        return this.weakRefs(nodes);
    }

    /** GT-E05: an unreachable two-node cycle can be collected. */
    gtE05_unreachableTwoNodeCycleCanBeCollected() {
        this.assertAllCollected(this.weakOnlyTwoNodeCycle());
    }

    private twoNodeCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildCycle(2, 9030);
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(nodes);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-E06: clearing root allows a two-node cycle to be collected. */
    gtE06_clearingRootAllowsTwoNodeCycleCollection() {
        const scenario = this.twoNodeCycleAfterRootClear();
        this.assertAllCollected(scenario.weaks);
    }

    /** GT-E07: a reachable 3-node cycle keeps all nodes alive. */
    gtE07_reachableThreeNodeCycleKeepsAllNodesAlive() {
        const nodes = this.buildCycle(3, 9040);
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(9042, scenario.root.ref!.next!.next!.id);
        assertEquals(9040, scenario.root.ref!.next!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private weakOnlyThreeNodeCycle(): WeakReference<GraphNode>[] {
        const nodes = this.buildCycle(3, 9050);
        return this.weakRefs(nodes);
    }

    /** GT-E08: an unreachable 3-node cycle can be collected. */
    gtE08_unreachableThreeNodeCycleCanBeCollected() {
        this.assertAllCollected(this.weakOnlyThreeNodeCycle());
    }

    /** GT-E09: a reachable 100-node cycle keeps representative nodes alive. */
    gtE09_reachableHundredNodeCycleKeepsRepresentativeNodesAlive() {
        const nodes = this.buildCycle(100, 9060);
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(9060, scenario.weaks[0].value!.id);
        assertEquals(9109, scenario.weaks[49].value!.id);
        assertEquals(9159, scenario.weaks[99].value!.id);
    }

    private hundredNodeCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildCycle(100, 9200);
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(nodes);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-E10: clearing root allows a 100-node cycle to be collected. */
    gtE10_clearingRootAllowsHundredNodeCycleCollection() {
        const scenario = this.hundredNodeCycleAfterRootClear();
        this.assertAllCollected(scenario.weaks);
    }

    private chainIntoCycle(): GraphNode[] {
        const head = new GraphNode(9300);
        const a = new GraphNode(9301);
        const b = new GraphNode(9302);
        const c = new GraphNode(9303);
        head.next = a;
        a.next = b;
        b.next = c;
        c.next = a;
        return [head, a, b, c];
    }

    /** GT-E11: a chain entering a cycle keeps both the chain head and cycle nodes alive. */
    gtE11_chainEnteringCycleKeepsWholeGraphAlive() {
        const nodes = this.chainIntoCycle();
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertEquals(9303, scenario.root.ref!.next!.next!.next!.id);
        assertEquals(9301, scenario.root.ref!.next!.next!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private chainAfterDisconnectingCycleEntry(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.chainIntoCycle();
        nodes[0].next = null;
        return new MixedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes.take(1)), this.weakRefs(nodes.drop(1)));
    }

    /** GT-E12: disconnecting the chain from the cycle keeps the head alive and collects the cycle. */
    gtE12_disconnectingChainFromCycleCollectsCycleOnly() {
        const scenario = this.chainAfterDisconnectingCycleEntry();
        this.forceGc();
        assertNull(scenario.root.ref!.next);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    /** GT-E13: a reachable cycle with an attached leaf keeps the leaf alive. */
    gtE13_cycleWithAttachedLeafKeepsLeafAlive() {
        const nodes = this.buildCycle(2, 9400);
        const leaf = new GraphNode(9402);
        nodes[0].left = leaf;
        const all = [...nodes, leaf];
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(all));
        this.forceGc();
        assertEquals(9402, scenario.root.ref!.left!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private cycleWithLeafAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildCycle(2, 9410);
        const leaf = new GraphNode(9412);
        nodes[0].left = leaf;
        const all = [...nodes, leaf];
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(all);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-E14: clearing root collects a cycle and its attached leaf. */
    gtE14_clearingRootCollectsCycleAndAttachedLeaf() {
        const scenario = this.cycleWithLeafAfterRootClear();
        this.assertAllCollected(scenario.weaks);
    }

    /** GT-E15: breaking an internal cycle edge turns it into a reachable chain that remains alive. */
    gtE15_breakingCycleInternalEdgeStillKeepsReachableChainAlive() {
        const nodes = this.buildCycle(3, 9500);
        nodes[2].next = null;
        const scenario = new RootedWeaks(new GraphRoot(nodes.first()), this.weakRefs(nodes));
        this.forceGc();
        assertNull(scenario.root.ref!.next!.next!.next);
        this.assertAllAlive(scenario.weaks);
    }

    private brokenCycleAfterRootClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const nodes = this.buildCycle(3, 9600);
        nodes[2].next = null;
        const root = new GraphRoot(nodes.first());
        const weaks = this.weakRefs(nodes);
        root.ref = null;
        return new RootedWeaks(root, weaks);
    }

    /** GT-E16: after breaking a cycle and clearing root, the whole former cycle can be collected. */
    gtE16_brokenCycleCollectedAfterRootClear() {
        const scenario = this.brokenCycleAfterRootClear();
        this.assertAllCollected(scenario.weaks);
    }
}
