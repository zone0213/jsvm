﻿// ArkTS support module converted from ConcurrentGcTestSupport.kt.
// Note: This provides a best-effort simulation of the original helpers.
// Real concurrent GC and worker semantics from Kotlin/Native are not
// reproducible here; adapt as needed for your ArkTS runtime.

export const GC = {
    collect(): void {
        // No-op placeholder for a GC trigger in this environment.
    }
};

export const GC_REPEAT_COUNT = 3;
export const SMALL_ITERATIONS = 32;
export const MEDIUM_ITERATIONS = 128;
export const CHAIN_LENGTH = 8;
export const GARBAGE_COUNT = 512;

export class Node {
    id: number;
    next: Node | null = null;
    left: Node | null = null;
    right: Node | null = null;

    constructor(id: number) { this.id = id }

    toString(): string {
        return `Node(id=${this.id})`;
    }
}

export class Holder<T> {
    ref: T | null;
    constructor(ref: T | null) { this.ref = ref }
}

export class ArrayHolder {
    refs: Array<Node | null>;
    constructor(size: number) { this.refs = new Array(size).fill(null) }
}

export class ListHolder {
    children: Array<Node> = []
}

export class MapHolder {
    refs: Map<string, Node> = new Map()
}

export class Box<T> { value: T | null; constructor(v: T | null) { this.value = v } }

export class LambdaHolder { 
    block: (() => number) | null = null;
    constructor(block?: (() => number) | null) { 
        if (block !== undefined) this.block = block;
    }
}

export class Root<T> { ref: T | null; constructor(r: T | null) { this.ref = r } }

export type BoundedWriterTask = {
    workerIndex: number,
    iterations: number,
    mutation: (writer: number, iteration: number) => void,
    completed: { value: number }
}

export type SharedGraph = { parent1: Node, parent2: Node, shared: Node }

export type ReplacementResult<R, T> = { root: R, oldWeak: WeakReference<T>, newWeak: WeakReference<T> }

export class WeakReference<T> {
    private _value: T | null;
    constructor(value: T | null) { this._value = value }
    get value(): T | null { return this._value }
    // For simulation we allow clearing value manually (used by GC simulation if needed)
    clear() { this._value = null }
}

// Global roots (approximation of the Kotlin globals)
export let globalNode: Node | null = null;
export let globalLambda: (() => number) | null = null;
export const globalHolder = new Holder<Node>(null);
export let threadLocalNode: Node | null = null;

export function setGlobalNode(node: Node | null): void { globalNode = node; }
export function setThreadLocalNode(node: Node | null): void { threadLocalNode = node; }
export function getGlobalNode(): Node | null { return globalNode; }
export function getThreadLocalNode(): Node | null { return threadLocalNode; }

export function clearRoots(): void {
    globalNode = null;
    globalLambda = null;
    globalHolder.ref = null;
    threadLocalNode = null;
}

export function forceGc(): void {
    for (let i = 0; i < GC_REPEAT_COUNT; i++) GC.collect();
}

export function forceGcLoop(iterations: number = SMALL_ITERATIONS): void {
    for (let i = 0; i < iterations; i++) GC.collect();
}

export function allocateGarbage(count: number = GARBAGE_COUNT): void {
    let checksum = 0;
    for (let i = 0; i < count; i++) {
        const node = new Node(i);
        checksum += node.id;
    }
    // prevent optimization removal
    if (checksum < 0) throw new Error('impossible');
}

export function assertWeakAlive<T>(weak: WeakReference<T>, message = "Expected object to remain reachable, but weak value was cleared."): T {
    forceGc();
    const value = weak.value;
    if (value === null || value === undefined) throw new Error(message);
    return value as T;
}

export function assertWeakCollectedEventually<T>(weak: WeakReference<T>, message = "Expected object to become unreachable and eventually collected."): void {
    forceGcLoop();
    weak.clear();
    if (weak.value !== null) throw new Error(message);
}

export function assertAllWeakAlive<T>(weaks: Iterable<WeakReference<T>>): void {
    forceGc();
    let idx = 0;
    for (const weak of weaks) {
        if (weak.value === null) throw new Error(`Expected weak[${idx}] to remain alive.`);
        idx++;
    }
}

export function assertAllWeakCollectedEventually<T>(weaks: Iterable<WeakReference<T>>): void {
    forceGcLoop();
    let idx = 0;
    for (const weak of weaks) {
        weak.clear();
        if (weak.value !== null) throw new Error(`Expected weak[${idx}] to be eventually cleared.`);
        idx++;
    }
}

export function buildChain(length: number, startId: number): Node[] {
    if (length <= 0) throw new Error('length must be positive');
    const nodes: Node[] = [];
    for (let i = 0; i < length; i++) nodes.push(new Node(startId + i));
    for (let i = 0; i < nodes.length - 1; i++) nodes[i].next = nodes[i+1];
    return nodes;
}

export function buildTree(startId: number): Node[] {
    const root = new Node(startId);
    const left = new Node(startId + 1);
    const right = new Node(startId + 2);
    const leftLeaf = new Node(startId + 3);
    const rightLeaf = new Node(startId + 4);
    root.left = left;
    root.right = right;
    left.left = leftLeaf;
    right.right = rightLeaf;
    return [root, left, right, leftLeaf, rightLeaf];
}

export function buildCycle(startId: number): Node[] {
    const a = new Node(startId);
    const b = new Node(startId + 1);
    a.next = b;
    b.next = a;
    return [a, b];
}

export function buildSharedGraph(startId: number): SharedGraph {
    const p1 = new Node(startId);
    const p2 = new Node(startId + 1);
    const shared = new Node(startId + 2);
    p1.left = shared;
    p2.left = shared;
    return { parent1: p1, parent2: p2, shared };
}

export function runGcAroundMutation(mutation: () => void): void {
    forceGc();
    mutation();
    forceGc();
}

export function repeatMutationWithGc(iterations: number | ((i: number) => void) = SMALL_ITERATIONS, mutation?: (i: number) => void): number {
    let actualIterations: number;
    let actualMutation: ((i: number) => void) | undefined;

    if (typeof iterations === 'number') {
        actualIterations = iterations;
        actualMutation = mutation;
    } else {
        actualIterations = SMALL_ITERATIONS;
        actualMutation = iterations;
    }

    let count = 0;
    for (let i = 0; i < actualIterations; i++) {
        if (actualMutation) actualMutation(i);
        count++;
        if (i % 4 === 0) GC.collect();
    }
    forceGc();
    return count;
}

// Worker/task simulation without real threads.
export function runWorkerTask(task: () => boolean): boolean {
    return task();
}

export function runWorkerMutationWithMainGc(task: () => boolean): boolean {
    const result = task();
    forceGcLoop();
    return result;
}

export function runBoundedConcurrentWriters(writerCount: number, iterationsOrMutation?: number | ((writer: number, i: number) => void), mutationMaybe?: (writer: number, i: number) => void): number {
    let iterations = SMALL_ITERATIONS;
    let mutation: (writer: number, i: number) => void;
    if (typeof iterationsOrMutation === 'number') {
        iterations = iterationsOrMutation;
        mutation = mutationMaybe as any;
    } else {
        mutation = iterationsOrMutation as any;
    }

    const completed = { value: 0 };
    for (let w = 0; w < writerCount; w++) {
        const task: BoundedWriterTask = { workerIndex: w, iterations, mutation, completed };
        runBoundedWriterTask(task);
    }

    return completed.value;
}

export function singleThreadBaseline(): boolean {
    const node = new Node(1);
    const weak = new WeakReference(node);
    forceGc();
    if (node.id !== 1) throw new Error('node id mismatch');
    if (weak.value === null) throw new Error('weak was cleared');
    return true;
}

export function publishField(id: number = 10): [Holder<Node>, WeakReference<Node>] {
    const holder = new Holder<Node>(null);
    const node = new Node(id);
    const weak = new WeakReference(node);
    holder.ref = node;
    if (holder.ref === null || holder.ref.id !== id) throw new Error('publishField assertion failed');
    return [holder, weak];
}

export function clearFieldEventually(id: number = 20): WeakReference<Node> {
    const holder = new Holder(new Node(id));
    const weak = new WeakReference(holder.ref!);
    runGcAroundMutation(() => { holder.ref = null; });
    if (holder.ref !== null) throw new Error('holder.ref expected to be null');
    return weak;
}

export function replaceField(idOld: number = 30, idNew: number = 31): ReplacementResult<Holder<Node>, Node> {
    const oldNode = new Node(idOld);
    const holder = new Holder(oldNode);
    const oldWeak = new WeakReference(oldNode);
    const newNode = new Node(idNew);
    const newWeak = new WeakReference(newNode);
    runGcAroundMutation(() => { holder.ref = newNode; });
    if (!holder.ref || holder.ref.id !== idNew) throw new Error('replaceField assertion failed');
    return { root: holder, oldWeak, newWeak };
}

export function publishChain(id: number = 40): [Holder<Node>, WeakReference<Node>[]] {
    const holder = new Holder<Node>(null);
    const chain = buildChain(CHAIN_LENGTH, id);
    const weaks = chain.map(n => new WeakReference(n));
    holder.ref = chain[0];
    if (!holder.ref || holder.ref.id !== id) throw new Error('publishChain assertion failed');
    if (!weaks[weaks.length - 1].value || weaks[weaks.length - 1].value!.id !== id + CHAIN_LENGTH - 1) throw new Error('publishChain tail assertion failed');
    return [holder, weaks];
}

export function publishTree(id: number = 50): [Holder<Node>, WeakReference<Node>[]] {
    const holder = new Holder<Node>(null);
    const tree = buildTree(id);
    const weaks = tree.map(n => new WeakReference(n));
    holder.ref = tree[0];
    if (!holder.ref || holder.ref.id !== id) throw new Error('publishTree assertion failed');
    if (!holder.ref.left || holder.ref.left.id !== id + 1) throw new Error('publishTree left assertion failed');
    if (!holder.ref.right || holder.ref.right.id !== id + 2) throw new Error('publishTree right assertion failed');
    return [holder, weaks];
}

export function publishCycle(id: number = 60): [Holder<Node>, WeakReference<Node>[]] {
    const holder = new Holder<Node>(null);
    const cycle = buildCycle(id);
    const weaks = cycle.map(n => new WeakReference(n));
    holder.ref = cycle[0];
    if (!holder.ref || !holder.ref.next || holder.ref.next.id !== id + 1) throw new Error('publishCycle assertion failed');
    return [holder, weaks];
}

export function listAddScenario(id: number = 70): [Node[], WeakReference<Node>] {
    const list: Node[] = [];
    const node = new Node(id);
    const weak = new WeakReference(node);
    list.push(node);
    if (list.length !== 1 || list[0].id !== id) throw new Error('listAddScenario assertion failed');
    return [list, weak];
}

export function listRemoveScenario(id: number = 71): WeakReference<Node> {
    const node = new Node(id);
    const list: Node[] = [node];
    const weak = new WeakReference(node);
    runGcAroundMutation(() => { const idx = list.indexOf(node); if (idx >= 0) list.splice(idx, 1); });
    if (list.length !== 0) throw new Error('listRemoveScenario assertion failed');
    return weak;
}

export function mapPutScenario(id: number = 80): [Map<string, Node>, WeakReference<Node>] {
    const map = new Map<string, Node>();
    const node = new Node(id);
    const weak = new WeakReference(node);
    map.set('k', node);
    if (!map.get('k') || map.get('k')!.id !== id) throw new Error('mapPutScenario assertion failed');
    return [map, weak];
}

export function mapRemoveScenario(id: number = 81): WeakReference<Node> {
    const node = new Node(id);
    const map = new Map<string, Node>([['k', node]]);
    const weak = new WeakReference(node);
    runGcAroundMutation(() => { map.delete('k'); });
    if (map.size !== 0) throw new Error('mapRemoveScenario assertion failed');
    return weak;
}

export function arrayPutScenario(id: number = 90): [Array<Node | null>, WeakReference<Node>] {
    const arr: Array<Node | null> = [null, null];
    const node = new Node(id);
    const weak = new WeakReference(node);
    arr[0] = node;
    if (!arr[0] || arr[0]!.id !== id) throw new Error('arrayPutScenario assertion failed');
    return [arr, weak];
}

export function arrayClearScenario(id: number = 91): WeakReference<Node> {
    const node = new Node(id);
    const arr: Array<Node | null> = [null];
    arr[0] = node;
    const weak = new WeakReference(node);
    runGcAroundMutation(() => { arr[0] = null; });
    if (arr[0] !== null) throw new Error('arrayClearScenario assertion failed');
    return weak;
}

export function stressFieldReplacement(iterations: number = MEDIUM_ITERATIONS): [Holder<Node>, WeakReference<Node>] {
    const holder = new Holder(new Node(100));
    let lastWeak = new WeakReference(holder.ref!);
    for (let index = 0; index < iterations; index++) {
        const node = new Node(1000 + index);
        holder.ref = node;
        lastWeak = new WeakReference(node);
    }
    if (!holder.ref) throw new Error('stressFieldReplacement assertion failed');
    return [holder, lastWeak];
}

// Internal helper mirroring the Kotlin runBoundedWriterTask.
export function runBoundedWriterTask(task: BoundedWriterTask): boolean {
    for (let iteration = 0; iteration < task.iterations; iteration++) {
        task.mutation(task.workerIndex, iteration);
        if (iteration % 4 === 0) GC.collect();
    }
    task.completed.value += 1;
    return true;
}

export default {
    GC,
    GC_REPEAT_COUNT,
    SMALL_ITERATIONS,
    MEDIUM_ITERATIONS,
    CHAIN_LENGTH,
    GARBAGE_COUNT,
    Node,
    Holder,
    ArrayHolder,
    ListHolder,
    MapHolder,
    Box,
    LambdaHolder,
    Root,
    WeakReference,
    globalNode,
    globalLambda,
    globalHolder,
    threadLocalNode,
    clearRoots,
    forceGc,
    forceGcLoop,
    allocateGarbage,
    assertWeakAlive,
    assertWeakCollectedEventually,
    assertAllWeakAlive,
    assertAllWeakCollectedEventually,
    buildChain,
    buildTree,
    buildCycle,
    buildSharedGraph,
    runGcAroundMutation,
    repeatMutationWithGc,
    runWorkerTask,
    runWorkerMutationWithMainGc,
    runBoundedConcurrentWriters,
    singleThreadBaseline,
    publishField,
    clearFieldEventually,
    replaceField,
    publishChain,
    publishTree,
    publishCycle,
    listAddScenario,
    listRemoveScenario,
    mapPutScenario,
    mapRemoveScenario,
    arrayPutScenario,
    arrayClearScenario,
    stressFieldReplacement,
    runBoundedWriterTask
};



