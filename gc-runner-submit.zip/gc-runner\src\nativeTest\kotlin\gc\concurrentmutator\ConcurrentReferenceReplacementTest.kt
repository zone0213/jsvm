@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-D group: replacing references and moving subgraphs while GC is interleaved.
 */
class ConcurrentReferenceReplacementTest : ConcurrentGcTestSupport() {

    /**
     * CG-D01
     * Scenario: mutator replaces normal field old -> new.
     * Expectation: old collected eventually and new alive.
     */
    @Test
    fun cgD01_replaceNormalFieldDuringGc() {
        val r = replaceField(501, 502)
        assertWeakCollectedEventually(r.oldWeak)
        assertWeakAlive(r.newWeak)
        assertEquals(502, r.root.ref!!.id)
    }

    /**
     * CG-D02
     * Scenario: mutator replaces nullable field.
     * Expectation: old collected and new alive.
     */
    @Test
    fun cgD02_replaceNullableFieldDuringGc() {
        val r = replaceField(503, 504)
        assertWeakCollectedEventually(r.oldWeak)
        assertWeakAlive(r.newWeak)
        assertNotNull(r.root.ref)
    }

    /**
     * CG-D03
     * Scenario: mutator replaces middle.next with new chain.
     * Expectation: old suffix collected and new chain alive.
     */
    @Test
    fun cgD03_replaceChainSuffixDuringGc() {
        val old = buildChain(6, 510)
        val root = Holder(old.first())
        val oldWeaks = old.drop(3).map { WeakReference(it) }
        val newChain = buildChain(3, 520)
        val newWeaks = newChain.map { WeakReference(it) }
        forceGc()
        old[2].next = newChain.first()
        forceGc()
        assertEquals(520, old[2].next!!.id)
        forceGcLoop()
        oldWeaks.forEachIndexed { i, w -> assertNull(w.value, "Expected oldWeak[$i] to be cleared.") }
        forceGc()
        newWeaks.forEachIndexed { i, w -> assertNotNull(w.value, "Expected newWeak[$i] to remain alive.") }
        assertNotNull(root.ref)
    }

    /**
     * CG-D04
     * Scenario: mutator replaces root.left subtree.
     * Expectation: old subtree collected and new subtree alive.
     */
    @Test
    fun cgD04_replaceTreeSubtreeDuringGc() {
        val treeNodes = buildTree(530).toMutableList()
        val root = treeNodes[0]
        var oldLeft: Node? = treeNodes[1]
        var oldLeaf: Node? = treeNodes[3]
        val oldWeaks = listOf(WeakReference(oldLeft!!), WeakReference(oldLeaf!!))
        val newTree = buildTree(540)
        val newWeaks = newTree.map { WeakReference(it) }
        forceGc()
        root.left = newTree.first()
        treeNodes.clear(); oldLeft = null; oldLeaf = null
        forceGc()
        assertEquals(540, root.left!!.id)
        forceGcLoop()
        oldWeaks.forEachIndexed { i, w -> assertNull(w.value, "Expected oldWeak[$i] to be cleared.") }
        forceGc()
        newWeaks.forEachIndexed { i, w -> assertNotNull(w.value, "Expected newWeak[$i] to remain alive.") }
        assertNotNull(root.left)
    }

    /**
     * CG-D05
     * Scenario: one parent edge is replaced while another still points to shared.
     * Expectation: old shared and new child both remain alive.
     */
    @Test
    fun cgD05_replaceOneSharedParentEdgeDuringGc() {
        val g = buildSharedGraph(550)
        val sharedWeak = WeakReference(g.shared)
        val newNode = Node(560)
        val newWeak = WeakReference(newNode)
        runGcAroundMutation { g.parent1.left = newNode }
        assertEquals(552, g.parent2.left!!.id)
        assertNotNull(sharedWeak.value)
        assertNotNull(newWeak.value)
    }

    /**
     * CG-D06
     * Scenario: all parent edges are replaced from old shared to new shared.
     * Expectation: old shared collected and new shared alive.
     */
    @Test
    fun cgD06_replaceAllSharedParentEdgesDuringGc() {
        val p1 = Node(570)
        val p2 = Node(571)
        var shared: Node? = Node(572)
        p1.left = shared; p2.left = shared
        val oldWeak = WeakReference(shared!!)
        val newShared = Node(580)
        val newWeak = WeakReference(newShared)
        forceGc()
        p1.left = newShared; p2.left = newShared
        shared = null
        forceGc()
        assertEquals(newShared, p1.left)
        forceGcLoop()
        assertNull(oldWeak.value)
        forceGc()
        assertNotNull(newWeak.value)
        assertNotNull(p1.left)
    }

    /**
     * CG-D07
     * Scenario: subgraph is moved from old parent to new parent.
     * Expectation: moved child remains alive.
     */
    @Test
    fun cgD07_moveSubgraphToNewParentDuringGc() {
        val oldParent = Node(590)
        val newParent = Node(591)
        val child = Node(592)
        oldParent.left = child
        val weak = WeakReference(child)
        runGcAroundMutation { oldParent.left = null
        newParent.left = child }
        assertEquals(592, newParent.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-D08
     * Scenario: subgraph is temporarily detached then attached to new parent.
     * Expectation: final child remains alive.
     */
    @Test
    fun cgD08_detachThenAttachSameSubgraphDuringGc() {
        val oldParent = Node(600)
        val newParent = Node(601)
        val child = Node(602)
        oldParent.left = child
        val weak = WeakReference(child)
        runGcAroundMutation { oldParent.left = null
        newParent.left = child }
        assertEquals(602, newParent.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-D09
     * Scenario: subgraph is attached to new parent before old parent edge is cleared.
     * Expectation: child remains alive.
     */
    @Test
    fun cgD09_attachThenDetachOldParentDuringGc() {
        val oldParent = Node(610)
        val newParent = Node(611)
        val child = Node(612)
        oldParent.left = child
        val weak = WeakReference(child)
        runGcAroundMutation { newParent.left = child
        oldParent.left = null }
        assertEquals(612, newParent.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-D10
     * Scenario: two holder refs are swapped.
     * Expectation: both objects remain alive.
     */
    @Test
    fun cgD10_swapTwoHolderRefsDuringGc() {
        val a = Node(620)
        val b = Node(621)
        val h1 = Holder(a)
        val h2 = Holder(b)
        val wa = WeakReference(a)
        val wb = WeakReference(b)
        runGcAroundMutation { val tmp = h1.ref
        h1.ref = h2.ref
        h2.ref = tmp }
        assertEquals(621, h1.ref!!.id)
        assertEquals(620, h2.ref!!.id)
        assertNotNull(wa.value)
        assertNotNull(wb.value)
    }

    /**
     * CG-D11
     * Scenario: field is replaced A -> B -> A.
     * Expectation: final A remains alive and test does not crash.
     */
    @Test
    fun cgD11_abaReplacementDuringGc() {
        val a = Node(630)
        val b = Node(631)
        val holder = Holder(a)
        val weakA = WeakReference(a)
        runGcAroundMutation { holder.ref = b
        holder.ref = a }
        assertEquals(630, holder.ref!!.id)
        assertNotNull(weakA.value)
    }

    /**
     * CG-D12
     * Scenario: holder field is replaced repeatedly across GC.
     * Expectation: last object remains alive.
     */
    @Test
    fun cgD12_highFrequencyFieldReplacementDuringGc() {
        forceGc()
        val (holder, weak) = stressFieldReplacement(64)
        forceGc()
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

    /**
     * CG-D13
     * Scenario: multiple workers replace the same holder field.
     * Expectation: no crash and final value is accessible.
     */
    @Test
    fun cgD13_multiThreadReplaceSameFieldDuringGc() {
        val completed = runBoundedConcurrentWriters(2, 16) { w, i -> globalHolder.ref = Node(640 + w * 100 + i) }
        assertEquals(2, completed)
        assertNotNull(globalHolder.ref)
    }

    /**
     * CG-D14
     * Scenario: lambda holder is replaced from old capture to new capture.
     * Expectation: old capture eventually collected and new capture alive.
     */
    @Test
    fun cgD14_replaceLambdaCaptureDuringGc() {
        val oldNode = Node(650)
        val oldWeak = WeakReference(oldNode)
        val holder = LambdaHolder({ oldNode.id })
        val newNode = Node(651)
        val newWeak = WeakReference(newNode)
        forceGc()
        holder.block = { newNode.id }
        forceGc()
        assertEquals(651, holder.block!!())
        forceGcLoop()
        assertNull(oldWeak.value)
        forceGc()
        assertNotNull(newWeak.value)
        assertNotNull(holder.block)
    }

}
