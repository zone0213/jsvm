import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class CoroutineContinuationLongStabilityTest extends LongStabilityTestSupport {

    ls_j01_batchSuspendResume() {
        const weaks = this.coroutineLikeBatch();
        this.assertAllWeakCollectedEventually(weaks);
    }

    ls_j02_repeatedSuspendResume() {
        for (let i = 0; i < 8; i++) this.assertAllWeakCollectedEventually(this.coroutineLikeBatch(8));
    }

    ls_j03_continuationLargePayload() {
        const continuation = new Holder(new LargePayload(3, new Array(MEDIUM_BYTES).fill(0)));
        const weak = new WeakReference(continuation.ref!);
        this.forceGc();
        assertNotNull(weak.value);
        continuation.ref = null;
        this.assertWeakCollectedEventually(weak);
    }

    ls_j04_nestedSuspendChain() {
        const outer = new Holder(new Holder(new LsNode(4)));
        this.forceGc();
        assertNotNull(outer.ref!.ref);
        outer.ref!.ref = null;
    }

    ls_j05_coroutineCancelBatch() {
        const weaks: WeakReference<LsNode>[] = [];
        for (let index = 0; index < 32; index++) { try { const node = new LsNode(index); weaks.push(new WeakReference(node)); throw new Error("cancel"); } catch (_e) {} }
        this.assertAllWeakCollectedEventually(weaks);
    }

    ls_j06_coroutineExceptionBatch() {
        const weaks: WeakReference<LsNode>[] = [];
        for (let index = 0; index < 32; index++) { try { const node = new LsNode(index); weaks.push(new WeakReference(node)); throw new Error("cancel"); } catch (_e) {} }
        this.assertAllWeakCollectedEventually(weaks);
    }

    ls_j07_asyncDeferredResultChurn() {
        for (let i = 0; i < SHORT_ITERATIONS; i++) { const result = new Holder(new FakeDto(i, "d", [])); assertEquals(i, result.ref!.id); }
    }

    ls_j08_channelSendReceiveChurn() {
        const queue: FakeDto[] = [];
        for (let i = 0; i < SHORT_ITERATIONS; i++) { queue.push(new FakeDto(i, "q", [])); assertEquals(i, queue.shift()!.id); }
    }

    ls_j09_flowEmitCollectChurn() {
        const collected: number[] = [];
        for (let i = 0; i < SHORT_ITERATIONS; i++) { const dto = new FakeDto(i, "f", []); collected.push(dto.id); }
        assertEquals(SHORT_ITERATIONS, collected.length);
    }

    ls_j10_coroutineWithAllocationPressure() {
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(8, it => new LargePayload(it, new Array(1024).fill(0))));
    }
}
