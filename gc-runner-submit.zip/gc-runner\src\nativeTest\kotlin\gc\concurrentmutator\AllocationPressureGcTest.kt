@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-H group: allocation pressure, STW fallback and safepoint cooperation tests.
 */
class AllocationPressureGcTest : ConcurrentGcTestSupport() {

    /**
     * CG-H01
     * Scenario: single thread allocates many short-lived objects.
     * Expectation: no crash.
     */
    @Test
    fun cgH01_singleThreadShortLivedAllocationStorm() {
        allocateGarbage(1024)
        forceGc()
        assertTrue(true)
    }

    /**
     * CG-H02
     * Scenario: long-lived root survives allocation pressure.
     * Expectation: root remains alive.
     */
    @Test
    fun cgH02_allocationStormWithLongLivedRoot() {
        val root=Node(1001)
        val weak=WeakReference(root)
        allocateGarbage(1024)
        forceGc()
        assertEquals(1001,root.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-H03
     * Scenario: root field is updated during allocation storm.
     * Expectation: final object remains alive.
     */
    @Test
    fun cgH03_allocationStormUpdatingRootField() {
        val holder=Holder(Node(1002))
        repeatMutationWithGc(64){ holder.ref=Node(10020+it)
        allocateGarbage(8) }
        assertNotNull(holder.ref)
    }

    /**
     * CG-H04
     * Scenario: multiple workers allocate short-lived objects.
     * Expectation: all complete.
     */
    @Test
    fun cgH04_multiThreadAllocationStorm() {
        val completed=runBoundedConcurrentWriters(3,16){_,_-> allocateGarbage(16) }
        assertEquals(3,completed)
    }

    /**
     * CG-H05
     * Scenario: allocation and GC loops run together.
     * Expectation: no deadlock.
     */
    @Test
    fun cgH05_multiThreadAllocationWithGcThread() {
        val completed=runBoundedConcurrentWriters(2,16){_,_-> allocateGarbage(16)
        GC.collect() }
        assertEquals(2,completed)
    }

    /**
     * CG-H06
     * Scenario: allocation pressure plus list add/clear.
     * Expectation: no crash.
     */
    @Test
    fun cgH06_allocationStormWithListAddClear() {
        val list=mutableListOf<Node>()
        repeatMutationWithGc(64){ list.add(Node(10060+it))
        if(it%4==0) list.clear()
        allocateGarbage(4) }
        list.forEach{assertTrue(it.id>=10060)}
    }

    /**
     * CG-H07
     * Scenario: allocation pressure plus map put/remove.
     * Expectation: no crash.
     */
    @Test
    fun cgH07_allocationStormWithMapPutRemove() {
        val map=mutableMapOf<Int,Node>()
        repeatMutationWithGc(64){ map[it]=Node(10070+it)
        if(it%3==0) map.remove(it)
        allocateGarbage(4) }
        map.values.forEach{assertTrue(it.id>=10070)}
    }

    /**
     * CG-H08
     * Scenario: weak observers to long-lived root stay alive during pressure.
     * Expectation: weak remains non-null.
     */
    @Test
    fun cgH08_allocationStormWithWeakObservers() {
        val root=Node(1008)
        val weak=WeakReference(root)
        allocateGarbage(2048)
        forceGc()
        assertEquals(1008,root.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-H09
     * Scenario: root cleared after allocation pressure.
     * Expectation: weak eventually clears.
     */
    @Test
    fun cgH09_allocationStormThenClearRoot() {
        val holder=Holder(Node(1009))
        val weak=WeakReference(holder.ref!!)
        allocateGarbage(512)
        holder.ref=null
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-H10
     * Scenario: busy mutation loop and GC complete.
     * Expectation: no deadlock.
     */
    @Test
    fun cgH10_busyLoopSafepointCooperation() {
        val holder=Holder(Node(1010))
        val count=repeatMutationWithGc(128){ holder.ref=Node(10100+it) }
        assertEquals(128,count)
        assertNotNull(holder.ref)
    }

    /**
     * CG-H11
     * Scenario: large chain is attached under allocation pressure.
     * Expectation: chain remains alive.
     */
    @Test
    fun cgH11_allocationPressureAttachLargeChain() {
        val holder = Holder<Node>(null)
        val chain = buildChain(8, 1011)
        val weaks = chain.map { WeakReference(it) }
        allocateGarbage(512)
        holder.ref = chain.first()
        forceGc()
        weaks.forEachIndexed { i, w -> assertNotNull(w.value, "Expected weak[$i] to remain alive.") }
        assertNotNull(holder.ref)
    }

    /**
     * CG-H12
     * Scenario: large chain is detached under allocation pressure.
     * Expectation: suffix eventually collected.
     */
    @Test
    fun cgH12_allocationPressureDetachLargeChain() {
        val chain=buildChain(8,1020)
        val root=Holder(chain.first())
        val suffix=chain.drop(1).map{WeakReference(it)}
        allocateGarbage(512)
        chain[0].next=null
        forceGc()
        assertEquals(1020, root.ref!!.id)
        assertAllWeakCollectedEventually(suffix)
    }

}
