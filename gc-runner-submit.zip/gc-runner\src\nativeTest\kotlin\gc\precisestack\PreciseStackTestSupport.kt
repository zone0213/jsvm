@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.precisestack

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * Common infrastructure for precise stack scanning tests.
 *
 * Scope:
 * - Validates exact stack root maps at GC safepoints.
 * - Separates live-root retention from dead-slot non-retention.
 * - WeakReference is used only as the lifetime oracle.
 */
open class PreciseStackTestSupport {
    @BeforeTest
    fun resetBeforeTest() {
        clearMutableRoots()
        forceGc()
    }

    @AfterTest
    fun resetAfterTest() {
        clearMutableRoots()
        forceGc()
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun clearMutableRoots() {
        globalPreciseStackPayload = null
        globalPreciseStackHolder = null
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected live stack root to keep object alive.",
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollected(
        weak: WeakReference<T>,
        message: String = "Expected dead stack slot to stop keeping object alive.",
    ) {
        forceGc()
        assertNull(weak.value, message)
    }

    protected fun runWorkerBoolean(task: () -> Boolean): Boolean {
        val worker = Worker.start()
        return try {
            worker.execute(TransferMode.SAFE, { task }) { it() }.result
        } finally {
            worker.requestTermination().result
        }
    }

    companion object {
        private const val GC_REPEAT_COUNT = 3
    }
}

interface PreciseStackMarker {
    val id: Int
}

class StackPayload(
    override val id: Int,
    var child: StackPayload? = null,
) : PreciseStackMarker {
    override fun toString(): String = "StackPayload(id=$id)"
}

class StackHolder<T : Any>(
    var ref: T?,
)

var globalPreciseStackPayload: StackPayload? = null
var globalPreciseStackHolder: StackHolder<StackPayload>? = null

