@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.test.Test

/**
 * LS-B group: short-lived object churn long-stability tests.
 */
class ShortLivedChurnLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-B01
     * Scenario: small object churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b01_smallObjectChurn() {
        assertNoSustainedMonotonicGrowth(shortLivedSamples { LsNode(it) })
    }

    /**
     * LS-B02
     * Scenario: medium object churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b02_mediumObjectChurn() {
        assertNoSustainedMonotonicGrowth(shortLivedSamples { MediumPayload(it) })
    }

    /**
     * LS-B03
     * Scenario: large object churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b03_largeObjectChurn() {
        assertNoSustainedMonotonicGrowth(
            shortLivedSamples(12) { LargePayload(it, ByteArray(MEDIUM_BYTES)) }
        )
    }

    /**
     * LS-B04
     * Scenario: mixed object churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b04_mixedObjectChurn() {
        assertNoSustainedMonotonicGrowth(shortLivedSamples { MixedPayload(it) })
    }

    /**
     * LS-B05
     * Scenario: string churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b05_stringChurn() {
        assertNoSustainedMonotonicGrowth(shortLivedSamples { "value-$it".reversed() })
    }

    /**
     * LS-B06
     * Scenario: ByteArray churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b06_bytearrayChurn() {
        assertNoSustainedMonotonicGrowth(
            shortLivedSamples(12) { ByteArray(4096) { b -> (b + it).toByte() } }
        )
    }

    /**
     * LS-B07
     * Scenario: nested DTO churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b07_nestedDtoChurn() {
        assertNoSustainedMonotonicGrowth(businessDtoSamples())
    }

    /**
     * LS-B08
     * Scenario: lambda churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b08_lambdaChurn() {
        assertNoSustainedMonotonicGrowth(
            shortLivedSamples {
                val node = LsNode(it)
                val callback = { node.id }
                callback
            }
        )
    }

    /**
     * LS-B09
     * Scenario: exception churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b09_exceptionChurn() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { index ->
                try {
                    error("boom-$index")
                } catch (_: Throwable) {
                }
            }
        )
    }

    /**
     * LS-B10
     * Scenario: burst churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_b10_burstChurn() {
        val spike = spikeLoop { allocateMixedBatch().toMutableList<Any>() }
        assertSpikeRecovered(spike.first, spike.second, spike.third)
        assertNoSustainedMonotonicGrowth(listOf(spike.first, spike.second, spike.third))
    }

}
