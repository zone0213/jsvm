@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * PS-D group: precise stack scanning for worker thread frames.
 */
class PreciseStackThreadRootTest : PreciseStackTestSupport() {
    /**
     * PS-D01
     * Scenario: worker local reference is live when worker triggers GC.
     * Expectation: worker frame root map keeps the local object alive.
     */
    @Test
    fun psD01_workerLiveLocalKeepsObjectAlive() {
        val result =
            runWorkerBoolean {
                val obj = StackPayload(4001)
                val weak = WeakReference(obj)
                GC.collect()
                weak.value != null && obj.id == 4001
            }

        assertTrue(result)
    }

    /**
     * PS-D02
     * Scenario: worker clears nullable local before triggering GC.
     * Expectation: worker frame root map does not retain the dead old slot.
     */
    @Test
    fun psD02_workerClearedLocalDropsStackRoot() {
        val result =
            runWorkerBoolean {
                var obj: StackPayload? = StackPayload(4002)
                val weak = WeakReference(obj!!)
                obj = null
                GC.collect()
                weak.value == null
            }

        assertTrue(result)
    }

    /**
     * PS-D03
     * Scenario: worker reassigns local root from old to new before GC.
     * Expectation: old object is cleared and new object remains live in worker frame.
     */
    @Test
    fun psD03_workerReassignmentDropsOldKeepsNew() {
        val result =
            runWorkerBoolean {
                var obj: StackPayload? = StackPayload(4003)
                val oldWeak = WeakReference(obj!!)
                obj = StackPayload(4030)
                val newWeak = WeakReference(obj!!)
                GC.collect()
                oldWeak.value == null && newWeak.value != null && obj!!.id == 4030
            }

        assertTrue(result)
    }

    /**
     * PS-D04
     * Scenario: worker passes object as a function parameter and triggers GC in callee.
     * Expectation: callee parameter is included in worker stack root map.
     */
    @Test
    fun psD04_workerCalleeParameterKeepsObjectAlive() {
        val result =
            runWorkerBoolean {
                fun consume(obj: StackPayload): Boolean {
                    val weak = WeakReference(obj)
                    GC.collect()
                    return weak.value != null && obj.id == 4004
                }

                consume(StackPayload(4004))
            }

        assertTrue(result)
    }

    /**
     * PS-D05
     * Scenario: worker loop reuses the same local slot and keeps only the final object live.
     * Expectation: old loop values are not retained by stale worker stack slots.
     */
    @Test
    fun psD05_workerLoopSlotReuseDropsOldValues() {
        val result =
            runWorkerBoolean {
                var current: StackPayload? = null
                val oldWeaks = mutableListOf<WeakReference<StackPayload>>()

                repeat(6) { index ->
                    current = StackPayload(4050 + index)
                    if (index < 5) {
                        oldWeaks.add(WeakReference(current!!))
                    }
                }
                val liveWeak = WeakReference(current!!)

                GC.collect()

                val oldCleared = oldWeaks.all { it.value == null }
                val newAlive = liveWeak.value != null && current!!.id == 4055
                oldCleared && newAlive
            }

        assertTrue(result)
    }
}
