@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * F group: reachability through generic containers and lambda captures.
 */
class GenericLambdaReachabilityTest : ReachabilityTestSupport() {

    private fun createGenericBoxRoot(): RootedWeak<Box<Payload>, Payload> {
        val obj = Payload(501)
        val box = Box(obj)

        return RootedWeak(
            root = box,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-F01
     * Scenario: a generic Box<Payload> field strongly references a Payload.
     * Expectation: the object remains reachable through Box.value.
     */
    @Test
    fun rcF01_genericBoxFieldKeepsObjectAlive() {
        val scenario = createGenericBoxRoot()

        forceGc()

        assertEquals(501, scenario.root.value!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createGenericBoxAfterClear(): RootedWeak<Box<Payload>, Payload> {
        val obj = Payload(502)
        val box = Box(obj)
        val weak = WeakReference(obj)

        box.value = null

        return RootedWeak(
            root = box,
            weak = weak
        )
    }

    /**
     * RC-F02
     * Scenario: a generic Box<Payload> field is cleared.
     * Expectation: the previously contained object can be collected.
     */
    @Test
    fun rcF02_clearingGenericBoxFieldAllowsCollection() {
        val scenario = createGenericBoxAfterClear()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root.value)
    }

    private fun createGenericBoxReplacementResult(): HolderReplacementResult<Box<Payload>, Payload> {
        val oldObj = Payload(503)
        val box = Box(oldObj)
        val oldWeak = WeakReference(oldObj)

        val newObj = Payload(530)
        box.value = newObj
        val newWeak = WeakReference(newObj)

        return HolderReplacementResult(
            holder = box,
            oldWeak = oldWeak,
            newWeak = newWeak
        )
    }

    /**
     * RC-F03
     * Scenario: a generic Box<Payload> field is reassigned.
     * Expectation: the old object can be collected, while the new object remains reachable.
     */
    @Test
    fun rcF03_genericBoxReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        val result = createGenericBoxReplacementResult()

        forceGc()

        assertNull(result.oldWeak.value)
        assertNotNull(result.newWeak.value)
        assertEquals(530, result.holder.value!!.id)
    }

    private fun createGenericAnyBoxRoot(): RootedWeak<Box<Any>, Any> {
        val obj: Any = Payload(504)
        val box = Box(obj)

        return RootedWeak(
            root = box,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-F04
     * Scenario: a generic Box<Any> field holds a Payload runtime object.
     * Expectation: the runtime object remains reachable through the generic Any field.
     */
    @Test
    fun rcF04_genericBoxAnyKeepsRuntimeObjectAlive() {
        val scenario = createGenericAnyBoxRoot()

        forceGc()

        assertEquals(504, (scenario.root.value as Payload).id)
        assertNotNull(scenario.weak.value)
    }

    private fun createLambdaCaptureRoot(): RootedWeak<Function0<Int>, Payload> {
        val obj = Payload(505)
        val block = { obj.id }

        return RootedWeak(
            root = block,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-F05
     * Scenario: a lambda captures a Payload and returns one of its fields.
     * Expectation: the captured object remains reachable through the lambda object.
     */
    @Test
    fun rcF05_lambdaCaptureKeepsObjectAlive() {
        val scenario = createLambdaCaptureRoot()

        forceGc()

        assertEquals(505, scenario.root())
        assertNotNull(scenario.weak.value)
    }

    private fun createWeakAfterClearingLambda(): WeakReference<Payload> {
        val obj = Payload(506)
        val weak = WeakReference(obj)

        var block: (() -> Int)? = { obj.id }
        assertEquals(506, block!!())

        block = null
        assertNull(block)

        return weak
    }

    /**
     * RC-F06
     * Scenario: a nullable lambda variable captures a Payload and is then cleared.
     * Expectation: after the helper stack frame returns, the captured object can be collected.
     */
    @Test
    fun rcF06_clearingLambdaAllowsCapturedObjectCollection() {
        val weak = createWeakAfterClearingLambda()

        assertWeakCollected(weak)
    }

    private fun createLambdaReturningObjectRoot(): RootedWeak<Function0<Payload>, Payload> {
        val obj = Payload(507)
        val block = { obj }

        return RootedWeak(
            root = block,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-F07
     * Scenario: a lambda captures a Payload and returns the captured object.
     * Expectation: the captured object remains reachable through the lambda.
     */
    @Test
    fun rcF07_lambdaReturningObjectKeepsObjectAlive() {
        val scenario = createLambdaReturningObjectRoot()

        forceGc()

        assertEquals(507, scenario.root().id)
        assertNotNull(scenario.weak.value)
    }

    private fun createLambdaStoredInListRoot(): RootedWeak<MutableList<() -> Int>, Payload> {
        val obj = Payload(508)
        val list = mutableListOf<() -> Int>()
        list.add { obj.id }

        return RootedWeak(
            root = list,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-F08
     * Scenario: a lambda capturing Payload is stored inside a MutableList.
     * Expectation: the captured object remains reachable through list -> lambda -> payload.
     */
    @Test
    fun rcF08_lambdaStoredInCollectionKeepsCapturedObjectAlive() {
        val scenario = createLambdaStoredInListRoot()

        forceGc()

        assertEquals(508, scenario.root[0]())
        assertNotNull(scenario.weak.value)
    }

    private fun createLambdaListAfterClear(): RootedWeak<MutableList<() -> Int>, Payload> {
        val obj = Payload(509)
        val list = mutableListOf<() -> Int>()
        list.add { obj.id }
        val weak = WeakReference(obj)

        list.clear()

        return RootedWeak(
            root = list,
            weak = weak
        )
    }

    /**
     * RC-F09
     * Scenario: a collection holding a lambda capture is cleared.
     * Expectation: after the helper stack frame returns, the captured object can be collected.
     */
    @Test
    fun rcF09_removingLambdaFromCollectionAllowsCapturedObjectCollection() {
        val scenario = createLambdaListAfterClear()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }
}
