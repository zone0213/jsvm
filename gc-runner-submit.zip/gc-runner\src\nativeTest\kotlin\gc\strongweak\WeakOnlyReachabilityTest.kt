@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-B group: WeakReference-only cases.
 */
class WeakOnlyReachabilityTest : WeakReferenceTestSupport() {

    private fun createLocalWeakOnly(): WeakReference<Payload> {
        val obj = Payload(201)
        return WeakReference(obj)
    }

    /**
     * WR-B01
     * Scenario: only a local WeakReference escapes from helper.
     * Expectation: the target object can be collected.
     */
    @Test
    fun wrB01_localWeakOnlyDoesNotKeepTargetAlive() {
        val weak = createLocalWeakOnly()

        assertWeakCollected(weak)
    }

    private fun createWeakHolderOnly(): WeakOnlyResult<Root<WeakHolder<Payload>>, Payload> {
        val obj = Payload(202)
        val holder = WeakHolder(WeakReference(obj))
        return WeakOnlyResult(Root(holder), holder.weak!!)
    }

    /**
     * WR-B02
     * Scenario: root strongly holds WeakHolder, and WeakHolder only weakly points to target.
     * Expectation: holder remains reachable, but target can be collected.
     */
    @Test
    fun wrB02_holderWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createWeakHolderOnly()

        forceGc()

        assertNotNull(scenario.root.ref)
        assertNull(scenario.weak.value)
    }

    private fun createGlobalWeakOnly(): WeakReference<Payload> {
        val obj = Payload(203)
        globalWeak = WeakReference(obj)
        return globalWeak!!
    }

    /**
     * WR-B03
     * Scenario: a global variable holds only WeakReference to target.
     * Expectation: the global WeakReference object survives, but its target can be collected.
     */
    @Test
    fun wrB03_globalWeakOnlyDoesNotKeepTargetAlive() {
        val weak = createGlobalWeakOnly()

        forceGc()

        assertNotNull(globalWeak)
        assertNull(weak.value)
    }

    private fun createObjectWeakOnly(): WeakReference<Payload> {
        val obj = Payload(204)
        ObjectStrongWeakHolder.weak = WeakReference(obj)
        return ObjectStrongWeakHolder.weak!!
    }

    /**
     * WR-B04
     * Scenario: an object singleton holds only WeakReference to target.
     * Expectation: the target can be collected.
     */
    @Test
    fun wrB04_objectWeakOnlyDoesNotKeepTargetAlive() {
        val weak = createObjectWeakOnly()

        forceGc()

        assertNotNull(ObjectStrongWeakHolder.weak)
        assertNull(weak.value)
    }

    private fun createWeakListOnly(): WeakOnlyResult<Root<MutableList<WeakReference<Payload>>>, Payload> {
        val obj = Payload(205)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableListOf(weak)), weak)
    }

    /**
     * WR-B05
     * Scenario: a list strongly holds WeakReference, but no strong reference holds target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB05_listWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createWeakListOnly()

        forceGc()

        assertNotNull(scenario.root.ref!!.single())
        assertNull(scenario.weak.value)
    }

    private fun createWeakArrayOnly(): WeakOnlyResult<Root<Array<WeakReference<Payload>?>>, Payload> {
        val obj = Payload(206)
        val weak = WeakReference(obj)
        val array = arrayOfNulls<WeakReference<Payload>>(1)
        array[0] = weak
        return WeakOnlyResult(Root(array), weak)
    }

    /**
     * WR-B06
     * Scenario: an array strongly holds WeakReference, but no strong reference holds target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB06_arrayWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createWeakArrayOnly()

        forceGc()

        assertNotNull(scenario.root.ref!![0])
        assertNull(scenario.weak.value)
    }

    private fun createWeakMapValueOnly(): WeakOnlyResult<Root<MutableMap<String, WeakReference<Payload>>>, Payload> {
        val obj = Payload(207)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableMapOf("target" to weak)), weak)
    }

    /**
     * WR-B07
     * Scenario: a map value strongly holds WeakReference.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB07_mapValueWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createWeakMapValueOnly()

        forceGc()

        assertNotNull(scenario.root.ref!!["target"])
        assertNull(scenario.weak.value)
    }

    private fun createWeakMapKeyOnly(): WeakOnlyResult<Root<MutableMap<WeakReference<Payload>, String>>, Payload> {
        val obj = Payload(208)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(mutableMapOf(weak to "metadata")), weak)
    }

    /**
     * WR-B08
     * Scenario: a map key is a WeakReference object.
     * Expectation: the key object remains in the map, but its target can be collected.
     */
    @Test
    fun wrB08_mapKeyWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createWeakMapKeyOnly()

        forceGc()

        assertNotNull(scenario.root.ref!!.keys.single())
        assertNull(scenario.weak.value)
    }

    private fun createGenericBoxWeakOnly(): WeakOnlyResult<Root<Box<WeakReference<Payload>>>, Payload> {
        val obj = Payload(209)
        val weak = WeakReference(obj)
        return WeakOnlyResult(Root(Box(weak)), weak)
    }

    /**
     * WR-B09
     * Scenario: a generic Box holds only WeakReference to target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB09_genericBoxWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createGenericBoxWeakOnly()

        forceGc()

        assertNotNull(scenario.root.ref!!.value)
        assertNull(scenario.weak.value)
    }

    private fun createLambdaCapturingWeakOnly(): WeakOnlyResult<Root<() -> Int?>, Payload> {
        val obj = Payload(210)
        val weak = WeakReference(obj)
        val block = { weak.value?.id }
        return WeakOnlyResult(Root(block), weak)
    }

    /**
     * WR-B10
     * Scenario: a lambda captures WeakReference, but not the target itself.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB10_lambdaCapturingWeakOnlyDoesNotKeepTargetAlive() {
        val scenario = createLambdaCapturingWeakOnly()

        forceGc()

        assertNull(scenario.root.ref!!())
        assertNull(scenario.weak.value)
    }

    private fun createAnyWeakOnly(): WeakReference<Any> {
        val obj: Any = Payload(211)
        return WeakReference(obj)
    }

    /**
     * WR-B11
     * Scenario: only WeakReference<Any> points to a Payload runtime object.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB11_weakOnlyAnyTypedTargetCanBeCollected() {
        val weak = createAnyWeakOnly()

        assertWeakCollected(weak)
    }

    private fun createInterfaceWeakOnly(): WeakReference<Marker> {
        val obj: Marker = MarkerPayload(212)
        return WeakReference(obj)
    }

    /**
     * WR-B12
     * Scenario: only WeakReference<Marker> points to an interface-typed target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrB12_weakOnlyInterfaceTypedTargetCanBeCollected() {
        val weak = createInterfaceWeakOnly()

        assertWeakCollected(weak)
    }
}
