@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.ExperimentalStdlibApi::class,
    kotlinx.cinterop.ExperimentalForeignApi::class,
)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * RS-H group: RootSetStatistics diagnostic tests.
 *
 * These tests intentionally avoid exact root-count assertions because runtime internals,
 * compiler optimizations and test framework temporaries may affect counts.
 */
class RootSetStatisticsDiagnosticTest : RootSetTestSupport() {
    /**
     * RS-H01
     * Scenario: GC.lastGCInfo is requested after GC.
     * Expectation: GCInfo is available for diagnostics.
     */
    @Test
    fun rsH01_gcInfoCanBeObtained() {
        forceGc()
        val info = GC.lastGCInfo
        assertNotNull(info)
    }

/**
     * RS-H02
     * Scenario: rootSet statistics fields are read after GC.
     * Expectation: all root-set counters are non-negative diagnostics.
     */
    @Test
    fun rsH02_rootSetFieldsAreNonNegative() {
        forceGc()
        val rootSet = GC.lastGCInfo!!.rootSet
        assertTrue(rootSet.stackReferences >= 0)
        assertTrue(rootSet.globalReferences >= 0)
        assertTrue(rootSet.threadLocalReferences >= 0)
        assertTrue(rootSet.stableReferences >= 0)
    }

/**
     * RS-H03
     * Scenario: markedCount is read after GC.
     * Expectation: marked count is non-negative.
     */
    @Test
    fun rsH03_markedCountIsNonNegative() {
        forceGc()
        val info = GC.lastGCInfo!!
        assertTrue(info.markedCount >= 0)
    }

/**
     * RS-H04
     * Scenario: local stack root exists while reading rootSet diagnostics.
     * Expectation: stackReferences is readable with conservative assertion.
     */
    @Test
    fun rsH04_stackRootDiagnosticIsReadable() {
        val obj = RootPayload(8004)
        val weak = WeakReference(obj)
        forceGc()
        val rootSet = GC.lastGCInfo!!.rootSet
        assertTrue(rootSet.stackReferences >= 0)
        assertEquals(8004, obj.id)
        assertNotNull(weak.value)
    }

/**
     * RS-H05
     * Scenario: global root exists while reading rootSet diagnostics.
     * Expectation: globalReferences is readable with conservative assertion.
     */
    @Test
    fun rsH05_globalRootDiagnosticIsReadable() {
        val obj = RootPayload(8005)
        globalPayload = obj
        val weak = WeakReference(obj)
        forceGc()
        val rootSet = GC.lastGCInfo!!.rootSet
        assertTrue(rootSet.globalReferences >= 0)
        assertEquals(8005, globalPayload!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-H06
     * Scenario: ThreadLocal root exists while reading rootSet diagnostics.
     * Expectation: threadLocalReferences is readable with conservative assertion.
     */
    @Test
    fun rsH06_threadLocalRootDiagnosticIsReadable() {
        val obj = RootPayload(8006)
        threadLocalPayload = obj
        val weak = WeakReference(obj)
        forceGc()
        val rootSet = GC.lastGCInfo!!.rootSet
        assertTrue(rootSet.threadLocalReferences >= 0)
        assertEquals(8006, threadLocalPayload!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-H07
     * Scenario: StableRef root exists while reading rootSet diagnostics.
     * Expectation: stableReferences is readable with conservative assertion.
     */
    @Test
    fun rsH07_stableRefRootDiagnosticIsReadable() {
        val obj = RootPayload(8007)
        val weak = WeakReference(obj)
        val stable = stableRefOf(obj)
        try {
            forceGc()
            val rootSet = GC.lastGCInfo!!.rootSet
            assertTrue(rootSet.stableReferences >= 0)
            assertEquals(8007, stable.get().id)
            assertNotNull(weak.value)
        } finally {
            stable.dispose()
        }
    }

/**
     * RS-H08
     * Scenario: a root is cleared before reading GCInfo.
     * Expectation: GCInfo remains readable after cleanup.
     */
    @Test
    fun rsH08_rootSetInfoRemainsReadableAfterRootCleanup() {
        var obj: RootPayload? = RootPayload(8008)
        val weak = WeakReference(obj!!)
        obj = null
        forceGc()
        assertNull(weak.value)
        assertNotNull(GC.lastGCInfo)
    }

/**
     * RS-H09
     * Scenario: sweepStatistics are read after GC.
     * Expectation: diagnostic object is readable.
     */
    @Test
    fun rsH09_sweepStatisticsAreReadable() {
        forceGc()
        val sweepStatisticsText = GC.lastGCInfo!!.sweepStatistics.toString()
        assertTrue(sweepStatisticsText.isNotEmpty())
    }

/**
     * RS-H10
     * Scenario: memory usage before and after GC are read.
     * Expectation: diagnostic maps are readable.
     */
    @Test
    fun rsH10_memoryUsageDiagnosticsAreReadable() {
        forceGc()
        val info = GC.lastGCInfo!!
        assertTrue(info.memoryUsageBefore.toString().isNotEmpty())
        assertTrue(info.memoryUsageAfter.toString().isNotEmpty())
    }

/**
     * RS-H11
     * Scenario: rootSet counts are intentionally not compared to exact values.
     * Expectation: test asserts non-negative counters only.
     */
    @Test
    fun rsH11_rootCountAssertionsRemainConservative() {
        forceGc()
        val rootSet = GC.lastGCInfo!!.rootSet
        val total = rootSet.stackReferences + rootSet.globalReferences + rootSet.threadLocalReferences + rootSet.stableReferences
        assertTrue(total >= 0)
    }

/**
     * RS-H12
     * Scenario: rootSet diagnostic text is generated for failure triage.
     * Expectation: diagnostic text is non-empty.
     */
    @Test
    fun rsH12_rootSetDiagnosticMessageCanBeProduced() {
        forceGc()
        val rootSetText = GC.lastGCInfo!!.rootSet.toString()
        assertTrue(rootSetText.isNotEmpty())
    }
}
