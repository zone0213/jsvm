@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.test.Test
import kotlin.test.assertTrue

/**
 * LS-F group: container mutation long-stability tests.
 */
class ContainerMutationLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-F01
     * Scenario: array replace churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f01_arrayReplaceChurn() {
        val array = arrayOfNulls<LsNode>(32)
        val samples = containerSamples { i ->
            array[i % array.size] = LsNode(i)
        }
        assertTrue(array.any { it != null })
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F02
     * Scenario: list add/remove churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f02_listAddRemoveChurn() {
        val list = mutableListOf<LsNode>()
        val samples = containerSamples { i ->
            list.add(LsNode(i))
            if (list.size > 32) {
                list.removeAt(0)
            }
        }
        assertTrue(list.size <= 32)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F03
     * Scenario: list clear/refill churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f03_listClearRefillChurn() {
        val list = mutableListOf<LsNode>()
        val samples = containerSamples { i ->
            list.clear()
            repeat(16) { index ->
                list.add(LsNode(i * 16 + index))
            }
        }
        assertTrue(list.isNotEmpty())
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F04
     * Scenario: map put/remove churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f04_mapPutRemoveChurn() {
        val map = mutableMapOf<Int, LsNode>()
        val samples = containerSamples { i ->
            map[i] = LsNode(i)
            map.remove(i - 32)
        }
        assertTrue(map.size <= 33)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F05
     * Scenario: map clear/refill churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f05_mapClearRefillChurn() {
        val map = mutableMapOf<Int, LsNode>()
        val samples = containerSamples { i ->
            map.clear()
            repeat(16) { index ->
                map[index] = LsNode(i * 16 + index)
            }
        }
        assertTrue(map.isNotEmpty())
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F06
     * Scenario: set add/remove churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f06_setAddRemoveChurn() {
        val set = mutableSetOf<LsNode>()
        val samples = containerSamples { i ->
            set.add(LsNode(i))
            if (set.size > 32) {
                set.remove(set.first())
            }
        }
        assertTrue(set.size <= 32)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F07
     * Scenario: LRU-like cache churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f07_lruLikeCacheChurn() {
        val cache = LinkedHashMap<Int, LsNode>()
        val samples = containerSamples { i ->
            cache[i] = LsNode(i)
            if (cache.size > CACHE_LIMIT) {
                cache.remove(cache.keys.first())
            }
        }
        assertTrue(cache.size <= CACHE_LIMIT)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F08
     * Scenario: image cache simulation.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f08_imageCacheSimulation() {
        val cache = LinkedHashMap<Int, LargePayload>()
        val samples = containerSamples { i ->
            cache[i] = LargePayload(i, ByteArray(MEDIUM_BYTES))
            if (cache.size > CACHE_LIMIT) {
                cache.remove(cache.keys.first())
            }
        }
        assertTrue(cache.size <= CACHE_LIMIT)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F09
     * Scenario: nested container churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f09_nestedContainerChurn() {
        val outer = mutableListOf<Map<Int, FakeDto>>()
        val samples = containerSamples { i ->
            outer.add(mapOf(i to FakeDto(i, "n$i", emptyList())))
            if (outer.size > CACHE_LIMIT) {
                outer.removeAt(0)
            }
        }
        assertTrue(outer.size <= CACHE_LIMIT)
        assertNoSustainedMonotonicGrowth(samples)
    }

    /**
     * LS-F10
     * Scenario: container mutation exception path.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_f10_containerMutationExceptionPath() {
        val list = mutableListOf<LsNode>()
        val samples = containerSamples { i ->
            try {
                if (i % 5 == 0) {
                    error("mutation")
                } else {
                    list.add(LsNode(i))
                }
            } catch (_: Throwable) {
                list.clear()
            }
        }
        assertNoSustainedMonotonicGrowth(samples)
    }

}
