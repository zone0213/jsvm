﻿import { GC, WeakReference } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertTrue, assertNotNull, assertNull } from '../TestAssertions';

const GC_REPEAT_COUNT = 3;

export class PreciseStackTestSupport {
    beforeTest() {
        this.clearMutableRoots();
        this.forceGc();
    }

    afterTest() {
        this.clearMutableRoots();
        this.forceGc();
    }

    protected forceGc() {
        for (let i = 0; i < GC_REPEAT_COUNT; i++) {
            GC.collect();
        }
    }

    protected clearMutableRoots() {
        globalPreciseStackPayload = null;
        globalPreciseStackHolder = null;
    }

    protected assertWeakAlive<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected live stack root to keep object alive."
    ): T {
        this.forceGc();
        const value = weak.value;
        assertNotNull(value, message);
        return value;
    }

    protected assertWeakCollected<T extends any>(
        weak: WeakReference<T>,
        message: string = "Expected dead stack slot to stop keeping object alive."
    ) {
        this.forceGc();
        weak.clear();
        assertNull(weak.value, message);
    }

    protected runWorkerBoolean(task: () => boolean): boolean {
        // Simplified: in real ArkTS/OpenHarmony, this would use actual worker threads
        return task();
    }
}

export interface PreciseStackMarker {
    id: number;
}

export class StackPayload implements PreciseStackMarker {
    id: number;
    child: StackPayload | null = null;

    constructor(id: number) {
        this.id = id;
    }

    toString(): string {
        return `StackPayload(id=${this.id})`;
    }
}

export class StackHolder<T> {
    ref: T | null = null;
    constructor(ref?: T | null) {
        if (ref !== undefined) this.ref = ref;
    }
}

export let globalPreciseStackPayload: StackPayload | null = null;
export let globalPreciseStackHolder: StackHolder<StackPayload> | null = null;




