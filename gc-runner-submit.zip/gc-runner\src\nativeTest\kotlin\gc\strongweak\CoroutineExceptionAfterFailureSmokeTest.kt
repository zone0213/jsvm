@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test

/**
 * Minimal two-test reproduction for the LS-J05 -> LS-J06 sequence.
 *
 * The first test intentionally mirrors the known J05-style failure pattern.
 * The second test immediately follows with the J06-style exception-path batch.
 */
class CoroutineExceptionAfterFailureSmokeTest : WeakReferenceTestSupport() {

    private fun createWeaksAfterStrongHolderClear(count: Int = 32): List<WeakReference<Payload>> {
        val holders = MutableList(count) { index ->
            StrongHolder(Payload(7000 + index))
        }
        val weaks = holders.map { holder ->
            WeakReference(holder.ref!!)
        }
        holders.forEach { holder ->
            holder.ref = null
        }
        return weaks
    }

    private fun createWeaksAfterExceptionBatch(count: Int = 32): List<WeakReference<Payload>> {
        val weaks = mutableListOf<WeakReference<Payload>>()

        repeat(count) { index ->
            val payload = Payload(8000 + index)
            weaks.add(WeakReference(payload))

            try {
                error("cancel-$index")
            } catch (_: Throwable) {
            }
        }

        return weaks
    }

    /**
     * Phase 1: mirrors the LS-J05 pattern and is expected to fail today.
     */
    @Test
    fun phase1_holderClearLeavesLastWeakAlive() {
        val weaks = createWeaksAfterStrongHolderClear()

        assertAllWeakCollected(weaks)
    }

    /**
     * Phase 2: mirrors the LS-J06 pattern and should still run after phase 1.
     */
    @Test
    fun phase2_exceptionBatchWeakTargetsAreCleared() {
        val weaks = createWeaksAfterExceptionBatch()

        assertAllWeakCollected(weaks)
    }
}
