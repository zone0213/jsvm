@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-C group: deleting references and disconnecting graphs while GC is interleaved.
 */
class ConcurrentReferenceDeletionTest : ConcurrentGcTestSupport() {

    /**
     * CG-C01
     * Scenario: mutator clears normal field while GC runs around mutation.
     * Expectation: old object is eventually collected.
     */
    @Test
    fun cgC01_clearNormalFieldDuringGc() {
        assertWeakCollectedEventually(clearFieldEventually(301))
    }

    /**
     * CG-C02
     * Scenario: mutator clears nullable field.
     * Expectation: old object is eventually collected.
     */
    @Test
    fun cgC02_clearNullableFieldDuringGc() {
        assertWeakCollectedEventually(clearFieldEventually(302))
    }

    /**
     * CG-C03
     * Scenario: mutator clears head.next.
     * Expectation: suffix is eventually collected while head remains alive.
     */
    @Test
    fun cgC03_disconnectChainHeadDuringGc() {
        val nodes = buildChain(4, 303)
        val root = Holder(nodes.first())
        val suffixWeaks = nodes.drop(1).map { WeakReference(it) }
        runGcAroundMutation { nodes[0].next = null }
        assertEquals(303, root.ref!!.id)
        assertAllWeakCollectedEventually(suffixWeaks)
    }

    /**
     * CG-C04
     * Scenario: mutator clears middle.next.
     * Expectation: disconnected suffix is eventually collected.
     */
    @Test
    fun cgC04_disconnectChainMiddleDuringGc() {
        val nodes = buildChain(6, 310)
        val root = Holder(nodes.first())
        val suffixWeaks = nodes.drop(3).map { WeakReference(it) }
        runGcAroundMutation { nodes[2].next = null }
        assertEquals(310, root.ref!!.id)
        assertAllWeakCollectedEventually(suffixWeaks)
    }

    /**
     * CG-C05
     * Scenario: mutator clears root.left.
     * Expectation: left subtree is eventually collected and right subtree remains alive.
     */
    @Test
    fun cgC05_disconnectTreeLeftSubtreeDuringGc() {
        val tree = buildTree(320)
        val root = Holder(tree.first())
        val leftWeaks = listOf(tree[1], tree[3]).map { WeakReference(it) }
        val rightWeak = WeakReference(tree[2])
        runGcAroundMutation { tree[0].left = null }
        assertEquals(322, root.ref!!.right!!.id)
        assertNotNull(rightWeak.value)
        assertAllWeakCollectedEventually(leftWeaks)
    }

    /**
     * CG-C06
     * Scenario: mutator clears root.right.
     * Expectation: right subtree is eventually collected.
     */
    @Test
    fun cgC06_disconnectTreeRightSubtreeDuringGc() {
        val tree = buildTree(330)
        val root = Holder(tree.first())
        val rightWeaks = listOf(tree[2], tree[4]).map { WeakReference(it) }
        runGcAroundMutation { tree[0].right = null }
        assertEquals(330, root.ref!!.id)
        assertAllWeakCollectedEventually(rightWeaks)
    }

    /**
     * CG-C07
     * Scenario: mutator disconnects one parent edge to shared child.
     * Expectation: shared child remains alive through the other parent.
     */
    @Test
    fun cgC07_disconnectOneSharedParentDuringGc() {
        val g = buildSharedGraph(340)
        val weak = WeakReference(g.shared)
        runGcAroundMutation { g.parent1.left = null }
        assertEquals(342, g.parent2.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-C08
     * Scenario: mutator disconnects all parent edges to shared child.
     * Expectation: shared child is eventually collected.
     */
    @Test
    fun cgC08_disconnectAllSharedParentsDuringGc() {
        val g = buildSharedGraph(350)
        val weak = WeakReference(g.shared)
        runGcAroundMutation { g.parent1.left = null
        g.parent2.left = null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-C09
     * Scenario: mutator removes root to cycle.
     * Expectation: cycle is eventually collected.
     */
    @Test
    fun cgC09_disconnectCycleEntryDuringGc() {
        val cycle = buildCycle(360)
        val holder = Holder(cycle.first())
        val weaks = cycle.map { WeakReference(it) }
        runGcAroundMutation { holder.ref = null }
        assertAllWeakCollectedEventually(weaks)
    }

    /**
     * CG-C10
     * Scenario: mutator clears global root.
     * Expectation: old global target is eventually collected.
     */
    @Test
    fun cgC10_disconnectGlobalRootDuringGc() {
        val node = Node(370)
        val weak = WeakReference(node)
        globalNode = node
        runGcAroundMutation { globalNode = null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-C11
     * Scenario: mutator clears ThreadLocal root.
     * Expectation: old ThreadLocal target is eventually collected.
     */
    @Test
    fun cgC11_disconnectThreadLocalRootDuringGc() {
        val node = Node(380)
        val weak = WeakReference(node)
        threadLocalNode = node
        runGcAroundMutation { threadLocalNode = null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-C12
     * Scenario: mutator clears lambda holder.
     * Expectation: captured object is eventually collected.
     */
    @Test
    fun cgC12_disconnectLambdaHolderDuringGc() {
        val node = Node(390)
        val weak = WeakReference(node)
        val holder = LambdaHolder({ node.id })
        runGcAroundMutation { holder.block = null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-C13
     * Scenario: mutator clears many holder fields.
     * Expectation: all old targets are eventually collected.
     */
    @Test
    fun cgC13_bulkClearFieldsDuringGc() {
        val holders = List(16) { Holder(Node(400 + it)) }
        val weaks = holders.map { WeakReference(it.ref!!) }
        runGcAroundMutation { holders.forEach { it.ref = null } }
        assertAllWeakCollectedEventually(weaks)
    }

    /**
     * CG-C14
     * Scenario: mutator repeatedly clears and rebuilds reference.
     * Expectation: final state is valid and test does not crash.
     */
    @Test
    fun cgC14_repeatedDisconnectReconnectAcrossGc() {
        val holder = Holder<Node>(null)
        val count = repeatMutationWithGc { if (it % 2 == 0) holder.ref = Node(420 + it) else holder.ref = null }
        assertEquals(SMALL_ITERATIONS, count)
    }

}
