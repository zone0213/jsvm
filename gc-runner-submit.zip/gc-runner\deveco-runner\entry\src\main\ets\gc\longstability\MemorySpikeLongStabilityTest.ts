import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class MemorySpikeLongStabilityTest extends LongStabilityTestSupport {

    ls_e01_smallMemorySpikeLoop() {
        const spike = this.spikeLoop(() => this.allocateSmallBatch(512).map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }

    ls_e02_largeMemorySpikeLoop() {
        const spike = this.spikeLoop(() => this.allocateLargeBatch(4, MEDIUM_BYTES).map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }

    ls_e03_mixedMemorySpikeLoop() {
        const spike = this.spikeLoop(() => this.allocateMixedBatch().map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }

    ls_e04_spikeIdleRecovery() {
        const spike = this.spikeLoop(() => this.allocateSmallBatch(512).map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }

    ls_e05_spikeWithLongLivedRoot() {
        const root = new LargePayload(5, new Array(MEDIUM_BYTES).fill(0));
        const weak = new WeakReference(root);
        const spike = this.spikeLoop(() => this.allocateMixedBatch().slice());
        assertNotNull(weak.value);
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
        assertEquals(5, root.id);
    }

    ls_e06_backToBackSpikes() {
        const first = this.spikeLoop(() => this.allocateLargeBatch(2, MEDIUM_BYTES).map(it => it as any));
        this.assertSpikeRecovered(first[0], first[1], first[2]);
        const second = this.spikeLoop(() => this.allocateLargeBatch(2, MEDIUM_BYTES).map(it => it as any));
        this.assertSpikeRecovered(second[0], second[1], second[2]);
    }

    ls_e07_delayedReleaseSpike() {
        const roots = this.allocateLargeBatch(4, MEDIUM_BYTES).map(it => it as any);
        this.forceGc();
        const before = this.heapAfterBytes();
        roots.length = 0;
        this.forceGc(8);
        const after = this.heapAfterBytes();
        assertTrue(after <= before, "Expected heap after delayed release to be <= heap before.");
    }

    ls_e08_randomLikeSpikePattern() {
        const samples: number[] = [];
        for (let i = 0; i < 8; i++) {
            const roots = i % 3 === 0 ? this.allocateLargeBatch(3, MEDIUM_BYTES).map(it => it as any) : this.allocateSmallBatch(256).map(it => it as any);
            roots.length = 0;
            this.forceGc();
            samples.push(this.heapAfterBytes());
        }
        this.assertNoSustainedMonotonicGrowth(samples);
        this.assertSpikeRecovered(samples.first(), Math.max(...samples), samples.last());
    }

    ls_e09_pressureWithoutManualGc() {
        const spike = this.spikeLoop(() => this.allocateSmallBatch(512).map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }

    ls_e10_pressureWithPeriodicGc() {
        const spike = this.spikeLoop(() => this.allocateSmallBatch(512).map(it => it as any));
        this.assertSpikeRecovered(spike[0], spike[1], spike[2]);
    }
}
