@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

/**
 * LS-J group: coroutine/continuation-like lifecycle long-stability tests.
 */
class CoroutineContinuationLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-J01
     * Scenario: batch suspend/resume.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j01_batchSuspendResume() {
        assertAllWeakCollectedEventually(coroutineLikeBatch())
    }

    /**
     * LS-J02
     * Scenario: repeated suspend/resume.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j02_repeatedSuspendResume() {
        assertNoSustainedMonotonicGrowth(containerSamples { coroutineLikeBatch(8) })
    }

    /**
     * LS-J03
     * Scenario: continuation large payload.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j03_continuationLargePayload() {
        fun run(): WeakReference<LargePayload> {
            val payload = LargePayload(3, ByteArray(MEDIUM_BYTES))
            val holder = Holder(payload)
            val weak = WeakReference(payload)
            assertNotNull(holder.ref)
            holder.ref = null
            return weak
        }

        assertWeakCollectedEventually(run())
    }

    /**
     * LS-J04
     * Scenario: nested suspend chain.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j04_nestedSuspendChain() {
        fun run(): WeakReference<LsNode> {
            val node = LsNode(4)
            val inner = Holder(node)
            val outer = Holder(inner)
            val weak = WeakReference(node)
            assertNotNull(outer.ref!!.ref)
            outer.ref = null
            return weak
        }

        assertWeakCollectedEventually(run())
    }

    /**
     * LS-J05
     * Scenario: coroutine cancel batch.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j05_coroutineCancelBatch() {
        val holders = MutableList(32) { Holder(LsNode(it)) }
        val weaks = holders.map { holder ->
            WeakReference(holder.ref!!)
        }
        holders.forEach { holder ->
            holder.ref = null
        }
        assertAllWeakCollectedEventually(weaks)
    }

    /**
     * LS-J06
     * Scenario: coroutine exception batch.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j06_coroutineExceptionBatch() {
        fun run(): List<WeakReference<LsNode>> {
            val weaks = mutableListOf<WeakReference<LsNode>>()
            repeat(32) { index ->
                val node = LsNode(index)
                weaks.add(WeakReference(node))
                try {
                    error("cancel")
                } catch (_: Throwable) {
                }
            }
            return weaks
        }

        assertAllWeakCollectedEventually(run())
    }

    /**
     * LS-J07
     * Scenario: async/deferred result churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j07_asyncDeferredResultChurn() {
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                val result = Holder(FakeDto(i, "d", emptyList()))
                assertEquals(i, result.ref!!.id)
                result.ref = null
            }
        )
    }

    /**
     * LS-J08
     * Scenario: channel send/receive churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j08_channelSendReceiveChurn() {
        val queue = ArrayDeque<FakeDto>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                queue.addLast(FakeDto(i, "q", emptyList()))
                if (queue.size > 8) {
                    queue.removeFirst()
                }
            }
        )
    }

    /**
     * LS-J09
     * Scenario: flow emit/collect churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j09_flowEmitCollectChurn() {
        val collected = mutableListOf<Int>()
        assertNoSustainedMonotonicGrowth(
            containerSamples { i ->
                val dto = FakeDto(i, "f", emptyList())
                collected.add(dto.id)
                if (collected.size > 32) {
                    collected.clear()
                }
            }
        )
    }

    /**
     * LS-J10
     * Scenario: coroutine with allocation pressure.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_j10_coroutineWithAllocationPressure() {
        assertNoSustainedMonotonicGrowth(
            containerSamples {
                coroutineLikeBatch(4)
                allocateMixedBatch()
            }
        )
    }

}
