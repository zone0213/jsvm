@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

/**
 * PS-A group: stack slot reuse and dead-slot precision.
 */
class PreciseStackSlotReuseTest : PreciseStackTestSupport() {
    /**
     * PS-A01
     * Scenario: a local reference is live across a GC safepoint.
     * Expectation: precise stack scanning includes the live reference slot.
     */
    @Test
    fun psA01_liveLocalReferenceKeepsObjectAliveAtGc() {
        val obj = StackPayload(1001)
        val weak = WeakReference(obj)

        val observed = assertWeakAlive(weak)

        assertEquals(1001, observed.id)
        assertEquals(1001, obj.id)
    }

    /**
     * PS-A02
     * Scenario: a nullable local root is set to null before GC.
     * Expectation: precise stack scanning does not retain the dead old reference slot.
     */
    @Test
    fun psA02_nullableLocalSetNullDropsOldStackRoot() {
        var obj: StackPayload? = StackPayload(1002)
        val weak = WeakReference(obj!!)

        obj = null

        assertWeakCollected(weak)
        assertEquals(null, obj)
    }

    /**
     * PS-A03
     * Scenario: a local reference slot is reassigned from old object to new object before GC.
     * Expectation: old object is not retained by the reused slot, new object remains live.
     */
    @Test
    fun psA03_localReassignmentDropsOldKeepsNew() {
        var obj: StackPayload? = StackPayload(1003)
        val oldWeak = WeakReference(obj!!)

        obj = StackPayload(1030)
        val newWeak = WeakReference(obj!!)

        assertWeakCollected(oldWeak)
        val newValue = assertWeakAlive(newWeak)
        assertEquals(1030, newValue.id)
        assertEquals(1030, obj!!.id)
    }

    /**
     * PS-A04
     * Scenario: a reference-typed local slot is overwritten by another reference many times.
     * Expectation: previous objects are not retained by stale stack slots.
     */
    @Test
    fun psA04_loopSlotReuseDropsPreviousObjects() {
        var current: StackPayload? = null
        val oldWeaks = mutableListOf<WeakReference<StackPayload>>()

        repeat(8) { index ->
            current = StackPayload(1040 + index)
            if (index < 7) {
                oldWeaks.add(WeakReference(current!!))
            }
        }
        val liveWeak = WeakReference(current!!)

        oldWeaks.forEachIndexed { index, weak ->
            assertWeakCollected(weak, "Expected loop slot old weak[$index] to be cleared.")
        }
        assertEquals(1047, assertWeakAlive(liveWeak).id)
        assertEquals(1047, current!!.id)
    }

    /**
     * PS-A05
     * Scenario: a child is disconnected from a live parent before GC.
     * Expectation: parent remains live, disconnected child is not retained by a stale local slot.
     */
    @Test
    fun psA05_disconnectedChildSlotIsNotRetained() {
        val root = StackPayload(1005, StackPayload(1050))
        val childWeak = WeakReference(root.child!!)

        root.child = null

        assertWeakCollected(childWeak)
        assertNotNull(assertWeakAlive(WeakReference(root)))
        assertEquals(1005, root.id)
    }
}

