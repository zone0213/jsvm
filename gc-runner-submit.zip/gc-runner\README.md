# Kotlin/Native GC Basic Reachability Tests

This package contains deterministic Kotlin/Native GC functional tests for the first layer: basic reachability.

## Scope

The tests validate:

- local roots
- function parameter and return-value roots
- global, object, and companion-object roots
- field paths
- arrays and collections
- generic holders
- lambda captures
- basic control-flow shapes

WeakReference is only used as an observation mechanism. The weak-reference semantics themselves should be covered in a dedicated weak-reference test layer.

## Test files

- `ReachabilityTestSupport.kt`: shared model types, global roots, GC helpers, common assertions
- `LocalRootReachabilityTest.kt`: RC-A01 ~ RC-A12
- `ParameterReturnReachabilityTest.kt`: RC-B01 ~ RC-B08
- `GlobalRootReachabilityTest.kt`: RC-C01 ~ RC-C08
- `FieldPathReachabilityTest.kt`: RC-D01 ~ RC-D09
- `ArrayCollectionReachabilityTest.kt`: RC-E01 ~ RC-E12
- `GenericLambdaReachabilityTest.kt`: RC-F01 ~ RC-F09
- `ControlFlowReachabilityTest.kt`: RC-G01 ~ RC-G10

## Notes

For collection assertions, objects are usually created inside helper functions and only WeakReference escapes. This avoids unstable assertions caused by stale references left in the current stack frame.

For alive assertions, tests trigger GC and then continue to use the strong reference after GC, making the intended liveness explicit.
