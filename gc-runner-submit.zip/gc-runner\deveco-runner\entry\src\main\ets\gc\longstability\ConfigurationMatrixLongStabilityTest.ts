import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class ConfigurationMatrixLongStabilityTest extends LongStabilityTestSupport {

    ls_m01_defaultConfigSmoke() {
        const descriptor = "default-smoke";
        assertTrue(descriptor.length > 0);
        this.assertNoSustainedMonotonicGrowth(this.shortLivedSamples(it => new LsNode(it)));
    }

    ls_m02_cmsDailyDescriptor() {
        assertTrue("cmsDaily".length > 0);
    }

    ls_m03_pmcsDailyDescriptor() {
        assertTrue("pmcsDaily".length > 0);
    }

    ls_m04_stwmsDailyDescriptor() {
        assertTrue("stwmsDaily".length > 0);
    }

    ls_m05_gcmarksinglethreadedDescriptor() {
        assertTrue("gcmarksinglethreaded".length > 0);
    }

    ls_m06_pagedallocatorFalseDescriptor() {
        assertTrue("pagedallocatorFalse".length > 0);
    }

    ls_m07_disablemmapTrueDescriptor() {
        assertTrue("disablemmapTrue".length > 0);
    }

    ls_m08_combinedAllocatorDescriptor() {
        assertTrue("combinedAllocator".length > 0);
    }

    ls_m09_macosArm64NightlyDescriptor() {
        assertTrue("macosArm64Nightly".length > 0);
    }

    ls_m10_linuxX64NightlyDescriptor() {
        assertTrue("linuxX64Nightly".length > 0);
    }

    ls_m11_iosSimulatorSmokeDescriptor() {
        assertTrue("iosSimulatorSmoke".length > 0);
    }

    ls_m12_multiPlatformResultComparisonDescriptor() {
        assertTrue("multiPlatformResultComparison".length > 0);
    }
}
