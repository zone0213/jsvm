import { LongStabilityTestSupport, LsNode, MediumPayload, LargePayload, MixedPayload, Holder, FakeContinuation, PinnedLike, FakeDto, FakeDtoChild, FakeState, globalHolder, SHORT_ITERATIONS, WORKER_COUNT, WORKER_ITERATIONS, CHURN_PER_ITERATION, SAMPLE_EVERY, MEDIUM_BYTES, CACHE_LIMIT, WeakReference } from './LongStabilityTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

export class RealBusinessWorkloadLongStabilityTest extends LongStabilityTestSupport {

    ls_l01_jsonDtoParseChurn() {
        this.assertNoSustainedMonotonicGrowth(this.businessDtoSamples());
    }

    ls_l02_jsonEncodeDecodeRoundtrip() {
        const dto = new FakeDto(1, "roundtrip", [new FakeDtoChild(1, "v")]);
        const decoded = FakeDto.decode(dto.encode());
        assertEquals(dto.id, decoded.id);
    }

    ls_l03_cliArgumentParseChurn() {
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { const args = ["--user", `u${i}`, "--limit", String(i % 10)]; assertEquals("--user", args[0]); }));
    }

    ls_l04_gitLogParserWorkload() {
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { const parts = `abc${i}|Author|2026-01-01|Message ${i}`.split("|"); assertEquals("Author", parts[1]); }));
    }

    ls_l05_repositoryMockQueryLoop() {
        this.assertNoSustainedMonotonicGrowth(this.repositoryCacheStateSamples());
    }

    ls_l06_lruCacheWorkload() {
        const cache = new Map<number, LargePayload>();
        const samples = this.containerSamples(i => { cache.set(i, new LargePayload(i, new Array(1024).fill(0))); if (cache.size > CACHE_LIMIT) cache.delete(Array.from(cache.keys())[0]); });
        assertTrue(cache.size <= CACHE_LIMIT);
        this.assertNoSustainedMonotonicGrowth(samples);
    }

    ls_l07_viewmodelStateReduce() {
        let state = new FakeState([]);
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { state = state.reduce(new FakeDto(i, "task", [])); }));
        assertTrue(state.items.length > 0);
    }

    ls_l08_coroutineTaskQueueWorkload() {
        const queue: FakeDto[] = [];
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { queue.push(new FakeDto(i, "task", [])); if (queue.length > 8) queue.shift(); }));
    }

    ls_l09_errorHeavyWorkload() {
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { try { if (i % 2 === 0) throw new Error("bad input"); } catch (_e) {} }));
    }

    ls_l10_mixedBusinessWorkload() {
        this.assertNoSustainedMonotonicGrowth(this.containerSamples(i => { new MixedPayload(i); FakeDto.decode(new FakeDto(i, "mix", []).encode()); }));
    }
}
