@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-F group: multi-thread shared object graph read/write tests.
 */
class SharedGraphConcurrentMutationTest : ConcurrentGcTestSupport() {

    /**
     * CG-F01
     * Scenario: two threads read/write same holder while GC runs.
     * Expectation: no crash.
     */
    @Test
    fun cgF01_twoThreadsReadWriteSameHolder() {
        val holder=Holder(Node(801))
        val completed=runBoundedConcurrentWriters(2,16){_,i-> holder.ref=Node(8010+i)
        assertNotNull(holder.ref) }
        assertEquals(2,completed)
        assertNotNull(holder.ref)
    }

    /**
     * CG-F02
     * Scenario: two writers alternately publish objects.
     * Expectation: final ref is accessible.
     */
    @Test
    fun cgF02_twoThreadsAlternatePublishObjects() {
        val completed=runBoundedConcurrentWriters(2,16){w,i-> globalHolder.ref=Node(8020+w*100+i) }
        assertEquals(2,completed)
        assertNotNull(globalHolder.ref)
    }

    /**
     * CG-F03
     * Scenario: reader stores old object in local while writer replaces holder.
     * Expectation: reader local object remains alive during use.
     */
    @Test
    fun cgF03_readerKeepsOldObjectLocalWhileWriterReplaces() {
        val old=Node(803)
        val holder=Holder(old)
        val weak=WeakReference(old)
        val local=holder.ref!!
        holder.ref=Node(804)
        forceGc()
        assertEquals(803,local.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-F04
     * Scenario: writer replaces old object while weak observes old.
     * Expectation: old is eventually collected after no strong remains.
     */
    @Test
    fun cgF04_writerReplacesReaderWeakObservesOld() {
        val result = replaceField(805, 806)
        val holder = result.root
        assertWeakCollectedEventually(result.oldWeak)
        assertWeakAlive(result.newWeak)
        assertNotNull(holder.ref)
    }

    /**
     * CG-F05
     * Scenario: two writers update left and right fields.
     * Expectation: both fields become accessible.
     */
    @Test
    fun cgF05_multiThreadUpdateDifferentFields() {
        val root=Node(807)
        val completed=runBoundedConcurrentWriters(2,8){w,i-> if(w==0) root.left=Node(8070+i) else root.right=Node(8080+i) }
        assertEquals(2,completed)
        assertNotNull(root.left)
        assertNotNull(root.right)
    }

    /**
     * CG-F06
     * Scenario: multiple writers update same field.
     * Expectation: no crash and final value accessible.
     */
    @Test
    fun cgF06_multiThreadUpdateSameField() {
        val root=Node(809)
        val completed=runBoundedConcurrentWriters(2,8){w,i-> root.next=Node(8090+w*100+i) }
        assertEquals(2,completed)
        assertNotNull(root.next)
    }

    /**
     * CG-F07
     * Scenario: child subgraph is moved between parents.
     * Expectation: child not incorrectly collected.
     */
    @Test
    fun cgF07_multiThreadMoveSubgraph() {
        val child=Node(810)
        val weak=WeakReference(child)
        val p1=Node(811)
        val p2=Node(812)
        p1.left=child
        runGcAroundMutation { p1.left=null
        p2.left=child }
        assertEquals(810,p2.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-F08
     * Scenario: producer publishes and consumer takes local reference.
     * Expectation: consumer local remains valid.
     */
    @Test
    fun cgF08_producerConsumerHandoff() {
        val shared=Holder<Node>(null)
        val node=Node(813)
        runGcAroundMutation{ shared.ref=node }
        val local=shared.ref!!
        forceGc()
        assertEquals(813,local.id)
    }

    /**
     * CG-F09
     * Scenario: producer clears root after consumer takes local reference.
     * Expectation: consumer local keeps object alive.
     */
    @Test
    fun cgF09_producerClearsAfterConsumerTakesLocal() {
        val shared=Holder(Node(814))
        val local=shared.ref!!
        val weak=WeakReference(local)
        runGcAroundMutation{ shared.ref=null }
        assertEquals(814,local.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-F10
     * Scenario: producer clears before consumer reads.
     * Expectation: consumer sees null or valid value without crash.
     */
    @Test
    fun cgF10_producerClearsBeforeConsumerReads() {
        val shared=Holder(Node(815))
        runGcAroundMutation{ shared.ref=null }
        val local=shared.ref
        assertNull(local)
    }

    /**
     * CG-F11
     * Scenario: writer mutates reachable cycle entry.
     * Expectation: no crash.
     */
    @Test
    fun cgF11_sharedCycleGraphMutation() {
        val cycle=buildCycle(816)
        val holder=Holder(cycle.first())
        runGcAroundMutation{ holder.ref=cycle[1] }
        assertEquals(817, holder.ref!!.id)
    }

    /**
     * CG-F12
     * Scenario: writers mutate parent edges in DAG.
     * Expectation: shared lifecycle remains valid.
     */
    @Test
    fun cgF12_sharedDagParentMutation() {
        val g=buildSharedGraph(820)
        val weak=WeakReference(g.shared)
        runGcAroundMutation{ g.parent1.left=null
        g.parent2.right=g.shared }
        assertNotNull(weak.value)
    }

    /**
     * CG-F13
     * Scenario: N writers update holder array while GC is triggered.
     * Expectation: all writers complete.
     */
    @Test
    fun cgF13_manyWritersOneGcThread() {
        val holders=Array(4){Holder<Node>(null)}
        val completed=runBoundedConcurrentWriters(4,16){w,i-> holders[w].ref=Node(8300+w*100+i) }
        forceGcLoop()
        assertEquals(4,completed)
        holders.forEach{ assertNotNull(it.ref) }
    }

    /**
     * CG-F14
     * Scenario: bounded mixed writer/reader simulation with GC.
     * Expectation: completes without crash.
     */
    @Test
    fun cgF14_manyWritersReadersAndGc() {
        val holders=Array(4){Holder(Node(8400+it))}
        val count=repeatMutationWithGc(64){ i -> holders[i%4].ref=Node(8400+i)
        holders.forEach{ it.ref?.id } }
        assertEquals(64,count)
    }

}
