@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.graphtopology

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/** GT-D group: DAG and shared-subgraph tests. */
class DagSharedGraphTest : GraphTopologyTestSupport() {

    private fun diamond(): List<GraphNode> {
        val a = GraphNode(8000)
        val b = GraphNode(8001)
        val c = GraphNode(8002)
        val d = GraphNode(8003)
        a.left = b
        a.right = c
        b.next = d
        c.next = d
        return listOf(a, b, c, d)
    }

    /** GT-D01: a diamond DAG keeps both branches and the shared leaf alive. */
    @Test
    fun gtD01_diamondDagKeepsWholeGraphAlive() {
        val nodes = diamond()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(8003, scenario.root.ref!!.left!!.next!!.id)
        assertEquals(8003, scenario.root.ref!!.right!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun diamondAfterOneParentEdgeClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = diamond()
        val root = GraphRoot(nodes.first())
        nodes[1].next = null
        return RootedWeaks(root, weakRefs(nodes))
    }

    /** GT-D02: clearing one parent edge does not collect a shared node that still has another parent. */
    @Test
    fun gtD02_clearingOneParentEdgeKeepsSharedNodeAlive() {
        val scenario = diamondAfterOneParentEdgeClear()
        forceGc()
        assertNull(scenario.root.ref!!.left!!.next)
        assertEquals(8003, scenario.root.ref!!.right!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun diamondAfterAllParentEdgesClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = diamond()
        val root = GraphRoot(nodes.first())
        val shared = nodes[3]
        nodes[1].next = null
        nodes[2].next = null
        return MixedWeaks(root, weakRefs(nodes.take(3)), weakRefs(listOf(shared)))
    }

    /** GT-D03: clearing all parent edges allows the shared leaf to be collected. */
    @Test
    fun gtD03_clearingAllParentEdgesCollectsSharedNode() {
        val scenario = diamondAfterAllParentEdgesClear()
        forceGc()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun sharedSubChain(): List<GraphNode> {
        val a = GraphNode(8100)
        val b = GraphNode(8101)
        val c = GraphNode(8102)
        val d = GraphNode(8103)
        val e = GraphNode(8104)
        val f = GraphNode(8105)
        a.left = b
        a.right = c
        b.next = d
        c.next = d
        d.next = e
        e.next = f
        return listOf(a, b, c, d, e, f)
    }

    /** GT-D04: a shared sub-chain remains alive when both parents point to its head. */
    @Test
    fun gtD04_sharedSubChainKeepsAllSharedNodesAlive() {
        val nodes = sharedSubChain()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(8105, nodes[3].next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun sharedSubChainAfterOneParentClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = sharedSubChain()
        nodes[1].next = null
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-D05: a shared sub-chain survives when one of two parent edges is cleared. */
    @Test
    fun gtD05_sharedSubChainSurvivesOneParentEdgeClear() {
        val scenario = sharedSubChainAfterOneParentClear()
        forceGc()
        assertEquals(8103, scenario.root.ref!!.right!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun sharedSubChainAfterAllParentsClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = sharedSubChain()
        nodes[1].next = null
        nodes[2].next = null
        return MixedWeaks(GraphRoot(nodes.first()), weakRefs(nodes.take(3)), weakRefs(nodes.drop(3)))
    }

    /** GT-D06: a shared sub-chain is collected after all parent edges are cleared. */
    @Test
    fun gtD06_sharedSubChainCollectedAfterAllParentEdgesClear() {
        val scenario = sharedSubChainAfterAllParentsClear()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun threeParentsSharedLeaf(): List<GraphNode> {
        val root = GraphNode(8200)
        val p1 = GraphNode(8201)
        val p2 = GraphNode(8202)
        val p3 = GraphNode(8203)
        val shared = GraphNode(8204)
        root.left = p1
        root.right = p2
        root.next = p3
        p1.next = shared
        p2.next = shared
        p3.next = shared
        return listOf(root, p1, p2, p3, shared)
    }

    /** GT-D07: three parents sharing one leaf keep the shared leaf alive. */
    @Test
    fun gtD07_threeParentSharedLeafKeepsSharedLeafAlive() {
        val nodes = threeParentsSharedLeaf()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(8204, scenario.weaks.last().value!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun threeParentsAfterTwoEdgesClear(): RootedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = threeParentsSharedLeaf()
        nodes[1].next = null
        nodes[2].next = null
        return RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
    }

    /** GT-D08: clearing two of three parent edges still keeps the shared leaf alive. */
    @Test
    fun gtD08_threeParentSharedLeafSurvivesPartialParentEdgeClear() {
        val scenario = threeParentsAfterTwoEdgesClear()
        forceGc()
        assertEquals(8204, scenario.root.ref!!.next!!.next!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun threeParentsAfterAllEdgesClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = threeParentsSharedLeaf()
        nodes[1].next = null
        nodes[2].next = null
        nodes[3].next = null
        return MixedWeaks(GraphRoot(nodes.first()), weakRefs(nodes.take(4)), weakRefs(nodes.drop(4)))
    }

    /** GT-D09: clearing all three parent edges allows the shared leaf to be collected. */
    @Test
    fun gtD09_threeParentSharedLeafCollectedAfterAllParentEdgesClear() {
        val scenario = threeParentsAfterAllEdgesClear()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun repeatedFieldSharedNode(): List<GraphNode> {
        val parent = GraphNode(8300)
        val shared = GraphNode(8301)
        parent.left = shared
        parent.right = shared
        parent.next = shared
        return listOf(parent, shared)
    }

    /** GT-D10: multiple fields from one parent to the same child keep the child alive. */
    @Test
    fun gtD10_repeatedFieldReferencesKeepSharedNodeAlive() {
        val nodes = repeatedFieldSharedNode()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertAllAlive(scenario.weaks)
    }

    /** GT-D11: clearing one repeated field still keeps the shared node alive through other fields. */
    @Test
    fun gtD11_clearingOneRepeatedFieldKeepsSharedNodeAlive() {
        val nodes = repeatedFieldSharedNode()
        nodes[0].left = null
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertNull(scenario.root.ref!!.left)
        assertEquals(8301, scenario.root.ref!!.right!!.id)
        assertAllAlive(scenario.weaks)
    }

    private fun repeatedFieldAfterAllClear(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        val nodes = repeatedFieldSharedNode()
        nodes[0].left = null
        nodes[0].right = null
        nodes[0].next = null
        return MixedWeaks(GraphRoot(nodes.first()), weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-D12: clearing all repeated fields allows the shared node to be collected. */
    @Test
    fun gtD12_clearingAllRepeatedFieldsCollectsSharedNode() {
        val scenario = repeatedFieldAfterAllClear()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }

    private fun repeatedListSharedNode(): List<MultiNode> {
        val parent = MultiNode(8400)
        val shared = MultiNode(8401)
        parent.children.add(shared)
        parent.children.add(shared)
        parent.children.add(shared)
        return listOf(parent, shared)
    }

    /** GT-D13: repeated List entries to the same node keep that node alive. */
    @Test
    fun gtD13_listRepeatedReferencesKeepSharedNodeAlive() {
        val nodes = repeatedListSharedNode()
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(3, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    /** GT-D14: removing one repeated List entry still keeps the shared node alive. */
    @Test
    fun gtD14_removingOneRepeatedListReferenceKeepsSharedNodeAlive() {
        val nodes = repeatedListSharedNode()
        nodes[0].children.removeAt(0)
        val scenario = RootedWeaks(GraphRoot(nodes.first()), weakRefs(nodes))
        forceGc()
        assertEquals(2, scenario.root.ref!!.children.size)
        assertAllAlive(scenario.weaks)
    }

    private fun repeatedListAfterClear(): MixedWeaks<GraphRoot<MultiNode>, MultiNode> {
        val nodes = repeatedListSharedNode()
        nodes[0].children.clear()
        return MixedWeaks(GraphRoot(nodes.first()), weakRefs(nodes.take(1)), weakRefs(nodes.drop(1)))
    }

    /** GT-D15: clearing all repeated List references allows the shared node to be collected. */
    @Test
    fun gtD15_clearingRepeatedListReferencesCollectsSharedNode() {
        val scenario = repeatedListAfterClear()
        assertAllAlive(scenario.aliveWeaks)
        assertAllCollected(scenario.collectedWeaks)
    }
}
