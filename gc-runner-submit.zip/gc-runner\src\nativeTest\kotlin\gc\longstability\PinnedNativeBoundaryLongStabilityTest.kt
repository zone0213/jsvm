@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * LS-K group: pinned/native-like boundary long-stability tests.
 */
class PinnedNativeBoundaryLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-K01
     * Scenario: repeat usePinned normal.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k01_repeatUsepinnedNormal() {
        assertEquals(SHORT_ITERATIONS, pinnedLikeLoop())
    }

    /**
     * LS-K02
     * Scenario: repeat usePinned exception.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k02_repeatUsepinnedException() {
        assertTrue(pinnedLikeLoop(throwInside = true) >= SHORT_ITERATIONS)
    }

    /**
     * LS-K03
     * Scenario: pinned with GC loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k03_pinnedWithGcLoop() {
        assertEquals(8, pinnedLikeLoop(8))
    }

    /**
     * LS-K04
     * Scenario: pinned with allocation pressure.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k04_pinnedWithAllocationPressure() {
        var count = 0
        repeat(16) { i ->
            val bytes = ByteArray(MEDIUM_BYTES)
            PinnedLike.use(bytes) {
                allocateMixedBatch()
                forceGc()
                it[0] = i.toByte()
                assertEquals(i.toByte(), it[0])
                count++
            }
        }
        assertEquals(16, count)
    }

    /**
     * LS-K05
     * Scenario: nested usePinned loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k05_nestedUsepinnedLoop() {
        repeat(16) { i ->
            PinnedLike.use(ByteArray(128)) { first ->
                PinnedLike.use(ByteArray(128)) { second ->
                    first[0] = i.toByte()
                    second[0] = first[0]
                    assertEquals(i.toByte(), second[0])
                }
            }
        }
        assertTrue(true)
    }

    /**
     * LS-K06
     * Scenario: multiple pinned arrays.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k06_multiplePinnedArrays() {
        repeat(16) { i ->
            List(4) { ByteArray(128) }.forEach { bytes ->
                PinnedLike.use(bytes) {
                    it[0] = i.toByte()
                    assertEquals(i.toByte(), it[0])
                }
            }
        }
        assertTrue(true)
    }

    /**
     * LS-K07
     * Scenario: manual pin/unpin-like loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k07_manualPinUnpinLikeLoop() {
        var cleaned = 0
        repeat(16) { index ->
            try {
                ByteArray(128)[0] = index.toByte()
            } finally {
                cleaned++
            }
        }
        assertEquals(16, cleaned)
    }

    /**
     * LS-K08
     * Scenario: native-like pointer read/write.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k08_nativeLikePointerReadWrite() {
        fun helper(bytes: ByteArray, value: Byte) {
            bytes[0] = value
        }

        repeat(16) { i ->
            val bytes = ByteArray(8)
            helper(bytes, i.toByte())
            assertEquals(i.toByte(), bytes[0])
        }
    }

    /**
     * LS-K09
     * Scenario: native-like callback churn.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k09_nativeLikeCallbackChurn() {
        repeat(16) { i ->
            val node = LsNode(i)
            val callback = { node.id }
            forceGc()
            assertEquals(i, callback())
        }
    }

    /**
     * LS-K10
     * Scenario: pinned boundary mixed stress.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_k10_pinnedBoundaryMixedStress() {
        val weak = WeakReference(ByteArray(128))
        val count = pinnedLikeLoop(8)
        allocateMixedBatch()
        forceGc()
        assertEquals(8, count)
        assertTrue(weak.value == null || weak.value!!.isNotEmpty())
    }

}
