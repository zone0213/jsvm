@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-B group: control-flow liveness boundaries for precise stack maps.
 */
class PreciseStackControlFlowTest : PreciseStackTestSupport() {
    private fun branchDropsUnselectedObject(selectFirst: Boolean): WeakReference<StackPayload> {
        var selected: StackPayload? = null
        var unselected: StackPayload? = null

        if (selectFirst) {
            selected = StackPayload(2001)
            unselected = StackPayload(2091)
        } else {
            unselected = StackPayload(2092)
            selected = StackPayload(2002)
        }

        val deadWeak = WeakReference(unselected!!)
        val liveWeak = WeakReference(selected!!)
        unselected = null

        forceGc()
        assertEquals(selected.id, liveWeak.value!!.id)
        assertEquals(null, unselected)
        return deadWeak
    }

    /**
     * PS-B01
     * Scenario: only one branch result remains live before GC.
     * Expectation: object from the unselected/dead branch is not retained.
     */
    @Test
    fun psB01_branchDeadLocalIsNotRetained() {
        val deadWeak = branchDropsUnselectedObject(selectFirst = true)

        assertWeakCollected(deadWeak)
    }

    /**
     * PS-B02
     * Scenario: loop temporary is cleared on every iteration before GC.
     * Expectation: cleared temporary objects are not retained by loop-carried stack slots.
     */
    @Test
    fun psB02_loopTemporaryClearedBeforeSafepointIsCollected() {
        val weaks = mutableListOf<WeakReference<StackPayload>>()

        repeat(6) { index ->
            var temporary: StackPayload? = StackPayload(2020 + index)
            weaks.add(WeakReference(temporary!!))
            temporary = null
            assertEquals(null, temporary)
        }

        weaks.forEachIndexed { index, weak ->
            assertWeakCollected(weak, "Expected cleared loop temporary weak[$index] to be cleared.")
        }
    }

    private fun createWeakAfterBreak(): WeakReference<StackPayload> {
        var obj: StackPayload? = null
        var weak: WeakReference<StackPayload>? = null

        while (true) {
            obj = StackPayload(2030)
            weak = WeakReference(obj!!)
            obj = null
            break
        }

        assertEquals(null, obj)
        return weak!!
    }

    /**
     * PS-B03
     * Scenario: a loop exits after clearing its local root.
     * Expectation: break edge root map does not retain the cleared object.
     */
    @Test
    fun psB03_breakAfterClearDropsStackRoot() {
        val weak = createWeakAfterBreak()

        assertWeakCollected(weak)
    }

    private fun createWeakAfterFinallyClear(): WeakReference<StackPayload> {
        var obj: StackPayload? = StackPayload(2040)
        val weak = WeakReference(obj!!)

        try {
            assertEquals(2040, obj!!.id)
        } finally {
            obj = null
        }

        assertEquals(null, obj)
        return weak
    }

    /**
     * PS-B04
     * Scenario: finally clears a local root before the caller performs GC.
     * Expectation: exceptional-control-flow root map does not retain the cleared object.
     */
    @Test
    fun psB04_finallyClearDropsStackRoot() {
        val weak = createWeakAfterFinallyClear()

        assertWeakCollected(weak)
    }

    private fun createWeakAfterCatchClear(): WeakReference<StackPayload> {
        var obj: StackPayload? = StackPayload(2050)
        val weak = WeakReference(obj!!)

        try {
            error("force catch path")
        } catch (_: Throwable) {
            obj = null
        }

        assertEquals(null, obj)
        return weak
    }

    /**
     * PS-B05
     * Scenario: catch path clears a local root before GC.
     * Expectation: exception edge root map does not retain the cleared object.
     */
    @Test
    fun psB05_catchClearDropsStackRoot() {
        val weak = createWeakAfterCatchClear()

        assertWeakCollected(weak)
    }
}
