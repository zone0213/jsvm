@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-I group: weak references in simple cycle-like relations.
 */
class WeakCycleRelationTest : WeakReferenceTestSupport() {

    /**
     * WR-I01
     * Scenario: root -> parent, parent strongly points to child, and child weakly points to parent.
     * Expectation: parent and child survive because of root -> parent -> child strong path.
     */
    @Test
    fun wrI01_oneStrongOneWeakCycleRootParentKeepsBothAlive() {
        val parent = Payload(901)
        val child = Payload(902)
        parent.strong = child
        child.weak = WeakReference(parent)
        val root = Root(parent)
        val weakParent = child.weak!!
        val weakChild = WeakReference(child)

        forceGc()

        assertEquals(901, root.ref!!.id)
        assertEquals(902, root.ref!!.strong!!.id)
        assertNotNull(weakParent.value)
        assertNotNull(weakChild.value)
    }

    private fun createRootChildWithChildWeakParent(): WeakOnlyResult<Root<Payload>, Payload> {
        val parent = Payload(903)
        val child = Payload(904)
        child.weak = WeakReference(parent)
        return WeakOnlyResult(Root(child), child.weak!!)
    }

    /**
     * WR-I02
     * Scenario: root -> child, and child weakly points to parent.
     * Expectation: child survives, but parent is not kept alive by weak edge.
     */
    @Test
    fun wrI02_oneStrongOneWeakCycleRootChildDoesNotKeepParentAlive() {
        val scenario = createRootChildWithChildWeakParent()

        forceGc()

        assertEquals(904, scenario.root.ref!!.id)
        assertNull(scenario.weak.value)
    }

    private fun createOneStrongOneWeakNoRoot(): List<WeakReference<Payload>> {
        val parent = Payload(905)
        val child = Payload(906)
        parent.strong = child
        child.weak = WeakReference(parent)
        return listOf(WeakReference(parent), WeakReference(child))
    }

    /**
     * WR-I03
     * Scenario: parent strongly points to child and child weakly points to parent, with no root.
     * Expectation: both objects can be collected.
     */
    @Test
    fun wrI03_oneStrongOneWeakCycleWithoutRootCanBeCollected() {
        val weaks = createOneStrongOneWeakNoRoot()

        assertAllWeakCollected(weaks)
    }

    private fun createTwoWeakMutualNoRoot(): List<WeakReference<Payload>> {
        val a = Payload(907)
        val b = Payload(908)
        a.weak = WeakReference(b)
        b.weak = WeakReference(a)
        return listOf(WeakReference(a), WeakReference(b))
    }

    /**
     * WR-I04
     * Scenario: two objects weakly point to each other with no root.
     * Expectation: both objects can be collected.
     */
    @Test
    fun wrI04_twoWeakMutualReferencesWithoutRootCanBeCollected() {
        val weaks = createTwoWeakMutualNoRoot()

        assertAllWeakCollected(weaks)
    }

    private fun createRootAWithTwoWeakMutual(): MixedWeakResult<Root<Payload>, Payload> {
        val a = Payload(909)
        val b = Payload(910)
        a.weak = WeakReference(b)
        b.weak = WeakReference(a)

        return MixedWeakResult(
            root = Root(a),
            aliveWeaks = listOf(WeakReference(a), b.weak!!),
            collectedWeaks = listOf(a.weak!!, WeakReference(b))
        )
    }

    /**
     * WR-I05
     * Scenario: a and b weakly point to each other, and root points only to a.
     * Expectation: a survives through root; b can be collected.
     */
    @Test
    fun wrI05_twoWeakMutualReferencesWithRootACollectsBOnly() {
        val scenario = createRootAWithTwoWeakMutual()

        forceGc()

        assertEquals(909, scenario.root.ref!!.id)
        assertAllWeakAlive(scenario.aliveWeaks)
        assertAllWeakCollected(scenario.collectedWeaks)
    }

    /**
     * WR-I06
     * Scenario: two objects strongly point to each other and root points to a.
     * Expectation: both objects survive.
     */
    @Test
    fun wrI06_twoStrongMutualReferencesWithRootKeepBothAlive() {
        val a = Payload(911)
        val b = Payload(912)
        a.strong = b
        b.strong = a
        val root = Root(a)
        val weakA = WeakReference(a)
        val weakB = WeakReference(b)

        forceGc()

        assertEquals(911, root.ref!!.id)
        assertEquals(912, root.ref!!.strong!!.id)
        assertNotNull(weakA.value)
        assertNotNull(weakB.value)
    }

    private fun createTwoStrongMutualNoRoot(): List<WeakReference<Payload>> {
        val a = Payload(913)
        val b = Payload(914)
        a.strong = b
        b.strong = a
        return listOf(WeakReference(a), WeakReference(b))
    }

    /**
     * WR-I07
     * Scenario: two objects strongly point to each other, but no root points to the cycle.
     * Expectation: tracing GC can collect the strong cycle.
     */
    @Test
    fun wrI07_twoStrongMutualReferencesWithoutRootCanBeCollected() {
        val weaks = createTwoStrongMutualNoRoot()

        assertAllWeakCollected(weaks)
    }

    /**
     * WR-I08
     * Scenario: weak observers point to a reachable strong cycle.
     * Expectation: observers remain non-null while root keeps the cycle alive.
     */
    @Test
    fun wrI08_weakObserversToReachableStrongCycleRemainNonNull() {
        val a = Payload(915)
        val b = Payload(916)
        a.strong = b
        b.strong = a
        val root = Root(a)
        val weakA = WeakReference(a)
        val weakB = WeakReference(b)

        forceGc()

        assertEquals(915, root.ref!!.id)
        assertNotNull(weakA.value)
        assertNotNull(weakB.value)
    }

    private fun createStrongCycleAfterRootClear(): List<WeakReference<Payload>> {
        val a = Payload(917)
        val b = Payload(918)
        a.strong = b
        b.strong = a
        val root = Root(a)
        val weakA = WeakReference(a)
        val weakB = WeakReference(b)

        root.ref = null

        return listOf(weakA, weakB)
    }

    /**
     * WR-I09
     * Scenario: root to a strong cycle is cleared.
     * Expectation: weak observers are cleared after the cycle becomes unreachable.
     */
    @Test
    fun wrI09_clearingRootToStrongCycleClearsWeakObservers() {
        val weaks = createStrongCycleAfterRootClear()

        assertAllWeakCollected(weaks)
    }

    private fun createWeakToStrongCycleEntryNoRoot(): List<WeakReference<Payload>> {
        val a = Payload(919)
        val b = Payload(920)
        a.strong = b
        b.strong = a
        return listOf(WeakReference(a), WeakReference(b))
    }

    /**
     * WR-I10
     * Scenario: weak observers point to an unreachable strong cycle.
     * Expectation: the cycle is collected and observers clear.
     */
    @Test
    fun wrI10_weakToUnreachableStrongCycleEntryClears() {
        val weaks = createWeakToStrongCycleEntryNoRoot()

        assertAllWeakCollected(weaks)
    }

    /**
     * WR-I11
     * Scenario: root points to a strong cycle entry, and weak observes an internal node.
     * Expectation: internal node survives and weak.value remains non-null.
     */
    @Test
    fun wrI11_weakToInternalNodeOfReachableStrongCycleRemainsAlive() {
        val a = Payload(921)
        val b = Payload(922)
        a.strong = b
        b.strong = a
        val root = Root(a)
        val weakB = WeakReference(b)

        forceGc()

        assertEquals(921, root.ref!!.id)
        assertEquals(922, root.ref!!.strong!!.id)
        assertNotNull(weakB.value)
    }

    private fun createWeakEdgeBreaksOnlyPathToSubgraph(): MixedWeakResult<Root<Payload>, Payload> {
        val a = Payload(923)
        val b = Payload(924)
        val c = Payload(925)
        a.weak = WeakReference(b)
        b.strong = c

        return MixedWeakResult(
            root = Root(a),
            aliveWeaks = listOf(WeakReference(a)),
            collectedWeaks = listOf(a.weak!!, WeakReference(b), WeakReference(c))
        )
    }

    /**
     * WR-I12
     * Scenario: root -> a, a weakly points to b, and b strongly points to c.
     * Expectation: weak edge from a does not keep b or c alive.
     */
    @Test
    fun wrI12_weakEdgeBreaksOnlyPathToSubgraph() {
        val scenario = createWeakEdgeBreaksOnlyPathToSubgraph()

        forceGc()

        assertEquals(923, scenario.root.ref!!.id)
        assertAllWeakAlive(scenario.aliveWeaks)
        assertAllWeakCollected(scenario.collectedWeaks)
    }
}
