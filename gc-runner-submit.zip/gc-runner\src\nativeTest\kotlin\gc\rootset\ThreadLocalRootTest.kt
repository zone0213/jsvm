@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class,
)

package gc.rootset

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * RS-E group: ThreadLocal root tests.
 */
class ThreadLocalRootTest : RootSetTestSupport() {
    /**
     * RS-E01
     * Scenario: main thread ThreadLocal var references payload.
     * Expectation: payload remains alive in current thread.
     */
    @Test
    fun rsE01_mainThreadThreadLocalKeepsPayloadAlive() {
        val obj = RootPayload(5001)
        threadLocalPayload = obj
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(5001, threadLocalPayload!!.id)
        assertNotNull(weak.value)
    }

    private fun clearMainThreadThreadLocal(): WeakReference<RootPayload> {
        val obj = RootPayload(5002)
        threadLocalPayload = obj
        val weak = WeakReference(obj)
        threadLocalPayload = null
        return weak
    }

/**
     * RS-E02
     * Scenario: main thread ThreadLocal root is cleared.
     * Expectation: payload can be collected.
     */
    @Test
    fun rsE02_mainThreadThreadLocalClearAllowsCollection() {
        val weak = clearMainThreadThreadLocal()
        assertWeakCollected(weak)
    }

    private fun reassignMainThreadThreadLocal(): ReplacementRoot<RootPayload, RootPayload> {
        threadLocalPayload = RootPayload(5003)
        val oldWeak = WeakReference(threadLocalPayload!!)
        threadLocalPayload = RootPayload(50030)
        val newWeak = WeakReference(threadLocalPayload!!)
        return ReplacementRoot(threadLocalPayload!!, oldWeak, newWeak)
    }

/**
     * RS-E03
     * Scenario: main thread ThreadLocal root is reassigned.
     * Expectation: old payload can be collected and new payload remains alive.
     */
    @Test
    fun rsE03_mainThreadThreadLocalReassignmentCollectsOldKeepsNew() {
        val scenario = reassignMainThreadThreadLocal()
        forceGc()
        assertNull(scenario.oldWeak.value)
        assertNotNull(scenario.newWeak.value)
        assertEquals(50030, scenario.root.id)
    }

/**
     * RS-E04
     * Scenario: ThreadLocal holder references payload.
     * Expectation: payload remains alive through ThreadLocal holder.
     */
    @Test
    fun rsE04_threadLocalHolderRootKeepsValueAlive() {
        val obj = RootPayload(5004)
        threadLocalHolder = RootHolder(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(5004, threadLocalHolder!!.ref!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-E05
     * Scenario: ThreadLocal payload references a child.
     * Expectation: parent and child remain alive.
     */
    @Test
    fun rsE05_threadLocalChildGraphRootKeepsChildAlive() {
        val child = RootPayload(50051)
        val obj = RootPayload(5005, child)
        threadLocalPayload = obj
        val childWeak = WeakReference(child)
        forceGc()
        assertEquals(5005, threadLocalPayload!!.id)
        assertNotNull(childWeak.value)
    }

/**
     * RS-E06
     * Scenario: ThreadLocal list contains payload.
     * Expectation: payload remains alive through ThreadLocal list.
     */
    @Test
    fun rsE06_threadLocalListRootKeepsElementAlive() {
        val obj = RootPayload(5006)
        threadLocalList = mutableListOf(obj)
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(5006, threadLocalList!!.single().id)
        assertNotNull(weak.value)
    }

/**
     * RS-E07
     * Scenario: worker thread sets ThreadLocal payload.
     * Expectation: worker observes the payload alive after GC in that thread.
     */
    @Test
    fun rsE07_workerThreadLocalKeepsPayloadAlive() {
        val result =
            runWorkerBoolean {
                threadLocalPayload = RootPayload(5007)
                val weak = WeakReference(threadLocalPayload!!)
                GC.collect()
                threadLocalPayload!!.id == 5007 && weak.value != null
            }
        assertTrue(result)
    }

/**
     * RS-E08
     * Scenario: main thread and worker thread set different ThreadLocal values.
     * Expectation: worker value does not overwrite main thread value.
     */
    @Test
    fun rsE08_threadLocalValuesAreIsolatedBetweenMainAndWorker() {
        threadLocalPayload = RootPayload(5008)
        val result =
            runWorkerBoolean {
                threadLocalPayload = RootPayload(50080)
                GC.collect()
                threadLocalPayload!!.id == 50080
            }
        forceGc()
        assertTrue(result)
        assertEquals(5008, threadLocalPayload!!.id)
    }

/**
     * RS-E09
     * Scenario: worker thread clears its ThreadLocal payload.
     * Expectation: worker observes that the target can be collected after clear.
     */
    @Test
    fun rsE09_workerThreadLocalClearAllowsCollection() {
        val result =
            runWorkerBoolean {
                val obj = RootPayload(5009)
                threadLocalPayload = obj
                val weak = WeakReference(obj)
                threadLocalPayload = null
                GC.collect()
                weak.value == null
            }
        assertTrue(result)
    }

/**
     * RS-E10
     * Scenario: main thread clears its ThreadLocal while worker uses its own ThreadLocal.
     * Expectation: worker ThreadLocal value remains independent.
     */
    @Test
    fun rsE10_clearingMainThreadLocalDoesNotAffectWorkerThreadLocal() {
        threadLocalPayload = RootPayload(5010)
        threadLocalPayload = null
        val result =
            runWorkerBoolean {
                threadLocalPayload = RootPayload(50100)
                val weak = WeakReference(threadLocalPayload!!)
                GC.collect()
                threadLocalPayload!!.id == 50100 && weak.value != null
            }
        assertTrue(result)
        assertNull(threadLocalPayload)
    }

/**
     * RS-E11
     * Scenario: multiple worker tasks each set their own ThreadLocal payload.
     * Expectation: each worker observes its own payload alive.
     */
    @Test
    fun rsE11_multipleWorkersEachHaveThreadLocalRoots() {
        val results =
            List(3) { index ->
                runWorkerBoolean {
                    threadLocalPayload = RootPayload(50110 + index)
                    val weak = WeakReference(threadLocalPayload!!)
                    GC.collect()
                    weak.value != null && threadLocalPayload!!.id == 50110 + index
                }
            }
        assertTrue(results.all { it })
    }

/**
     * RS-E12
     * Scenario: worker creates a ThreadLocal payload and exits.
     * Expectation: after worker completes, the test only verifies task completion as the ThreadLocal root is thread-scoped.
     */
    @Test
    fun rsE12_workerThreadExitRemovesThreadLocalRoot() {
        val result =
            runWorkerBoolean {
                threadLocalPayload = RootPayload(5012)
                GC.collect()
                threadLocalPayload!!.id == 5012
            }
        assertTrue(result)
        forceGc()
    }

/**
     * RS-E13
     * Scenario: ThreadLocal nullable variable holds non-null payload.
     * Expectation: payload remains alive.
     */
    @Test
    fun rsE13_threadLocalNullableNonNullKeepsPayloadAlive() {
        val obj: RootPayload? = RootPayload(5013)
        threadLocalPayload = obj
        val weak = WeakReference(obj!!)
        forceGc()
        assertEquals(5013, threadLocalPayload!!.id)
        assertNotNull(weak.value)
    }

/**
     * RS-E14
     * Scenario: ThreadLocal Any and interface variables reference payloads.
     * Expectation: runtime objects remain alive through ThreadLocal roots.
     */
    @Test
    fun rsE14_threadLocalAnyAndInterfaceRootsKeepRuntimeObjectsAlive() {
        val anyObj: Any = RootPayload(5014)
        val markerObj: RootMarker = RootPayload(50140)
        threadLocalAny = anyObj
        threadLocalMarker = markerObj
        val anyWeak = WeakReference(anyObj)
        val markerWeak = WeakReference(markerObj)
        forceGc()
        assertEquals(5014, (threadLocalAny as RootPayload).id)
        assertEquals(50140, threadLocalMarker!!.id)
        assertNotNull(anyWeak.value)
        assertNotNull(markerWeak.value)
    }
}
