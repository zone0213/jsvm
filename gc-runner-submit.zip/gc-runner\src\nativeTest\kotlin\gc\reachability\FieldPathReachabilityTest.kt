@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * D group: reachability through object fields and field paths.
 */
class FieldPathReachabilityTest : ReachabilityTestSupport() {

    private fun createPayloadHolderRoot(): RootedWeak<PayloadHolder, Payload> {
        val child = Payload(301)
        val holder = PayloadHolder(child)

        return RootedWeak(
            root = holder,
            weak = WeakReference(child)
        )
    }

    /**
     * RC-D01
     * Scenario: a root object has a direct field pointing to Payload.
     * Expectation: the field target remains reachable through the root object.
     */
    @Test
    fun rcD01_rootObjectFieldKeepsChildAlive() {
        val scenario = createPayloadHolderRoot()

        forceGc()

        assertEquals(301, scenario.root.ref!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createClearedPayloadHolderRoot(): RootedWeak<PayloadHolder, Payload> {
        val child = Payload(302)
        val holder = PayloadHolder(child)
        val weak = WeakReference(child)

        holder.ref = null

        return RootedWeak(
            root = holder,
            weak = weak
        )
    }

    /**
     * RC-D02
     * Scenario: a root object's direct field is cleared.
     * Expectation: after the helper stack frame returns, the former field target can be collected.
     */
    @Test
    fun rcD02_clearingRootObjectFieldAllowsChildCollection() {
        val scenario = createClearedPayloadHolderRoot()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root.ref)
    }

    private fun createTwoLevelFieldPathRoot(): RootedWeak<TwoLevelHolder, Payload> {
        val leaf = Payload(303)
        val mid = PayloadHolder(leaf)
        val root = TwoLevelHolder(mid)

        return RootedWeak(
            root = root,
            weak = WeakReference(leaf)
        )
    }

    /**
     * RC-D03
     * Scenario: a root object reaches Payload through a two-level field path.
     * Expectation: the leaf object remains reachable through root.child.ref.
     */
    @Test
    fun rcD03_twoLevelFieldPathKeepsLeafAlive() {
        val scenario = createTwoLevelFieldPathRoot()

        forceGc()

        assertEquals(303, scenario.root.child!!.ref!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createMiddleFieldDisconnectedResult(): TwoLevelDisconnectResult {
        val leaf = Payload(304)
        val mid = PayloadHolder(leaf)
        val root = TwoLevelHolder(mid)
        val midWeak = WeakReference(mid)
        val leafWeak = WeakReference(leaf)

        root.child = null

        return TwoLevelDisconnectResult(
            root = root,
            midWeak = midWeak,
            leafWeak = leafWeak
        )
    }

    /**
     * RC-D04
     * Scenario: the middle field in a two-level path is disconnected.
     * Expectation: both the middle holder and the leaf can be collected.
     */
    @Test
    fun rcD04_disconnectingMiddleFieldAllowsSubgraphCollection() {
        val result = createMiddleFieldDisconnectedResult()

        forceGc()

        assertNull(result.root.child)
        assertNull(result.midWeak.value)
        assertNull(result.leafWeak.value)
    }

    private fun createLeafFieldDisconnectedResult(): RootedWeak<TwoLevelHolder, Payload> {
        val leaf = Payload(305)
        val mid = PayloadHolder(leaf)
        val root = TwoLevelHolder(mid)
        val leafWeak = WeakReference(leaf)

        mid.ref = null

        return RootedWeak(
            root = root,
            weak = leafWeak
        )
    }

    /**
     * RC-D05
     * Scenario: the leaf field in a two-level path is cleared while the middle holder remains reachable.
     * Expectation: the leaf can be collected, but the middle holder remains reachable through the root.
     */
    @Test
    fun rcD05_clearingLeafFieldAllowsLeafCollectionButKeepsMiddleAlive() {
        val scenario = createLeafFieldDisconnectedResult()

        assertWeakCollected(scenario.weak)
        assertNotNull(scenario.root.child)
        assertNull(scenario.root.child!!.ref)
    }

    private fun createAnyFieldRoot(): RootedWeak<AnyHolder, Any> {
        val obj: Any = Payload(306)
        val holder = AnyHolder(obj)

        return RootedWeak(
            root = holder,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-D06
     * Scenario: a field has static type Any? and runtime type Payload.
     * Expectation: the runtime object remains reachable through the Any?-typed field.
     */
    @Test
    fun rcD06_anyTypedFieldKeepsRuntimeObjectAlive() {
        val scenario = createAnyFieldRoot()

        forceGc()

        assertEquals(306, (scenario.root.ref as Payload).id)
        assertNotNull(scenario.weak.value)
    }

    private fun createInterfaceFieldRoot(): RootedWeak<InterfaceHolder, Marker> {
        val obj: Marker = Payload(307)
        val holder = InterfaceHolder(obj)

        return RootedWeak(
            root = holder,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-D07
     * Scenario: a field has static type Marker? and runtime type Payload.
     * Expectation: the runtime object remains reachable through the interface-typed field.
     */
    @Test
    fun rcD07_interfaceTypedFieldKeepsRuntimeObjectAlive() {
        val scenario = createInterfaceFieldRoot()

        forceGc()

        assertEquals(307, scenario.root.ref!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createNullableFieldRoot(): RootedWeak<PayloadHolder, Payload> {
        val obj = Payload(308)
        val holder = PayloadHolder(obj)

        return RootedWeak(
            root = holder,
            weak = WeakReference(obj)
        )
    }

    /**
     * RC-D08
     * Scenario: a nullable Payload? field holds a non-null Payload.
     * Expectation: the object remains reachable through the nullable field.
     */
    @Test
    fun rcD08_nullableFieldNonNullReferenceKeepsObjectAlive() {
        val scenario = createNullableFieldRoot()

        forceGc()

        assertEquals(308, scenario.root.ref!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createFieldReplacementResult(): HolderReplacementResult<PayloadHolder, Payload> {
        val oldObj = Payload(309)
        val holder = PayloadHolder(oldObj)
        val oldWeak = WeakReference(oldObj)

        val newObj = Payload(390)
        holder.ref = newObj
        val newWeak = WeakReference(newObj)

        return HolderReplacementResult(
            holder = holder,
            oldWeak = oldWeak,
            newWeak = newWeak
        )
    }

    /**
     * RC-D09
     * Scenario: a root object's field is reassigned from an old object to a new object.
     * Expectation: the old object can be collected, while the new field target remains reachable.
     */
    @Test
    fun rcD09_fieldReassignmentReleasesOldObjectAndKeepsNewObjectAlive() {
        val result = createFieldReplacementResult()

        forceGc()

        assertNull(result.oldWeak.value)
        assertNotNull(result.newWeak.value)
        assertEquals(390, result.holder.ref!!.id)
    }
}
