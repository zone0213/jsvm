
package gc.exceptionalboundary

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

open class ExceptionalBoundaryTestSupport {
    protected fun forceGc() {
        repeat(3) { GC.collect() }
    }

    protected fun weakCheck(obj: Any?): WeakReference<Any>? {
        return obj?.let { WeakReference(it) }
    }
}
