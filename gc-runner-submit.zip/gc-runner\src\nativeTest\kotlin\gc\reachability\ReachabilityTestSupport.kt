@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.reachability

import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * Common test infrastructure for Kotlin/Native GC basic reachability tests.
 *
 * Scope:
 * - Only validates basic strong-reference reachability.
 * - WeakReference is used as an observation mechanism, not as the feature under test.
 * - Complex graphs, cycles, weak-reference semantics, concurrency and interop are intentionally excluded.
 */
open class ReachabilityTestSupport {

    @BeforeTest
    fun resetBeforeTest() {
        clearGlobalRoots()
    }

    @AfterTest
    fun resetAfterTest() {
        clearGlobalRoots()
        forceGc()
    }

    protected fun forceGc() {
        repeat(GC_REPEAT_COUNT) {
            GC.collect()
        }
    }

    protected fun clearGlobalRoots() {
        globalPayload = null
        globalAny = null
        globalMarker = null
        GlobalHolder.ref = null
        CompanionRootHolder.ref = null
    }

    protected fun <T : Any> assertWeakAlive(
        weak: WeakReference<T>,
        message: String = "Expected object to remain reachable, but WeakReference was cleared."
    ): T {
        forceGc()
        val value = weak.value
        assertNotNull(value, message)
        return value
    }

    protected fun <T : Any> assertWeakCollected(
        weak: WeakReference<T>,
        message: String = "Expected object to become unreachable and be collected."
    ) {
        forceGc()
        assertNull(weak.value, message)
    }

    companion object {
        private const val GC_REPEAT_COUNT = 3
    }
}

/**
 * Common marker interface used to verify reachability through interface-typed references.
 */
interface Marker {
    val id: Int
}

/**
 * Common base class used to verify reachability through base-class-typed references.
 */
open class BasePayload(open val id: Int)

/**
 * Main test payload type.
 */
class Payload(
    override val id: Int,
    var child: Payload? = null
) : BasePayload(id), Marker {
    override fun toString(): String = "Payload(id=$id)"
}

/**
 * Subclass payload used for parent-class root tests.
 */
class ChildPayload(
    override val id: Int
) : BasePayload(id), Marker

/**
 * Data class payload used to make sure data-class instances are also scanned normally.
 */
data class DataPayload(
    override val id: Int
) : Marker

class PayloadHolder(var ref: Payload?)
class AnyHolder(var ref: Any?)
class InterfaceHolder(var ref: Marker?)
class BaseHolder(var ref: BasePayload?)
class TwoLevelHolder(var child: PayloadHolder?)
class Box<T : Any>(var value: T?)
class LambdaHolder(var block: (() -> Int)?)

data class RootedWeak<R : Any, T : Any>(
    val root: R,
    val weak: WeakReference<T>
)

data class ReplacementResult<T : Any>(
    val liveObject: T,
    val oldWeak: WeakReference<T>,
    val newWeak: WeakReference<T>
)

data class HolderReplacementResult<H : Any, T : Any>(
    val holder: H,
    val oldWeak: WeakReference<T>,
    val newWeak: WeakReference<T>
)

data class TwoLevelDisconnectResult(
    val root: TwoLevelHolder,
    val midWeak: WeakReference<PayloadHolder>,
    val leafWeak: WeakReference<Payload>
)

data class LoopReplacementResult(
    val liveObject: Payload,
    val oldWeaks: List<WeakReference<Payload>>,
    val liveWeak: WeakReference<Payload>
)

var globalPayload: Payload? = null
var globalAny: Any? = null
var globalMarker: Marker? = null

object GlobalHolder {
    var ref: Payload? = null
}

class CompanionRootHolder {
    companion object {
        var ref: Payload? = null
    }
}
