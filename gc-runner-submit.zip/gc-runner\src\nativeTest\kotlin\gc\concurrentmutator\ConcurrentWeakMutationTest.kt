@file:OptIn(
    kotlin.native.runtime.NativeRuntimeApi::class,
    kotlin.native.concurrent.ObsoleteWorkersApi::class
)

package gc.concurrentmutator

import kotlin.native.concurrent.TransferMode
import kotlin.native.concurrent.Worker
import kotlin.native.ref.WeakReference
import kotlin.native.runtime.GC
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * CG-I group: WeakReference interaction with concurrent strong-reference mutation.
 */
class ConcurrentWeakMutationTest : ConcurrentGcTestSupport() {

    /**
     * CG-I01
     * Scenario: strong edge is added while weak observes object.
     * Expectation: weak remains non-null.
     */
    @Test
    fun cgI01_addStrongDuringGcWeakNotCleared() {
        val holder=Holder<Node>(null)
        val node=Node(1101)
        val weak=WeakReference(node)
        runGcAroundMutation{ holder.ref=node }
        assertEquals(1101,holder.ref!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-I02
     * Scenario: strong edge is deleted while weak observes object.
     * Expectation: weak eventually clears.
     */
    @Test
    fun cgI02_deleteStrongDuringGcWeakEventuallyCleared() {
        val holder=Holder(Node(1102))
        val weak=WeakReference(holder.ref!!)
        runGcAroundMutation{ holder.ref=null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-I03
     * Scenario: strong edge is replaced while weak observers watch old and new.
     * Expectation: old clears and new survives.
     */
    @Test
    fun cgI03_replaceStrongDuringGcOldWeakClearedNewAlive() {
        val r = replaceField(1103, 1104)
        assertWeakCollectedEventually(r.oldWeak)
        assertWeakAlive(r.newWeak)
        assertNotNull(r.root.ref)
    }

    /**
     * CG-I04
     * Scenario: weak.value is promoted to strong holder field.
     * Expectation: object remains alive.
     */
    @Test
    fun cgI04_weakValuePromotionDuringGc() {
        val node = Node(1105)
        val weak = WeakReference(node)
        val holder = Holder<Node>(null)
        forceGc()
        holder.ref = node
        forceGc()
        assertEquals(1105, holder.ref!!.id)
        assertNotNull(weak.value)
        assertNotNull(holder.ref)
    }

    /**
     * CG-I05
     * Scenario: promoted strong is cleared.
     * Expectation: weak eventually clears.
     */
    @Test
    fun cgI05_clearPromotedStrongDuringGc() {
        val node=Node(1106)
        val weak=WeakReference(node)
        val holder=Holder<Node>(weak.value)
        runGcAroundMutation{ holder.ref=null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-I06
     * Scenario: many weak observers see object after strong edge is added.
     * Expectation: all weak remain non-null.
     */
    @Test
    fun cgI06_manyWeaksAddStrongDuringGc() {
        val node = Node(1107)
        val weaks = List(16) { WeakReference(node) }
        val holder = Holder<Node>(null)
        forceGc()
        holder.ref = node
        forceGc()
        weaks.forEachIndexed { i, w -> assertNotNull(w.value, "Expected weak[$i] to remain alive.") }
        assertNotNull(holder.ref)
    }

    /**
     * CG-I07
     * Scenario: many weak observers clear after strong edge is deleted.
     * Expectation: all weak clear.
     */
    @Test
    fun cgI07_manyWeaksDeleteStrongDuringGc() {
        val holder=Holder(Node(1108))
        val weaks=List(16){WeakReference(holder.ref!!)}
        runGcAroundMutation{ holder.ref=null }
        assertAllWeakCollectedEventually(weaks)
    }

    /**
     * CG-I08
     * Scenario: strong list add keeps weak target alive.
     * Expectation: weak remains non-null.
     */
    @Test
    fun cgI08_weakObserversWithStrongListAdd() {
        val node=Node(1109)
        val weak=WeakReference(node)
        val list=mutableListOf<Node>()
        runGcAroundMutation{ list.add(node) }
        assertEquals(1109,list[0].id)
        assertNotNull(weak.value)
    }

    /**
     * CG-I09
     * Scenario: strong list remove releases weak target.
     * Expectation: weak eventually clears.
     */
    @Test
    fun cgI09_weakObserversWithStrongListRemove() {
        val node=Node(1110)
        val weak=WeakReference(node)
        val list=mutableListOf(node)
        runGcAroundMutation{ list.remove(node) }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-I10
     * Scenario: one strong edge to shared target is removed.
     * Expectation: weak remains non-null through remaining edge.
     */
    @Test
    fun cgI10_weakSharedSubgraphDisconnectOneStrongEdge() {
        val g=buildSharedGraph(1111)
        val weak=WeakReference(g.shared)
        runGcAroundMutation{ g.parent1.left=null }
        assertEquals(1113,g.parent2.left!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-I11
     * Scenario: all strong edges to shared target are removed.
     * Expectation: weak clears.
     */
    @Test
    fun cgI11_weakSharedSubgraphDisconnectAllStrongEdges() {
        val g=buildSharedGraph(1114)
        val weak=WeakReference(g.shared)
        runGcAroundMutation{ g.parent1.left=null
        g.parent2.left=null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-I12
     * Scenario: cycle observed by weak is attached to root.
     * Expectation: weak remains non-null.
     */
    @Test
    fun cgI12_weakCycleAttachRootDuringGc() {
        val cycle=buildCycle(1120)
        val weak=WeakReference(cycle.first())
        val holder=Holder<Node>(null)
        runGcAroundMutation{ holder.ref=cycle.first() }
        assertEquals(1120,holder.ref!!.id)
        assertNotNull(weak.value)
    }

    /**
     * CG-I13
     * Scenario: cycle root is detached.
     * Expectation: weak clears eventually.
     */
    @Test
    fun cgI13_weakCycleDetachRootDuringGc() {
        val cycle=buildCycle(1130)
        val holder=Holder(cycle.first())
        val weak=WeakReference(cycle.first())
        runGcAroundMutation{ holder.ref=null }
        assertWeakCollectedEventually(weak)
    }

    /**
     * CG-I14
     * Scenario: many weak observers and writer mutations run under GC pressure.
     * Expectation: final weak state is correct.
     */
    @Test
    fun cgI14_weakProcessingPressureWithWriter() {
        val holder=Holder(Node(1140))
        val weaks=List(32){WeakReference(holder.ref!!)}
        repeatMutationWithGc(32){ if(it%2==0) holder.ref=Node(1140+it) }
        assertNotNull(holder.ref)
        forceGc()
        assertTrue(weaks.all { it.value == null || it.value!!.id >= 1140 })
    }

}
