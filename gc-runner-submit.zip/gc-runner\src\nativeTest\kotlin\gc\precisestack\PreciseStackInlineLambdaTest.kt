@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.precisestack

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * PS-C group: inline, lambda and local-function stack root maps.
 */
class PreciseStackInlineLambdaTest : PreciseStackTestSupport() {
    private inline fun inlineGcCheck(obj: StackPayload): WeakReference<StackPayload> {
        val weak = WeakReference(obj)
        forceGc()
        assertEquals(obj.id, weak.value!!.id)
        return weak
    }

    /**
     * PS-C01
     * Scenario: inline function parameter is live across GC inside the inlined body.
     * Expectation: precise stack scanning keeps the inlined parameter live.
     */
    @Test
    fun psC01_inlineParameterKeepsObjectAlive() {
        val obj = StackPayload(3001)
        val weak = inlineGcCheck(obj)

        assertEquals(3001, assertWeakAlive(weak).id)
        assertEquals(3001, obj.id)
    }

    /**
     * PS-C02
     * Scenario: non-inline lambda captures a payload and runs GC while the lambda is live.
     * Expectation: captured reference is present in the lambda object and remains live.
     */
    @Test
    fun psC02_liveLambdaCaptureKeepsObjectAlive() {
        val obj = StackPayload(3002)
        val weak = WeakReference(obj)
        val block = { obj.id }

        assertEquals(3002, block())
        forceGc()
        assertEquals(3002, block())
        assertEquals(3002, weak.value!!.id)
    }

    private fun createWeakAfterLambdaCleared(): WeakReference<StackPayload> {
        var obj: StackPayload? = StackPayload(3003)
        val weak = WeakReference(obj!!)
        var block: (() -> Int)? = { obj!!.id }

        assertEquals(3003, block!!())
        block = null
        obj = null

        assertEquals(null, block)
        assertEquals(null, obj)
        return weak
    }

    /**
     * PS-C03
     * Scenario: lambda capture and local root are both cleared before GC.
     * Expectation: neither lambda slot nor local slot retains the old object.
     */
    @Test
    fun psC03_clearedLambdaCaptureDoesNotRetainObject() {
        val weak = createWeakAfterLambdaCleared()

        assertWeakCollected(weak)
    }

    private fun localFunctionGcCheck(obj: StackPayload): WeakReference<StackPayload> {
        fun nested(value: StackPayload): WeakReference<StackPayload> {
            val weak = WeakReference(value)
            forceGc()
            assertEquals(value.id, weak.value!!.id)
            return weak
        }

        return nested(obj)
    }

    /**
     * PS-C04
     * Scenario: local function parameter is live across GC.
     * Expectation: nested function frame root map keeps the parameter live.
     */
    @Test
    fun psC04_localFunctionParameterKeepsObjectAlive() {
        val obj = StackPayload(3004)
        val weak = localFunctionGcCheck(obj)

        assertEquals(3004, assertWeakAlive(weak).id)
        assertEquals(3004, obj.id)
    }

    /**
     * PS-C05
     * Scenario: lambda body creates a temporary, stores only WeakReference, then clears local root.
     * Expectation: lambda frame does not retain dead temporary after the body returns.
     */
    @Test
    fun psC05_lambdaTemporaryClearedAfterInvocationIsCollected() {
        val createWeak = {
            var obj: StackPayload? = StackPayload(3005)
            val weak = WeakReference(obj!!)
            obj = null
            assertEquals(null, obj)
            weak
        }

        val weak = createWeak()

        assertWeakCollected(weak)
    }
}
