@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * LS-A group: monitoring framework and metric baseline tests.
 */
class LongStabilityMonitorTest : LongStabilityTestSupport() {

    /**
     * LS-A01
     * Scenario: GCInfo collection baseline.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a01_gcinfoCollectionBaseline() {
        assertGcInfoReadable()
    }

    /**
     * LS-A02
     * Scenario: heapAfter sampling baseline.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a02_heapafterSamplingBaseline() {
        val samples = List(5) { heapAfterBytes() }
        assertTrue(samples.all { it >= 0 })
    }

    /**
     * LS-A03
     * Scenario: sweepStatistics sampling baseline.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a03_sweepstatisticsSamplingBaseline() {
        repeat(5) {
            assertGcInfoReadable()
        }
    }

    /**
     * LS-A04
     * Scenario: workload progress counter.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a04_workloadProgressCounter() {
        var iteration = 0
        repeat(64) { iteration++ }
        assertTrue(iteration == 64)
    }

    /**
     * LS-A05
     * Scenario: latency sampling.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a05_latencySampling() {
        val samples = mutableListOf<Long>()
        repeat(8) {
            val before = heapAfterBytes()
            forceGc()
            val after = heapAfterBytes()
            samples.add(kotlin.math.abs(after - before))
        }
        assertTrue(samples.all { it >= 0 })
    }

    /**
     * LS-A06
     * Scenario: warmup excluded trend.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a06_warmupExcludedTrend() {
        shortLivedSamples(4) { LsNode(it) }
        assertNoSustainedMonotonicGrowth(shortLivedSamples(12) { LsNode(it) })
    }

    /**
     * LS-A07
     * Scenario: monotonic growth detector.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a07_monotonicGrowthDetector() {
        assertNoSustainedMonotonicGrowth(listOf(10, 11, 9, 12, 8, 8, 9))
    }

    /**
     * LS-A08
     * Scenario: spike recovery detector.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a08_spikeRecoveryDetector() {
        assertSpikeRecovered(100, 500, 160)
    }

    /**
     * LS-A09
     * Scenario: sweptCount activity detector.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a09_sweptcountActivityDetector() {
        shortLivedSamples(8) { LsNode(it) }
        assertTrue(sweptCount() >= 0)
    }

    /**
     * LS-A10
     * Scenario: report data completeness.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_a10_reportDataCompleteness() {
        val report = mapOf("case" to "LS-A10", "heap" to heapAfterBytes().toString())
        assertEquals("LS-A10", report["case"])
        assertNotNull(report["heap"])
    }

}
