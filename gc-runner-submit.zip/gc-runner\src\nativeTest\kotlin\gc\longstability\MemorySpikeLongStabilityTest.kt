@file:OptIn(
    kotlin.experimental.ExperimentalNativeApi::class,
    kotlin.native.runtime.NativeRuntimeApi::class
)

package gc.longstability

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * LS-E group: memory spike and pressure long-stability tests.
 */
class MemorySpikeLongStabilityTest : LongStabilityTestSupport() {

    /**
     * LS-E01
     * Scenario: small memory spike loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e01_smallMemorySpikeLoop() {
        val spike = spikeLoop { allocateSmallBatch(512).toMutableList<Any>() }
        assertSpikeRecovered(spike.first, spike.second, spike.third)
    }

    /**
     * LS-E02
     * Scenario: large memory spike loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e02_largeMemorySpikeLoop() {
        val spike = spikeLoop { allocateLargeBatch(4, MEDIUM_BYTES).toMutableList<Any>() }
        assertSpikeRecovered(spike.first, spike.second, spike.third)
    }

    /**
     * LS-E03
     * Scenario: mixed memory spike loop.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e03_mixedMemorySpikeLoop() {
        val spike = spikeLoop { allocateMixedBatch().toMutableList<Any>() }
        assertSpikeRecovered(spike.first, spike.second, spike.third)
    }

    /**
     * LS-E04
     * Scenario: spike idle recovery.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e04_spikeIdleRecovery() {
        val spike = spikeLoop { allocateLargeBatch(4, MEDIUM_BYTES).toMutableList<Any>() }
        forceGc(8)
        assertSpikeRecovered(spike.first, spike.second, spike.third)
    }

    /**
     * LS-E05
     * Scenario: spike with long-lived root.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e05_spikeWithLongLivedRoot() {
        val root = LargePayload(5, ByteArray(MEDIUM_BYTES))
        val weak = WeakReference(root)
        val spike = spikeLoop { allocateMixedBatch().toMutableList<Any>() }
        assertNotNull(weak.value)
        assertSpikeRecovered(spike.first, spike.second, spike.third)
        assertEquals(5, root.id)
    }

    /**
     * LS-E06
     * Scenario: back-to-back spikes.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e06_backToBackSpikes() {
        val first = spikeLoop { allocateLargeBatch(2, MEDIUM_BYTES).toMutableList<Any>() }
        assertSpikeRecovered(first.first, first.second, first.third)
        val second = spikeLoop { allocateLargeBatch(2, MEDIUM_BYTES).toMutableList<Any>() }
        assertSpikeRecovered(second.first, second.second, second.third)
    }

    /**
     * LS-E07
     * Scenario: delayed release spike.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e07_delayedReleaseSpike() {
        val roots = allocateLargeBatch(4, MEDIUM_BYTES).toMutableList<Any>()
        forceGc()
        val before = heapAfterBytes()
        roots.clear()
        forceGc(8)
        val after = heapAfterBytes()
        assertTrue(after <= before, "Expected heap after delayed release to be <= heap before.")
    }

    /**
     * LS-E08
     * Scenario: random-like spike pattern.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e08_randomLikeSpikePattern() {
        val samples = mutableListOf<Long>()
        repeat(8) { i ->
            val roots =
                if (i % 3 == 0) allocateLargeBatch(3, MEDIUM_BYTES).toMutableList<Any>()
                else allocateSmallBatch(256).toMutableList<Any>()
            roots.clear()
            forceGc()
            samples.add(heapAfterBytes())
        }
        assertNoSustainedMonotonicGrowth(samples)
        assertSpikeRecovered(samples.first(), samples.maxOrNull() ?: samples.first(), samples.last())
    }

    /**
     * LS-E09
     * Scenario: pressure without manual GC.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e09_pressureWithoutManualGc() {
        repeat(8) {
            allocateLargeBatch(2, MEDIUM_BYTES)
        }
        val after = heapAfterBytes()
        assertSpikeRecovered(after, after, after)
    }

    /**
     * LS-E10
     * Scenario: pressure with periodic GC.
     * Expectation: the workload completes, GC metrics remain readable, and lifecycle/trend assertions hold.
     */
    @Test
    fun ls_e10_pressureWithPeriodicGc() {
        val samples = containerSamples(16) { i ->
            allocateLargeBatch(2, MEDIUM_BYTES)
            if (i % 2 == 0) {
                forceGc()
            }
        }
        assertNoSustainedMonotonicGrowth(samples)
        assertSpikeRecovered(samples.first(), samples.maxOrNull() ?: samples.first(), samples.last())
    }

}
