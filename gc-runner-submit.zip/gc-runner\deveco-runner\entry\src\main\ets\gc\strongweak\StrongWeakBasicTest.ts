﻿// @ts-nocheck
import { WeakReferenceTestSupport, Payload, MarkerPayload, StrongHolder, WeakHolder, MixedHolder, Box, Root, DataWeakHolder, WeakOnlyResult, MixedWeakResult, ReplacementResult, Marker, globalPayload, globalAny, globalMarker, globalWeak, setGlobalPayload, ObjectStrongWeakHolder } from './WeakReferenceTestSupport';
import { WeakReference, GC } from '../concurrentmutator/ConcurrentGcTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

/**
 * WR-A group: basic strong-reference and WeakReference semantics.
 */
export class StrongWeakBasicTest extends WeakReferenceTestSupport {
    /**
     * WR-A01
     * Scenario: a local strong reference and a local WeakReference point to the same object.
     * Expectation: while the local strong reference is still used after GC, weak.value remains non-null.
     */
    wrA01_localStrongKeepsWeakTargetAlive() {
        const obj = new Payload(101);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(101, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * WR-A02
     * Scenario: a holder field strongly references an object.
     * Expectation: the object remains alive through holder.ref.
     */
    wrA02_holderStrongKeepsWeakTargetAlive() {
        const obj = new Payload(102);
        const holder = new StrongHolder(obj);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(102, holder.ref.id);
        assertNotNull(weak.value);
    }
    private setGlobalStrongAndWeak(): WeakReference<Payload> {
        const obj = new Payload(103);
        setGlobalPayload(obj);
        return new WeakReference(obj);
    }
    /**
     * WR-A03
     * Scenario: a global variable strongly references an object.
     * Expectation: the object remains alive through the global root.
     */
    wrA03_globalStrongKeepsWeakTargetAlive() {
        const weak = this.setGlobalStrongAndWeak();
        this.forceGc();
        assertEquals(103, globalPayload.id);
        assertNotNull(weak.value);
    }
    /**
     * WR-A04
     * Scenario: a collection strongly references an object.
     * Expectation: the object remains alive through the collection element.
     */
    wrA04_collectionStrongKeepsWeakTargetAlive() {
        const obj = new Payload(104);
        const list = [obj];
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(104, list.single().id);
        assertNotNull(weak.value);
    }
    /**
     * WR-A05
     * Scenario: an array slot strongly references an object.
     * Expectation: the object remains alive through the array element.
     */
    wrA05_arrayStrongKeepsWeakTargetAlive() {
        const obj = new Payload(105);
        const array = new Array(1).fill(null);
        array[0] = obj;
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(105, array[0].id);
        assertNotNull(weak.value);
    }
    /**
     * WR-A06
     * Scenario: a lambda strongly captures an object.
     * Expectation: the captured object remains alive through the lambda object.
     */
    wrA06_lambdaStrongCaptureKeepsWeakTargetAlive() {
        const obj = new Payload(106);
        const weak = new WeakReference(obj);
        const block = () => obj.id;
        this.forceGc();
        assertEquals(106, block());
        assertNotNull(weak.value);
    }
    /**
     * WR-A07
     * Scenario: local strong reference and local WeakReference coexist.
     * Expectation: the strong reference determines liveness; weak.value remains non-null.
     */
    wrA07_localStrongAndWeakCoexistKeepsTargetAlive() {
        const obj = new Payload(107);
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(107, obj.id);
        assertNotNull(weak.value);
    }
    /**
     * WR-A08
     * Scenario: a holder has both strong and weak fields pointing to the same object.
     * Expectation: the strong field keeps the object alive and the weak field remains non-null.
     */
    wrA08_holderStrongAndWeakCoexistKeepsTargetAlive() {
        const obj = new Payload(108);
        const holder = new MixedHolder(obj, new WeakReference(obj));
        this.forceGc();
        assertEquals(108, holder.strong.id);
        assertNotNull(holder.weak.value);
    }
    /**
     * WR-A09
     * Scenario: a list strongly holds an object and another list holds a weak reference to it.
     * Expectation: the strong list keeps the object alive.
     */
    wrA09_collectionStrongAndWeakCoexistKeepsTargetAlive() {
        const obj = new Payload(109);
        const strongList = [obj];
        const weakList = [new WeakReference(obj)];
        this.forceGc();
        assertEquals(109, strongList.single().id);
        assertNotNull(weakList.single().value);
    }
    /**
     * WR-A10
     * Scenario: local, holder and list strong references coexist with a weak reference.
     * Expectation: as long as at least one strong reference remains, weak.value remains non-null.
     */
    wrA10_multipleStrongReferencesAndWeakKeepsTargetAlive() {
        const obj = new Payload(110);
        const holder = new StrongHolder(obj);
        const list = [obj];
        const weak = new WeakReference(obj);
        this.forceGc();
        assertEquals(110, obj.id);
        assertEquals(110, holder.ref.id);
        assertEquals(110, list.single().id);
        assertNotNull(weak.value);
    }
}


