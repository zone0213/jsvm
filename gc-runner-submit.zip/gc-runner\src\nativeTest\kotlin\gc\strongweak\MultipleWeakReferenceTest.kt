@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * WR-F group: multiple and batch WeakReference tests.
 */
class MultipleWeakReferenceTest : WeakReferenceTestSupport() {

    private fun createTwoWeaksSameTarget(): List<WeakReference<Payload>> {
        val obj = Payload(601)
        return listOf(WeakReference(obj), WeakReference(obj))
    }

    /**
     * WR-F01
     * Scenario: two WeakReferences point to the same target with no strong reference.
     * Expectation: both weak values are cleared.
     */
    @Test
    fun wrF01_twoWeaksSameTargetWithoutStrongAreCleared() {
        val weaks = createTwoWeaksSameTarget()

        assertAllWeakCollected(weaks)
    }

    private fun createThreeWeaksSameTarget(): List<WeakReference<Payload>> {
        val obj = Payload(602)
        return listOf(WeakReference(obj), WeakReference(obj), WeakReference(obj))
    }

    /**
     * WR-F02
     * Scenario: three WeakReferences point to the same target with no strong reference.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF02_threeWeaksSameTargetWithoutStrongAreCleared() {
        val weaks = createThreeWeaksSameTarget()

        assertAllWeakCollected(weaks)
    }

    private fun createHundredWeaksSameTarget(): List<WeakReference<Payload>> {
        val obj = Payload(603)
        return List(100) { WeakReference(obj) }
    }

    /**
     * WR-F03
     * Scenario: one hundred WeakReferences point to the same target with no strong reference.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF03_hundredWeaksSameTargetWithoutStrongAreCleared() {
        val weaks = createHundredWeaksSameTarget()

        assertAllWeakCollected(weaks)
    }

    /**
     * WR-F04
     * Scenario: one hundred WeakReferences point to the same strongly reachable target.
     * Expectation: all weak values remain non-null.
     */
    @Test
    fun wrF04_hundredWeaksSameStrongReachableTargetRemainAlive() {
        val obj = Payload(604)
        val weaks = List(100) { WeakReference(obj) }

        forceGc()

        assertEquals(604, obj.id)
        assertAllWeakAlive(weaks)
    }

    private fun createHundredObjectsEachWeakOnly(): List<WeakReference<Payload>> {
        val objects = List(100) { index -> Payload(60500 + index) }
        return objects.map { WeakReference(it) }
    }

    /**
     * WR-F05
     * Scenario: one hundred objects each have one WeakReference and no strong reference escapes.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF05_manyObjectsEachWeakOnlyAreCollected() {
        val weaks = createHundredObjectsEachWeakOnly()

        assertAllWeakCollected(weaks)
    }

    private fun createPartialStrongReachability(): MixedWeakResult<MutableList<Payload>, Payload> {
        val strongObjects = mutableListOf<Payload>()
        val aliveWeaks = mutableListOf<WeakReference<Payload>>()
        val collectedWeaks = mutableListOf<WeakReference<Payload>>()

        for (index in 0 until 100) {
            val obj = Payload(60600 + index)
            val weak = WeakReference(obj)
            if (index % 2 == 0) {
                strongObjects.add(obj)
                aliveWeaks.add(weak)
            } else {
                collectedWeaks.add(weak)
            }
        }

        return MixedWeakResult(strongObjects, aliveWeaks, collectedWeaks)
    }

    /**
     * WR-F06
     * Scenario: even-indexed objects are strongly reachable; odd-indexed objects are weak-only.
     * Expectation: even weak values survive, odd weak values are cleared.
     */
    @Test
    fun wrF06_batchWeakReferencesDistinguishStrongReachableAndWeakOnlyTargets() {
        val scenario = createPartialStrongReachability()

        forceGc()

        assertEquals(50, scenario.root.size)
        assertAllWeakAlive(scenario.aliveWeaks)
        assertAllWeakCollected(scenario.collectedWeaks)
    }

    private fun createAfterReleasingHalfStrongReferences(): MixedWeakResult<MutableList<Payload>, Payload> {
        return createPartialStrongReachability()
    }

    /**
     * WR-F07
     * Scenario: a batch initially creates many objects, but only half remain strongly reachable.
     * Expectation: strongly reachable half survives; weak-only half is cleared.
     */
    @Test
    fun wrF07_releasingHalfStrongReferencesClearsOnlyThatHalf() {
        val scenario = createAfterReleasingHalfStrongReferences()

        forceGc()

        assertEquals(50, scenario.root.size)
        assertAllWeakAlive(scenario.aliveWeaks)
        assertAllWeakCollected(scenario.collectedWeaks)
    }

    private fun createWeakListWithRepeatedSameTarget(): List<WeakReference<Payload>> {
        val obj = Payload(608)
        return MutableList(20) { WeakReference(obj) }
    }

    /**
     * WR-F08
     * Scenario: a list contains many WeakReferences to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF08_weakListRepeatedSameTargetWithoutStrongClearsAll() {
        val weaks = createWeakListWithRepeatedSameTarget()

        assertAllWeakCollected(weaks)
    }

    private fun createWeakMapValuesSameTarget(): Collection<WeakReference<Payload>> {
        val obj = Payload(609)
        val map = mutableMapOf<String, WeakReference<Payload>>()
        repeat(20) { index ->
            map["k$index"] = WeakReference(obj)
        }
        return map.values
    }

    /**
     * WR-F09
     * Scenario: a map contains many WeakReference values to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF09_weakMapValuesSameTargetWithoutStrongClearAll() {
        val weaks = createWeakMapValuesSameTarget()

        assertAllWeakCollected(weaks)
    }

    private fun createWeakArraySameTarget(): List<WeakReference<Payload>> {
        val obj = Payload(610)
        val array = Array(20) { WeakReference(obj) }
        return array.toList()
    }

    /**
     * WR-F10
     * Scenario: an array contains many WeakReferences to the same weak-only target.
     * Expectation: all weak values are cleared.
     */
    @Test
    fun wrF10_weakArraySameTargetWithoutStrongClearAll() {
        val weaks = createWeakArraySameTarget()

        assertAllWeakCollected(weaks)
    }
}
