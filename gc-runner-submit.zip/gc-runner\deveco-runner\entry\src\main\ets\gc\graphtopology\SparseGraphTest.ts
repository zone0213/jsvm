﻿import { GraphTopologyTestSupport, GraphRoot, GraphNode, MultiNode, ArrayNode, MapNode, SetNode, RootedWeaks, MixedWeaks, ReplacementWeaks, WeakReference } from './GraphTopologyTestSupport';
import { assertEquals, assertNotNull, assertNull, assertTrue } from '../TestAssertions';

class MultiRootScenario {
    constructor(
        public rootA: GraphRoot<GraphNode>,
        public rootB: GraphRoot<GraphNode>,
        public aliveWeaks: WeakReference<GraphNode>[],
        public collectedWeaks: WeakReference<GraphNode>[]
    ) {}
}

/** GT-G group: sparse graph and disconnected-component tests. */
export class SparseGraphTest extends GraphTopologyTestSupport {

    private buildCycle(size: number, startId: number): GraphNode[] {
        const nodes = Array.from({ length: size }, (_, index) => new GraphNode(startId + index));
        for (let index = 0; index < nodes.length; index++) nodes[index].next = nodes[(index + 1) % nodes.length];
        return nodes;
    }

    private reachableChainAndUnreachableChain(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const reachable = this.buildGraphNodeChain(3, 12000);
        const unreachable = this.buildGraphNodeChain(3, 12100);
        return new MixedWeaks(new GraphRoot(reachable.first()), this.weakRefs(reachable), this.weakRefs(unreachable));
    }

    /** GT-G01: one reachable chain and one unreachable chain are handled independently. */
    gtG01_reachableChainAndUnreachableChainAreDistinguished() {
        const scenario = this.reachableChainAndUnreachableChain();
        this.forceGc();
        assertEquals(12002, scenario.aliveWeaks.last().value!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private reachableTreeAndUnreachableTree(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const reachable = this.buildFullBinaryTree(3, 12200);
        const unreachable = this.buildFullBinaryTree(3, 12300);
        return new MixedWeaks(new GraphRoot(reachable.first()), this.weakRefs(reachable), this.weakRefs(unreachable));
    }

    /** GT-G02: one reachable tree and one unreachable tree are handled independently. */
    gtG02_reachableTreeAndUnreachableTreeAreDistinguished() {
        const scenario = this.reachableTreeAndUnreachableTree();
        this.forceGc();
        assertEquals(12206, scenario.aliveWeaks.last().value!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private reachableChainAndUnreachableCycle(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const reachable = this.buildGraphNodeChain(3, 12400);
        const unreachableCycle = this.buildCycle(3, 12500);
        return new MixedWeaks(new GraphRoot(reachable.first()), this.weakRefs(reachable), this.weakRefs(unreachableCycle));
    }

    /** GT-G03: a reachable chain and an unreachable cycle are handled independently. */
    gtG03_reachableChainAndUnreachableCycleAreDistinguished() {
        const scenario = this.reachableChainAndUnreachableCycle();
        this.forceGc();
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private multipleRootsScenario(): MultiRootScenario {
        const componentA = this.buildGraphNodeChain(2, 12600);
        const componentB = this.buildGraphNodeChain(2, 12700);
        const componentC = this.buildGraphNodeChain(2, 12800);
        return new MultiRootScenario(new GraphRoot(componentA.first()), new GraphRoot(componentB.first()), this.weakRefs([...componentA, ...componentB]), this.weakRefs(componentC));
    }

    /** GT-G04: multiple roots keep multiple components alive while an unrooted component is collected. */
    gtG04_multipleRootsKeepMultipleComponentsAlive() {
        const scenario = this.multipleRootsScenario();
        this.forceGc();
        assertEquals(12600, scenario.rootA.ref!.id);
        assertEquals(12700, scenario.rootB.ref!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private afterClearingOneOfTwoRoots(): MultiRootScenario {
        const componentA = this.buildGraphNodeChain(2, 12900);
        const componentB = this.buildGraphNodeChain(2, 13000);
        const rootA = new GraphRoot(componentA.first());
        const rootB = new GraphRoot(componentB.first());
        const collected = this.weakRefs(componentA);
        const alive = this.weakRefs(componentB);
        rootA.ref = null;
        return new MultiRootScenario(rootA, rootB, alive, collected);
    }

    /** GT-G05: clearing one root collects only its component while another root keeps its component alive. */
    gtG05_clearingOneRootCollectsOnlyThatComponent() {
        const scenario = this.afterClearingOneOfTwoRoots();
        assertNull(scenario.rootA.ref);
        assertEquals(13000, scenario.rootB.ref!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private afterClearingAllRoots(): MultiRootScenario {
        const componentA = this.buildGraphNodeChain(2, 13100);
        const componentB = this.buildGraphNodeChain(2, 13200);
        const rootA = new GraphRoot(componentA.first());
        const rootB = new GraphRoot(componentB.first());
        const weaks = this.weakRefs([...componentA, ...componentB]);
        rootA.ref = null;
        rootB.ref = null;
        return new MultiRootScenario(rootA, rootB, [], weaks);
    }

    /** GT-G06: clearing all roots allows all previously rooted components to be collected. */
    gtG06_clearingAllRootsCollectsAllComponents() {
        const scenario = this.afterClearingAllRoots();
        assertNull(scenario.rootA.ref);
        assertNull(scenario.rootB.ref);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private weakOnlyIsolatedNodes(count: number): WeakReference<GraphNode>[] {
        const nodes = Array.from({ length: count }, (_, index) => new GraphNode(13300 + index));
        return this.weakRefs(nodes);
    }

    /** GT-G07: 100 isolated nodes with only WeakReferences can be collected. */
    gtG07_hundredWeakOnlyIsolatedNodesCanBeCollected() {
        this.assertAllCollected(this.weakOnlyIsolatedNodes(100));
    }

    private oneOfHundredComponentsRooted(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const components = Array.from({ length: 100 }, (_, index) => this.buildGraphNodeChain(2, 14000 + index * 10));
        const rooted = components[42];
        const unrooted = components.filter((_, index) => index != 42).flat();
        return new MixedWeaks(new GraphRoot(rooted.first()), this.weakRefs(rooted), this.weakRefs(unrooted));
    }

    /** GT-G08: among 100 components, only the rooted component remains alive. */
    gtG08_onlyOneOfHundredComponentsIsKeptAlive() {
        const scenario = this.oneOfHundredComponentsRooted();
        this.forceGc();
        assertEquals(14420, scenario.root.ref!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private sparseSegmentedChains(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const segmentA = this.buildGraphNodeChain(50, 15000);
        const segmentB = this.buildGraphNodeChain(50, 15100);
        return new MixedWeaks(new GraphRoot(segmentA.first()), this.weakRefs(segmentA), this.weakRefs(segmentB));
    }

    /** GT-G09: a sparse big chain segment and an unrooted segment are handled independently. */
    gtG09_sparseSegmentedChainsKeepOnlyRootedSegmentAlive() {
        const scenario = this.sparseSegmentedChains();
        this.forceGc();
        assertEquals(15049, scenario.aliveWeaks.last().value!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    private forestPartialReachability(): MultiRootScenario {
        const treeA = this.buildFullBinaryTree(3, 15200);
        const treeB = this.buildFullBinaryTree(3, 15300);
        const treeC = this.buildFullBinaryTree(3, 15400);
        return new MultiRootScenario(new GraphRoot(treeA.first()), new GraphRoot(treeB.first()), this.weakRefs([...treeA, ...treeB]), this.weakRefs(treeC));
    }

    /** GT-G10: a forest with only some tree roots kept alive collects unrooted trees. */
    gtG10_forestKeepsReachableTreesAndCollectsUnreachableTrees() {
        const scenario = this.forestPartialReachability();
        this.forceGc();
        assertEquals(15200, scenario.rootA.ref!.id);
        assertEquals(15300, scenario.rootB.ref!.id);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }

    /** GT-G11: an initially orphan subgraph becomes alive after being attached to root. */
    gtG11_orphanSubgraphBecomesAliveAfterAttachment() {
        const rootNode = new GraphNode(15600);
        const orphan = this.buildGraphNodeChain(3, 15700);
        rootNode.next = orphan.first();
        const scenario = new RootedWeaks(new GraphRoot(rootNode), this.weakRefs([rootNode, ...orphan]));
        this.forceGc();
        assertEquals(15702, scenario.root.ref!.next!.next!.next!.id);
        this.assertAllAlive(scenario.weaks);
    }

    private attachedSubgraphAfterDisconnect(): MixedWeaks<GraphRoot<GraphNode>, GraphNode> {
        const rootNode = new GraphNode(15800);
        const orphan = this.buildGraphNodeChain(3, 15900);
        rootNode.next = orphan.first();
        const root = new GraphRoot(rootNode);
        rootNode.next = null;
        return new MixedWeaks(root, this.weakRefs([rootNode]), this.weakRefs(orphan));
    }

    /** GT-G12: after an attached subgraph is disconnected again, it can be collected. */
    gtG12_attachedSubgraphCollectedAfterDisconnect() {
        const scenario = this.attachedSubgraphAfterDisconnect();
        assertNull(scenario.root.ref!.next);
        this.assertAllAlive(scenario.aliveWeaks);
        this.assertAllCollected(scenario.collectedWeaks);
    }
}
