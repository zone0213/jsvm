@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-H group: type-shape, generic, nullable and lambda combinations.
 */
class WeakTypeShapeTest : WeakReferenceTestSupport() {

    private fun createConcreteWeakOnly(): WeakReference<Payload> {
        val obj = Payload(801)
        return WeakReference(obj)
    }

    /**
     * WR-H01
     * Scenario: WeakReference<Payload> is the only escaping reference.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH01_concreteWeakOnlyCanBeCollected() {
        val weak = createConcreteWeakOnly()

        assertWeakCollected(weak)
    }

    private fun createAnyWeakOnly(): WeakReference<Any> {
        val obj: Any = Payload(802)
        return WeakReference(obj)
    }

    /**
     * WR-H02
     * Scenario: WeakReference<Any> points to Payload runtime object.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH02_anyTypedWeakOnlyCanBeCollected() {
        val weak = createAnyWeakOnly()

        assertWeakCollected(weak)
    }

    private fun createMarkerWeakOnly(): WeakReference<Marker> {
        val obj: Marker = MarkerPayload(803)
        return WeakReference(obj)
    }

    /**
     * WR-H03
     * Scenario: WeakReference<Marker> points to interface-typed object.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH03_interfaceTypedWeakOnlyCanBeCollected() {
        val weak = createMarkerWeakOnly()

        assertWeakCollected(weak)
    }

    private fun createWeakBoxOnly(): WeakReference<Box<Payload>> {
        val box = Box(Payload(804))
        return WeakReference(box)
    }

    /**
     * WR-H04
     * Scenario: WeakReference<Box<Payload>> is the only escaping reference to the box.
     * Expectation: box and its contained payload can be collected.
     */
    @Test
    fun wrH04_weakBoxOnlyCanBeCollected() {
        val weak = createWeakBoxOnly()

        assertWeakCollected(weak)
    }

    private fun createStrongBoxWithPayload(): WeakOnlyResult<Box<Payload>, Payload> {
        val obj = Payload(805)
        val box = Box(obj)
        val weak = WeakReference(obj)
        return WeakOnlyResult(box, weak)
    }

    /**
     * WR-H05
     * Scenario: a strong Box holds Payload while WeakReference observes Payload.
     * Expectation: payload remains alive through Box.value.
     */
    @Test
    fun wrH05_strongBoxPayloadKeepsWeakTargetAlive() {
        val scenario = createStrongBoxWithPayload()

        forceGc()

        assertEquals(805, scenario.root.value!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createBoxAfterClear(): WeakOnlyResult<Box<Payload>, Payload> {
        val obj = Payload(806)
        val box = Box(obj)
        val weak = WeakReference(obj)
        box.value = null
        return WeakOnlyResult(box, weak)
    }

    /**
     * WR-H06
     * Scenario: Box.value is cleared.
     * Expectation: payload can be collected.
     */
    @Test
    fun wrH06_clearingBoxValueClearsWeak() {
        val scenario = createBoxAfterClear()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root.value)
    }

    /**
     * WR-H07
     * Scenario: nullable strong variable is non-null and WeakReference observes it.
     * Expectation: target remains alive while nullable strong reference is used.
     */
    @Test
    fun wrH07_nullableStrongNonNullKeepsWeakTargetAlive() {
        val obj: Payload? = Payload(807)
        val weak = WeakReference(obj!!)

        forceGc()

        assertEquals(807, obj.id)
        assertNotNull(weak.value)
    }

    private fun createAfterNullableStrongNull(): WeakReference<Payload> {
        var obj: Payload? = Payload(808)
        val weak = WeakReference(obj!!)
        obj = null
        assertNull(obj)
        return weak
    }

    /**
     * WR-H08
     * Scenario: nullable strong reference is set to null.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH08_nullableStrongSetNullClearsWeak() {
        val weak = createAfterNullableStrongNull()

        assertWeakCollected(weak)
    }

    private fun createGenericWeakHolderOnly(): WeakOnlyResult<WeakHolder<Payload>, Payload> {
        val obj = Payload(809)
        val weak = WeakReference(obj)
        return WeakOnlyResult(WeakHolder(weak), weak)
    }

    /**
     * WR-H09
     * Scenario: generic WeakHolder<Payload> holds WeakReference only.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH09_genericWeakHolderOnlyDoesNotKeepTargetAlive() {
        val scenario = createGenericWeakHolderOnly()

        forceGc()

        assertNotNull(scenario.root.weak)
        assertNull(scenario.weak.value)
    }

    /**
     * WR-H10
     * Scenario: generic MixedHolder<Payload> holds both strong and weak references to target.
     * Expectation: target remains alive through MixedHolder.strong.
     */
    @Test
    fun wrH10_genericMixedHolderStrongAndWeakKeepsTargetAlive() {
        val obj = Payload(810)
        val holder = MixedHolder(obj, WeakReference(obj))

        forceGc()

        assertEquals(810, holder.strong!!.id)
        assertNotNull(holder.weak!!.value)
    }

    /**
     * WR-H11
     * Scenario: lambda strongly captures target.
     * Expectation: target remains alive through lambda capture.
     */
    @Test
    fun wrH11_lambdaStrongCaptureKeepsTargetAlive() {
        val obj = Payload(811)
        val weak = WeakReference(obj)
        val block = { obj.id }

        forceGc()

        assertEquals(811, block())
        assertNotNull(weak.value)
    }

    private fun createLambdaWeakCaptureOnly(): WeakOnlyResult<Root<() -> Int?>, Payload> {
        val obj = Payload(812)
        val weak = WeakReference(obj)
        val block = { weak.value?.id }
        return WeakOnlyResult(Root(block), weak)
    }

    /**
     * WR-H12
     * Scenario: lambda captures WeakReference but not the target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH12_lambdaWeakCaptureOnlyDoesNotKeepTargetAlive() {
        val scenario = createLambdaWeakCaptureOnly()

        forceGc()

        assertNull(scenario.root.ref!!())
        assertNull(scenario.weak.value)
    }

    private fun createNestedLambdaWeakCaptureOnly(): WeakOnlyResult<Root<() -> (() -> Int?)>, Payload> {
        val obj = Payload(813)
        val weak = WeakReference(obj)
        val outer = { { weak.value?.id } }
        return WeakOnlyResult(Root(outer), weak)
    }

    /**
     * WR-H13
     * Scenario: nested lambdas capture WeakReference but not the target.
     * Expectation: target can be collected.
     */
    @Test
    fun wrH13_nestedLambdaWeakCaptureOnlyDoesNotKeepTargetAlive() {
        val scenario = createNestedLambdaWeakCaptureOnly()

        forceGc()

        val inner = scenario.root.ref!!()
        assertNull(inner())
        assertNull(scenario.weak.value)
    }

    private fun passWeakReferenceOnly(weak: WeakReference<Payload>): WeakReference<Payload> = weak

    private fun createFunctionParameterWeakOnly(): WeakReference<Payload> {
        val obj = Payload(814)
        val weak = WeakReference(obj)
        return passWeakReferenceOnly(weak)
    }

    /**
     * WR-H14
     * Scenario: a helper receives and returns WeakReference without receiving target strongly.
     * Expectation: target can be collected after creator helper returns.
     */
    @Test
    fun wrH14_functionParameterWeakOnlyDoesNotKeepTargetAlive() {
        val weak = createFunctionParameterWeakOnly()

        assertWeakCollected(weak)
    }
}
