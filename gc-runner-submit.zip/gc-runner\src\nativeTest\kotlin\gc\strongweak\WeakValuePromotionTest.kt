@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class)

package gc.strongweak

import kotlin.native.ref.WeakReference
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/**
 * WR-G group: WeakReference.value access and promotion to strong references.
 */
class WeakValuePromotionTest : WeakReferenceTestSupport() {

    /**
     * WR-G01
     * Scenario: strong reference exists and weak.value is read.
     * Expectation: weak.value returns a non-null object.
     */
    @Test
    fun wrG01_readWeakValueWhileStrongExistsReturnsNonNull() {
        val obj = Payload(701)
        val weak = WeakReference(obj)

        forceGc()

        assertEquals(701, weak.value!!.id)
        assertEquals(701, obj.id)
    }

    private fun createWeakOnlyForPostGcRead(): WeakReference<Payload> {
        val obj = Payload(702)
        return WeakReference(obj)
    }

    /**
     * WR-G02
     * Scenario: only WeakReference remains and GC runs before weak.value is read.
     * Expectation: weak.value returns null.
     */
    @Test
    fun wrG02_readWeakValueAfterTargetCollectedReturnsNull() {
        val weak = createWeakOnlyForPostGcRead()

        forceGc()

        assertNull(weak.value)
    }

    /**
     * WR-G03
     * Scenario: weak.value is saved into a local strong variable.
     * Expectation: the promoted local reference keeps target alive while used after GC.
     */
    @Test
    fun wrG03_weakValuePromotedToLocalStrongKeepsTargetAlive() {
        val obj = Payload(703)
        val weak = WeakReference(obj)
        val promoted = weak.value!!

        forceGc()

        assertEquals(703, promoted.id)
        assertNotNull(weak.value)
    }

    private fun createWeakAfterPromotionScopeEnds(): WeakReference<Payload> {
        val obj = Payload(704)
        val weak = WeakReference(obj)

        run {
            val promoted = weak.value!!
            assertEquals(704, promoted.id)
        }

        return weak
    }

    /**
     * WR-G04
     * Scenario: weak.value is promoted only inside helper scope.
     * Expectation: after helper returns, target can be collected.
     */
    @Test
    fun wrG04_promotedLocalLeavingScopeDoesNotKeepTargetAliveLongTerm() {
        val weak = createWeakAfterPromotionScopeEnds()

        assertWeakCollected(weak)
    }

    private fun createHolderPromotedFromWeakValue(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        val obj = Payload(705)
        val weak = WeakReference(obj)
        return WeakOnlyResult(StrongHolder(weak.value!!), weak)
    }

    /**
     * WR-G05
     * Scenario: weak.value is stored into a holder strong field.
     * Expectation: holder.ref keeps target alive.
     */
    @Test
    fun wrG05_weakValueStoredInHolderStrongFieldKeepsTargetAlive() {
        val scenario = createHolderPromotedFromWeakValue()

        forceGc()

        assertEquals(705, scenario.root.ref!!.id)
        assertNotNull(scenario.weak.value)
    }

    private fun createAfterClearingPromotedHolder(): WeakOnlyResult<StrongHolder<Payload>, Payload> {
        val obj = Payload(706)
        val weak = WeakReference(obj)
        val holder = StrongHolder(weak.value!!)
        holder.ref = null
        return WeakOnlyResult(holder, weak)
    }

    /**
     * WR-G06
     * Scenario: weak.value was stored into holder strong field, then holder field is cleared.
     * Expectation: target can be collected.
     */
    @Test
    fun wrG06_clearingHolderPromotedStrongClearsWeak() {
        val scenario = createAfterClearingPromotedHolder()

        assertWeakCollected(scenario.weak)
        assertNull(scenario.root.ref)
    }

    private fun createListPromotedFromWeakValue(): WeakOnlyResult<MutableList<Payload>, Payload> {
        val obj = Payload(707)
        val weak = WeakReference(obj)
        return WeakOnlyResult(mutableListOf(weak.value!!), weak)
    }

    /**
     * WR-G07
     * Scenario: weak.value is stored into a list.
     * Expectation: the list strongly keeps target alive.
     */
    @Test
    fun wrG07_weakValueStoredInListKeepsTargetAlive() {
        val scenario = createListPromotedFromWeakValue()

        forceGc()

        assertEquals(707, scenario.root.single().id)
        assertNotNull(scenario.weak.value)
    }

    private fun createAfterClearingPromotedList(): WeakOnlyResult<MutableList<Payload>, Payload> {
        val obj = Payload(708)
        val weak = WeakReference(obj)
        val list = mutableListOf(weak.value!!)
        list.clear()
        return WeakOnlyResult(list, weak)
    }

    /**
     * WR-G08
     * Scenario: weak.value was stored into list, then list is cleared.
     * Expectation: target can be collected.
     */
    @Test
    fun wrG08_clearingListPromotedStrongClearsWeak() {
        val scenario = createAfterClearingPromotedList()

        assertWeakCollected(scenario.weak)
        assertEquals(0, scenario.root.size)
    }

    private fun createWeakAfterReadOnlyAccess(): WeakReference<Payload> {
        val obj = Payload(709)
        val weak = WeakReference(obj)
        val id = weak.value?.id
        assertEquals(709, id)
        return weak
    }

    /**
     * WR-G09
     * Scenario: weak.value is read for a property and not stored as a long-lived strong reference.
     * Expectation: after helper returns, target can be collected.
     */
    @Test
    fun wrG09_readOnlyWeakValueAccessDoesNotKeepTargetAliveLongTerm() {
        val weak = createWeakAfterReadOnlyAccess()

        assertWeakCollected(weak)
    }

    private fun createLambdaReadingWeakValue(): WeakOnlyResult<Root<() -> Int?>, Payload> {
        val obj = Payload(710)
        val weak = WeakReference(obj)
        val block = { weak.value?.id }
        return WeakOnlyResult(Root(block), weak)
    }

    /**
     * WR-G10
     * Scenario: lambda captures WeakReference and reads weak.value when invoked.
     * Expectation: target is not strongly captured and can be collected.
     */
    @Test
    fun wrG10_lambdaReadingWeakValueDoesNotCaptureTargetStrongly() {
        val scenario = createLambdaReadingWeakValue()

        forceGc()

        assertNull(scenario.root.ref!!())
        assertNull(scenario.weak.value)
    }

    private fun createLambdaWithTemporaryPromotion(): WeakOnlyResult<Root<() -> Int?>, Payload> {
        val obj = Payload(711)
        val weak = WeakReference(obj)
        val block = {
            val promoted = weak.value
            promoted?.id
        }
        return WeakOnlyResult(Root(block), weak)
    }

    /**
     * WR-G11
     * Scenario: lambda temporarily promotes weak.value to a local variable inside invocation.
     * Expectation: this does not keep target alive after helper returns.
     */
    @Test
    fun wrG11_lambdaTemporaryPromotionDoesNotKeepTargetAliveLongTerm() {
        val scenario = createLambdaWithTemporaryPromotion()

        forceGc()

        assertNull(scenario.root.ref!!())
        assertNull(scenario.weak.value)
    }

    private fun createWeakAlreadyNull(): WeakReference<Payload> {
        val obj = Payload(712)
        return WeakReference(obj)
    }

    /**
     * WR-G12
     * Scenario: weak.value is read after target has already been collected.
     * Expectation: reading value returns null and does not crash.
     */
    @Test
    fun wrG12_promotingAlreadyClearedWeakValueReturnsNull() {
        val weak = createWeakAlreadyNull()

        forceGc()

        val promoted = weak.value
        assertNull(promoted)
    }
}
